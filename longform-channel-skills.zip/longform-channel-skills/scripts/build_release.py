#!/usr/bin/env python3
"""검토된 저장소 소스·자산을 SHA256 목록과 배포 ZIP으로 묶는다."""
from pathlib import Path
import hashlib
import zipfile

ROOT = Path(__file__).resolve().parents[1]
EXCLUDED = {'.git', '__pycache__', 'node_modules', '.venv', 'work', 'runs', 'cache'}


def sources():
    return sorted(p for p in ROOT.rglob('*') if p.is_file()
                  and not any(part in EXCLUDED for part in p.relative_to(ROOT).parts)
                  and p.name != '.DS_Store' and p.suffix != '.pyc'
                  and not (p.parent == ROOT and (p.suffix == '.zip' or p.name.endswith('.zip.sha256') or p.name == 'SHA256SUMS')))


def main():
    files = sources()
    digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
    (ROOT / 'SHA256SUMS').write_text(''.join(f'{digest(p)}  {p.relative_to(ROOT)}\n' for p in files))
    files.append(ROOT / 'SHA256SUMS')
    target = ROOT / 'longform-channel-skills.zip'
    with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path in files:
            archive.write(path, Path('longform-channel-skills') / path.relative_to(ROOT))
    with zipfile.ZipFile(target) as archive:
        assert archive.testzip() is None
    (ROOT / (target.name + '.sha256')).write_text(f'{digest(target)}  {target.name}\n')
    target = ROOT / 'longform-project-handoff.zip'
    base = ROOT / 'skills/longform-project-handoff'
    with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as archive:
        for path in files:
            if path.is_relative_to(base):
                archive.write(path, Path(base.name) / path.relative_to(base))
    print(f'{len(files)} files; bundle {(ROOT / "longform-channel-skills.zip").stat().st_size:,} bytes')


if __name__ == '__main__':
    main()
