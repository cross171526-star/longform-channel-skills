# 롱폼 클로너부터 본편·쇼츠 제작까지

2026-10-08 최신 통합본. 채널 도입, 테스트, 전용 스킬 작성, 새 제작 프로젝트 인계, 본편, 피드백, 관련 쇼츠 3편, 최종 파일 정리에 필요한 **15개 스킬과 실행 코드·기준 자산**을 포함합니다. `skills/` 소스를 직접 버전 관리하며 다운로드 ZIP도 같은 파일로 만듭니다.

## 전체 순서

채널 URL → 제목·메타데이터 → 주제 승인 → 최신 적격 영상 1편 정밀 분석 → 대본·TTS·묵음 제거 → 자료·편집·170~210초 테스트 → 피드백 → 채널 전용 스킬 작성 → 사용자가 새 제작 프로젝트에 파일 배치 → 그 프로젝트에서 **“인계해라”** → 주제·제목·썸네일 → 전체 본편 → 피드백·본편 확정 → **11번: 같은 핵심 주제 쇼츠 3편(A→I)** → 결과물 정리.

이미 지정·확정한 주제는 재선정하지 않습니다. 인계 요청으로 새 프로젝트를 자동 생성하지 않습니다. 자세한 절차는 [전체 제작 프로세스](production-workflow.md)를 읽습니다.

## 오늘 반영한 기준

- 주제는 핵심 사건이 일치하는 실제 영상 **한 편 이상 50만 조회수**를 확인해야 추천합니다. 제목·채널·링크·조회수·게시일·확인일과 일치 근거를 함께 남깁니다. 미확인·미달은 제외하며 추천 개수와 5분 목표 때문에 기준을 낮추지 않습니다.
- 채널 제목 문법에 맞는 추천 제목 3개와 썸네일 문구·파일명 대응을 유지합니다.
- 현재 4개 제작 채널의 최신 서사·자료·컷·제작 기준을 함께 제공합니다. 별별역사형은 문장마다 최소 한 배경 컷 기준과 계약 검사를 포함합니다.
- 공통 쇼츠는 **GRB v7** 렌더러, 서체, 예제 패널, 42개 기준 프레임, 효과음 25큐와 믹서를 포함합니다. 기존 스포츠 쇼츠 스킬은 참고 이력이며 충돌 시 공통 v7을 우선합니다.
- 납품 폴더에는 최종 이미지·설명글·최신 본편·편별 최신 쇼츠만 둡니다. 쇼츠 파일명은 `영상 제목.mp4`입니다. 대본·자막·코드·타임라인·검증 기록은 작업 폴더에 유지합니다.

## 포함 파일

| 단계 | 위치 |
|---|---|
| 운영·설치·폴더 관리 | `lfc.py`, `skills/longform-channel-workflow/` |
| 채널 도입과 분석·기획·제작·피드백 | `skills/longform-channel-cloner/` 및 analysis/planning/production/review |
| 새 프로젝트에서 인계 | `skills/longform-project-handoff/` |
| 스포츠몽땅형 본편 | `skills/sportsmongttang-longform/` |
| 별별역사형 본편·승인 v3 자산·Remotion | `skills/byeolbyeol-longform/` |
| 다큐스토리 844형 본편 | `skills/docustory-844-longform/` |
| 책트폭행 AI그림형 본편 | `skills/read-y-ai-longform/` |
| 관련 쇼츠 A→I·GRB v7 | `skills/longform-companion-shorts/` |
| 과거 스포츠 쇼츠 참고 | `skills/sportsmongttang-shorts/` |
| 최종 결과물 검사·휴지통 정리 | `skills/video-output-cleanup/` |
| 영상 다운로드·프레임·전사 | `skills/watch/` |

승인된 스포츠·다큐스토리 본편의 실제 렌더 구현도 [examples](examples/README.md)에 참고용으로 포함합니다.

## 설치

저장소를 clone하거나 [통합 ZIP](longform-channel-skills.zip)을 풀고 최상위 폴더에서 실행합니다.

```bash
python3 lfc.py install
```

`${CODEX_HOME:-$HOME/.codex}/skills`에 동봉 15개 스킬을 설치합니다. 기존 동일 파일은 유지하고, 내용이 다른 기존 스킬은 덮어쓰지 않고 중단합니다. 기존 변경을 별도 백업·비교한 뒤 필요한 것만 갱신하세요. 이 명령은 앱 모델·실행 중 채팅의 설정을 바꾸지 않습니다.

채널 전용 프로젝트에는 선택한 채널 스킬과 참조·scripts·assets를 함께 넣고, 공통 `longform-companion-shorts`, `video-output-cleanup`, `longform-project-handoff`도 연결합니다. 문서가 `.agents/skills/`를 가리키면 해당 폴더에 복사합니다. 받은 프로젝트에서 “인계해라”라고 요청하면 현재 자료를 읽고 AGENTS 연결과 의존성을 확인합니다. JSON 인계서를 미리 만들 필요는 없습니다.

## 제작 환경

제작 코드는 Python **3.12 이상**, Node **22 이상**, ffmpeg/ffprobe가 필요합니다. Apple Silicon 맥의 기존 준비 도구는 다음과 같습니다.

```bash
bash skills/longform-channel-cloner/scripts/setup_env.sh
bash skills/longform-channel-cloner/scripts/fetch_fonts.sh
npm ci --prefix skills/longform-channel-cloner/assets/remotion-template
"$HOME/.longform-cloner/venv/bin/python" lfc.py doctor
```

Intel 맥·다른 운영체제는 Python 가상환경과 `scripts/requirements.txt`, Node와 ffmpeg를 별도로 준비합니다. 위 설치 스크립트는 Apple Silicon용입니다. 프로젝트 모델 요구값은 `gpt-6.1-sol / high`이며 실제 사용 가능한 설정과 세션을 작업 기록에 남깁니다.

API 키는 본인 환경변수 또는 `~/.longform-cloner/secrets.env`로 설정합니다. 실제 값은 동봉하지 않습니다. TTS는 채널별 지정 공급자·목소리·배속을 따릅니다. `assets/fixed-bgm.json`의 `local_path`는 미연결 상태이므로 지정 음원을 확보해 실제 경로로 연결해야 합니다.

[외부 의존성 안내](DEPENDENCIES.md)에 미동봉 자료와 연결 방법을 정리했습니다. 이미지 생성 도구는 사용하는 Codex 환경에서 제공되어야 합니다. 폴더 생성·환경 검사 성공만으로 새 영상 제작이 완료된 것은 아닙니다.

## 선택 명령

새 폴더 생성을 직접 요청받은 경우에만 다음 도구를 사용할 수 있습니다. 기본 인계는 기존 새 제작 프로젝트에서 진행합니다.

```bash
python3 lfc.py cloner --dest /원하는/롱폼클로너
python3 lfc.py channel --name 스포츠몽땅형 --profile sportsmongttang --dest /원하는/스포츠몽땅형
python3 lfc.py video --project /원하는/스포츠몽땅형 --keyword 작품키워드 --title '영상 제목'
```

다른 채널의 선택 CLI 인계 형식은 [인계 참고](skills/longform-channel-workflow/references/handoff.md)에 있습니다. 기존 목적지를 덮어쓰지 않으며 실제 영상 생성 명령은 아닙니다.

## 검증과 공유 범위

[오늘 변경내역](변경내역.md), [검증 결과](release/validation.json), [원본 해시 목록](release/source-manifest.json)을 제공합니다. `SHA256SUMS`는 배포 소스와 자산, 별도 `.zip.sha256`은 ZIP을 검증합니다.

원본 작업 폴더·설치 스킬은 수정하지 않았습니다. API 키·쿠키·다운로드 원본 영상·완성 영상·개별 실행 로그·캐시·가상환경·node_modules는 포함하지 않습니다. 제작 기준에 실제 필요한 고정 자산과 예제는 포함하며 제3자 서체·효과음의 이용조건과 크레딧을 유지합니다. 새 컴퓨터 전체 환경 설치, 유료 TTS, 새 본편 전체 렌더는 이번 패키지 검증 범위가 아닙니다. 저장소의 공개 범위는 변경하지 않습니다.
