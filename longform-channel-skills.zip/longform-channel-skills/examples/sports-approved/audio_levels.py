from pathlib import Path
import subprocess,json,re,math
from concurrent.futures import ThreadPoolExecutor
P=Path(__file__).parent;FF='~/.longform-cloner/bin/ffmpeg';bgm='~/.longform-cloner/media/fixed-bgm/qcUy4duzHPI/loop-source.wav';dt=json.loads((P/'narration.json').read_text())['duration']
def one(q):
 n,p,g=q;cmd=[FF,'-hide_banner','-i',str(p),'-t',str(dt),'-af',f'volume={g},volumedetect','-f','null','-'];r=subprocess.run(cmd,capture_output=True,text=True);(P/f'{n}-levels.log').write_text(r.stderr);return n,{k:float(re.search(k+r': ([\-0-9.]+)',r.stderr)[1]) for k in ['mean_volume','max_volume']}
r=dict(ThreadPoolExecutor(max_workers=2).map(one,[('voice',P/'narration.wav',3),('music',bgm,.2)]));diff=r['voice']['mean_volume']-r['music']['mean_volume'];gain=.2*10**((diff-14)/20);r.update(initial_difference_db=diff,selected_voice_gain=3,selected_music_gain=round(gain,6),target_difference_db=14,master_peak_limit=.8912);(P/'audio_mix.json').write_text(json.dumps(r,indent=2));print(r)
