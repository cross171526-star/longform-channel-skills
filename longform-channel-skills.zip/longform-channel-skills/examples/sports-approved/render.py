import json,subprocess,math,time,sys,hashlib
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
P=Path(__file__).resolve().parent;A=P/'assets';C=P/'cuts';C.mkdir(exist_ok=True)
FF='~/.longform-cloner/bin/ffmpeg';T=json.loads((P/'timeline.json').read_text());fps=T['fps']
from reference_preflight import check
check(T)
def signature(c):
 keys=['kind','path','trim','source_crop','zoom','offset_y','film_opacity','transition','start_frame','end_frame','motion_curve','motion_interpolation','offset_x','pan_y','source_rate']
 spec={k:c.get(k) for k in keys};st=Path(c['path']).stat();spec['source_stamp']=[st.st_size,st.st_mtime_ns]
 index=int(c['id'][1:]);spec['next_transition']=T['cuts'][index+1]['transition'] if index+1<len(T['cuts']) else None
 spec['renderer']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
 return hashlib.sha256(json.dumps(spec,sort_keys=True).encode()).hexdigest()
def pan_expression(keys):
 # Seconds from this cut; smooth velocity at every keyframe, no abrupt jumps.
 expr=str(keys[-1][1])
 for (ta,ya),(tb,yb) in reversed(list(zip(keys,keys[1:]))):
  fa=ta*fps;fb=tb*fps;u=f'max(0,min((on-{fa})/{fb-fa},1))'
  val=f'({ya}+({yb-ya})*({u})*({u})*(3-2*({u})))'
  expr=f'if(lt(on,{fb}),{val},{expr})'
 return expr

def one(c):
 out=C/f"{c['id']}.mp4";log=C/f"{c['id']}.log"
 marker=C/f"{c['id']}.signature";sig=signature(c)
 if out.exists() and out.stat().st_size>10000 and marker.exists() and marker.read_text()==sig:return c['id']
 n=c['end_frame']-c['start_frame'];dt=n/fps;phase=(int(c['id'][1:])*3%12)/12
 cmd=[FF,'-hide_banner','-loglevel','error','-y','-threads','1']
 if c['kind']=='video':cmd+=['-ss',str(c['trim']),'-i',c['path']]
 else:cmd+=['-loop','1','-framerate',str(fps),'-i',c['path']]
 for texture in ['grain','scratch']:cmd+=['-stream_loop','-1','-ss',str(phase),'-i',str(A/f'{texture}.mkv')]
 z0,z1=c['zoom'];u=f'min(on/{max(1,n-1)},1)';zoom=f'({z0}+({z1}-{z0})*({u})*({u})*(3-2*({u})))';y=pan_expression(c['pan_y']) if c.get('pan_y') else c['offset_y'];x=c.get('offset_x',0);op=c['film_opacity']
 # Floating point source corners, no per-frame integer crop/resize steps.
 left=f'W/2-W/(2*{zoom})+{x}/{zoom}';right=f'W/2+W/(2*{zoom})+{x}/{zoom}';top=f'H/2-H/(2*{zoom})-{y}/{zoom}';bottom=f'H/2+H/(2*{zoom})-{y}/{zoom}'
 motion=f"perspective=x0='{left}':y0='{top}':x1='{right}':y1='{top}':x2='{left}':y2='{bottom}':x3='{right}':y3='{bottom}':sense=source:interpolation=cubic:eval=frame"
 crop=c.get("source_crop");cropfilter=("crop=%d:%d:%d:%d,"%(crop[2],crop[3],crop[0],crop[1])) if crop else ""
 vf=f"[0:v]{cropfilter}setpts=(PTS-STARTPTS)/{c.get("source_rate",1)},fps=30000/1001,scale=1920:1080:force_original_aspect_ratio=increase,crop=1920:1080,format=yuv444p,{motion},format=gbrp[b];[1:v]setpts=PTS-STARTPTS,format=gbrp[g];[2:v]setpts=PTS-STARTPTS,format=gbrp[s];[b][g]blend=all_mode=overlay:all_opacity={op}[bg];[bg][s]blend=all_mode=screen:all_opacity={__import__('production_contract').load()[0]['film']['scratch_opacity']},format=yuv420p"
 fx=[]
 if c['transition']=='blackdip':fx.append('fade=t=in:st=0:d=0.3335:color=black')
 elif c['transition']=='whiteflash':fx.append('fade=t=in:st=0:d=0.267:color=white')
 elif c['transition']=='fade':fx.append('fade=t=in:st=0:d=0.15:color=black')
 index=int(c['id'][1:]);nextc=T['cuts'][index+1] if index+1<len(T['cuts']) else None
 if nextc and nextc['transition']=='blackdip':fx.append(f'fade=t=out:st={max(0,dt-.3335)}:d=0.3335:color=black')
 if fx:vf+=','+','.join(fx)
 vf+='[out]'
 cmd+=['-filter_complex_threads','1','-filter_complex',vf,'-map','[out]','-frames:v',str(n),'-an','-c:v','h264_videotoolbox','-b:v','8M','-pix_fmt','yuv420p','-r','30000/1001',str(out)]
 with log.open('w') as f:r=subprocess.run(cmd,stderr=f)
 if r.returncode:raise RuntimeError(c['id']+log.read_text()[-1500:])
 marker.write_text(sig)
 return c['id']
if __name__=='__main__':
 cuts=T['cuts'];limit=int(sys.argv[1]) if len(sys.argv)>1 else None
 if limit:cuts=cuts[:limit]
 start=time.time()
 with ThreadPoolExecutor(max_workers=4) as pool:
  fs=[pool.submit(one,c) for c in cuts]
  for i,f in enumerate(as_completed(fs)):
   name=f.result();print(f'{i+1}/{len(cuts)} {name} elapsed {time.time()-start:.1f}s',flush=True)
 print('CUTS COMPLETE',flush=True)
