from pathlib import Path
import json,subprocess
P=Path(__file__).resolve().parent;T=json.loads((P/'timeline.json').read_text());M=json.loads((P/'delivery-v2.json').read_text())
from reference_preflight import check
from render import signature
check(T)
for c in T['cuts']:
 marker=P/'cuts'/f"{c['id']}.signature"
 if not marker.is_file() or marker.read_text()!=signature(c):raise RuntimeError(c['id']+': rerender required')
(P/'concat.txt').write_text(''.join("file '"+str(P/'normalized-cuts'/f"{c['id']}.mp4").replace("'","'\\''")+"'\n" for c in T['cuts']))
FF='~/.longform-cloner/bin/ffmpeg';bgm='~/.longform-cloner/media/fixed-bgm/qcUy4duzHPI/loop-source.wav';mix=json.loads((P/'audio_mix.json').read_text())
def run(args):subprocess.run([FF,'-hide_banner','-loglevel','warning','-y']+args,check=True)
# Normalize each decoded frame to the editorial frame clock before subtitle rendering.
# Keep narration out of the concat-demuxer pass: timestamp discontinuity handling
# in that pass had removed audio packets cumulatively from the delivered mix.
vf=f"setpts=N/(30000/1001*TB),ass='{P/'captions.ass'}':fontsdir='{P/'fonts'}'"
print('VIDEO ONLY',flush=True)
run(['-threads','2','-reinit_filter','0','-f','concat','-safe','0','-i',str(P/'concat.txt'),'-vf',vf,'-an','-frames:v',str(T['frames']),'-c:v','h264_videotoolbox','-b:v','8M','-pix_fmt','yuv420p','-r','30000/1001',str(P/'captioned-video.mp4')])
probe=json.loads(subprocess.check_output([FF.replace('ffmpeg','ffprobe'),'-v','error','-select_streams','v:0','-show_entries','stream=nb_frames,duration','-of','json',str(P/'captioned-video.mp4')]))['streams'][0]
assert int(probe['nb_frames'])==T['frames'],'Video frame count mismatch before mux'
assert abs(float(probe['duration'])-T['duration'])<.04,'Video duration mismatch before mux'
print('INDEPENDENT AUDIO MIX',flush=True)
filters=f"[0:a]volume={mix['selected_voice_gain']},aformat=sample_rates=48000:channel_layouts=stereo[n];[1:a]volume={mix['selected_music_gain']},aformat=sample_rates=48000:channel_layouts=stereo[b];[n][b]amix=inputs=2:duration=first:normalize=0,alimiter=limit=0.87:level=0:latency=1[a]"
run(['-i',str(P/'narration.wav'),'-stream_loop','-1','-i',bgm,'-filter_complex',filters,'-map','[a]','-c:a','pcm_s24le','-ar','48000',str(P/'final-mix.wav')])
print('MUX NORMALIZED VIDEO AND AUDIO',flush=True)
run(['-i',str(P/'captioned-video.mp4'),'-i',str(P/'final-mix.wav'),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','192k','-ar','48000','-t',str(T['duration']),'-movflags','+faststart',str(P/'complete.mp4')])
out=Path(M['output_dir'])/'03_영상완성본'/(M['selected_title']+'.mp4')
(P/'final_path.json').write_text(json.dumps({'work_file':str(P/'complete.mp4'),'delivery_file':str(out)},ensure_ascii=False,indent=2));print('FULL RENDER COMPLETE',flush=True)
