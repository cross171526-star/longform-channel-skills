from pathlib import Path
import subprocess,json
from concurrent.futures import ThreadPoolExecutor,as_completed
P=Path(__file__).resolve().parent;T=json.loads((P/'timeline.json').read_text());O=P/'normalized-cuts';O.mkdir(exist_ok=True);FF='~/.longform-cloner/bin/ffmpeg'
def one(c):
 src=P/'cuts'/(c['id']+'.mp4');dst=O/src.name
 subprocess.run([FF,'-hide_banner','-loglevel','error','-y','-threads','1','-i',str(src),'-vf','scale=in_range=auto:out_range=tv:out_color_matrix=bt709,format=yuv420p,setsar=1','-an','-c:v','h264_videotoolbox','-b:v','8M','-color_range','tv','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-r','30000/1001',str(dst)],check=True)
 j=json.loads(subprocess.check_output([FF.replace('ffmpeg','ffprobe'),'-v','error','-select_streams','v:0','-show_entries','stream=nb_frames,pix_fmt,color_range,color_space','-of','json',str(dst)]))['streams'][0]
 assert int(j['nb_frames'])==c['end_frame']-c['start_frame']
 assert j['pix_fmt']=='yuv420p' and j['color_range']=='tv' and j['color_space']=='bt709'
 return c['id']
with ThreadPoolExecutor(max_workers=4) as pool:
 for i,f in enumerate(as_completed([pool.submit(one,c) for c in T['cuts']])):
  f.result()
  if i%20==19:print(i+1,flush=True)
print('170 cuts normalized and frame counts verified',flush=True)
