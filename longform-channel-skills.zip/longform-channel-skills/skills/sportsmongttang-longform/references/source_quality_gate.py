"""Fail closed on absent, rejected, stale, or unsampled editorial quality reviews.
The reviewer must inspect source_full_bleed at the planned maximum zoom. Resolution
is recorded, but is never treated as proof that a photograph inside a PDF is sharp.
"""
import hashlib,json
from pathlib import Path

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def spec(c):
 p=Path(c['path']);st=p.stat()
 return {'path':str(p.resolve()),'size':st.st_size,'mtime_ns':st.st_mtime_ns,'kind':c['kind'],'trim':c.get('trim',0),'available_end':c.get('available_end'),'crop':c.get('source_crop'),'zoom':c['zoom']}
def fingerprint(c):return hashlib.sha256(json.dumps(spec(c),sort_keys=True).encode()).hexdigest()
def check(cuts,review_path):
 p=Path(review_path)
 if not p.is_file():raise RuntimeError('source_quality_review.json 없음: 실제 최대 확대 샘플 검토 필요')
 q=json.loads(p.read_text());rows=q.get('sources',{});errors=[]
 for c in cuts:
  k=c['candidate_id'];r=rows.get(k,{})
  if r.get('status')!='approved':errors.append(k+': 미검토 또는 낮은 화질로 탈락');continue
  if r.get('fingerprint')!=fingerprint(c):errors.append(k+': 원본·구간·크롭·확대 변경 후 재검토 필요')
  if not r.get('native_dimensions') or not r.get('intrinsic_assessment') or not r.get('visual_review_notes'):errors.append(k+': 해상도·내재 화질·실제 육안 기록 누락')
  samples=r.get('max_zoom_samples',[])
  if not samples:errors.append(k+': 최종 1920×1080 최대 확대 샘플 없음')
  for s in samples:
   f=Path(s.get('path',''))
   if not f.is_file() or s.get('sha256')!=sha(f):errors.append(k+': 검토 샘플 누락·변경')
 if errors:raise RuntimeError('\n'.join(errors))
 return {'source_quality_checked':len(cuts),'unreviewed_or_rejected_sources':0}
