"""오프라인 계약 동작 회귀 검사. 합성 fixture는 영상 품질 검수가 아니다."""
import copy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

import production_contract as pc


class ProductionTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.cfg,self.mdsha,self.preset = pc.load_rules()
        self.script = self.root/'script.txt'
        self.script.write_text('주인공은 철수 대신 주민을 남겨 두기로 했습니다.\n')
        self.review = self.root/'script_review.json'
        self.write(self.review,{'script_sha256':pc.digest(self.script),'model':'gpt-6.1-sol',
            'reasoning_effort':'high','session_id':'offline-test', 'sentences':[{
            'id':'s1','text':self.script.read_text().strip(),'narrative_function':'사건의 선택 제시',
            'causal_link':'앞의 봉쇄로 철수 여부 결정이 필요함','necessity':'주인공 결정 없이는 다음 공급 문제가 성립하지 않음',
            'fact_basis':'테스트용 근거 기록: 실제 역사 주장 검증 아님'}]})
        self.files=[]
        timing=self.root/'narration.json'
        self.write(timing,{'lines':[{'id':'s1','display_text':self.script.read_text().strip(),
                                    'placed_start_s':0,'placed_end_s':180}]})
        timing_binding={'path':str(timing),'sha256':pc.digest(timing)}
        self.files.append(timing_binding)
        def asset(name,data):
            path=self.root/name;path.write_bytes(data)
            row={'path':str(path),'sha256':pc.digest(path)};self.files.append(row)
            return {'source_path':str(path),'sha256':row['sha256'],'kind':'image'}
        image=asset('source.bin',b'historical-image-fixture')
        frame=asset('reference.bin',b'observed-reference-fixture')
        font=asset('font.bin',b'font-fixture')
        # 실제 폰트 대신 offline fixture 해시를 사용하는 설정 사본.
        self.rules=self.root/'rules.md'
        cfg=copy.deepcopy(self.cfg);cfg['caption']['font_sha256']=font['sha256'];self.cfg=cfg
        self.rules.write_text('```production-config\n'+json.dumps(cfg)+'\n```\n')
        self.mdsha=pc.digest(self.rules)
        film1=asset('film1.bin',b'film-frame-one');film2=asset('film2.bin',b'film-frame-two')
        self.ink=[132,954.2,300,68]
        geo=pc.caption_geometry(300,68,cfg)
        self.ink=geo['ink_box']
        measure=self.root/'measurement.json'
        self.write(measure,{'c1_cap1_ink':{'ink_bbox':self.ink,'text':'주민을 남겨 두기로 했습니다.', 'font_sha256':font['sha256']}})
        self.files.append({'path':str(measure),'sha256':pc.digest(measure)})
        caption={'id':'c1_cap1_ink','kind':'text','text':'주민을 남겨 두기로 했습니다.',
                 'start_s':0,'end_s':180,'box_px':self.ink,'z_index':251,'font':font,
                 'keyframes':{'scale_x':[{'t':0,'v':.9,'easing':'linear'}]}}
        caption.update({k:cfg['caption'][k] for k in ['font_size_px','font_weight','letter_spacing_px','line_height','color']})
        plate={'id':'c1_cap1_plate','kind':'path','box_px':geo['plate_box'],'d':geo['path'], 'start_s':0,'end_s':180}
        plate.update({k:cfg['caption'][k] for k in ['fill','stroke','stroke_width_px']})
        highlight={'id':'c1_title','kind':'text','box_px':[132,200,300,68],'z_index':10}
        bar=pc.make_underline(self.preset,'c1_underline','c1_title',[132,200,300,68],0,180,10,cfg)
        film={'id':'c1_film','kind':'texture_sequence','start_s':0,'end_s':180,
              'clock_origin_s':0,'visibility_windows_s':[[0,180]],
              'keyframes':{'opacity':[{'t':0,'v':.28,'easing':'linear'}]},
              'texture_frames':[{'at_s':i/10,'media':film1 if i%2==0 else film2} for i in range(1800)]}
        camera={'id':'c1_camera','kind':'group','start_s':0,'end_s':180,
                'keyframes':{'scale_x':[{'t':0,'v':1,'easing':'linear'},{'t':180,'v':1.05,'easing':'linear'}]}}
        self.p={'width':1920,'height':1080,'fps':30,'duration_s':180,'cuts':[{
            'id':'c1','start_s':0,'end_s':180,'asset':image,'renderer_layers':[film,camera,plate,caption,highlight,bar]}]}
        source={'candidate_id':'src1','kind':'image','path':image['source_path'],'sha256':image['sha256'],
                'renderer_node_id':'__background__',
                'canonical_source_id':'archive/photo1','scene_id':'photo1','identity_basis':'테스트 원자료 ID'}
        self.c={'rules_sha256':self.mdsha,'model':'gpt-6.1-sol','reasoning_effort':'high','session_id':'offline-test',
                'narration_timing':timing_binding,
                'scope':'test','tts':cfg['tts'],'audio':cfg['audio'],'input_files':self.files,
                'cuts':[{'id':'c1','narration_lines':['s1'],'layout':'historical_full_bleed','motion_basis':'주인공 선택 발화 때 중심 인물로 이동',
                         'reference_evidence':{'video_id':'reference','time_s':1,'frame_path':frame['source_path'],'frame_sha256':frame['sha256']},
                         'correspondence':{'speech_role':'잔류 선택', 'reference_features':'자료 위 독립 강조',
                             'source_role':'선택의 당사자', 'renderer_node_ids':['c1_camera','c1_title'],
                             'differences':'오프라인 fixture이며 실제 시각 비교 아님'}, 'sources':[source]}],
                'underlines':[{'cut_id':'c1','node_id':'c1_underline','text_node_id':'c1_title','ink_bbox':[132,200,300,68]}],
                'captions':[{'cut_id':'c1','plate_node_id':'c1_cap1_plate','text_node_id':'c1_cap1_ink',
                             'text':caption['text'],'ink_bbox':self.ink,'measurement_path':str(measure),'measurement_sha256':pc.digest(measure)}]}
        self.contract=self.root/'production.json';self.props=self.root/'props.json';self.save()

    def write(self,path,data):
        path.write_text(json.dumps(data,ensure_ascii=False))

    def save(self):
        self.write(self.contract,self.c);self.write(self.props,self.p)

    def check(self):
        self.save()
        return pc.check(self.contract,self.props,self.script,self.review,self.rules,pc.PACKAGE)

    def test_valid_contract_and_cache(self):
        first=self.check();self.assertTrue(first['passed'])
        self.assertEqual(first['sentence_cuts']['sentences'],1)
        self.assertEqual(first['direct_listening'],'not_observed')
        self.p['cuts'][0]['renderer_layers'][1]['keyframes']['scale_x'][1]['v']=1.08
        self.assertNotEqual(first['fingerprint'],self.check()['fingerprint'])

    def test_missing_correspondence_and_invented_node_rejected(self):
        original = copy.deepcopy(self.c)
        for key in ('speech_role', 'reference_features', 'source_role', 'differences', 'renderer_node_ids'):
            with self.subTest(key=key):
                self.c = copy.deepcopy(original)
                self.c['cuts'][0]['correspondence'].pop(key)
                with self.assertRaises(pc.ContractError): self.check()
        self.c = copy.deepcopy(original)
        self.c['cuts'][0]['correspondence']['renderer_node_ids'] = ['invented-layer']
        with self.assertRaises(pc.ContractError): self.check()

    def test_paper_design_is_not_historical_source_reuse(self):
        source = self.c['cuts'][0]['sources'][0]
        self.c['cuts'][0].update(layout='paper_country_reaction', sources=[], design_assets=[{
            'path':source['path'], 'sha256':source['sha256'],
            'renderer_node_id':'c1_camera', 'identity_basis':'국가 반응을 표현하는 지속 디자인 자산 fixture'}])
        self.p['cuts'][0]['renderer_layers'][1]['children'] = [{'media':self.p['cuts'][0]['asset']}]
        self.assertTrue(self.check()['passed'])
        self.c['cuts'][0]['design_assets'][0]['renderer_node_id'] = 'invented'
        with self.assertRaises(pc.ContractError): self.check()

    def test_design_only_cannot_replace_historical_scene(self):
        self.c['cuts'][0].update(sources=[], design_assets=[{'identity_basis':'불충분한 대체'}])
        with self.assertRaises(pc.ContractError): self.check()

    def test_all_fixed_underline_mutations_rejected(self):
        original=copy.deepcopy(self.p)
        for field,value in [('fill','#ff0000'),('box_px',[116,249,332,9]),('kind','path'),
                            ('keyframes',{'reveal_x':[{'t':0,'v':1},{'t':.65,'v':0}]})]:
            with self.subTest(field=field):
                self.p=copy.deepcopy(original);self.p['cuts'][0]['renderer_layers'][-1][field]=value
                with self.assertRaises(pc.ContractError):self.check()

    def test_missing_underline_rejected(self):
        self.p['cuts'][0]['renderer_layers'].pop()
        with self.assertRaises(pc.ContractError):self.check()

    def test_film_missing_opacity_and_static_rejected(self):
        original=copy.deepcopy(self.p)
        for mutation in ('missing','opacity','static','coverage'):
            with self.subTest(mutation=mutation):
                self.p=copy.deepcopy(original);f=self.p['cuts'][0]['renderer_layers'][0]
                if mutation=='missing':self.p['cuts'][0]['renderer_layers'].pop(0)
                elif mutation=='opacity':f['keyframes']['opacity'][0]['v']=.06
                elif mutation=='static':f['texture_frames']=f['texture_frames'][:1]
                else:f['end_s']=1
                with self.assertRaises(pc.ContractError):self.check()

    def test_motion_missing_rejected(self):
        self.p['cuts'][0]['renderer_layers'][1]['keyframes']['scale_x'][1]['v']=1
        with self.assertRaises(pc.ContractError):self.check()

    def test_caption_unbalanced_padding_rejected(self):
        self.c['captions'][0]['ink_bbox'][0]+=10
        with self.assertRaises(pc.ContractError):self.check()

    def test_caption_next_sentence_rejected(self):
        self.p['cuts'][0]['renderer_layers'][3]['text']='첫 문장. 다음 문장'
        self.c['captions'][0]['text']='첫 문장. 다음 문장'
        with self.assertRaises(pc.ContractError):self.check()

    def test_caption_decimal_and_initialism(self):
        for text in ('3.5톤을 실었습니다.','U.S. 정부의 대응','Dr. Smith의 선택'):
            self.assertFalse(pc.has_multiple_sentences(text),text)
        for text in ('끝입니다.다음 문장','끝입니다. 다음 문장','왜일까요? 다음 문장'):
            self.assertTrue(pc.has_multiple_sentences(text),text)

    def test_caption_fixed_style_and_missing_rejected(self):
        original=copy.deepcopy(self.p)
        for mutation in ('font_size','stroke','missing'):
            self.p=copy.deepcopy(original)
            if mutation=='font_size':self.p['cuts'][0]['renderer_layers'][3]['font_size_px']=49
            elif mutation=='stroke':self.p['cuts'][0]['renderer_layers'][2]['stroke']='#000000'
            else:self.p['cuts'][0]['renderer_layers'].pop(3)
            with self.assertRaises(pc.ContractError):self.check()

    def test_script_change_rejected(self):
        self.script.write_text('수정한 새 문장입니다.\n')
        with self.assertRaises(pc.ContractError):self.check()

    def test_sentence_timing_binding_missing_or_changed_rejected(self):
        original=copy.deepcopy(self.c)
        self.c.pop('narration_timing')
        with self.assertRaisesRegex(pc.ContractError,'narration_timing'):self.check()
        self.c=original
        Path(self.c['narration_timing']['path']).write_text('{}')
        with self.assertRaises(pc.ContractError):self.check()

    def test_cli_render_blocks_missing_sentence_binding(self):
        self.c['cuts'][0].pop('narration_lines');self.save()
        marker=self.root/'sentence-invalid-render-started'
        command=[sys.executable,str(pc.PACKAGE/'scripts/production_contract.py'),'render',
                 '--rules',str(self.rules),'--script',str(self.script),'--review',str(self.review),
                 '--contract',str(self.contract),'--props',str(self.props),'--report',str(self.root/'report.json'),
                 '--',sys.executable,'-c',f'from pathlib import Path; Path({str(marker)!r}).touch()']
        result=subprocess.run(command,capture_output=True,text=True)
        self.assertNotEqual(result.returncode,0);self.assertFalse(marker.exists())

    def test_review_mirrors_script_rejected(self):
        r=pc.read(self.review);r['sentences'][0]['necessity']=r['sentences'][0]['text'];self.write(self.review,r)
        with self.assertRaises(pc.ContractError):self.check()

    def test_rules_change_and_preset_tampering_rejected(self):
        self.rules.write_text(self.rules.read_text()+'개정\n')
        with self.assertRaises(pc.ContractError):self.check()
        package=self.root/'package';(package/'assets').mkdir(parents=True)
        self.write(package/'assets/fixed-underline.json',{'preset':{}})
        with self.assertRaises(pc.ContractError):pc.load_rules(self.rules,package)

    def test_source_hash_change_rejected(self):
        Path(self.c['cuts'][0]['sources'][0]['path']).write_bytes(b'changed')
        with self.assertRaises(pc.ContractError):self.check()

    def test_same_original_different_crop_rejected(self):
        a=copy.deepcopy(self.c['cuts'][0]['sources'][0]);b=copy.deepcopy(a)
        crop=self.root/'crop.bin';crop.write_bytes(b'different-crop-bytes')
        b.update(candidate_id='other',scene_id='other',path=str(crop),sha256=pc.digest(crop))
        pool=pc.SourcePool([a,b]);pool.take(a['candidate_id'])
        with self.assertRaises(pc.ContractError):pool.take(b['candidate_id'])

    def test_video_scene_and_overlap_rejected(self):
        a=copy.deepcopy(self.c['cuts'][0]['sources'][0]);a.update(kind='video',canonical_trim_s=10,canonical_end_s=20,
                local_trim_s=0,local_end_s=10,verified_end_s=30)
        for same_scene in (True,False):
            b=copy.deepcopy(a);b.update(candidate_id='other',scene_id=a['scene_id'] if same_scene else 'different',canonical_trim_s=19,canonical_end_s=29)
            pool=pc.SourcePool([a,b]);pool.take(a['candidate_id'])
            with self.assertRaises(pc.ContractError):pool.take(b['candidate_id'])
        b=copy.deepcopy(a);b.update(candidate_id='other',scene_id='new-scene',canonical_trim_s=20,canonical_end_s=30)
        pool=pc.SourcePool([a,b]);pool.take(a['candidate_id']);pool.take(b['candidate_id'])

    def test_reference_frame_missing_rejected(self):
        self.c['cuts'][0]['reference_evidence']['frame_sha256']='missing'
        with self.assertRaises(pc.ContractError):self.check()

    def test_video_render_interval_binding(self):
        source=self.c['cuts'][0]['sources'][0]
        source.update(kind='video',canonical_trim_s=10,canonical_end_s=190,
                      local_trim_s=0,local_end_s=180,verified_end_s=200)
        self.p['cuts'][0]['asset']['kind']='video'
        self.assertTrue(self.check()['passed'])
        self.p['cuts'][0]['trim_start_s']=1
        with self.assertRaises(pc.ContractError):self.check()

    def test_portrait_side_reversed_rejected(self):
        self.c['cuts'][0].update(layout='portrait_left_problem_right',portrait_node_id='portrait',problem_node_id='problem')
        self.p['cuts'][0]['renderer_layers'] += [{'id':'portrait','kind':'group','box_px':[1200,100,500,500]},
                                               {'id':'problem','kind':'group','box_px':[100,100,500,500]}]
        with self.assertRaises(pc.ContractError):self.check()

    def test_cli_render_blocks_command_on_invalid_input(self):
        marker=self.root/'render-started'
        self.p['cuts'][0]['renderer_layers'].pop(0);self.save()
        command=[sys.executable,str(pc.PACKAGE/'scripts/production_contract.py'),'render',
                 '--rules',str(self.rules),'--script',str(self.script),'--review',str(self.review),
                 '--contract',str(self.contract),'--props',str(self.props),'--report',str(self.root/'report.json'),
                 '--',sys.executable,'-c',f'from pathlib import Path; Path({str(marker)!r}).touch()']
        result=subprocess.run(command,capture_output=True,text=True)
        self.assertNotEqual(result.returncode,0);self.assertFalse(marker.exists())
        self.p['cuts'][0]['renderer_layers'].insert(0,copy.deepcopy(self.original_film()))
        self.save();result=subprocess.run(command,capture_output=True,text=True)
        self.assertEqual(result.returncode,0,result.stderr);self.assertTrue(marker.exists())

    def original_film(self):
        media=[{'source_path':x['path'],'sha256':x['sha256'],'kind':'image'} for x in self.files if Path(x['path']).name.startswith('film')]
        return {'id':'c1_film','kind':'texture_sequence','start_s':0,'end_s':180,
                'clock_origin_s':0,'visibility_windows_s':[[0,180]],
                'keyframes':{'opacity':[{'t':0,'v':.28,'easing':'linear'}]},
                'texture_frames':[{'at_s':i/10,'media':media[i%2]} for i in range(1800)]}


class SentenceCutTests(unittest.TestCase):
    """실측 TTS 경계에 맞춘 컷 분할의 회귀 사례. 영상 품질 판정은 아니다."""
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.path=Path(self.tmp.name)/'narration.json'
        self.review={'sentences':[{'id':'a','text':'첫 문장입니다.'},{'id':'b','text':'다음 문장입니다.'}]}
        self.lines=[{'id':'a','display_text':'첫 문장입니다.','placed_start_s':0,'placed_end_s':4.015},
                    {'id':'b','display_text':'다음 문장입니다.','placed_start_s':4.015,'placed_end_s':8.011}]
        self.props={'fps':30,'duration_s':8,'cuts':[{'id':'c1','start_s':0,'end_s':4},
                                                {'id':'c2','start_s':4,'end_s':8}]}
        self.contract={'cuts':[{'id':'c1','narration_lines':['a']},{'id':'c2','narration_lines':['b']}]}

    def check(self):
        self.path.write_text(json.dumps({'lines':self.lines}))
        binding={'path':str(self.path),'sha256':pc.digest(self.path)}
        self.contract['narration_timing']=binding
        return pc.check_sentence_cuts(self.contract,self.props,self.review,{str(self.path.resolve()):binding['sha256']})

    def test_one_cut_per_sentence_with_frame_rounding(self):
        self.assertEqual(self.check()['sentences'],2)

    def test_additional_cuts_within_sentence_allowed(self):
        self.props['cuts']=[{'id':'c1','start_s':0,'end_s':2},
                            {'id':'c1b','start_s':2,'end_s':4},{'id':'c2','start_s':4,'end_s':8}]
        self.contract['cuts'].insert(1,{'id':'c1b','narration_lines':['a']})
        self.assertEqual(self.check()['cuts'],3)

    def test_multiple_sentences_in_one_cut_rejected(self):
        self.contract['cuts']=[{'id':'c1','narration_lines':['a','b']}]
        self.props['cuts']=[{'id':'c1','start_s':0,'end_s':8}]
        with self.assertRaisesRegex(pc.ContractError,'문장 하나'):self.check()

    def test_total_cut_count_does_not_prove_boundary_alignment(self):
        self.props['cuts'][0]['end_s']=5;self.props['cuts'][1]['start_s']=5
        with self.assertRaisesRegex(pc.ContractError,'경계를 넘음'):self.check()

    def test_unassigned_unknown_or_missing_sentence_rejected(self):
        original=copy.deepcopy(self.contract)
        for ids in ([],['invented'],['a']):
            with self.subTest(ids=ids):
                self.contract=copy.deepcopy(original);self.contract['cuts'][1]['narration_lines']=ids
                with self.assertRaises(pc.ContractError):self.check()

    def test_tts_reorder_text_change_and_missing_line_rejected(self):
        original=copy.deepcopy(self.lines)
        for mutation in ('order','text','missing'):
            with self.subTest(mutation=mutation):
                self.lines=copy.deepcopy(original)
                if mutation=='order':self.lines.reverse()
                elif mutation=='text':self.lines[0]['display_text']='변경된 대본.'
                else:self.lines.pop()
                with self.assertRaises(pc.ContractError):self.check()

    def test_invalid_tts_times_rejected(self):
        original=copy.deepcopy(self.lines)
        for value in (-1,float('nan'),float('inf'),'0',True):
            with self.subTest(value=value):
                self.lines=copy.deepcopy(original);self.lines[0]['placed_start_s']=value
                with self.assertRaises(pc.ContractError):self.check()

    def test_gap_overlap_and_uncovered_ending_rejected(self):
        original=copy.deepcopy(self.lines)
        for mutation in ('gap','overlap','ending'):
            with self.subTest(mutation=mutation):
                self.lines=copy.deepcopy(original)
                if mutation=='gap':self.lines[1]['placed_start_s']=5
                elif mutation=='overlap':self.lines[1]['placed_start_s']=3
                else:self.lines[-1]['placed_end_s']=7
                with self.assertRaises(pc.ContractError):self.check()


if __name__ == '__main__':
    unittest.main(verbosity=2)
