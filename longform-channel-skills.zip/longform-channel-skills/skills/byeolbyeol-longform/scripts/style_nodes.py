"""확정 v3의 자막·말풍선·아이콘 노드 제작. 입력 글자는 실제 Chrome 측정값이다."""
from pathlib import Path
import math
from production_contract import digest, caption_geometry, make_underline

def keyframes(**values):
    base={k:[{'t':0,'v':v,'easing':'linear'}]for k,v in {'opacity':1,'scale_x':1,'scale_y':1,'x_px':0,'y_px':0,'rotation_deg':0,'blur_px':0}.items()}
    for k,v in values.items():base[k]=v if isinstance(v,list)else[{'t':0,'v':v,'easing':'linear'}]
    return base

def node(id,kind,box,start,end,evidence_path,pointer,z=0,**fields):
    if not 0<=start<end:raise ValueError('노드 시각이 역전되거나 비어 있음')
    return {'id':id,'kind':kind,'start_s':start,'end_s':end,'clock_origin_s':start,'visibility_windows_s':[[start,end]],'box_px':list(box),'origin_px':[0,0],'z_index':z,'blend':'normal','clip':False,'measurement':{'status':'measured','evidence':{'file':str(evidence_path),'pointer':pointer}},'keyframes':keyframes(),**fields}

def media(path):return {'kind':'image','source_path':str(Path(path).resolve()),'sha256':digest(path)}

def text_nodes(id,metric,font,center,top,start,end,evidence_path,color='#fff',z=35,shadow='0 4px 3px rgba(0,0,0,.65)',plate=None):
    if metric['text']=='':raise ValueError('빈 표시 글자')
    x=center-metric['ink_width']/2;ink=[x,top,metric['ink_width'],metric['ink_height']]
    if x<30 or x+ink[2]>1890 or top<0 or top+ink[3]>=908:raise ValueError('주요 글자 안전 영역 초과: '+id)
    left,up,_,_=metric['ink_box'];box=[x-left,top-up,metric['advance_width'],metric['size']*metric['line_height']*len(metric['lines'])+4]
    nodes=[]
    if plate:
        pad=plate.get('pad',24);nodes.append(node(id+'_label','rect',[x-pad,top-pad,ink[2]+2*pad,ink[3]+2*pad],start,end,evidence_path,'/'+id,z-2,fill=plate.get('color','#121212'),radius_px=plate.get('radius',16)))
    nodes.append(node(id,'text',box,start,end,evidence_path,'/'+id,z,text=metric['text'],font=font,font_size_px=metric['size'],font_weight=metric['weight'],color=color,align='center',line_height=metric['line_height'],letter_spacing_px=0,text_shadow=shadow,text_stroke={'width_px':0,'color':'transparent'}))
    return nodes,ink

def bubble_nodes(id,metric,font,center,top,start,end,evidence_path,tail='left'):
    if tail not in ['left','right']:raise ValueError('말풍선 꼬리 방향 불명')
    pad=30;w=metric['ink_width']+pad*2;h=metric['ink_height']+pad*2;x=center-w/2;y=top-pad
    d=f'M26 3H{w-26}Q{w-3} 3 {w-3} 26V{h-26}Q{w-3} {h-3} {w-26} {h-3}'
    if tail=='left':d+=f'H{w*.35}L{w*.19} {h+37}L{w*.23} {h-3}'
    else:d+=f'H{w*.79}L{w*.83} {h+37}L{w*.66} {h-3}'
    d+=f'H26Q3 {h-3} 3 {h-26}V26Q3 3 26 3Z'
    n=node(id+'_bubble','path',[x,y,w,h+37],start,end,evidence_path,'/'+id,32,d=d,view_box=f'0 0 {w} {h+37}',fill='#fff',stroke='#121212',stroke_width_px=6)
    texts,ink=text_nodes(id,metric,font,center,top,start,end,evidence_path,color='#111',z=35,shadow='none')
    return [n]+texts,{'body_box':[x,y,w,h],'ink_bbox':ink,'padding_px':[30,30,30,30],'tail_in_padding':False}

def caption_nodes(id,metric,font,start,end,cfg,evidence_path):
    cc=cfg['caption'];geo=caption_geometry(metric['ink_width']*cc['scale_x'],metric['ink_height'],cfg);pb=geo['plate_box'];ink=geo['ink_box'];l,t,_,_=metric['ink_box']
    plate=node(id+'_plate','path',pb,start,end,evidence_path,'/'+id,80,d=geo['path'],view_box=f'0 0 {pb[2]} {pb[3]}',fill=cc['fill'],stroke=cc['stroke'],stroke_width_px=cc['stroke_width_px'])
    text=node(id+'_ink','text',[ink[0]-l*cc['scale_x'],ink[1]-t,metric['advance_width']+4,cc['font_size_px']*cc['line_height']+4],start,end,evidence_path,'/'+id,81,text=metric['text'],font=font,font_size_px=cc['font_size_px'],font_weight=cc['font_weight'],color=cc['color'],align='left',line_height=cc['line_height'],letter_spacing_px=cc['letter_spacing_px'],text_shadow='none',text_stroke={'width_px':0,'color':'transparent'})
    text['keyframes']=keyframes(scale_x=cc['scale_x']);return[plate,text],ink

def icon_node(id,path,start,end,evidence_path,side=0):
    if side not in [0,1]:raise ValueError('비교 아이콘 위치는 0 또는 1')
    return node(id,'image',[450 if side==0 else 1250,225,220,350],start,end,evidence_path,'/'+id,25,media=media(path))

def film_node(id,frames,duration,cfg,evidence_path):
    if len(set(map(str,frames)))<2:raise ValueError('실제 움직이는 필름 프레임 부족')
    n=node(id,'texture_sequence',[0,0,1920,1080],0,duration,evidence_path,'/'+id,15,film_kind='grain',texture_frames=[{'at_s':round(i/10,6),'media':media(frames[i%len(frames)])}for i in range(math.floor(duration*10)+1)])
    n['keyframes']=keyframes(opacity=cfg['film']['opacity']);return n

def underline_node(preset,id,text_id,ink,start,end,text_z,cfg,evidence_path):
    n=make_underline(preset,id,text_id,ink,start,end,text_z,cfg);n.pop('target_text_node_id');n['measurement']={'status':'measured','evidence':{'file':str(evidence_path),'pointer':'/'+text_id}};return n
