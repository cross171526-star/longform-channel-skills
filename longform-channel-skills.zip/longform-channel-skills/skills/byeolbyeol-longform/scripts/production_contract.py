"""별별역사 실제 prepared props 계약. 의미/시각 품질 자동 승인기는 아니다."""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import math
import re
import subprocess
from pathlib import Path

PACKAGE = Path(__file__).resolve().parents[1]
DEFAULT_RULES = PACKAGE / 'references/별별역사형_영상제작규칙.md'


class ContractError(ValueError):
    pass


def require(ok, message):
    if not ok:
        raise ContractError(message)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def load_rules(path=DEFAULT_RULES, package=PACKAGE):
    blocks = re.findall(r'^```production-config\s*\n(.*?)\n```', Path(path).read_text(), re.M | re.S)
    require(len(blocks) == 1, 'production-config는 정확히 1개 필요')
    cfg = json.loads(blocks[0])
    require(cfg['schema_version'] == 1, '지원하지 않는 설정 버전')
    preset_file = Path(package) / cfg['underline']['preset']
    require(digest(preset_file) == cfg['underline']['sha256'], '고정 밑줄 원형 해시 불일치')
    return cfg, digest(path), read(preset_file)['preset']


def script_gate(script, review, cfg):
    rows = [line.strip() for line in Path(script).read_text().splitlines() if line.strip()]
    data = read(review)
    require(data['script_sha256'] == digest(script), '대본 변경: 문장 검토를 갱신해야 함')
    require(data['model'] == cfg['model'] and data['reasoning_effort'] == cfg['reasoning_effort']
            and bool(data['session_id']), '실제 대본 검토 모델·세션 누락/불일치')
    require(rows and len(data['sentences']) == len(rows), '대본 전체 문장 검토 누락')
    ids = set()
    for text, row in zip(rows, data['sentences']):
        require(row['id'] not in ids, '문장 ID 중복')
        ids.add(row['id'])
        require(row['text'] == text, '검토 문장과 대본 불일치')
        for key in ('narrative_function', 'causal_link', 'necessity', 'fact_basis'):
            value = row.get(key)
            require(isinstance(value, str) and value.strip() and value.strip() != text,
                    f'{row["id"]}: {key} 실제 검토 내용 누락')
    return data


class SourcePool:
    """한 timeline 안 원자료·장면 소진. 원자료 동일성은 근거 있는 ID가 전제다."""
    def __init__(self, candidates):
        self.available = {}
        self.scenes = set()
        self.images = set()
        self.image_hashes = set()
        self.intervals = {}
        for candidate in candidates:
            key = candidate['candidate_id']
            require(key not in self.available, '후보 ID 중복')
            self.available[key] = copy.deepcopy(candidate)

    def take(self, key):
        require(key in self.available, '없는/소진된 자료 후보: ' + key)
        source = self.available[key]
        origin, scene = source['canonical_source_id'], source['scene_id']
        require(origin and scene and source.get('identity_basis'), '원자료·장면 식별 근거 누락')
        require(scene not in self.scenes, '동일 장면 재사용: ' + scene)
        actual_hash = digest(source['path'])
        require(actual_hash == source['sha256'], '자료 입력 해시 불일치')
        require(source['kind'] in ('image', 'video'), '역사 자료 kind 불명')
        if source['kind'] == 'image':
            require(origin not in self.images and actual_hash not in self.image_hashes,
                    '사진/기사 원자료 재사용: ' + origin)
            self.images.add(origin)
            self.image_hashes.add(actual_hash)
        else:
            a, b = source['canonical_trim_s'], source['canonical_end_s']
            la, lb = source['local_trim_s'], source['local_end_s']
            require(0 <= a < b and 0 <= la < lb <= source['verified_end_s'], '검증된 자료 구간 부족')
            require(abs((b-a)-(lb-la)) < 1e-6, '원본/로컬 자료 구간 길이 불일치')
            require(not any(a < y and b > x for x, y in self.intervals.get(origin, [])),
                    '영상 원본 시각축 사용 구간 중복: ' + origin)
            self.intervals.setdefault(origin, []).append((a, b))
        self.scenes.add(scene)
        del self.available[key]
        return copy.deepcopy(source)


def make_underline(preset, node_id, text_node_id, ink_bbox, start_s, end_s, text_z, cfg):
    """잉크 bbox는 실제 loaded font의 화면 좌표. 효과 필드는 원형에서만 복제."""
    x, y, width, height = ink_bbox
    draw_s = preset['keyframes']['reveal_x'][-1]['t']
    require(width > 0 and height > 0 and end_s - start_s >= draw_s, '밑줄 잉크/표시 시간 부족')
    node = copy.deepcopy(preset)
    bar_height = node.pop('height_px')
    pad, offset = cfg['underline']['padding_x_px'], cfg['underline']['ink_bottom_offset_px']
    node.update(id=node_id, start_s=start_s, end_s=end_s, clock_origin_s=start_s,
                visibility_windows_s=[[start_s, end_s]], box_px=[x-pad, y+height-offset, width+2*pad, bar_height],
                origin_px=[0, 0], z_index=text_z-1, target_text_node_id=text_node_id)
    return node


def caption_plate_path(width, height=108):
    require(width > 44, '자막판 폭 부족')
    r = width - 22
    return (f'M22 4H{r}Q{r} 22 {width-4} 22V{height-22}'
            f'Q{r} {height-22} {r} {height-4}H22Q22 {height-22} 4 {height-22}'
            'V22Q22 22 22 4Z')


def caption_geometry(ink_width, ink_height, cfg):
    """font 로드·scale 적용 후 실제 잉크 폭/높이에서 목표 좌표를 계산한다."""
    cap = cfg['caption']
    require(ink_width > 0 and 0 < ink_height < cap['height_px'], '자막 잉크 크기 오류')
    width = ink_width + 2*cap['padding_x_px']
    require(width <= cfg['canvas']['width']-64, '긴 자막: 의미 단위 분할 필요')
    x = (cfg['canvas']['width']-width)/2
    y = cap['y_px']
    return {'plate_box': [x,y,width,cap['height_px']],
            'ink_box': [x+cap['padding_x_px'],y+(cap['height_px']-ink_height)/2,ink_width,ink_height],
            'path': caption_plate_path(width, cap['height_px'])}


def source_media(obj):
    """renderer가 실제 참조하는 모든 source_path/sha256를 찾아낸다."""
    if isinstance(obj, dict):
        if 'source_path' in obj:
            yield obj
        for value in obj.values():
            yield from source_media(value)
    elif isinstance(obj, list):
        for value in obj:
            yield from source_media(value)


def check_underline(node, preset):
    for key, value in preset.items():
        actual = node['box_px'][3] if key == 'height_px' else node.get(key)
        require(actual == value, f'{node["id"]}: 고정 밑줄 {key} 변형')
    require(not any(key in node for key in ('d','stroke','stroke_width_px')), '밑줄을 선으로 대체함')
    require(node['end_s']-node['start_s'] >= preset['keyframes']['reveal_x'][-1]['t'], '밑줄 표시 시간 부족')
    require(node.get('clock_origin_s') == node['start_s']
            and node.get('visibility_windows_s') == [[node['start_s'],node['end_s']]], '밑줄 clock 불일치')


def near(a, b, tolerance=1e-6):
    return abs(a-b) <= tolerance


def has_multiple_sentences(text):
    # 영어 initialism/호칭의 점과 숫자 소수점은 한국어 문장 끝과 구분한다.
    clean = re.sub(r'\b(?:[A-Za-z]\.){2,}|\b(?:Mr|Mrs|Ms|Dr|Prof|St|vs|etc)\.', '', text)
    return bool(re.search(r'[.!?。][”\"\']?\s*[가-힣A-Za-z]', clean))


def check_sentence_cuts(contract, props, review, files):
    """확정 문장·실측 TTS·실제 컷의 연결만 검사한다. 장면의 의미는 판정하지 않는다."""
    binding = contract.get('narration_timing', {})
    require(isinstance(binding, dict) and binding.get('path') and binding.get('sha256'),
            '묵음 제거 후 narration_timing 파일 연결 누락')
    path = str(Path(binding['path']).resolve())
    require(files.get(path) == binding['sha256'] and digest(path) == binding['sha256'],
            '실측 TTS 시각 파일 미등록/변경')
    lines = read(path).get('lines', [])
    sentences = review['sentences']
    require(isinstance(lines, list) and len(lines) == len(sentences), '실측 TTS 문장 누락')
    fps = props['fps']
    tolerance = 1 / fps + 1e-6
    timeline = {}
    for line, sentence in zip(lines, sentences):
        sid = sentence['id']
        require(line.get('id') == sid and line.get('display_text') == sentence['text'],
                f'{sid}: 확정 대본과 TTS 문장 ID/화면용 문구 불일치')
        start, end = line.get('placed_start_s'), line.get('placed_end_s')
        require(all(isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)
                    for x in (start, end)) and 0 <= start < end,
                f'{sid}: 실측 TTS 문장 시간창 오류')
        if timeline:
            previous_end = next(reversed(timeline.values()))[1]
            require(near(start, previous_end, tolerance), f'{sid}: TTS 문장 사이 빈 구간/겹침')
        else:
            require(near(start, 0, tolerance), '첫 TTS 문장 시작과 영상 시작 불일치')
        timeline[sid] = (start, end)
    require(timeline and near(next(reversed(timeline.values()))[1], props['duration_s'], tolerance),
            '마지막 TTS 문장과 전체 길이 불일치')
    require([x['id'] for x in contract['cuts']] == [x['id'] for x in props['cuts']],
            '실제 컷 계약 누락/순서 불일치')
    require(len({x['id'] for x in props['cuts']}) == len(props['cuts']), '배경 컷 ID 중복')
    assigned = {sid: [] for sid in timeline}
    order = []
    previous_end = 0
    for planned, actual in zip(contract['cuts'], props['cuts']):
        ids = planned.get('narration_lines')
        require(isinstance(ids, list) and len(ids) == 1 and isinstance(ids[0], str)
                and ids[0] in timeline, f'{planned["id"]}: 배경 컷은 확정 문장 하나에 연결해야 함')
        sid = ids[0]
        start, end = actual['start_s'], actual['end_s']
        require(all(isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)
                    for x in (start, end)) and start < end and near(start, previous_end),
                f'{planned["id"]}: 컷 시간창/연속성 오류')
        previous_end = end
        sentence_start, sentence_end = timeline[sid]
        require(start >= sentence_start - tolerance and end <= sentence_end + tolerance,
                f'{planned["id"]}: 배경 컷이 {sid}의 실측 문장 경계를 넘음')
        if not order or order[-1] != sid:
            order.append(sid)
        assigned[sid].append(actual)
    require(order == list(timeline), '문장별 배경 컷 누락/순서 불일치')
    for sid, cuts in assigned.items():
        start, end = timeline[sid]
        require(cuts and near(cuts[0]['start_s'], start, tolerance)
                and near(cuts[-1]['end_s'], end, tolerance), f'{sid}: 문장 전체의 배경 컷 연결 부족')
    return {'sentences': len(timeline), 'cuts': len(contract['cuts']),
            'minimum_cuts_per_sentence': 1, 'boundary_tolerance_frames': 1,
            'scope': 'sentence_timing_binding_only'}


def check(contract, props, script, review, rules=DEFAULT_RULES, package=PACKAGE):
    cfg, mdsha, preset = load_rules(rules, package)
    reviewed = script_gate(script, review, cfg)
    c, p = read(contract), read(props)
    require(c['rules_sha256'] == mdsha, '실행 계약의 제작 규칙 해시 불일치')
    require(c['model'] == cfg['model'] and c['reasoning_effort'] == cfg['reasoning_effort']
            and c['session_id'], '실제 제작 모델·세션 누락/불일치')
    require(c['tts'] == cfg['tts'] and c['audio'] == cfg['audio'], '음성/음악 설정 불일치')
    for key, val in cfg['canvas'].items():
        require(p[key] == val, '출력 canvas 불일치: ' + key)
    require(c['scope'] in ('test','main'), 'test/main 범위 누락')
    limits = cfg['test']['duration_s'] if c['scope'] == 'test' else [
        cfg['reference']['duration_s']-cfg['reference']['tolerance_s'],
        cfg['reference']['duration_s']+cfg['reference']['tolerance_s']]
    require(limits[0] <= p['duration_s'] <= limits[1], '영상 계획 길이 범위 불일치')
    require([x['id'] for x in c['cuts']] == [x['id'] for x in p['cuts']], '실제 컷 계약 누락/순서 불일치')
    sources = [s for cut in c['cuts'] for s in cut['sources']]
    pool = SourcePool(sources)
    nodes = {}
    files = {}
    for file in c['input_files']:
        path = str(Path(file['path']).resolve())
        require(path not in files, '입력 파일 중복 등록')
        require(digest(path) == file['sha256'], '실제 입력 파일 변경: ' + path)
        files[path] = file['sha256']
    for media in source_media(p):
        path = str(Path(media['source_path']).resolve())
        require(path in files and media.get('sha256') == files[path], 'props 실제 자산 미등록: ' + path)
    sentence_cuts = check_sentence_cuts(c, p, reviewed, files)
    previous_end = 0
    for planned, actual in zip(c['cuts'], p['cuts']):
        require(near(actual['start_s'], previous_end), '컷 간 빈 구간/겹침')
        duration = actual['end_s']-actual['start_s']
        require(duration > 0, '컷 시간창 오류')
        previous_end = actual['end_s']
        require(planned['layout'] in cfg['allowed_layouts'] and planned['motion_basis'], '구도/모션 근거 누락')
        ev = planned['reference_evidence']
        require(ev['video_id'] and ev['time_s'] >= 0 and digest(ev['frame_path']) == ev['frame_sha256'], '실제 구도 프레임 근거 누락')
        require(str(Path(ev['frame_path']).resolve()) in files, '레퍼런스 프레임 입력 미등록')
        design_assets = planned.get('design_assets', [])
        require(planned['sources'] or (planned['layout'] == 'paper_country_reaction' and design_assets),
                '자료 또는 종이 국가 반응 디자인 자산이 없는 컷')
        layers = actual['renderer_layers']
        layer_map = {n['id']: n for n in layers}
        require(len(layer_map) == len(layers), '노드 ID 중복')
        if cfg.get('reference_correspondence_required'):
            correspondence = planned.get('correspondence', {})
            for key in ('speech_role', 'reference_features', 'source_role', 'differences'):
                value = correspondence.get(key)
                require(isinstance(value, str) and value.strip(),
                        f'{planned["id"]}: 장면별 구도 대응 {key} 누락')
            ids = correspondence.get('renderer_node_ids')
            require(isinstance(ids, list) and ids and len(ids) == len(set(ids))
                    and all(isinstance(i, str) and i in layer_map for i in ids),
                    f'{planned["id"]}: 구도 대응 실제 노드 연결 누락')
        for asset in design_assets:
            require(asset.get('identity_basis'), '지속 디자인 자산 역할 누락')
            target = layer_map.get(asset.get('renderer_node_id'))
            require(target is not None and any(m.get('sha256') == asset.get('sha256')
                    and m.get('source_path') == asset.get('path') for m in source_media(target)),
                    '디자인 자산과 실제 렌더 노드 연결 불일치')
        for s in planned['sources']:
            pool.take(s['candidate_id'])
            target = actual if s['renderer_node_id'] == '__background__' else layer_map[s['renderer_node_id']]
            require(any(m['sha256'] == s['sha256'] and m.get('kind') == s['kind']
                        for m in source_media(target)), '선택 자료와 실제 노드 자산 연결 불일치')
            if s['kind'] == 'video':
                local_start = target.get('trim_start_s',0)
                local_end = local_start + (target['end_s']-target['start_s'])*target.get('speed',1)
                require(near(local_start,s['local_trim_s']) and near(local_end,s['local_end_s']), '실제 렌더 영상 구간과 원자료 장부 불일치')
        for n in layers:
            key = (actual['id'],n['id'])
            require(key not in nodes, '노드 ID 중복')
            nodes[key] = n
        film = [n for n in layers if n.get('kind') == cfg['film']['kind']]
        require(len(film) == 1, '전 컷 필름 누락/중복')
        f = film[0]
        require(f['keyframes']['opacity'] == [{'t':0,'v':cfg['film']['opacity'],'easing':'linear'}], '필름 투명도 변형')
        require(near(f['start_s'],0) and near(f['end_s'],duration), '필름이 컷 전체를 덮지 않음')
        require(len({x['media']['sha256'] for x in f['texture_frames']}) >= 2, '움직이는 필름 프레임 부족')
        times = [x['at_s'] for x in f['texture_frames']]
        require(times[0] == 0 and all(0 < b-a <= .100001 for a,b in zip(times,times[1:]))
                and 0 <= duration-times[-1] <= .100001, '필름 프레임 시각 누락/긴 정지 구간')
        require(f.get('clock_origin_s') == 0 and f.get('visibility_windows_s') == [[0,duration]], '필름 clock/표시 시간창 불일치')
        cameras = [n for n in layers if n['id'].endswith('_camera')]
        require(len(cameras) == 1, '클립 카메라 키프레임 누락/중복')
        camera = cameras[0]
        require(near(camera['start_s'],0) and near(camera['end_s'],duration), '카메라 시간창 불일치')
        require(any(len(v) >= 2 and v[0]['v'] != v[-1]['v'] for k,v in camera['keyframes'].items()
                    if k in ('scale_x','scale_y','x_px','y_px')), '클립 카메라 실제 움직임 없음')
        if planned['layout'] == 'portrait_left_problem_right':
            portrait = nodes[(actual['id'],planned['portrait_node_id'])]
            problem = nodes[(actual['id'],planned['problem_node_id'])]
            require(portrait['box_px'][0]+portrait['box_px'][2]/2 < cfg['canvas']['width']/2
                    < problem['box_px'][0]+problem['box_px'][2]/2, '인물 왼쪽/과제 오른쪽 구도 반전')
    require(near(previous_end,p['duration_s']), '마지막 컷과 전체 길이 불일치')
    expected_bars = {(x['cut_id'],x['node_id']) for x in c['underlines']}
    actual_bars = {key for key in nodes if key[1].endswith('_underline')}
    require(expected_bars == actual_bars, '밑줄 효과 명세/실제 노드 누락')
    for row in c['underlines']:
        bar = nodes[(row['cut_id'],row['node_id'])]
        text = nodes[(row['cut_id'],row['text_node_id'])]
        check_underline(bar, preset)
        x,y,w,h = row['ink_bbox']
        pad,offset = cfg['underline']['padding_x_px'],cfg['underline']['ink_bottom_offset_px']
        require(all(near(a,b) for a,b in zip(bar['box_px'],[x-pad,y+h-offset,w+2*pad,preset['height_px']])), '밑줄 실제 잉크 위치/폭 불일치')
        require(bar['z_index'] == text['z_index']-1, '밑줄이 글자 뒤에 있지 않음')
    expected_caps = {(x['cut_id'],x['text_node_id']) for x in c['captions']}
    actual_caps = {key for key in nodes if key[1].endswith('_ink') and '_cap' in key[1]}
    require(expected_caps and expected_caps == actual_caps, '자막 명세/실제 노드 누락')
    cap = cfg['caption']
    for row in c['captions']:
        plate = nodes[(row['cut_id'],row['plate_node_id'])]
        ink = nodes[(row['cut_id'],row['text_node_id'])]
        require(row['text'] == ink['text'] and '\n' not in ink['text'], '자막 텍스트/한 줄 불일치')
        require(not has_multiple_sentences(ink['text']), '마침표 뒤 다음 문장을 한 자막에 표시')
        for key in ('font_size_px','font_weight','letter_spacing_px','line_height','color'):
            require(ink[key] == cap[key], '자막 고정 설정 변형: ' + key)
        require(ink['font']['sha256'] == cap['font_sha256'], '자막 실제 폰트 불일치')
        require(ink['keyframes']['scale_x'] == [{'t':0,'v':cap['scale_x'],'easing':'linear'}], '자막 가로 배율 변형')
        for key in ('fill','stroke','stroke_width_px'):
            require(plate[key] == cap[key], '자막판 설정 변형: ' + key)
        require(near(plate['box_px'][1],cap['y_px']) and near(plate['box_px'][3],cap['height_px']), '자막판 위치/높이 불일치')
        require(plate['d'] == caption_plate_path(plate['box_px'][2],cap['height_px']), '자막판 모서리 형태 변형')
        require(plate['start_s'] == ink['start_s'] and plate['end_s'] == ink['end_s'], '자막판/잉크 표시 시각 불일치')
        x,y,w,h = row['ink_bbox'];px,py,pw,ph = plate['box_px']
        tol = cap['padding_tolerance_px']
        require(near(x-px,cap['padding_x_px'],tol) and near(px+pw-x-w,cap['padding_x_px'],tol)
                and y >= py and y+h <= py+ph and near(y-py,py+ph-y-h,tol), '자막 실제 잉크 여백 불균형/잘림')
        measurement_path = str(Path(row['measurement_path']).resolve())
        require(files.get(measurement_path) == row['measurement_sha256'], '실제 잉크 측정 입력 미등록')
        measurement = read(measurement_path)[row['text_node_id']]
        require(measurement['ink_bbox'] == row['ink_bbox'] and measurement['text'] == row['text']
                and measurement['font_sha256'] == cap['font_sha256'], '자막 측정 데이터 불일치')
    payload = {'rules':mdsha,'contract':digest(contract),'props':digest(props),
               'script':digest(script),'review':digest(review),'files':files}
    fingerprint = hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    return {'passed':True,'scope':'prepared_input_contract_only','fingerprint':fingerprint,
            'cuts':len(c['cuts']),'underlines':len(c['underlines']),'captions':len(c['captions']),
            'sentence_cuts': sentence_cuts,
            'visual_match':'not_observed','continuous_playback':'not_observed','direct_listening':'not_observed'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['script','check','render'])
    parser.add_argument('--rules',type=Path,default=DEFAULT_RULES)
    parser.add_argument('--package',type=Path,default=PACKAGE)
    for key in ('script','review','contract','props','report'):
        parser.add_argument('--'+key,type=Path,required=key in ('script','review'))
    import sys
    argv = sys.argv[1:]
    split = argv.index('--') if '--' in argv else len(argv)
    command = argv[split+1:] if split < len(argv) else []
    args = parser.parse_args(argv[:split])
    cfg, _, _ = load_rules(args.rules,args.package)
    if args.mode == 'script':
        script_gate(args.script,args.review,cfg)
        print(json.dumps({'passed':True,'scope':'script_review_binding_only'}))
        return
    require(args.contract and args.props and args.report, 'contract/props/report 필요')
    result = check(args.contract,args.props,args.script,args.review,args.rules,args.package)
    args.report.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    if args.mode == 'render':
        require(command, '렌더 실행 명령 누락')
        subprocess.run(command,check=True)
        after = check(args.contract,args.props,args.script,args.review,args.rules,args.package)
        require(after['fingerprint'] == result['fingerprint'], '렌더 실행 중 입력 변경')
    print(json.dumps(result,ensure_ascii=False))


if __name__ == '__main__':
    try:
        main()
    except (ContractError,KeyError,OSError,json.JSONDecodeError) as error:
        raise SystemExit('제작 계약 실패: '+str(error))
