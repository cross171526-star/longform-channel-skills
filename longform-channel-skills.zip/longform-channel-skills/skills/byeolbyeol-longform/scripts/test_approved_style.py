"""실제 확정본 측정·자산으로 재현 함수와 입력 보존을 확인한다."""
from pathlib import Path
import copy, json, tempfile, unittest
import approved_style as approved
import style_nodes as sn
import production_contract as pc

class StyleTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.package=Path(__file__).resolve().parents[1]
        cls.base,cls.lib=approved.load(cls.package)
        cls.cfg,_,cls.preset=pc.load_rules()

    def example(self,name):return next(e for e in self.lib['examples']if e['id']==name)

    def metric(self,e,id):return copy.deepcopy(e['text_measurements'][id]['chrome_measurement'])

    def font(self,name):
        path=self.package/'assets/approved-v3/fonts'/name
        return {'family':'verified-test','source_path':str(path),'sha256':pc.digest(path)}

    def test_real_caption_geometry_matches_approved_output(self):
        e=self.example('title');old=next(n for n in e['example_layers']if n['kind']=='text'and '_cap'in n['id']);m=self.metric(e,old['id'])
        nodes,ink=sn.caption_nodes('new_cap',m,self.font('NotoSansKR-Regular.ttf'),0,1,self.cfg,'new-measurement.json')
        self.assertEqual(nodes[1]['box_px'],old['box_px'])
        self.assertEqual(nodes[1]['keyframes'],old['keyframes'])
        oldplate=next(n for n in e['example_layers']if'_cap'in n['id']and n['kind']=='path')
        self.assertEqual(nodes[0]['d'],oldplate['d']);self.assertEqual(nodes[0]['box_px'],oldplate['box_px'])

    def test_real_bubble_body_and_tail_match_approved_output(self):
        e=self.example('paper_single');m=self.metric(e,'c004_bubble0');nodes,check=sn.bubble_nodes('new',m,self.font('Pretendard-Black.otf'),1280,220,.25,4.4,'geometry.json')
        old=next(n for n in e['example_layers']if n['id']=='c004_bubble0_bubble')
        self.assertEqual(nodes[0]['d'],old['d']);self.assertEqual(nodes[0]['box_px'],old['box_px'])
        self.assertEqual(check['padding_px'],[30]*4);self.assertFalse(check['tail_in_padding'])

    def test_fixed_underline_matches_approved_output(self):
        e=self.example('title');old=next(n for n in e['example_layers']if n['id']=='c001_claim_underline');ink=e['text_measurements']['c001_claim']['ink_bbox'];new=sn.underline_node(self.preset,'new','new_text',ink,old['start_s'],old['end_s'],35,self.cfg,'measure.json')
        for key in ['kind','fill','box_px','keyframes','z_index','clock_origin_s','visibility_windows_s']:self.assertEqual(new[key],old[key])

    def test_icon_asset_placement_and_clock_are_preserved(self):
        e=self.example('compare');old=next(n for n in e['example_layers']if n['id']=='c029_icon1');path=self.package/'assets/approved-v3/icons-hq/dollar.svg';new=sn.icon_node('new',path,old['start_s'],old['end_s'],'geometry.json',side=1)
        for key in ['kind','box_px','keyframes','z_index','start_s','end_s','clock_origin_s','visibility_windows_s']:self.assertEqual(new[key],old[key])
        self.assertEqual(new['media']['sha256'],old['media']['sha256'])

    def test_film_covers_clip_and_is_not_static(self):
        f=sorted((self.package/'assets/approved-v3/film').glob('*.png'));n=sn.film_node('film',f,5.25,self.cfg,'geometry.json')
        self.assertEqual(n['keyframes']['opacity'][0]['v'],.28);self.assertEqual(n['end_s'],5.25)
        self.assertEqual(n['texture_frames'][-1]['at_s'],5.2);self.assertGreater(len({x['media']['sha256']for x in n['texture_frames']}),1)

    def test_init_is_portable_and_does_not_overwrite(self):
        with tempfile.TemporaryDirectory()as t:
            p=Path(t)/'run';r=approved.initialize(p,self.package);self.assertEqual(r['templates'],9)
            for row in json.loads((p/'style-assets.json').read_text())['assets']:
                self.assertTrue(Path(row['path']).is_relative_to(p.resolve()));self.assertEqual(pc.digest(row['path']),row['sha256'])
            with self.assertRaises(ValueError):approved.initialize(p,self.package)

    def test_fixed_asset_tampering_is_rejected(self):
        with tempfile.TemporaryDirectory()as t:
            import shutil
            p=Path(t);shutil.copytree(self.package/'assets',p/'assets');shutil.copytree(self.package/'references',p/'references')
            (p/'assets/approved-v3/icons-hq/ship.svg').write_text('<svg/>')
            with self.assertRaises(ValueError):approved.load(p)

    def test_heading_overflow_is_not_hidden_by_shrinking(self):
        e=self.example('title');m=self.metric(e,'c001_event');m['ink_width']=1900
        with self.assertRaises(ValueError):sn.text_nodes('bad',m,self.font('NanumPenScript-Regular.ttf'),960,205,0,1,'geometry.json')

if __name__=='__main__':unittest.main(verbosity=2)
