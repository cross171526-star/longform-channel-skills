"""확정 영상의 고정 자산을 확인하고 새 실행에 독립 복사한다."""
from pathlib import Path
import argparse, hashlib, json, shutil

PACKAGE=Path(__file__).resolve().parents[1]

def digest(p):
    with Path(p).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()

def load(package=PACKAGE):
    package=Path(package);base=json.loads((package/'references/approved-v3/baseline.json').read_text())
    libfile=package/base['library']
    if digest(libfile)!=base['library_sha256']:raise ValueError('확정 스타일 라이브러리 해시 불일치')
    lib=json.loads(libfile.read_text())
    for row in base['renderer_files']:
        if digest(package/row['path'])!=row['sha256']:raise ValueError('확정 렌더러 변경: '+row['path'])
    for row in lib['fixed_assets']:
        p=package/row['path']
        if not p.is_file()or digest(p)!=row['sha256']:raise ValueError('고정 자산 변경/누락: '+row['path'])
    for row in lib['examples']:
        if digest(package/row['sample'])!=row['sample_sha256']:raise ValueError('기준 프레임 변경: '+row['sample'])
    return base,lib

def initialize(target,package=PACKAGE):
    target=Path(target);package=Path(package);base,lib=load(package)
    if target.exists():raise ValueError('기존 실행을 덮어쓰지 않는다. 새 출력 경로를 지정한다.')
    target.mkdir(parents=True)
    for name in ['approved-v3','remotion-template']:
        shutil.copytree(package/'assets'/name,target/'assets'/name)
    assets=[]
    for row in lib['fixed_assets']:
        assets.append({'path':str((target/row['path']).resolve()),'sha256':row['sha256']})
    (target/'style-assets.json').write_text(json.dumps({'baseline_video_sha256':base['video_sha256'],'assets':assets},ensure_ascii=False,indent=2)+'\n')
    return {'run':str(target.resolve()),'baseline_video_sha256':base['video_sha256'],'assets':len(assets),'templates':len(lib['examples'])}

def main():
    a=argparse.ArgumentParser(description=__doc__);a.add_argument('mode',choices=['check','init']);a.add_argument('--out');a.add_argument('--package',type=Path,default=PACKAGE);args=a.parse_args()
    if args.mode=='check':
        base,lib=load(args.package);result={'passed':True,'video_sha256':base['video_sha256'],'templates':len(lib['examples']),'fixed_assets':len(lib['fixed_assets'])}
    else:
        if not args.out:a.error('init에는 --out 새 실행 경로가 필요하다')
        result=initialize(args.out,args.package)
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
