const fs = require('fs');
const path = require('path');
const template = process.argv[4] ? path.resolve(process.argv[4]) : null;
if (!template) throw new Error('실행별 Remotion template 경로를 네 번째 인수로 전달해야 합니다');
const {openBrowser} = require(path.join(template, 'node_modules/@remotion/renderer'));
(async () => {
  const requests = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
  const fonts = [...new Map(requests.map(r => [r.family, r.font_path])).entries()].map(([family, file]) => ({family, data: 'data:font/ttf;base64,' + fs.readFileSync(file).toString('base64')}));
  const browser = await openBrowser('chrome', {logLevel: 'error'});
  try {
    const page = await browser.newPage({context: () => null, logLevel: 'error', indent: false, pageIndex: 0, onBrowserLog: null, onLog: () => {}});
    const measured = await page.evaluate(async (fonts, requests) => {
      for (const f of fonts) {const face = new FontFace(f.family, `url(${f.data})`); await face.load(); document.fonts.add(face);}
      await document.fonts.ready;
      const canvas = document.createElement('canvas'); const ctx = canvas.getContext('2d');
      return requests.map(r => {
        const div = document.createElement('div');
        Object.assign(div.style, {position: 'absolute', left: '0px', top: '0px', fontFamily: r.family, fontSize: r.size + 'px', fontWeight: String(r.weight), lineHeight: String(r.line_height), letterSpacing: r.spacing + 'px', whiteSpace: 'pre', width: '1800px', margin: '0', padding: '0'});
        const marker = document.createElement('span'); marker.style.display = 'inline-block'; marker.style.width = '0'; marker.style.height = '0';
        div.append(document.createTextNode(r.text.split('\n')[0]), marker); document.body.append(div);
        const baseline = marker.getBoundingClientRect().top - div.getBoundingClientRect().top;
        ctx.font = `${r.weight} ${r.size}px "${r.family}"`; ctx.letterSpacing = r.spacing + 'px';
        const lines = r.text.split('\n').map(text => {const m = ctx.measureText(text); return {text, width: m.width, left: m.actualBoundingBoxLeft, right: m.actualBoundingBoxRight, ascent: m.actualBoundingBoxAscent, descent: m.actualBoundingBoxDescent};});
        const advance = r.size * r.line_height;
        const top = Math.min(...lines.map((x, i) => baseline + i * advance - x.ascent));
        const bottom = Math.max(...lines.map((x, i) => baseline + i * advance + x.descent));
        const width = Math.max(...lines.map(x => x.width));
        const left = Math.min(...lines.map(x => (width - x.width) / 2 - x.left));
        const right = Math.max(...lines.map(x => (width - x.width) / 2 + x.right));
        div.remove(); return {...r, baseline, lines, advance_width: width, ink_box: [left, top, right, bottom], ink_width: right - left, ink_height: bottom - top};
      });
    }, fonts, requests);
    fs.writeFileSync(process.argv[3], JSON.stringify({method: 'actual loaded Chrome fonts + DOM baseline marker + Canvas glyph bounds', measured}, null, 2) + '\n', {flag: 'wx'});
    console.log(JSON.stringify({measured_texts: measured.length, actual_font_baselines: [...new Set(measured.map(x => `${x.family}:${x.size}:${x.baseline}`))].length}));
  } finally {await browser.close({silent: true});}
})().catch(e => {console.error(e.message); process.exitCode = 1;});
