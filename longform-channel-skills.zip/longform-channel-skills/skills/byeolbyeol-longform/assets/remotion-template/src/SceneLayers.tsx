import React from 'react';
import {Img, OffthreadVideo, Sequence, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {sampleKeyframes} from './easing';
import {validateScenes} from './sceneContract.cjs';
import type {SceneNode} from './types';

// Uses the existing cut Sequence clock. Hiding a retained node never restarts its keyframes.
export const SceneLayers: React.FC<{nodes: SceneNode[]; duration_s: number; diagnostic_only?: boolean}> = ({nodes, duration_s, diagnostic_only}) => {
  validateScenes(nodes, duration_s, diagnostic_only === true);
  const frame = useCurrentFrame(); const {fps} = useVideoConfig();
  return <>{nodes.map(n => <Node key={n.id} node={n} cutTime={frame / fps} />)}</>;
};
const Node: React.FC<{node: SceneNode; cutTime: number}> = ({node: n, cutTime: t}) => {
  const {fps} = useVideoConfig();
  if (t < n.start_s || t >= n.end_s || !n.visibility_windows_s.some(([a,b]) => a <= t && t < b)) return null;
  const kt = t - n.clock_origin_s;
  const v = (name: string, fallback: number) => sampleKeyframes(n.keyframes[name], kt, fallback);
  const [x,y,w,h] = n.box_px;
  const style: React.CSSProperties = {position:'absolute',left:x,top:y,width:w,height:h,zIndex:n.z_index,
    opacity:v('opacity',1),transformOrigin:`${n.origin_px[0]}px ${n.origin_px[1]}px`,
    transform:`translate(${v('x_px',0)}px,${v('y_px',0)}px) rotate(${v('rotation_deg',0)}deg) scale(${v('scale_x',1)},${v('scale_y',1)})`,
    filter:`blur(${v('blur_px',0)}px)`,mixBlendMode:n.blend,overflow:n.clip?'hidden':'visible',
    clipPath:n.keyframes.reveal_x || n.keyframes.reveal_y ? `inset(0 ${(1-v('reveal_x',1))*100}% ${(1-v('reveal_y',1))*100}% 0)` : undefined};
  let content: React.ReactNode;
  const fit: React.CSSProperties = {width:'100%',height:'100%',objectFit:'fill'};
  if (n.kind === 'group') content=n.children!.map(c=><Node key={c.id} node={c} cutTime={t} />);
  else if (n.kind === 'image') content=<Img src={staticFile(n.media!.file)} style={fit} />;
  else if (n.kind === 'video') content=<Sequence layout="none" from={Math.round(n.start_s*fps)}>
    <OffthreadVideo src={staticFile(n.media!.file)} muted playbackRate={n.speed!} trimBefore={Math.round(n.trim_start_s!*fps)} style={fit} />
  </Sequence>;
  else if (n.kind === 'texture_sequence') {
    const f=[...n.texture_frames!].reverse().find(f=>f.at_s<=kt)!;
    content=<Img src={staticFile(f.media.file)} style={fit} />;
  } else if (n.kind === 'rect') content=<div style={{width:'100%',height:'100%',background:n.fill,borderRadius:n.radius_px}} />;
  else if (n.kind === 'path') content=<svg width="100%" height="100%" viewBox={n.view_box} preserveAspectRatio="none"><path d={n.d} fill={n.fill} stroke={n.stroke} strokeWidth={n.stroke_width_px} pathLength={1} strokeDasharray={1} strokeDashoffset={1-v('stroke_progress',1)} /></svg>;
  else if (n.kind === 'text') content=<div style={{width:'100%',height:'100%',fontFamily:n.font!.family,fontSize:n.font_size_px,fontWeight:n.font_weight,color:n.color,textAlign:n.align,lineHeight:n.line_height,letterSpacing:n.letter_spacing_px,whiteSpace:'pre-wrap',textShadow:n.text_shadow,WebkitTextStroke:`${n.text_stroke!.width_px}px ${n.text_stroke!.color}`}}>{n.text}</div>;
  else throw new Error('Unsupported scene node');
  return <div data-scene-id={n.id} style={style}>{content}</div>;
};
