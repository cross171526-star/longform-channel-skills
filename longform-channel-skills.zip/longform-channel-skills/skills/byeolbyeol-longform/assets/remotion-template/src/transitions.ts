import type React from 'react';
import {random} from 'remotion';
import {easingOf} from './easing';

// Transition looks. Tune these against the reference filmstrips (frames/bounds_*.jpg) when compare.py
// shows a mismatch. p runs 0 -> 1 over the transition frames.
export const SUPPORTED_TRANSITIONS = [
  'cut', 'dissolve', 'fade_black', 'fade_white', 'flash_white', 'dip_color', 'slide_left', 'slide_right', 'slide_up',
  'slide_down', 'push_left', 'push_right', 'push_up', 'push_down', 'zoom_in', 'zoom_out', 'whip_pan', 'wipe', 'blur',
  'glitch', 'spin', 'luma_matte', 'shape_mask',
];

export type TransitionLook = {style: React.CSSProperties; overlay?: {color: string; opacity: number}};

const dir = (type: string): [number, number] => {
  if (type.endsWith('_left')) return [1, 0];
  if (type.endsWith('_right')) return [-1, 0];
  if (type.endsWith('_up')) return [0, 1];
  return [0, -1];
};

export const incoming = (type: string, rawP: number, easing?: string, color?: string, seed = 0): TransitionLook => {
  const p = easingOf(easing ?? 'ease_in_out')(Math.min(1, Math.max(0, rawP)));
  switch (type) {
    case 'dissolve':
      return {style: {opacity: p}};
    case 'fade_black':
    case 'fade_white':
    case 'flash_white':
    case 'dip_color': {
      const c = type === 'fade_black' ? '#000000' : type === 'dip_color' ? color ?? '#000000' : '#FFFFFF';
      return {style: {opacity: rawP < 0.5 ? 0 : 1}, overlay: {color: c, opacity: rawP < 0.5 ? rawP * 2 : 2 - rawP * 2}};
    }
    case 'slide_left':
    case 'slide_right':
    case 'slide_up':
    case 'slide_down':
    case 'push_left':
    case 'push_right':
    case 'push_up':
    case 'push_down': {
      const [dx, dy] = dir(type);
      return {style: {transform: `translate(${dx * (1 - p) * 100}%, ${dy * (1 - p) * 100}%)`}};
    }
    case 'whip_pan': {
      const [dx, dy] = dir('push_left');
      const blur = Math.sin(Math.PI * rawP) * 40;
      return {style: {transform: `translate(${dx * (1 - p) * 100}%, ${dy * (1 - p) * 100}%)`, filter: `blur(${blur}px)`}};
    }
    case 'zoom_in':
      return {style: {opacity: p, transform: `scale(${1.6 - 0.6 * p})`}};
    case 'zoom_out':
      return {style: {opacity: p, transform: `scale(${0.6 + 0.4 * p})`}};
    case 'wipe':
      return {style: {clipPath: `inset(0 ${(1 - p) * 100}% 0 0)`}};
    case 'blur':
      return {style: {opacity: p, filter: `blur(${(1 - p) * 30}px)`}};
    case 'glitch': {
      const j = rawP < 0.7 ? (random(`g${seed}-${Math.floor(rawP * 20)}`) - 0.5) * 60 : 0;
      return {style: {opacity: rawP < 0.35 ? 0.5 : 1, transform: `translateX(${j}px)`, filter: `hue-rotate(${j * 3}deg) saturate(${1 + Math.abs(j) / 20})`}};
    }
    case 'spin':
      return {style: {transform: `rotate(${(1 - p) * -180}deg) scale(${0.3 + 0.7 * p})`, opacity: p}};
    case 'luma_matte':
    case 'shape_mask':
      return {style: {clipPath: `circle(${p * 75}% at 50% 50%)`}};
    default:
      return {style: {opacity: p}};
  }
};

export const outgoing = (type: string, rawP: number, easing?: string): React.CSSProperties => {
  const p = easingOf(easing ?? 'ease_in_out')(Math.min(1, Math.max(0, rawP)));
  switch (type) {
    case 'push_left':
    case 'push_right':
    case 'push_up':
    case 'push_down':
    case 'whip_pan': {
      const [dx, dy] = dir(type === 'whip_pan' ? 'push_left' : type);
      const blur = type === 'whip_pan' ? Math.sin(Math.PI * rawP) * 40 : 0;
      return {transform: `translate(${-dx * p * 100}%, ${-dy * p * 100}%)`, filter: blur ? `blur(${blur}px)` : undefined};
    }
    case 'zoom_in':
      return {transform: `scale(${1 + 0.6 * p})`};
    case 'zoom_out':
      return {transform: `scale(${1 - 0.3 * p})`};
    case 'blur':
      return {filter: `blur(${p * 30}px)`};
    case 'spin':
      return {transform: `rotate(${p * 180}deg) scale(${1 - 0.7 * p})`};
    default:
      return {};
  }
};
