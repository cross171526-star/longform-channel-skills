import React from 'react';
import {CalculateMetadataFunction, Composition} from 'remotion';
import {Main} from './Main';
import {compositionFrames} from './cutTiming.cjs';
import type {MainProps} from './types';

const defaultProps: MainProps = {fps: 30, width: 1920, height: 1080, duration_s: 1, background: '#000000', cuts: [], texts: [], fonts: [], audio: null};

const calculateMetadata: CalculateMetadataFunction<MainProps> = ({props}) => ({
  fps: props.fps,
  width: props.width,
  height: props.height,
  durationInFrames: compositionFrames(props),
});

export const Root: React.FC = () => (
  <Composition
    id="Main"
    component={Main}
    defaultProps={defaultProps}
    calculateMetadata={calculateMetadata}
    fps={30}
    width={1920}
    height={1080}
    durationInFrames={30}
  />
);
