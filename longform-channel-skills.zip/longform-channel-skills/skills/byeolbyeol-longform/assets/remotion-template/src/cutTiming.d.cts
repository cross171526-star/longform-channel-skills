import type {MainProps} from './types';
export function frameOf(seconds: number, fps: number): number;
export function compositionFrames(props: MainProps): number;
export function cutSchedule(props: MainProps): Array<{id: string; from: number; end: number; tail: number; durationInFrames: number}>;
