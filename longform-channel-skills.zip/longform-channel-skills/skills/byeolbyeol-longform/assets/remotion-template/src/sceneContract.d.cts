export function validateScenes(nodes: unknown[], duration: number, allowDiagnostic?: boolean): unknown[];
export function authoredScene(nodes: unknown[]): unknown[];
export function sceneMedia(nodes: unknown[]): unknown[];
export function sceneFonts(nodes: unknown[]): unknown[];
