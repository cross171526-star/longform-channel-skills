// Strict scene contract shared by the actual renderer and its schedule inspector.
// Times are cut-relative; keyframe times are relative to clock_origin_s, not visibility windows.
const BASIC = ['opacity', 'scale_x', 'scale_y', 'x_px', 'y_px', 'rotation_deg', 'blur_px'];
const CHANNELS = [...BASIC, 'reveal_x', 'reveal_y', 'stroke_progress'];
const EASINGS = ['linear', 'ease_in', 'ease_out', 'ease_in_out', 'ease', 'back_out'];
const KINDS = ['group', 'image', 'video', 'rect', 'path', 'text', 'texture_sequence'];
const finite = (v) => typeof v === 'number' && Number.isFinite(v);
function need(c, m) {if (!c) throw new Error(m);}
function validateScenes(nodes, duration, allowDiagnostic = false, prefix = 'scene', ids = new Set()) {
  need(Array.isArray(nodes), prefix + ': nodes must be an explicit array');
  for (const n of nodes) {
    const label = prefix + ':' + n.id;
    const common = ['id','kind','start_s','end_s','clock_origin_s','visibility_windows_s','box_px','origin_px','z_index','blend','clip','measurement','keyframes'];
    const specific = {group:['children'],image:['media'],video:['media','trim_start_s','speed'],rect:['fill','radius_px'],path:['d','fill','stroke','stroke_width_px','view_box'],text:['text','font','font_size_px','font_weight','color','align','line_height','letter_spacing_px','text_shadow','text_stroke'],texture_sequence:['film_kind','texture_frames']};
    for (const key of Object.keys(n)) need([...common,...(specific[n.kind]??[])].includes(key), label + ': unsupported field ' + key);
    need(typeof n.id === 'string' && n.id && !ids.has(n.id), label + ': missing/duplicate id'); ids.add(n.id);
    need(KINDS.includes(n.kind), label + ': unsupported kind');
    need(finite(n.start_s) && finite(n.end_s) && 0 <= n.start_s && n.start_s < n.end_s && n.end_s <= duration + 1e-8, label + ': invalid interval');
    need(finite(n.clock_origin_s) && n.clock_origin_s <= n.start_s, label + ': missing/late clock origin');
    need(Array.isArray(n.box_px) && n.box_px.length === 4 && n.box_px.every(finite) && n.box_px[2] > 0 && n.box_px[3] > 0, label + ': missing measured box');
    need(Array.isArray(n.origin_px) && n.origin_px.length === 2 && n.origin_px.every(finite), label + ': missing transform origin');
    need(finite(n.z_index) && Number.isInteger(n.z_index), label + ': missing integer z_index');
    need(['normal','multiply','screen','overlay','darken','lighten'].includes(n.blend), label + ': missing/unsupported blend');
    need(typeof n.clip === 'boolean', label + ': explicit clip required');
    need(n.measurement && ['measured','diagnostic_fixture'].includes(n.measurement.status) && n.measurement.evidence, label + ': measured evidence required');
    need(allowDiagnostic || n.measurement.status === 'measured', label + ': diagnostic fixture cannot enter production');
    if (!allowDiagnostic) need(typeof n.measurement.evidence.file === 'string' && typeof n.measurement.evidence.pointer === 'string' && n.measurement.evidence.pointer.startsWith('/'), label + ': file/JSON Pointer evidence required');
    need(n.keyframes && typeof n.keyframes === 'object', label + ': keyframes required');
    for (const c of BASIC) need(Array.isArray(n.keyframes[c]) && n.keyframes[c].length > 0, label + ': missing ' + c);
    for (const [c, points] of Object.entries(n.keyframes)) {
      need(CHANNELS.includes(c) && Array.isArray(points) && points.length, label + ': unknown/empty channel');
      let prev = -Infinity;
      for (const p of points) {
        need(finite(p.t) && p.t >= 0 && p.t > prev && finite(p.v) && EASINGS.includes(p.easing), label + ': invalid/unknown keyframe');
        need(p.t <= n.end_s - n.clock_origin_s + 1e-8, label + ': keyframe outside lifetime'); prev = p.t;
        if (['opacity','reveal_x','reveal_y','stroke_progress'].includes(c)) need(p.v >= 0 && p.v <= 1, label + ': bounded channel outside 0..1');
        if (['scale_x','scale_y','blur_px'].includes(c)) need(p.v >= 0, label + ': negative scale/blur');
      }
      need(points[0].t === 0, label + ': channel must define initial value');
    }
    need(Array.isArray(n.visibility_windows_s) && n.visibility_windows_s.length, label + ': visibility windows required');
    let prior = n.start_s;
    for (const w of n.visibility_windows_s) {
      need(Array.isArray(w) && w.length === 2 && w.every(finite) && w[0] >= prior && w[1] > w[0] && w[1] <= n.end_s, label + ': invalid visibility'); prior = w[1];
    }
    const media = (m, kind) => {
      need(m && m.kind === kind && typeof m.source_path === 'string' && m.source_path.startsWith('/') && /^[a-f0-9]{64}$/.test(m.sha256), label + ': media identity required');
      for (const key of Object.keys(m)) need(['kind','source_path','sha256','file','duration_s'].includes(key), label + ': unsupported media field ' + key);
    };
    if (n.kind === 'image') media(n.media, 'image');
    if (n.kind === 'video') {
      media(n.media, 'video'); need(finite(n.media.duration_s) && n.media.duration_s > 0 && finite(n.trim_start_s) && n.trim_start_s >= 0 && finite(n.speed) && n.speed > 0, label + ': video timing required');
      need(n.trim_start_s + (n.end_s - n.start_s) * n.speed <= n.media.duration_s + 1e-8, label + ': video would exhaust; looping is forbidden');
    }
    if (n.kind === 'texture_sequence') {
      need(Array.isArray(n.texture_frames) && n.texture_frames.length, label + ': texture frames required'); let prev = -Infinity;
      for (const f of n.texture_frames) {need(finite(f.at_s) && f.at_s >= 0 && f.at_s > prev && f.at_s <= n.end_s - n.clock_origin_s, label + ': invalid texture time'); media(f.media, 'image'); prev = f.at_s;}
      need(n.texture_frames[0].at_s === 0, label + ': initial texture required');
      need(['gate','scratch','grain','vignette','other'].includes(n.film_kind), label + ': explicit film kind required');
    }
    if (n.kind === 'rect') need(typeof n.fill === 'string' && finite(n.radius_px) && n.radius_px >= 0, label + ': rect style required');
    if (n.kind === 'path') need(typeof n.d === 'string' && n.d && typeof n.fill === 'string' && typeof n.stroke === 'string' && finite(n.stroke_width_px) && n.stroke_width_px >= 0 && typeof n.view_box === 'string', label + ': path style required');
    if (n.kind === 'text') {
      need(typeof n.text === 'string' && n.font && typeof n.font.family === 'string' && typeof n.font.source_path === 'string' && n.font.source_path.startsWith('/') && /^[a-f0-9]{64}$/.test(n.font.sha256), label + ': text/font identity required');
      need(finite(n.font_size_px) && n.font_size_px > 0 && finite(n.font_weight) && typeof n.color === 'string' && ['left','center','right'].includes(n.align) && finite(n.line_height) && n.line_height > 0 && finite(n.letter_spacing_px) && typeof n.text_shadow === 'string' && n.text_stroke && finite(n.text_stroke.width_px) && typeof n.text_stroke.color === 'string', label + ': complete text style required');
    }
    if (n.kind === 'group') validateScenes(n.children, duration, allowDiagnostic, label, ids);
  }
  return nodes;
}
function authoredScene(nodes) {
  // Only the content-addressed public filename is preparation output. All semantic fields stay exact.
  const clean = JSON.parse(JSON.stringify(nodes));
  for (const n of clean) {
    if (n.media) delete n.media.file;
    for (const f of n.texture_frames ?? []) delete f.media.file;
    if (n.children) n.children = authoredScene(n.children);
  }
  return clean;
}
function sceneMedia(nodes) {
  return nodes.flatMap(n => [...(n.media ? [n.media] : []), ...(n.texture_frames ?? []).map(f => f.media), ...sceneMedia(n.children ?? [])]);
}
function sceneFonts(nodes) {return nodes.flatMap(n => [...(n.font ? [n.font] : []), ...sceneFonts(n.children ?? [])]);}
function sceneEvidence(nodes) {return nodes.flatMap(n => [n.measurement.evidence, ...sceneEvidence(n.children ?? [])]);}
module.exports = {validateScenes, authoredScene, sceneMedia, sceneFonts, sceneEvidence, BASIC};
