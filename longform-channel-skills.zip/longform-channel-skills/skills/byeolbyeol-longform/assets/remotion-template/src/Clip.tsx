import React from 'react';
import {AbsoluteFill, Img, Loop, OffthreadVideo, random, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {easingOf, sampleKeyframes} from './easing';
import {incoming, outgoing} from './transitions';
import type {Cut} from './types';
import {SceneLayers} from './SceneLayers';

const DIPS = ['fade_black', 'fade_white', 'flash_white', 'dip_color'];

// One source clip. The Sequence around it starts at cut.start_s and also covers the next cut's incoming
// transition, so the outgoing half of a transition is drawn here.
export const Clip: React.FC<{cut: Cut; next?: Cut; index: number; occupancyFrames: number}> = ({cut, next, index, occupancyFrames}) => {
  const frame = useCurrentFrame();
  const {fps, width, height} = useVideoConfig();
  const t = frame / fps;
  const dur = cut.end_s - cut.start_s;

  // measured keyframes; scale/x/y are relative to the first measured frame of the reference clip
  const kf = cut.keyframes;
  const s = sampleKeyframes(kf.scale, t, 1) * cut.layer.base_scale;
  const x = sampleKeyframes(kf.x, t, 0) * width;
  const y = sampleKeyframes(kf.y, t, 0) * height;
  const r = sampleKeyframes(kf.rotation_deg, t, 0);
  let opacity = sampleKeyframes(kf.opacity, t, 1);

  // clip in/out animation (separate from transitions)
  const an = cut.animation;
  let animTransform = '';
  let animFilter = '';
  const inS = an.in_s ?? 0.3;
  if (an.in && an.in !== 'none' && an.in !== 'unknown' && t < inS) {
    const p = easingOf('ease_out')(t / inS);
    if (an.in === 'fade') opacity *= p;
    if (an.in === 'pop_scale') animTransform += ` scale(${0.85 + 0.15 * easingOf('back_out')(t / inS)})`;
    if (an.in === 'scale_down') animTransform += ` scale(${1.15 - 0.15 * p})`;
    if (an.in === 'slide_up') animTransform += ` translateY(${(1 - p) * 8}%)`;
    if (an.in === 'slide_down') animTransform += ` translateY(${-(1 - p) * 8}%)`;
    if (an.in === 'slide_left') animTransform += ` translateX(${(1 - p) * 8}%)`;
    if (an.in === 'slide_right') animTransform += ` translateX(${-(1 - p) * 8}%)`;
    if (an.in === 'blur_in') animFilter += ` blur(${(1 - p) * 20}px)`;
  }
  const outS = an.out_s ?? 0.3;
  if (an.out && an.out !== 'none' && an.out !== 'unknown' && t > dur - outS && t <= dur) {
    const p = easingOf('ease_in')((t - (dur - outS)) / outS);
    if (an.out === 'fade') opacity *= 1 - p;
    if (an.out === 'blur_in') animFilter += ` blur(${p * 20}px)`;
  }

  const fx = cut.effects;
  const params = cut.effect_params ?? {};
  const shakeAmp = Number(params.shake?.amplitude_px ?? 8);
  const shake = fx.includes('shake')
    ? ` translate(${(random(`sx${index}-${frame}`) - 0.5) * 2 * shakeAmp}px, ${(random(`sy${index}-${frame}`) - 0.5) * 2 * shakeAmp}px)`
    : '';

  // incoming transition
  const inF = cut.transition_in?.frames ?? 0;
  let tStyle: React.CSSProperties = {};
  let tOverlay: {color: string; opacity: number} | undefined;
  if (inF > 0 && cut.transition_in.type !== 'cut' && frame < inF) {
    const look = incoming(cut.transition_in.type, frame / inF, cut.transition_in.easing, cut.transition_in.color, index);
    tStyle = look.style;
    tOverlay = look.overlay;
  }
  // outgoing half of the next transition
  const endF = occupancyFrames;
  const nt = next?.transition_in;
  const inOut = !!nt && nt.frames > 0 && nt.type !== 'cut' && frame >= endF;
  const oStyle: React.CSSProperties = inOut ? outgoing(nt!.type, (frame - endF) / nt!.frames, nt!.easing) : {};
  const outDip = inOut && DIPS.includes(nt!.type);
  const dipP = outDip ? (frame - endF) / Math.max(1, nt!.frames) : 0;

  const cg = params.color_grade ?? {};
  const filters = [
    fx.includes('color_grade') ? `saturate(${cg.saturate ?? 1}) contrast(${cg.contrast ?? 1}) brightness(${cg.brightness ?? 1}) hue-rotate(${cg.hue ?? 0}deg)` : '',
    fx.includes('black_white') ? 'grayscale(1)' : '',
    fx.includes('sepia') ? `sepia(${params.sepia?.amount ?? 0.8})` : '',
    fx.includes('glow') ? `brightness(1.05) drop-shadow(0 0 ${params.glow?.radius_px ?? 12}px rgba(255,255,255,0.35))` : '',
    animFilter,
  ].filter(Boolean).join(' ');

  const layerTransform = `translate(${x}px, ${y}px) rotate(${r}deg) scale(${s})${animTransform}${shake}`;
  const media = <Media cut={cut} fit={cut.layer.fit === 'cover' ? 'cover' : 'contain'} />;

  let body: React.ReactNode;
  if (cut.layer.fit === 'blur_background') {
    body = (
      <>
        <AbsoluteFill style={{filter: `blur(${params.blur_background?.radius_px ?? 40}px) brightness(0.8)`, transform: 'scale(1.15)'}}>
          <Media cut={cut} fit="cover" />
        </AbsoluteFill>
        <AbsoluteFill style={{transform: layerTransform, transformOrigin: '50% 50%'}}>{media}</AbsoluteFill>
      </>
    );
  } else if (cut.layer.fit === 'pip' && cut.layer.pip_box) {
    const [bx, by, bw, bh] = cut.layer.pip_box;
    body = (
      <AbsoluteFill style={{backgroundColor: cut.layer.background ?? 'transparent'}}>
        <div style={{position: 'absolute', left: bx * width, top: by * height, width: bw * width, height: bh * height, overflow: 'hidden', transform: layerTransform}}>
          <Media cut={cut} fit="cover" />
        </div>
      </AbsoluteFill>
    );
  } else {
    body = (
      <AbsoluteFill style={{backgroundColor: cut.layer.fit === 'contain' ? cut.layer.background ?? '#000' : undefined}}>
        <AbsoluteFill style={{transform: layerTransform, transformOrigin: '50% 50%'}}>{media}</AbsoluteFill>
      </AbsoluteFill>
    );
  }

  return (
    <AbsoluteFill style={oStyle}>
      <AbsoluteFill style={{overflow: 'hidden', opacity: outDip && dipP >= 0.5 ? 0 : cut.renderer_layers?.length ? 1 : opacity, filter: cut.renderer_layers?.length ? undefined : filters || undefined, ...tStyle}}>
        {cut.renderer_layers?.length ? <>
          <AbsoluteFill style={{opacity, filter: filters || undefined}}>{body}<Effects cut={cut} frame={frame} index={index} /></AbsoluteFill>
          <SceneLayers nodes={cut.renderer_layers} duration_s={dur} diagnostic_only={cut.diagnostic_only} />
        </> : <>{body}<Effects cut={cut} frame={frame} index={index} /></>}
      </AbsoluteFill>
      {tOverlay ? <AbsoluteFill style={{backgroundColor: tOverlay.color, opacity: tOverlay.opacity}} /> : null}
      {outDip ? (
        <AbsoluteFill
          style={{
            backgroundColor: nt!.type === 'fade_black' ? '#000' : nt!.type === 'dip_color' ? nt!.color ?? '#000' : '#fff',
            opacity: Math.min(1, dipP * 2),
          }}
        />
      ) : null}
    </AbsoluteFill>
  );
};

const Media: React.FC<{cut: Cut; fit: 'cover' | 'contain'}> = ({cut, fit}) => {
  const {fps} = useVideoConfig();
  const style: React.CSSProperties = {width: '100%', height: '100%', objectFit: fit};
  if (cut.asset.kind === 'image') return <Img src={staticFile(cut.asset.file)} style={style} />;
  const trim = Math.round(cut.trim_start_s * fps);
  const needFrames = Math.ceil((cut.end_s - cut.start_s) * fps * cut.speed) + trim + 1;
  const assetFrames = cut.asset.duration_s ? Math.floor(cut.asset.duration_s * fps) : needFrames;
  const video = (
    <OffthreadVideo src={staticFile(cut.asset.file)} muted playbackRate={cut.speed} trimBefore={trim > 0 ? trim : undefined} style={style} />
  );
  if (assetFrames - trim > 0 && assetFrames < needFrames) {
    return <Loop durationInFrames={Math.max(1, Math.floor((assetFrames - trim) / cut.speed))}>{video}</Loop>;
  }
  return video;
};

const Effects: React.FC<{cut: Cut; frame: number; index: number}> = ({cut, frame, index}) => {
  const {width, height, fps} = useVideoConfig();
  const fx = cut.effects;
  const p = cut.effect_params ?? {};
  const t = frame / fps;
  return (
    <>
      {fx.includes('vignette') ? (
        <AbsoluteFill
          style={{background: `radial-gradient(ellipse at center, rgba(0,0,0,0) ${Number(p.vignette?.inner ?? 55)}%, rgba(0,0,0,${p.vignette?.strength ?? 0.55}) 100%)`}}
        />
      ) : null}
      {fx.includes('film_grain') || fx.includes('vhs') ? (
        <AbsoluteFill style={{opacity: Number(p.film_grain?.opacity ?? 0.12), mixBlendMode: 'overlay'}}>
          <svg width={width} height={height}>
            <filter id={`grain${index}`}>
              <feTurbulence type="fractalNoise" baseFrequency={Number(p.film_grain?.frequency ?? 0.9)} numOctaves={2} seed={frame % 97} />
            </filter>
            <rect width="100%" height="100%" filter={`url(#grain${index})`} />
          </svg>
        </AbsoluteFill>
      ) : null}
      {fx.includes('light_leak') ? (
        <AbsoluteFill
          style={{
            background: `radial-gradient(circle at ${30 + 40 * Math.sin(frame / 40)}% 30%, rgba(255,160,60,${p.light_leak?.opacity ?? 0.35}), rgba(0,0,0,0) 60%)`,
            mixBlendMode: 'screen',
          }}
        />
      ) : null}
      {fx.includes('letterbox_bars') ? (
        <>
          <div style={{position: 'absolute', left: 0, top: 0, width, height: Number(p.letterbox_bars?.height_ratio ?? 0.1) * height, background: '#000'}} />
          <div style={{position: 'absolute', left: 0, bottom: 0, width, height: Number(p.letterbox_bars?.height_ratio ?? 0.1) * height, background: '#000'}} />
        </>
      ) : null}
      {fx.includes('overlay_texture') && p.overlay_texture?.file ? (
        <AbsoluteFill style={{mixBlendMode: (p.overlay_texture?.blend as React.CSSProperties['mixBlendMode']) ?? 'screen', opacity: Number(p.overlay_texture?.opacity ?? 0.5)}}>
          <Img src={staticFile(String(p.overlay_texture.file))} style={{width: '100%', height: '100%', objectFit: 'cover'}} />
        </AbsoluteFill>
      ) : null}
      {cut.overlays.map((o, i) => {
        if (!o.box) return null;
        if (o.start_s !== undefined && t < o.start_s) return null;
        if (o.end_s !== undefined && t > o.end_s) return null;
        const [bx, by, bw, bh] = o.box;
        const style: React.CSSProperties = {position: 'absolute', left: bx * width, top: by * height, width: bw * width, height: bh * height};
        const color = o.color ?? '#FF2D2D';
        if (o.kind === 'circle') return <div key={i} style={{...style, border: `6px solid ${color}`, borderRadius: '50%'}} />;
        if (o.kind === 'underline') return <div key={i} style={{...style, borderBottom: `8px solid ${color}`}} />;
        if (o.kind === 'arrow')
          return (
            <svg key={i} style={style} viewBox="0 0 100 100" preserveAspectRatio="none">
              <path d="M5 50 L80 50 M60 25 L85 50 L60 75" stroke={color} strokeWidth={10} fill="none" />
            </svg>
          );
        return <div key={i} style={{...style, border: `4px solid ${color}`}} />;
      })}
    </>
  );
};
