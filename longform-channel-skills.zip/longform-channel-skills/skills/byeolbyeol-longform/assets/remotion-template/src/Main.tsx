import {loadFont} from '@remotion/fonts';
import React from 'react';
import {AbsoluteFill, Html5Audio, Img, Sequence, staticFile, useVideoConfig} from 'remotion';
import {Clip} from './Clip';
import {cutSchedule} from './cutTiming.cjs';
import {TextLayer} from './TextLayer';
import type {MainProps} from './types';

const loaded = new Set<string>();
const ensureFonts = (fonts: MainProps['fonts']) => {
  for (const f of fonts) {
    if (loaded.has(f.family)) continue;
    loaded.add(f.family);
    loadFont({family: f.family, url: staticFile(f.file)});
  }
};

export const Main: React.FC<MainProps> = (props) => {
  const {fps} = useVideoConfig();
  ensureFonts(props.fonts);
  const toF = (s: number) => Math.round(s * fps);
  const schedule = cutSchedule(props);
  return (
    <AbsoluteFill style={{backgroundColor: props.background}}>
      {props.cuts.map((cut, i) => {
        const next = props.cuts[i + 1];
        const {from, durationInFrames: dur} = schedule[i];
        return (
          <Sequence key={cut.id} from={from} durationInFrames={dur} premountFor={Math.round(fps)} name={cut.id}>
            <Clip cut={cut} next={next} index={i} occupancyFrames={schedule[i].end - from} />
          </Sequence>
        );
      })}
      {(props.chrome ?? []).map((c) => (
        <Sequence key={c.id} from={toF(c.start_s)} durationInFrames={Math.max(1, toF(c.end_s) - toF(c.start_s))} name={c.id}>
          <AbsoluteFill style={{pointerEvents: 'none'}}>
            {c.image ? (
              <Img src={staticFile(c.image)} style={{position: 'absolute', left: c.rect_px[0], top: c.rect_px[1],
                width: c.rect_px[2], height: c.rect_px[3], objectFit: 'contain'}} />
            ) : (
              <div style={{position: 'absolute', left: c.rect_px[0], top: c.rect_px[1], width: c.rect_px[2],
                height: c.rect_px[3], background: c.color ?? '#000', opacity: c.alpha ?? 1, borderRadius: c.radius_px ?? 0}} />
            )}
          </AbsoluteFill>
        </Sequence>
      ))}
      {props.texts.map((item) => (
        <Sequence key={item.id} from={toF(item.start_s)} durationInFrames={Math.max(1, toF(item.end_s) - toF(item.start_s))} name={item.id}>
          <TextLayer item={item} />
        </Sequence>
      ))}
      {props.audio ? <Html5Audio src={staticFile(props.audio)} /> : null}
    </AbsoluteFill>
  );
};
