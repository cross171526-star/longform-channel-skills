// Shared by Main, Root, and the pre-render validator. No separately maintained schedule.
function frameOf(seconds, fps) { return Math.round(seconds * fps); }
function compositionFrames(props) {
  if (!Number.isFinite(props.fps) || props.fps <= 0 || !Number.isFinite(props.duration_s) || props.duration_s <= 0) throw new Error('Invalid composition timing');
  return Math.max(1, frameOf(props.duration_s, props.fps));
}
function cutSchedule(props) {
  compositionFrames(props);
  const ids = new Set();
  return props.cuts.map((cut, index) => {
    if (!cut.id || ids.has(cut.id)) throw new Error('Missing/duplicate render cut ID');
    ids.add(cut.id);
    if (!Number.isFinite(cut.start_s) || !Number.isFinite(cut.end_s) || cut.start_s < 0 || cut.end_s <= cut.start_s) throw new Error('Invalid render cut interval');
    const from = frameOf(cut.start_s, props.fps);
    const end = frameOf(cut.end_s, props.fps);
    const next = props.cuts[index + 1];
    const tail = next ? next.transition_in?.frames ?? 0 : 0;
    if (!Number.isInteger(tail) || tail < 0 || end <= from) throw new Error('Invalid render frame interval/transition');
    return {id: cut.id, from, end, tail, durationInFrames: end - from + tail};
  });
}
module.exports = {frameOf, compositionFrames, cutSchedule};
