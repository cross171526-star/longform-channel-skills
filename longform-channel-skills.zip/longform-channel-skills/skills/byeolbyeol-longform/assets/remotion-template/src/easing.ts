import {Easing} from 'remotion';

// Easing names used in analysis JSON -> Remotion easing functions.
export const easingOf = (name?: string | null): ((t: number) => number) => {
  switch (name) {
    case 'ease_in':
      return Easing.in(Easing.cubic);
    case 'ease_out':
      return Easing.out(Easing.cubic);
    case 'ease_in_out':
      return Easing.inOut(Easing.cubic);
    case 'ease':
      return Easing.ease;
    case 'back_out':
      return Easing.out(Easing.back(1.6));
    default:
      return Easing.linear;
  }
};

// Piecewise interpolation over keyframes; each segment uses the easing of its end keyframe.
export const sampleKeyframes = (kfs: {t: number; v: number; easing?: string}[] | undefined, t: number, fallback: number): number => {
  if (!kfs || kfs.length === 0) return fallback;
  if (t <= kfs[0].t) return kfs[0].v;
  const last = kfs[kfs.length - 1];
  if (t >= last.t) return last.v;
  for (let i = 1; i < kfs.length; i++) {
    const a = kfs[i - 1];
    const b = kfs[i];
    if (t <= b.t) {
      const span = b.t - a.t || 1e-6;
      const u = easingOf(b.easing)((t - a.t) / span);
      return a.v + (b.v - a.v) * u;
    }
  }
  return last.v;
};
