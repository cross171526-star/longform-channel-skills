// Props written by scripts/build_timeline.py. Times are seconds on the output timeline.
export type Keyframe = {t: number; v: number; easing?: string};
export type Keyframes = Partial<Record<'scale' | 'x' | 'y' | 'rotation_deg' | 'opacity', Keyframe[]>>;

export type Transition = {type: string; frames: number; easing?: string; color?: string};

export type Asset = {file: string; kind: 'video' | 'image'; duration_s?: number};

export type Cut = {
  id: string;
  start_s: number;
  end_s: number;
  asset: Asset;
  layer: {fit: 'cover' | 'contain' | 'blur_background' | 'pip' | 'split'; background?: string; pip_box?: number[]; base_scale: number};
  keyframes: Keyframes;
  trim_start_s: number;
  speed: number;
  effects: string[];
  effect_params: Record<string, Record<string, number | string>>;
  animation: {in?: string | null; in_s?: number | null; out?: string | null; out_s?: number | null};
  transition_in: Transition;
  overlays: Overlay[];
  renderer_layers?: SceneNode[];
  diagnostic_only?: boolean;
};

// Measured independent layers. Numeric channels are explicit even for static nodes.
export type SceneMedia = Asset & {source_path: string; sha256: string};
export type SceneNode = {
  id: string; kind: 'group'|'image'|'video'|'rect'|'path'|'text'|'texture_sequence';
  start_s: number; end_s: number; clock_origin_s: number;
  visibility_windows_s: [number,number][]; box_px: [number,number,number,number];
  origin_px: [number,number]; z_index: number; blend: React.CSSProperties['mixBlendMode']; clip: boolean;
  measurement: {status: 'measured'|'diagnostic_fixture'; evidence: unknown};
  keyframes: Record<string, Keyframe[]>; children?: SceneNode[]; media?: SceneMedia;
  trim_start_s?: number; speed?: number;
  texture_frames?: {at_s: number; media: SceneMedia}[]; film_kind?: string;
  fill?: string; radius_px?: number; d?: string; view_box?: string; stroke?: string; stroke_width_px?: number;
  text?: string; font?: {family: string; source_path: string; sha256: string}; font_size_px?: number;
  font_weight?: number; color?: string; align?: 'left'|'center'|'right'; line_height?: number;
  letter_spacing_px?: number; text_shadow?: string; text_stroke?: {width_px: number; color: string};
};

export type Overlay = {kind: string; box?: number[]; color?: string; start_s?: number; end_s?: number};

export type TextItem = {
  id: string;
  kind: 'text' | 'credit';
  text: string;
  start_s: number;
  end_s: number;
  family: string;
  font_size_px: number;
  weight?: number;
  color: string;
  stroke?: {color: string; width_px: number} | null;
  shadow?: string | null;
  box?: {color: string; pad_x_px: number; pad_top_px: number; pad_bottom_px: number; radius_px?: number;
         alpha?: number; bars?: {side: 'left' | 'right'; w_px: number; color: string; inset_px?: number}[]} | null;
  align: 'left' | 'center' | 'right';
  anchor_px: {x: number; y: number};
  ink_dy_px: number;
  animation: {in?: string | null; in_s?: number | null; out?: string | null; out_s?: number | null; growth?: [number, number][] | null};
};

export type FontFile = {family: string; file: string};

// persistent screen chrome (own logo / icon image, or a plate) placed in the reference rect
export type Overlay2 = {id: string; start_s: number; end_s: number; rect_px: [number, number, number, number];
  image?: string | null; color?: string | null; alpha?: number | null; radius_px?: number | null};

export type MainProps = {
  fps: number;
  width: number;
  height: number;
  duration_s: number;
  background: string;
  cuts: Cut[];
  texts: TextItem[];
  fonts: FontFile[];
  chrome?: Overlay2[];
  audio?: string | null;
};
