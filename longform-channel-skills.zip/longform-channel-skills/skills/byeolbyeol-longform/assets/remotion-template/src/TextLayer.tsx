import React from 'react';
import {useCurrentFrame, useVideoConfig} from 'remotion';
import {easingOf} from './easing';
import type {TextItem} from './types';

// Burned-in text: subtitles, keyword pop-ups, titles and source credits (credits only exist where the reference
// shows one). anchor_px is the reference box position on the 1920x1080 canvas: x at the alignment edge/centre,
// y at the vertical centre of the text box.
export const TextLayer: React.FC<{item: TextItem}> = ({item}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;
  const dur = item.end_s - item.start_s;
  const an = item.animation ?? {};
  const inS = an.in_s && an.in_s > 0 ? an.in_s : 0.25;
  let opacity = 1;
  let transform = '';
  let filter = '';
  let text = item.text;
  const fs = item.font_size_px;

  if (an.in && t < inS) {
    const p = Math.min(1, t / inS);
    const eo = easingOf('ease_out')(p);
    switch (an.in) {
      case 'fade':
        opacity = eo;
        break;
      case 'pop_scale':
        transform += ` scale(${0.6 + 0.4 * easingOf('back_out')(p)})`;
        opacity = Math.min(1, p * 3);
        break;
      case 'scale_down':
        transform += ` scale(${1.3 - 0.3 * eo})`;
        opacity = Math.min(1, p * 2);
        break;
      case 'slide_up':
        transform += ` translateY(${(1 - eo) * fs * 0.8}px)`;
        opacity = eo;
        break;
      case 'slide_down':
        transform += ` translateY(${-(1 - eo) * fs * 0.8}px)`;
        opacity = eo;
        break;
      case 'slide_left':
        transform += ` translateX(${(1 - eo) * fs * 2}px)`;
        opacity = eo;
        break;
      case 'slide_right':
        transform += ` translateX(${-(1 - eo) * fs * 2}px)`;
        opacity = eo;
        break;
      case 'blur_in':
        filter = `blur(${(1 - p) * 12}px)`;
        opacity = p;
        break;
      case 'bounce':
        transform += ` translateY(${-Math.abs(Math.sin(p * Math.PI * 2)) * (1 - p) * fs * 0.5}px)`;
        break;
      default:
        break;
    }
  }
  if (an.in === 'typewriter' || an.in === 'word_by_word') {
    // reveal by the measured character growth [(t, chars)] when present, otherwise linearly over in_s
    const chars = [...item.text.replace(/\s/g, '')].length;
    let shown = chars;
    if (an.growth && an.growth.length > 1) {
      shown = an.growth[0][1];
      for (const [gt, n] of an.growth) if (gt <= t) shown = n;
    } else {
      shown = Math.ceil(chars * Math.min(1, t / inS));
    }
    let count = 0;
    const out: string[] = [];
    if (an.in === 'word_by_word') {
      for (const w of item.text.split(' ')) {
        if (count >= shown) break;
        out.push(w);
        count += [...w].length;
      }
      text = out.join(' ');
    } else {
      for (const ch of [...item.text]) {
        if (count >= shown) break;
        out.push(ch);
        if (ch.trim()) count++;
      }
      text = out.join('');
    }
  }
  const outS = an.out_s ?? 0.15;
  if (an.out === 'fade' && t > dur - outS) opacity *= Math.max(0, (dur - t) / outS);

  const stroke = item.stroke;
  const box = item.box;
  const tx = item.align === 'center' ? '-50%' : item.align === 'right' ? '-100%' : '0%';
  // plate colour with measured transparency (see-through subtitle plates are common)
  const hexA = (hex: string, a: number) => {
    const h = hex.replace('#', '');
    const n = h.length === 3 ? h.split('').map((c) => c + c).join('') : h.slice(0, 6);
    const r = parseInt(n.slice(0, 2), 16), g = parseInt(n.slice(2, 4), 16), b = parseInt(n.slice(4, 6), 16);
    return `rgba(${r}, ${g}, ${b}, ${a})`;
  };
  const boxColor = box ? (box.alpha != null && box.alpha < 1 ? hexA(box.color, box.alpha) : box.color) : undefined;
  return (
    <div
      style={{
        position: 'absolute',
        left: item.anchor_px.x,
        top: item.anchor_px.y + item.ink_dy_px,
        transform: `translate(${tx}, -50%)${transform}`,
        transformOrigin: 'center center',
        opacity,
        filter: filter || undefined,
        whiteSpace: 'pre',
      }}
    >
      <span
        style={{
          fontFamily: `'${item.family}'`,
          fontSize: fs,
          fontWeight: item.weight ?? 400,
          lineHeight: 1.15,
          color: item.color,
          WebkitTextStroke: stroke ? `${stroke.width_px * 2}px ${stroke.color}` : undefined,
          paintOrder: stroke ? 'stroke fill' : undefined,
          textShadow: item.shadow ?? undefined,
          backgroundColor: boxColor,
          padding: box ? `${box.pad_top_px}px ${box.pad_x_px}px ${box.pad_bottom_px}px` : undefined,
          borderRadius: box?.radius_px,
          display: 'inline-block',
          position: 'relative',
        }}
      >
        {box?.bars?.map((b, i) => (
          <span key={i} style={{position: 'absolute', top: 0, bottom: 0, width: b.w_px, background: b.color,
            [b.side]: b.inset_px ?? 0} as React.CSSProperties} />
        ))}
        {text.length ? text : '\u00A0'}
      </span>
    </div>
  );
};
