from pathlib import Path
import json
from PIL import Image
import numpy as np
from render_v7 import Renderer
S=Path(__file__).resolve().parents[1];p=S/'assets/v7-example';r=Renderer(p/'timeline.json');times=json.loads((p/'check-times.json').read_text())
for i,t in enumerate(times):
 expected=np.asarray(Image.open(p/f'expected/{i:03}.png'));actual=np.asarray(r.frame(t));assert np.array_equal(expected,actual),f'Frame mismatch at {t}'
print(f'PASS: {len(times)} timestamps exactly match approved v7 renderer, including opening, captions, and zoom ramp.')
