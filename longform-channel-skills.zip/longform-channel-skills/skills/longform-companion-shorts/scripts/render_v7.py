from pathlib import Path
from PIL import Image,ImageFont,ImageDraw
import json,math,subprocess,argparse,shutil
F=Path(__file__).resolve().parents[1]/'assets/fonts'
W,H=1080,972
def font(n,s):return ImageFont.truetype(str(F/n),s)
def glyph(txt,height,col,fn='Pretendard-Black.otf',maxw=980):
 ft=font(fn,180);b=ft.getbbox(txt);im=Image.new('RGBA',(b[2]-b[0]+8,b[3]-b[1]+8));ImageDraw.Draw(im).text((4-b[0],4-b[1]),txt,font=ft,fill=col);im=im.crop(im.getbbox());scale=min(height/im.height,maxw/im.width);return im.resize((round(im.width*scale),round(im.height*scale)),Image.Resampling.LANCZOS)
def put(out,im,x,y):out.paste(im,(round(x),round(y)),im if im.mode=='RGBA' else None)
def text(out,txt,x,y,h=75,col='white',fn='Pretendard-Black.otf',maxw=960):
 im=glyph(txt,h,col,fn,maxw);put(out,im,x-im.width/2,y);return im.size

def zoom(im,z,anchor):
 return im.transform((W,H),Image.Transform.AFFINE,(1/z,0,anchor[0]*(1-1/z),0,1/z,anchor[1]*(1-1/z)),Image.Resampling.BICUBIC)
class Renderer:
 def __init__(self,timeline):
  self.path=Path(timeline);self.t=json.loads(self.path.read_text());t=self.t
  assert t.get('style')=='grb-v7','Use v7 timeline contract'
  assert t['fps']==60 and len(t['title'])==2
  assert t['cuts'][0]['start']==0 and t['captions'][0]['start']==0
  assert abs(t['cuts'][-1]['end']-t['duration'])<.02
  for a,b in zip(t['cuts'],t['cuts'][1:]):assert abs(a['end']-b['start'])<.02
  self.head=Image.new('RGB',(1080,474),'black')
  for txt,y,h,col in zip(t['title'],[203,330],[104,128],['white','#f9ed00']):text(self.head,txt,540,y,h,col,'BlackHanSans-Regular.ttf',940)
  self.panels=[]
  for c in t['cuts']:
   im=Image.open(self.path.parent/c['panel']).convert('RGB');assert im.size==(1080,972),c['panel'];self.panels.append(im)
  self.caps=[]
  for c in t['captions']:
   if c['style']=='opening':self.caps.append(None);continue
   im=glyph(c['text'],70,'white' if c['style']=='white' else '#fdee00',maxw=984);box=Image.new('RGB',(im.width+32,102),'black');put(box,im,16,(102-im.height)//2);self.caps.append(box)
 def frame(self,t):
  T=self.t;i=max(j for j,c in enumerate(T['cuts']) if c['start']<=t);c=T['cuts'][i];dt=t-c['start'];pa=self.panels[i].copy()
  for o in c.get('overlays',[]):
   if dt>=o.get('at',0):text(pa,o['text'],o['x'],o['y'],o['height'],o.get('color','white'),o.get('font','Pretendard-Black.otf'),o.get('maxw',960))
  if c.get('opening_text'):
   ImageDraw.Draw(pa).rectangle((0,416,1080,528),fill='#101010');text(pa,c['opening_text'],540,449,40,'#b8b8b8',maxw=1000)
  z=1+.018*dt
  if c.get('emphasis'):z*=(1+min(1,dt/(10/60)))
  pa=zoom(pa,z,c.get('anchor',[540,240]));out=Image.new('RGB',(1080,1920),'black');out.paste(self.head,(0,0));out.paste(pa,(0,474))
  k=max(j for j,c in enumerate(T['captions']) if c['start']<=t);cap=self.caps[k]
  if cap is not None:out.paste(cap,((1080-cap.width)//2,1320))
  if t>=T['duration']-2.7 and T.get('cta',True):text(out,T.get('cta_text','전체 이야기는 관련 영상에서'),540,1540,35,'#cecece',maxw=960)
  return out
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('timeline');p.add_argument('--preview');p.add_argument('--time',type=float,default=0);p.add_argument('--audio');p.add_argument('--out');p.add_argument('--ffmpeg',default=shutil.which('ffmpeg'));a=p.parse_args();r=Renderer(a.timeline)
 if a.preview:r.frame(a.time).save(a.preview)
 else:
  assert a.audio and a.out and a.ffmpeg,'Provide --audio --out --ffmpeg'
  out=Path(a.out);out.parent.mkdir(parents=True,exist_ok=True)
  cmd=[a.ffmpeg,'-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','1080x1920','-r','60','-i','-','-i',a.audio,'-map','0:v:0','-map','1:a:0','-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p','-c:a','aac','-b:a','256k','-t',str(r.t['duration']),'-movflags','+faststart',str(out)]
  proc=subprocess.Popen(cmd,stdin=subprocess.PIPE)
  try:
   for k in range(round(r.t['duration']*60)):proc.stdin.write(r.frame(k/60).tobytes())
  finally:proc.stdin.close()
  assert proc.wait()==0,'ffmpeg failed'
