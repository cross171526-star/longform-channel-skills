from pathlib import Path
import argparse,json
import numpy as np
import soundfile as sf

def mix(cues_path,voice=None,music=None,extra_db=0):
 p=Path(cues_path);c=json.loads(p.read_text());sr=48000;n=round(c['duration']*sr);fx=np.zeros((n,2))
 def read(path):
  a,rate=sf.read(path,always_2d=True);assert rate==sr,'Inputs must be 48kHz';return np.repeat(a,2,axis=1) if a.shape[1]==1 else a[:,:2]
 for cue in c['cues']:
  a=read(p.parent/cue['path'])*10**((cue['gain_db']+extra_db)/20);i=round(cue['start']*sr);assert 0<=i<n
  a=a[:n-i];fx[i:i+len(a)]+=a
 out=fx.copy()
 for path in [voice,music]:
  if path:
   a=read(path);out[:min(n,len(a))]+=a[:n]
 assert np.max(np.abs(out))<1,'Clipping: adjust SFX cues; do not lower voice/music silently'
 return out,fx,sr
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('cues');p.add_argument('--voice');p.add_argument('--music');p.add_argument('--extra-db',type=float,default=0);p.add_argument('--out',required=True);a=p.parse_args();out,fx,sr=mix(a.cues,a.voice,a.music,a.extra_db);sf.write(a.out,out,sr,subtype='PCM_24');sf.write(str(Path(a.out).with_suffix('.sfx.wav')),fx,sr,subtype='PCM_24')
