# v7 실행 템플릿

이 패키지의 scripts/assets를 실행 작업 폴더로 복사해 사용한다. 스킬 설치 원본을 직접 수정하며 영상을 만들지 않는다. Python(Pillow, numpy, soundfile), FFmpeg가 필요하다. 현재 환경의 Python은 `~/.longform-cloner/venv/bin/python`, FFmpeg는 `~/.longform-cloner/bin/ffmpeg`이며 다른 환경은 실제 설치 경로를 찾는다.

## 먼저 기준 출력 확인

```
python scripts/check_v7.py
python scripts/render_v7.py assets/v7-example/timeline.json --time 11.66 --preview example.png
```

check_v7는 승인 영상 v7과 같은 화면을 만든 원본 렌더러에서 추출한 42시점의 무손실 프레임과 픽셀 단위로 비교한다. 최종 MP4에는 압축 오차가 있으므로 MP4 픽셀과 일치한다는 뜻은 아니다. 이 검사만으로 새 작품의 자료·구도·대본 품질이 통과된 것은 아니다.

## 새 주제를 넣는 방법

1. `assets/v7-example/timeline.json`의 구조를 복사한다. `style: grb-v7`, 60fps를 유지한다. 제목 2줄, duration, cuts, captions를 새 음성에 맞게 바꾼다. 컷 수와 러닝타임은 새 내용에 맞춘다.
2. 각 컷의 `panel`은 **제목·하단 자막을 제외한 1080×972 합성 자료 이미지**다. 경로는 timeline.json 기준이다. 새로운 배경/인물/사진/소품을 합성해 만든다. 표준 인물은 중앙, 선택 구간은 인물 얼굴을 확대하고, 회상은 인물과 사진을 나란히 두는 등 승인 예제의 구도 역할을 재사용한다. 예제 패널은 기준 자료이지 새 주제에 그대로 쓰는 재료가 아니다.
3. cut의 start/end는 연속, 첫 시각은0, 마지막은 duration과 일치시킨다. `anchor: [540,240]` 기본, 숫자/도입 타이포는 `[540,480]`. `emphasis: true`는10프레임 약2배 확대 후 유지하므로 실제 핵심 선택 구간에 배치한다.
4. `opening_text`가 있는 컷은 v7의 도입 제목판을 만든다. 예제 도입은1.9초이나 새 발화에 맞춰 길이를 조정한다. 정적 자료만 나열하지 말고 인물·사진·숫자·실제 영상 캡처·감정 컷을 서사에 맞게 전개한다.
5. `overlays`는 panel 영역 기준 텍스트이며 at초 뒤 공개된다. 제목/자막은 렌더러가 따로 올리므로 panel에 중복 삽입하지 않는다.
6. captions의 start/end/text/style을 새 최종 음성에 맞춘다. style은 white 또는 강조 yellow, 도입은 opening. 자막·자료 타임라인이 음성과 어긋나지 않는지 확인한다. CTA는 마지막2.7초에 자동 표시된다.

```
python scripts/render_v7.py RUN/timeline.json --audio RUN/mix.wav --out RUN/final.mp4 --ffmpeg /actual/path/ffmpeg
```

새 작품의 도입·인물·소품·사진·강조 확대 전후·결말 프레임을 기준 예제와 나란히 확인한다. 제목/자료/자막 경계와 글자색·실제 크기를 비교한다. 사용자에게 별도 파일럿 승인을 요구할 필요는 없다. 결과 확인 후 바로 완성 파일을 전달한다.

## 승인 음향의 재사용

`assets/v7-example/mix-cues.json`과 `sfx/`는 v7에 실제 사용한25큐의 정규화 소스와 최종 개별 gain을 담는다. sound-cues.json의 과거 버스값을 여기에 다시 더하지 않는다. 브금·화자는 별도 입력이며 음악 파일은 동봉하지 않았다. 같은 프로젝트의 기존 blue와 음성을 유지하고, 새 프로젝트는 사용자 음악 지시를 확인한다.

```
python scripts/mix_v7.py RUN/mix-cues.json --voice RUN/voice.wav --music RUN/music.wav --out RUN/mix.wav
```

입력은48kHz이며 voice/music은 이미 적절한 레벨로 맞춘 스템이다. 새 내레이션에는 예제의 시각을 그대로 적용하지 않는다. source 파일·start·gain_db를 사건에 맞게 교체한다. 첫 큐는0초 집중 효과음, 경기 시작에는 종, 승리에는 환호, 감정 구간에는 절제를 유지한다. 복싱이 아닌 주제에 종을 자동으로 쓰지 않는다. 저장된 gain은 현재 적용값이며 '4dB 더' 요청 때만 `--extra-db 4`를 쓴다. 믹서가 클리핑을 보고하면 해당 효과음을 조정하며 음성·브금 전체를 조용히 낮추지 않는다.

동봉 외부 음원의 출처는 `assets/v7-example/sfx-attribution.txt`에 있으며 사용할 때 결과물 설명글용 크레딧에 옮긴다. 출처에 따라 현장음과 추가 효과음을 구분한다. 이 예제의 사진/생성 인물은 v7 재현 확인용이며 다른 주제나 무관한 작품에 재사용하지 않는다.
