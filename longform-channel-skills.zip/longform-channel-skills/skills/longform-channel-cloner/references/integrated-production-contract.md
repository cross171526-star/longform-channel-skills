> 구형 실행 참조: 2026-10-06 이후 `tts-first-v1` 신규 제작에는 이 문서의 주제/파일럿/독립 승인·고정 컷 80~120%·중앙 graph 절차를 적용하지 않는다. 현재 실행은 [production-guide.md](production-guide.md)를 따른다. 아래는 기존 스냅샷 결과 해석을 위해 보존한다.

# 신규 실행의 작업·품질·개정 계약

`runtime init`의 `scheduler_version:3`은 작업 수 제한을 제거했다. 품질·graph 게이트는 기존 version2부터 유지한다. 이미 실행 중인 고정 스냅샷·등록·자동화는 변경하지 않는다. 아래 검사는 파일 연결과 기록된 판단을 검증하며 실제 관찰의 진실성이나 콘텐츠 적합성을 숫자로 인증하지 않는다.

## 작업 소유권과 완료 기록

서로 다른 resource/stage는 전역 작업 수 상한과 대기열 없이 즉시 등록한다. `work_guard claim`은 동일 자료/단계 중복·입력 해시·유효 완료결과 재사용을 검사하며 `lease`는 소유권 ID다. `--pool model|local`은 기존 API의 작업 분류값이며 용량이나 우선순위가 아니다. `run.sh`는 model 작업에 실제 최신 `LFC_ROLLOUT`/세션/Sol6.1/high를 연결하고 종료/중단된 턴을 거절한다.

ack/heartbeat/readiness 등록·반복 대기·model에서local로 자리 전환은 하지 않는다. `check`는 입력 무결성, 선택적 `checkpoint`는 실제 완료범위, `finish`는 출력·검증보고서, `fail`은 실패 근거를 기록한다. `events`는 완료/실패/명령 기록 커서일 뿐 배정기가 아니다. `metrics`는 작업 경과·실제 응답 input/cached/output을 반환하며 순수 추론·총 유휴·계정 비용은 근거 없으면 미측정이다.

무거운 명령은 실제 프로세스 실행 중에만 파일 잠금으로 명령 동시실행을 제한하고 정상/오류 종료 때 해제한다. 전사/로컬 영상 생성1, 그 밖의 중량 명령2는 호스트 보호의 보수적 시작값이다. 포화 시 exit3으로 즉시 반환하며 모델/기계의 busywait를 만들지 않는다. 명령 종료 후 재시도한다. 다른 채널의 분석·기획·검수 등록을 막지 않는다.

구형 `enqueue`는 준비됨만 반환하며 대기표를 만들지 않는다. `wait-claim`은 즉시 한 번 claim하는 별칭이고 ack/heartbeat는 호환 응답만 반환한다. 이전 frozen 실행기는 당시 코드/등록 계약을 유지하며 DB 열·기존 등록·자동화·실행 중 프로세스를 변환하거나 중단하지 않는다. 구형 호출의 인자를 새 작업 수 제한으로 재해석하지 않는다.

`diagnose`/`recover`는 동일 자료의 남은 소유권을 현재 실제 로그의 확인된 turn_aborted와 증거 토큰으로만 복구한다. 시간 경과·owner 미상·살아 있는 작업은 허가가 아니다. 출력/파일을 보존하고 프로세스를 종료하지 않는다.

## 주제 자료 확인 후 본대본 확정

새 실행의 `topic_materials_version:2`에서는 후보·자료 조사를 `work_guard claim --stage prepare` 또는 `collection`으로 먼저 진행한다. 이 준비 경로에는 자료 확보 완료를 요구하지 않는다. 핵심 주장과 필수 장면에 맞는 대표 자료의 실제 내용·화질·사용 조건을 확인해 이야기 범위를 정한 뒤 제목·전체 대본을 확정한다. 모든 컷을 미리 수집하거나 후보 수·검색 시간을 고정하지 않는다. 사용자 고정 주제는 임의 전환하지 않는다. 자료가 부족하면 독립 조사를 이어가고 본대본 확정은 미완료로 둔다.

에이전트가 기존 사용자 원문·출처·주제 고정 여부를 `P/topic-request.json`에 기록하고, `P/topic-materials.json`에는 core_claims/essential_scenes 대응과 실제 Sol6.1/high 판단을 관리한다. 사용자가 양식을 채우는 절차가 아니다. 내부 예시는 `assets/topic-request.example.json`, `assets/topic-materials.example.json`에 있다. 기사·논문·실제 문서·사진·영상은 장면 역할에 맞게 허용한다. 검색 결과/링크만은 actual source_content로 승인하지 않는다. 실제 사건 증거(actual_record)와 설명(explanation)/삽화(illustration)를 구분한다. access_failed/not_found/insufficient는 이유를 보존하며 검색 미발견을 부재로 단정하지 않는다. 선택한 inspected 자료에는 실제 파일·관찰 기록·사용조건 근거를 path/sha256으로 연결한다. 확보 자료로 성립하는 supported_scope를 판단한다.

`workflow topic "$P/topic-materials.json" --request "$P/topic-request.json" --review "$P/topic-review.json" --out "$P/topic-check.json"`은 연결·실체·누락을 검사한다. 내용 적합성과 사용조건의 진실성을 자동 증명하지 않으며 실제 담당 판단을 기록한다. 신규 `work_guard claim --stage planning`은 이 표준 기록이 미완료면 전체 대본 작업을 시작하지 않고, 통과하면 자료·판단·원 지시까지 입력 의존성으로 자동 고정한다. 이후 자료 변경 시 현재 소유권/재사용 검사가 실패한다. 신규 TTS/영상 제작도 같은 확인을 요구한다. planning handoff에는 `topic_materials:{request:{path,sha256},assessment:{path,sha256},independent_review:{path,sha256}}`를 연결하고 생산 인계에서도 선행 기록을 재확인한다. 기존 고정 실행에는 새 조건을 소급 적용하지 않는다.

전체 대본 전에 원본 핵심 서사·필수 화면 역할이 후보에서도 성립하는지 독립 Sol6.1/high 문맥이 실제 내용으로 판정한다. `topic-materials.json`에 `semantic_review_version:2`, `reference_semantics:{analysis:{path,sha256},roles:[{reference_role,candidate_role,matches,evidence:[{path,sha256}]}]}`, `difficult_scene_ids`를 기록한다. 어려운 필수 후반 장면도 실제 대표 자료를 확인한다. 독립 판단 `P/topic-review.json`에는 `schema:lfc-topic-semantic-review-v1`, `assessment_sha256`, `request_sha256`, 실제 `reviewer_rollout/session_id`, `reference_roles_reviewed:true`, `story_fit_passed:true`, `difficult_scenes_passed:true`, 전체 essential_scenes 순서의 `reviewed_scene_ids`, `unresolved_items:[]`, 실제 `evidence:[{path,sha256}]`를 기록한다. 사용자가 고정한 주제의 부적합은 근거와 구체 변경안으로 보고하고 임의 전환하지 않는다.

## 컷 계약과 약30초 난컷

분석 근거를 `P/quality-contract.json` (`schema:lfc-cut-contract-v1`)에 연결한다. `complete_cut_ids`는 전체 계획 컷 ID 순서이며 `cuts`의 각 행에는 다음을 담는다.

- `id`, `visual_role`, `narrative_role`, `ink_geometry`, `texture`, `anchors`, `before`, `middle`, `after`, `material_role`, `unresolved_items`.
- `visual_evidence`, `script_evidence`: 실제 파일 `path`/`sha256`; `reference_states.before/middle/after`: 실제 원본 프레임 이미지 `path`/`sha256`. 추출과 직접 관찰을 구분한다.
- `claims`: `kind:channel_grammar|episode_fact`, `text`. 편별 협찬·관람·후원·사건 사실은 새주제의 `new_topic_evidence`가 필요하며 원본 사실을 복제하지 않는다. 화면을 실제 사건 증거로 지시하면 `screen_is_evidence:true`, `asset_relation:actual_record`, `asset_evidence`가 필요하다. 일반 종사진·삽화에 기관 인장을 얹어 실제 기록으로 승인하지 않는다. 사실 조건을 충족하지 못하면 미해결이며 기존 최우선 조건을 완화하지 않는다. 미출력 actual_record 화면의 실제 소스가 아직 없으면 해당 컷에 `material_readiness:deferred`와 구체 `unresolved_items`를 남기고 asset_evidence를 빈 목록으로 둘 수 있다. episode_fact의 사실 근거와 계획 역할 검토는 유지하며 출력 범위에 들어오면 실제 asset_evidence가 없이는 통과하지 않는다.
- 신규 `readiness_version:2`는 `output_scope:{kind:preview,range_s:[0,실제끝점],cut_ids:[실제출력컷순서],manifest:{path,sha256}}`를 연결한다. manifest는 전체 컷 계획을 보존한 실제 프리뷰 reference_map이다. 컷 길이 누적과 actual output_scope에서 출력 컷을 자동 계산하며 임의 부분집합으로 미확보 출력 컷을 빼지 않는다. 별도 본편 제작 지시 후에는 kind:full·전체 manifest·전체 컷으로 새 revision을 검토한다.
- `pilot.samples`: 첫 출력 범위의 어려운 서로 다른3–5컷의 `cut_id`, `risk_reason`, `absolute_range_s`, 대표 `line_ids`. 합계25–35초다. 이 추가 사전검증은 최신1편 전체분석·전체대본·최종170–210초·컷80–120%·본편±30초·독립검수 범위를 줄이지 않는다.

`workflow quality "$P/quality-contract.json" --out ...`으로 연결을 검사한다. 초기 TTS는 pilot line_ids만 합성하고 본 제작에서 재사용한다. 전체 본편 음성을 미리 합성하지 않는다.

pilot props는 원래 절대 start/end와 전체 composition duration을 유지하되 선언한 난컷만 담는다. 실제 소스·폰트·표현을 확보해 기존 Main props 형태로 작성하며 모든 소비파일을 해시로 연결한다. `pilot_render --contract "$P/quality-contract.json" --props PILOT_PROPS --public ISOLATED_PUBLIC --out NEW_DIR`는 전체 TTS 전에 실제30초표본과 전·중·후 PNG를 렌더한다. 독립 문맥에 원본 프레임·실제 출력·전체대본·미해결을 전달한다.

독립 관찰 결과 `P/pilot-review.json`에는 contract_sha256, 실제 `reviewer_rollout`/session_id, implementation_session_ids, 관찰한 pilot 순서의 observed_cut_ids, direct_observation, visual_passed/script_passed, unresolved_items, 실제 출력의 render_evidence(path/sha256)를 기록한다. `workflow quality ... --review ...`는 다른 실제 Sol/High 문맥·전체 pilot 범위·실제 출력 연결을 검사한다. 제작자의 통과 문구를 복사하거나 관찰하지 않은 표본을 승인하지 않는다. 신규 전체 테스트 TTS/렌더는 이 독립 사전결과가 없으면 차단된다.

## 앞단 판단과 최종 검토 근거의 재사용

새 실행의 `front_review_version:2`은 기존 pilot 검수에 전체 대본·자료 판단을 함께 기록한다. 별도 승인 세션을 추가하지 않는다. quality-contract의 `full_script:{path,sha256}`는 현재 전체 대본이다. 기존 pilot-review에 `front_review`를 넣고 `full_script_sha256`, `complete_script_reviewed:true`, `script_passed:true`, 전체 계약 순서의 `plan_cut_ids`, `plan_semantics_passed:true`, 실제 출력 범위 순서의 `material_cut_ids`, `materials_passed:true`, 나머지 계약 순서의 `deferred_material_cut_ids`, `unresolved_items:[]`, 실제 독립 판단 `evidence:[{path,sha256}]`를 연결한다. 전체 대본의 인과·사실·표현과 모든 계획 컷의 서사·화면 역할은 검토하되, 실제 소스 확보·구현 통과는 현재 출력 범위만 요구한다. 후반 일반 컷의 자료는 미완료로 명시하며 미확보만으로 첫 출력을 막지 않는다. 핵심 어려운 후반 장면의 성립 여부는 주제 사전판정에서 확인한다. 출력 컷 미해결은 계속 차단하며 미출력 자료를 승인했다고 표시하지 않는다. 초기 pilot의 실제 출력 판단은 기존 그대로 유지한다. 자료 파일이 존재한다거나 해시가 맞는 것으로 의미 판단을 대신하지 않는다. 이 앞단 검토를 통과한 대본·자료를 제작 기준으로 확정하고 변경 때 해당 판단을 갱신한다.

대표 난컷은 표현 기준을 확인하는 표본이며 나머지 개별 컷의 시각 승인으로 확대하지 않는다. 첫 완성 출력은 실제 개별 컷과 전체 통합 영상의 필수 범위를 모두 검토한다. 해시불변이고 검토 범위/판단이 유효한 전체 대본·자료 근거를 다시 처음부터 분석하지 않는다. 전체 청취/자막·음성 싱크/전환/흐름 확인은 매 현재 최종 영상에서 유지하며 기존 capability 완료 조건을 대체하지 않는다.

`workflow review-plan --contract CONTRACT --pilot-review PILOT_REVIEW --graph CURRENT_GRAPH --scope preview --out PLAN`은 실제 graph scope props의 컷과 계약/소비자료에서 첫 출력의 필수 컷을 계산한다. `--previous VERIFIED_REVIEW_RECORD`가 있으면 유효한 실제 독립 관찰 기록의 판단·범위·출력·근거와 현재 입력을 비교한다. 변경 컷과 해당 자료의 모든 실제 사용처, 앞뒤 경계가 필수 검토다. 공통 코드·음원·전역 타이밍/조건·미매핑 의존성 변화는 전체 범위로 확대한다. 해시만으로 파일을 승인하거나 제작자의 자기 승인 기록을 받아들이지 않는다.

실제 최종 검수 후 `workflow review-record --plan PLAN --render OUTPUT --judgment JUDGMENT --out NEW_RECORD`로 현재 근거를 연결한다. JUDGMENT는 실제 `reviewer_rollout/session_id`, `implementation_session_ids`, `plan_sha256`, `render_sha256`, `direct_observation:true`, `full_integration_passed:true`, `unresolved_items:[]`, PLAN 순서대로 실제 관찰한 `observed_cut_ids`/유효 재사용한 `reused_cut_ids`, 실제 `integration_evidence:[{path,sha256}]`와 관찰 컷별 `cut_evidence:{cut_id:[{path,sha256}]}`를 기록한다. 이는 기록된 판단과 실체·범위를 검사하며 관찰의 진실성을 자동 인증하지 않는다. 성공한 실제 렌더 디코드/프레임/fps/canvas 검증도 함께 연결한다.

신규 conformance와 최종 review handoff에는 `review_evidence.record:{path,sha256}`를 넣는다. final 검사와 workflow handoff는 현재 plan을 다시 계산하여 낡은 근거·누락 범위·실패/자기 승인·다른 출력 재사용을 차단한다. 최초 전체 통합 검수와 이후 실제 필요 검수의 결과를 current reviewer가 기록하며, 변하지 않은 검토 항목의 중복 재분석은 하지 않는다. 기존 고정 실행과 구형 payload는 당시 계약을 유지한다.

## 환경·파일·청취/재생 사전확인

`workflow preflight SPEC --out "$P/preflight-report.json"`을 제작 전에 실행한다. SPEC의 `files`는 실제 소스·폰트·샘플 경로다. HTML 응답을 이미지/영상으로 사용하지 못하며 이미지·미디어·폰트를 실제 디코더로 검사한다. 관리 venv/PIL·PATH의 node/npm/ffmpeg/ffprobe와 pyc 미생성 설정을 확인한다.

`capabilities.direct_listening`, `continuous_playback`은 `status:available|unsupported|denied|unverified`와 실제 허용된 `probe_evidence:[{path,sha256}]`를 기록한다. available/unsupported/denied는 실제 허용 경로의 probe_evidence가 필요하다. 아직 조사하지 않았으면 unverified로 두며 미지원으로 단정하지 않는다. 미지원이면 시작부터 필수 미검증 목록에 남는다. preflight는 spec·probe·소스 해시와 delivery_route/next_action을 고정한다. 가능한 독립 제작은 진행하지만 ASR/신호/정지프레임으로 청취·재생 완료를 대신하지 않는다. 거절 경로를 우회하지 않는다.

진단 `diagnostic_clock`은 fps, master_duration_s, composition_frames, absolute_frames, functional_boundary_frames(0/마지막), reset_clock_or_rebase_props:false다. composition_frames는 전체 master 프레임수여야 하며 표본990장을 composition990프레임으로 설정하지 않는다. pilot은 고정 Main의 절대시계로 출력하며 late/end 표본을 확인한다.

## 중앙 개정 graph와 재사용

`workflow revision SPEC --out-dir NEW_REVISION_DIR`로 현재 full/preview manifest·graph·인계 파일 목록을 생성한다. SPEC은 `schema:lfc-revision-spec-v1`, revision, artifacts, scopes다. artifacts는 `id`, `role`, 실제 `path`, 선택적sha256, scopes(full/preview), consumers(영향cut ID), 선택적handoff_role을 담는다. 렌더역할은 props/mix/renderer/public/font/media/narration이며 metadata 역할은 attribution/script_evidence/review_note만 허용한다. 코드·실제 public 소비는 graph가 직접 수집한다.

scopes의 각 full/preview는 기존 계약의 template 파일과 `bindings:[{pointer:"/tts/timeline",artifact:"현재artifactID"}]`를 선언한다. 구버전 경로의 일괄 치환을 하지 않는다. preview full_plan은 새 full manifest에 자동 연결되고 compiled는 output으로만 등록된다. scope의 모든 실제소비는 중앙 graph에 포함돼야 한다.

`workflow graph GRAPH --out ...`의 저렴한 연결/해시 검사를 먼저 한다. `LFC_REVISION_GRAPH=GRAPH`를 설정해 기존 compile_timeline/check_production/build_timeline을 실행한다. 신규 compile·최종 렌더는 현재 graph의 scope인지 runtime이 확인한다. 기존 필수 계획·assets·시각/전체대본 최종검사는 유지한다. `workflow graph-handoff GRAPH --template PREVIOUS_PACKET --out NEW_PACKET`은 현재 파일목록을 생성하며 `workflow handoff`가 실제 단계 계약을 다시 확인한다.

재사용은 `workflow reuse OLD_GRAPH NEW_GRAPH --record VERIFIED_RENDER_RECORD --out ...`로 검사한다. record는 `workflow render-record GRAPH --scope preview --render OUTPUT --out NEW_RECORD`로 실제 전체디코드·프레임/fps/canvas를 검증해 생성한다. 성공한 lfc-verified-render-v1 및 graph_sha256/render_signature/output_sha256에 실제 출력이 연결돼야 한다. 신규 공식 최종 build_timeline 성공 때 runtime도 이 기록을 생성한다. 렌더 소비·역할·해시가 모두 불변이고 변경이 명시된 metadata뿐일 때만 reuse_render:true다. 이는 사실·근거·독립검토 재사용 승인이 아니다. 공유 그래픽·소스·renderer 변경은 consumers와 인접컷까지 영향검수하며 미매핑은 unknown_scope로 전체 영향을 확인한다. 실패 입력·도구·로그·유효 완료결과는 보존한다.

최종 review 인계는 `capability_evidence.preflight/resolution`의 실제path/sha256을 연결한다. resolution은 초기 preflight_sha256·현재 render_sha256/input_sha256·실제 독립 reviewer_rollout/session_id와 각 capability의 status:available, passed:true, method:direct_listening_observation|continuous_playback_observation, 전체 coverage_s, 실제evidence(path/sha256)를 기록한다. 시작 때 unsupported/denied였다면 실제 허용 경로의 resolution_reason/approved_access:true 근거가 필요하다. 신규 최종 workflow handoff는 이 근거가 없으면 완료승인을 차단하며 numeric 기술통과에 미검증 목록을 유지한다. 준비작업을 막거나 ASR/신호를 청취로 바꾸지 않는다.


실제 청취·연속 재생이 미지원/미검증인 경우 첫 출력의 소스·기술 검사와 가능한 독립 내용 검토를 진행하고 `workflow review-draft "$P/production-handoff.json" --preflight "$P/preflight-report.json" --out "$P/review-draft.json"`로 검토본을 전달한다. 이 경로는 실제 render·input·기술검증·preflight 해시와 미검증 목록을 연결하며 `completion_passed:false`, `content_completion_eligible:false`를 유지한다. 검토본 전달을 final 검수 통과나 채널 승인으로 표시하지 않는다. 실제 관찰 경로와 사람이 확인할 항목을 출력 전에 정하고 이후 실제 resolution과 독립 최종 검수로 완료본을 판정한다.

## 실패 원인과 명시적 재개

실패마다 분석 오류/자료 불일치·미확보/구현 오류/capability 미지원으로 원인과 근거를 작업상태에 기록한다. 분석 오류는 해당 원본 구간만 보완하고 자료 문제는 해당 자료를 재탐색하며 구현 오류는 영향 컷과 연결부를 수정한다. 변경 입력·새 관찰·새 자료가 없으면 같은 검수를 반복하거나 버전 번호만 늘리지 않는다. 불변 근거는 현재 해시·범위·판단이 유효한 부분만 재사용한다.

사용자가 기존 실행에 새 기준 적용을 명시하면 기존 run/skill·실패 로그를 보존하고 현재 스킬의 `runtime init --project C --run-id UNIQUE_NEW_RUN`으로 새 고정 실행을 만든다. 새 작업상태에 원 실행 경로·이전/현재 해시·직접 변경 지시·재사용/재판정 범위를 적는다. 기존 분석 인계는 새 topic/front 조건을 소급 적용하지 않고 당시 근거·실제 모델·범위를 유지한다. 새 주제 확정·출력 범위는 현재 v2 기준으로 실제 판정하고 새 인계를 연결한다. render 소비가 불변인 기존 MP4는 현재 graph+실제 media 검증으로 재사용할 수 있으며 이 재사용을 콘텐츠 승인으로 확대하지 않는다.
