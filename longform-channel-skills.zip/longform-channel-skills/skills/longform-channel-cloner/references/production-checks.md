> 구형 실행 참조: 2026-10-06 이후 `tts-first-v1` 신규 제작에는 이 문서의 주제/파일럿/독립 승인·고정 컷 80~120%·중앙 graph 절차를 적용하지 않는다. 현재 실행은 [production-guide.md](production-guide.md)를 따른다. 아래는 기존 스냅샷 결과 해석을 위해 보존한다.

# 제작 검사 계약

이 문서는 파일 형식과 **길이 사전검사 → 전체 대본/계획 검사 → 소스·TTS·렌더 입력 준비 → 재계획·컴파일 → 렌더 타이밍/소스 검사 → 위험 샘플 → 준비 입력 렌더 → 범위별 Sol 6.1 High 검토 → 최종 검사 → 전달**을 담당한다. 배경 제작 컷·상세 내부 이벤트·효과 시간·Typecast·자막·고정 BGM의 구현 방법은 [production-guide.md](production-guide.md)를 따른다. Sol 6.1 High는 전체 수치·시간 연결을 검사하고 Sol 6.1 High은 영상과 전체 대본의 적합성을 각각 판정한다. 설정 이름·파일 존재·JSON 성공을 실제 구현 근거로 대신하지 않는다.

## 1. 순서와 선행 파일

`S`는 적용 스킬 폴더, `P`는 채널 프로젝트이며 `SLUG` 대신 고유 실행 폴더명을 사용한다. 모든 명령은 관리 venv와 FFmpeg 경로를 설정하는 `run.sh`로 실행한다. 실패한 입력·로그·결과를 보존하고 유효한 완료 결과를 재사용한다.

전체 대본 전에 [통합 계약](integrated-production-contract.md)의 독립 topic-review로 서사·필수 화면 적합성을 확인한다. 전체 대본·TTS 전에 제작 레시피의 `check_duration_feasibility`로 최신 1편의 확인된 구조 S1과 원본 길이 ±30초의 목표 범위를 검사한다. 목표 범위와 컷별 80~120%의 합산 가능 범위가 겹치면 그 교집합 안의 실제 계획을 허용하며 별도 길이 승인을 요구하지 않는다. 교집합이 없거나 ±30초 밖의 길이가 필요하면 실패 보고와 아래 사용자 길이 결정이 필요하다. 후보 비교 또는 범위가 한정된 결정 이후 baseline·영상/대본 근거·선정/계산 파일·시각 기준·구현 코드와 전체 문장 잠정 배치를 준비해 계획 검사로 넘어간다. plan도 원본 배경 길이와 가능성을 다시 검사한다. 선언 컷 자산·TTS 기록/배치·변환 출력의 기존 유예 외에 아직 없는 일반 입력을 등록하지 않는다. props·mix·의존성은 준비 후 등록해 재계획한다. 검사 보고서·출력 렌더·캐시는 `render_inputs`가 아니다.

~~~bash
# 본편은 전체 계획 검사만 먼저 수행한다.
bash "$S/scripts/run.sh" check_production "$P/new/SLUG/reference_map.json" --stage plan --out "$P/new/SLUG/plan_check.json"
# 본편 전체 배치 계획을 연결한 프리뷰 계획 검사
bash "$S/scripts/run.sh" check_production "$P/new/SLUG/preview/reference_map.json" --stage plan --out "$P/new/SLUG/preview/plan_check.json"
~~~

통과 후 출력 범위 자산·TTS·자막·고정 BGM·EDL을 준비하고 [잠정 계획과 실측 배치 정렬](production-guide.md#전체-잠정-계획과-프리뷰-실측-배치-정렬)을 따른다. `build_timeline --no-render`로 실제 props·mix를 만들고 `render_timing`과 렌더 의존성을 입력에 등록한다. 프리뷰 발화 시각을 본편 계획에도 반영하며 manifest의 공유 컷·자산·입력 목록을 함께 갱신한다. 전체 TTS 합성은 요구하지 않는다.

~~~bash
# 컴파일 내부에서 최신 본편/프리뷰 계획을 검사하고 한 거래에서 근거를 공유한다.
# --out은 첫 manifest.compiled_timeline과 같아야 하며 추가 출력은 각 manifest의 선언 경로다.
bash "$S/scripts/run.sh" compile_timeline "$P/new/SLUG/reference_map.json" --out "$P/new/SLUG/compiled_timeline.json" --also-manifest "$P/new/SLUG/preview/reference_map.json"
# assets 보고서의 render_timing_check에 실제 renderer 타이밍 검사가 포함된다.
bash "$S/scripts/run.sh" check_production "$P/new/SLUG/preview/reference_map.json" --stage assets --out "$P/new/SLUG/preview/assets_check.json"
~~~

같은 입력의 여러 검사를 함께 수행하려면 `check_production MANIFEST --stage plan --also PREVIEW plan --also PREVIEW assets --out REPORT`를 사용한다. batch 보고서의 `reports`는 각 scope·stage의 원래 판정이며 모두 통과해야 집계가 통과한다. 한 거래에서 JSON 파싱·파일 해시·동일 scope/stage의 성공 검사를 공유하되 종료 시 현재 내용을 다시 대조한다. 영구 PASS 캐시나 stat-only 재사용은 없다. 입력·검사기·renderer가 변경되거나 거래 중 파일/별칭이 바뀌면 통과를 반환하지 않는다. 단일 명령도 기존과 동일하게 지원하며 별도 renderer 어댑터·진단에는 `check_render_timing`을 직접 실행할 수 있다.

타이밍/소스 검사 통과 후 새 구현·위험 구간을 짧은 샘플로 확인한다. 최종 렌더는 제작 레시피의 `--render-prepared --production-manifest`로 검사된 props·mix를 유지해 실행한다. 추가 입력·코드·자막·배치가 바뀌면 목록 갱신·재계획·재컴파일·검사를 거친다. 짧은 샘플의 실제 검토 근거는 유효한 범위만 재사용하며 전체 프레임 관찰로 확대하지 않는다.

최종 렌더 후 별도 Sol 6.1 High 세션이 신규·변경·의심 구간과 앞뒤 연결을 실제 확인하고, 나머지는 기존 실제 검토의 유효한 근거를 재사용한다. 대본은 전체 문장 검토를 유지한다. 범위·근거·미검증 사항을 보고하고 최신 출력 집계 해시를 `conformance.json`에 연결한다. **필수 기준의 관찰/재사용 근거와 미해결 상태를 확인하기 전에 final을 성공 처리하지 않는다.** 전체 영상을 새로 재분석하는 것은 기본 단계가 아니다.

~~~bash
bash "$S/scripts/run.sh" check_production "$P/new/SLUG/preview/reference_map.json" --stage final --out "$P/new/SLUG/preview/final_check.json"
~~~

검사 실패는 종료 코드 1이다. 최종 통과 전에는 완료본 전달·완료 표시·구조 순환 갱신을 하지 않는다. 전달 직전 final을 다시 실행하고 최신 `final_check.json`·`conformance.json`·렌더 해시를 읽어 상태를 정한다. 이 도구는 실행한 전달 경로를 검사하며 외부 렌더 실행을 기술적으로 봉쇄하지 않는다. 생성 채널 스킬에도 같은 실행 순서를 연결한다.

미통과 출력은 검토본/미완성으로 표시하고 미해결 구간을 알린다. 실제 청취/재생 사전시험이 미지원이면 workflow review-draft로 출력·기술검증·미검증 해시를 연결한 검토본을 전달하며 final 완료승인은 false로 유지한다. 기술 검사 통과, 검토용 렌더, 레퍼런스 적합성 통과, 사용자 확인은 다른 상태다. 본편 미출력 구간의 소스·렌더·검수는 미완료로 유지한다. 별도 본편 제작 지시 후에는 본편 manifest에 대해 같은 준비·컴파일·assets·렌더·검토·final 순서를 수행한다. 프리뷰·재시도·수정본은 구조 순번을 소비하지 않는다.

## 2. 입력 경로와 JSON 근거

모든 경로는 해당 `reference_map.json` 폴더 기준이며 절대 경로도 가능하다. 본편과 프리뷰가 공유하는 분석·baseline·자산은 절대 경로 사용을 권장한다. 근거는 `{"file":"분석.json","pointer":"/cuts/0"}` 형태의 JSON Pointer로 실제 존재하는 비어 있지 않은 항목을 참조한다. 포인터는 `/`로 시작하는 비루트 경로이고 RFC 6901의 `~0`·`~1` 이스케이프를 사용한다.

### reference_map.json

| 필드 | 계약 |
|---|---|
| `baseline` | 합성 전에 확정한 `structure_plan.json` 경로 |
| `duration_link` | `selected6`, `input`, `plan` 경로. 선정 근거와 길이 입력은 `reference_count:1`과 정확히 같은 1개 `{id,duration_s}`를 가진다. `plan`은 실제 `plan_duration` 출력이며 입력 해시/재계산값을 대조한다. 선택 `decision`은 아래 사용자 길이 결정의 `{file,pointer}` 근거다 |
| `compiled_timeline` | 변환 출력 경로. 처음부터 `render_inputs`에 등록하되 계획 단계에는 출력 파일이 없어도 된다. assets·final에는 최신 결과가 필수다 |
| `visual_acceptance` | 채널별 시각 비교 기준 JSON 경로. 계획부터 필수이며 `render_inputs`에 포함한다 |
| `structure_id`, `canvas` | 선택 구조 ID와 출력 크기. 예: `"S1"`, `[1920,1080]` |
| `render`, `conformance` | 완성 렌더와 적합성 JSON의 경로. 검수 전에 정하고 경로가 바뀌면 재검사한다 |
| `render_inputs` | 실제 코드·타임라인·새 대본·배치·음성·폰트·소스·BGM 명세/준비 소스/루프/기록·mix·EDL·props·패키지 렌더 의존성 목록. 실제 복사 자산도 포함하며 원격 자료는 로컬로 확정한다 |
| `output_scope` | 본편은 `{"kind":"full"}`(생략 시 full), 프리뷰는 아래 부분 출력 계약 |
| `tts` | `provider:"typecast"`, `voice_name`, `voice_id`, `uniform_speed:1.2`, `speed_method:"provider"`, `playback_rate:1.0`. 시연은 `official_voice_evidence` 근거 객체가 필수다 |
| `tts.narration_metadata`, `tts.timeline` | assets·final에서 필수인 생성 기록과 편집 배치 파일 경로. 둘 다 `render_inputs`에 포함하며 metadata 파일명은 `narration.json`이다 |
| `cuts` | 확정 순서의 제작 배경 클립 배열. 내부 상세 이벤트는 같은 부모 배경에 연결한다 |
| `render_timing` | assets·final 필수. 패키지 렌더러는 `{"kind":"remotion-template","props":"render/props.json"}`. props 경로는 manifest 폴더 기준이고 실제 준비 결과와 일치해야 한다 |

baseline의 기준을 제작 결과에 맞춰 사후 변경하지 않는다. 기존 이벤트 단위의 제작 baseline/manifest는 [제작 레시피의 변환 절차](production-guide.md#2-대본배경-제작-컷과-내부-이벤트-대응표-만들기)로 다시 구성하며 분석 원본 이벤트 목록은 보존한다. 필수 원본 시각·provenance 누락은 필요한 구간만 재관찰해 보충한 뒤 검사한다. 사용자 변경은 구체적 지시 근거로 기준과 영향 검토를 다시 확정한다. 원본 목표·±30초 범위·본편 계획 길이·차이를 모두 보고하며 실제 의존성과 렌더 사용을 대조한다. 기존 프로젝트의 자동 변환이나 완료 상태 갱신을 가정하지 않는다.

| 컷 필드 | 계약 |
|---|---|
| `id` | 제작 컷의 고유 ID |
| `reference_video_id`, `reference_cut_id` | 원본 영상 ID와 `background_segments`의 부모 배경 ID. 상세 이벤트 ID는 내부 연결 명세에 보존한다 |
| `duration_s` | 실제 제작 배경의 타임라인 점유 시간. 해당 원본 `background_segments.end_s-start_s`의 80~120%이며 원본 근거와 대조한다 |
| `media_kind`, `source_kind` | 주 소스의 `video`/`image`와 분석으로 정한 세부 유형(예: documentary_footage, stock, ai_image) |
| `visual_evidence`, `script_evidence`, `new_script` | 각각 원본 배경·대본 분석·새 대본의 근거 객체. 영상 pointer는 `/background_segments/N`이며 원본 ID·기준 길이의 실제 대조를 수행한다 |
| `layers`, `effects` | `{구성요소ID: 실제 적용 설정}` 객체. 내부 이벤트의 원본/제작 상대시각·지속 ID·상태·효과 실측을 연결하며 필수 요소의 빈 값은 실패 |
| `transition_in` | 관찰된 진입 전환의 확정 설정. 하드 컷 생략은 `{type:"cut",frames:0}`으로 정규화하며 props와 컴파일된 컷의 정규화 값이 정확히 같아야 한다 |
| `assets` | `path`, `media_kind`, `source_kind`, `primary`를 가진 파일 목록. 주 시각 소스에 `primary:true`를 쓰고 여러 주 소스도 모두 검사한다 |

부모 배경·레이어·애니메이션 ID, 지속 구간·상태·시간 대응과 코드 위치는 제작 레시피대로 컷 설정 또는 연결 명세에 보존한다. 분석 확장 필드를 그대로 붙여 렌더 호환이나 의미 검사가 완료됐다고 간주하지 않는다.

### structure_plan.json

`structure_id`, `analysis_session_ids`(원본 분석에 사용한 실제 세션 ID 배열), `implementation_session_ids`(실제 제작 세션 ID 배열), `implementation_provenance`(`session_ids`를 기록한 제작 이력 JSON 경로), 비어 있지 않은 `rule_evidence` 근거 배열, `required_visual_rule_ids`(고유 필수 시각 규칙 ID 배열), `narration_windows`, `cuts`를 저장한다.

`narration_windows`는 각 문장의 `line_id`, `cut_ids`, `allowed_start_s`, `allowed_end_s`를 가지며 연결 배경 컷들의 이어진 범위 안에 둔다. baseline `cuts`는 제작 컷과 같은 ID·순서·원본 ID·소스 유형·영상/대본 근거, 기준 `duration_s`, `required_layers`, `required_effects`를 가진다. `visual_evidence`는 실제 `/background_segments/N`을 가리키고 해당 분석의 `analysis_provenance.video_id=reference_video_id`, 배경 `id=reference_cut_id`, 원본 `end_s-start_s=baseline.duration_s`를 코드가 대조한다. 상세 이벤트 간격을 기준 길이로 넣지 않으며 동일 `(reference_video_id,reference_cut_id)` 원본 배경을 다른 제작 ID로 중복 등록해 가능 길이를 늘리지 않는다. 필수 구성요소는 실제 분석에서 없음을 확인했을 때만 빈 배열로 둔다.

제작 배경 컷은 전환 점유 시간을 포함하는 서로 겹치지 않는 구간이며 합이 본편 계획 길이다. 부모 내부 이벤트의 등장 순서·상대시각·유지/퇴장과 효과 지속 시간은 `layers`/효과 연결 명세에 보존하고 이벤트 간격에 ±20%를 일괄 적용하지 않는다. 이미지 MP4는 형식상 영상으로 판정되므로 실제 움직임·자료 성격·역할은 Sol 6.1 High 근거로 확인한다. 기계 유형 비교를 의미적 적합성 통과로 해석하지 않는다.

### 사용자 길이 결정

`duration_link.decision`은 선택 근거 객체 `{"file":"사용자 결정.json","pointer":"/결정 항목"}`다. 참조 항목에는 `authorized_by:"user"`, 비어 있지 않은 사용자 `instruction`, 지시 출처 `source`, 기록 시점 `recorded_at`, `planned_duration_s`와 다음 scope를 저장한다.

~~~json
{
  "structure_id":"현재 구조 ID",
  "cut_ids":["현재 baseline의 제작 배경 컷 ID를 같은 순서로 모두 기재"],
  "selected6_sha256":"현재 선정 1편 파일의 SHA-256",
  "baseline_sha256":"현재 전체 baseline 파일의 SHA-256"
}
~~~

scope는 현재 구조·전체 컷 순서·두 파일 해시와 정확히 일치해야 한다. 승인 길이는 원본 배경 합의 80~120% 범위 안이며 실제 전체 계획 길이와 일치해야 한다. 원본 길이 ±30초 범위와 컷별 조건을 동시에 충족하지 못하는데 유효한 추가 결정 근거가 없거나 결정 범위/해시가 달라지면 plan은 실패한다. 프리뷰와 본편은 동일 결정 근거를 연결한다. 결정은 원래 1편 목표를 바꾸지 않고 해당 실행의 승인된 계획 길이를 별도로 남긴다. 코드의 연결 검사는 사용자 지시의 진위를 증명하지 않으므로 실제 원문·출처·범위를 대조한다.

## 3. 부분 출력과 내레이션 계약

프리뷰는 본편과 **전체 `cuts`의 내용·순서**, 구조·canvas·TTS 정책·동일 baseline·시각 기준·선정 1편/계산 연결을 보존하고 출력만 제한한다. manifest·conformance·검사/검토 보고서는 `preview/`에 분리한다.

~~~json
{"output_scope":{"kind":"preview","full_plan":"../reference_map.json","start_s":0,"end_s":180}}
~~~

`end_s:180`은 예시다. 실제 값은 제작 레시피에서 정한 170~210초의 끝점 또는 짧은 본편 전체다. 실제 본편 계획 길이보다 길 수 없다. `full_plan` 파일도 프리뷰 `render_inputs`에 등록하고 본편의 plan 통과를 확인한다. 프리뷰 계획 검사부터 본편 전체 문장 배치 파일이 실제로 있어야 하며 baseline 시간창을 각각 한 번 포함해야 한다. 본편 배치와 프리뷰 배치 파일은 서로 달라야 한다.

본편 `tts.timeline`은 합성하지 않은 문장도 포함한 전체 배치 계획, 프리뷰 `tts.timeline`·`tts.narration_metadata`는 실제 출력에 필요한 문장과 경계 문장만 포함한 별도 파일이다. 프리뷰에 필요한 문장은 본편 배치의 `start_s`가 출력 끝점보다 앞선 문장이며 실측 반영 후 다시 확인한다. 파일을 준비하는 순서는 제작 레시피의 정렬 절차를 따른다.

~~~json
{"segments":[{"line_id":"l1","cut_ids":["c1"],"allowed_start_s":0,"allowed_end_s":10,"start_s":0.2,"end_s":9.1,"playback_rate":1.0}]}
~~~

assets·final은 생성 metadata의 provider·voice, `uniform_speed:1.2`·`speed_method:"provider"`·`fit:false`, 문장별 `provider_tempo:1.2`·`atempo:1.0`을 확인한다. metadata 문장 ID와 timeline 문장이 일대일이고 출력 범위 문장과 일치하며 중복·겹침이 없어야 한다. 배치는 baseline 시간창·연결 컷 범위 안에 있고 metadata의 실측 placement와 일치해야 한다. 이 placement 비교·일부 겹침 검사는 0.01초 허용을 사용하지만 **프리뷰와 본편의 해당 `start_s`·`end_s`는 정확히 같아야 한다**. 속도 값은 오차 허용 없이 정책값과 일치해야 한다.

종료를 가로지르는 문장의 프리뷰 segment에만 `output_clip:{"start_s":...,"end_s":...}`을 넣고 출력 범위와의 정확한 교집합을 기록한다. 원래 문장 끝·본편 배치를 바꾸지 않으며 다른 문장/본편 배치에는 넣지 않는다. 컴파일된 배경 컷의 `output_clip`은 출력 교집합이고 범위 밖 컷은 null이다. 경계 배경의 원본 길이·80~120% 기준과 발화 시간창은 본편 기준으로 검사한다. 실제 props에도 경계 컷의 원래 끝을 유지하고 composition만 프리뷰 길이로 제한한다. 프레임 반올림을 새로운 ±20% 허용으로 해석하거나 경계 잘림을 음성 누락·배속 변경으로 판정하지 않는다.

미출력 본편의 자산·TTS 합성은 요구하지 않는다. 다만 코드가 제외하는 없는 입력은 미출력 컷 자산 경로에 한정되므로 미생성 일반 파일까지 입력 목록에 넣어 통과할 것으로 기대하지 않는다. 소스 검사 통과가 미출력 본편의 검증을 뜻하지 않는다.

## 4. 컴파일과 해시 연결

`compile_timeline`은 내부에서 plan을 검사하고 확정 컷 순서로 `start_s`·`end_s`를 누적한다. 컷 ID·근거·레이어·효과·자산 설정을 보존하고 `narration_windows`·배치 segments·출력 교집합을 연결한다. 결과의 `source_manifest`, `source_root`, `source_manifest_sha256`, `plan_input_sha256`로 입력을 추적한다. 출력의 상대 경로는 출력 폴더가 아니라 `source_root` 기준이다. `--out`은 manifest의 `compiled_timeline`과 같아야 한다.

컴파일 출력 경로는 입력 목록에 등록하되 내용은 자기 입력 해시에서 제외해 순환을 방지한다. 다른 입력·baseline·배치·코드·manifest가 바뀌면 다시 컴파일한다. 계획 이후 미래 자산·TTS 파일이 생성돼도 입력 해시가 바뀌므로 다시 변환한다. assets·final은 같은 빌더의 최신 예상 타임라인과 실제 변환 내용을 대조하며 오래되거나 수동 변경된 결과를 실패시킨다.

컴파일러는 없는 분석·대본·효과를 생성하거나 렌더하지 않는다. 기존 `renderer_usage_verified:false` 보고만으로 실제 소비 타이밍을 판정하지 않고 다음 렌더 계약의 검사 결과를 함께 확인한다. 동일 내용의 ffprobe 결과만 `.probe-cache.json`에서 재사용하며 파일 내용이 바뀌면 재측정한다.

### 실제 렌더 타이밍 계약

주 시각 소스는 props의 `asset.source_path`, `asset.sha256`, 실제 public 복사본을 manifest의 primary 자산과 대조한다. 원본과 복사본 모두 `render_inputs`에 등록하며 같은 파일명·파일 크기로 내용 일치를 대신하지 않는다. 준비 시 내용 해시 기반 파일명을 사용한다.

`render_timing`의 props와 `renderer_dependencies()`가 반환하는 **모든** 패키지 파일을 `render_inputs`에 등록한다. 현재 반환 범위는 `assets/remotion-template/src/`의 모든 파일과 `package.json`, `remotion.config.ts`, `tsconfig.json`이다. 준비 mix·EDL·실제 미디어/폰트도 의존성에 포함한다. `check_render_timing`의 `--out` 보고서는 입력 목록에 넣지 않는다. assets·final은 이 타이밍 검사를 함께 실행한다.

검사는 Main/Root와 동일한 `src/cutTiming.cjs`를 Node에서 실행해 실제 composition 프레임 수, 출력에 걸친 배경 컷의 ID·순서·시작/끝 프레임·연속성을 대조한다. Main에서 Clip에 전달하는 점유 프레임도 같은 스케줄 결과를 사용하며 내부에서 초 단위 길이를 별도로 반올림해 전환 시계를 어긋나게 하지 않는다. `transition_in`은 컴파일된 컷과 props를 기본 `{type:"cut",frames:0}`으로 정규화한 뒤 정확히 비교하며 전환 프레임 길이의 유효성도 검사한다. 하드 컷 생략은 가능하고 관찰된 전환은 명시한다. 원래 본편 컷 끝과 composition 출력 끝을 구분하고 양자화 차이는 기록하되 추가 백분율 허용으로 쓰지 않는다.

현재 계측 대상은 패키지 Remotion 템플릿이다. 커스텀 Remotion·FFmpeg는 실제 실행 스케줄 어댑터가 필요하며 지원되지 않는 렌더러에 PASS를 만들지 않는다. 이 검사는 내부 모든 효과·상태·자막/음성 배치의 의미나 시각 정확성을 자동 인증하지 않는다. 해당 타이밍은 별도 코드 검사 및 위험 샘플 근거와 연결한다.

`build_timeline --render-prepared`는 실제 props/mix 경로·최종 output 경로를 확인하고 비용이 큰 렌더 전에 assets 검사를 재실행한다. 실행 폴더의 템플릿 복사본은 등록된 패키지 소스 해시와 같아야 한다. 런타임 소스는 실행별로 격리하고 일치하는 의존성 캐시만 공유한다. 준비 입력이나 의존성 변경 시 재등록·재계획·재컴파일·검사가 필요하다.

## 5. 시각 기준과 측정 결과

`P/style/visual_acceptance.json`은 `tolerance_status:"provisional"` 또는 `"confirmed"`, `rules` 배열을 가진다. 각 규칙은 고유 `id`, 적용 `cut_ids`, `evidence` 근거 객체, 비어 있지 않은 `metrics:[{id,unit,target,tolerance}]`를 가진다. 수치는 유한하며 tolerance는 0 이상이다. 규칙 ID는 baseline의 `required_visual_rule_ids`를 정확히 한 번씩 포함해야 한다. 계획 단계부터 본편 전체의 규칙 정의·근거를 검사한다.

Sol 6.1 High는 새 구현·위험 샘플과 최종 신규·변경·의심 구간의 같은 역할 장면에서 위치·크기·등장 시간·움직임·필수 소스/효과를 비교한다. 기준값·실측값·차이·프레임/시간대를 기록하고, 재사용 측정은 이전 실제 관찰 근거와 현재 구간의 일치 증거에 연결한다. 필수 요소 누락은 작은 위치 차이로 상쇄하지 않는다. 존재는 목표 1·허용 0의 0/1 값으로 표현할 수 있다. 잠정 허용값을 사용자 승인으로 표시하지 않으며 테스트 피드백으로 확정한다. 임의 공통 오차율을 만들지 않는다.

최종 `conformance.visual_measurements`:

~~~json
{
  "status":"pass",
  "input_sha256":"실제 최신 입력 해시",
  "render_sha256":"실제 최신 렌더 해시",
  "visual_acceptance_sha256":"실제 시각 기준 파일 해시",
  "rules":[{"rule_id":"실제 규칙 ID","status":"pass","evidence":{"file":"visual_review.json","pointer":"/findings/0"},"metrics":[{"id":"실제 metric ID","value":1}]}]
}
~~~

final은 출력 배경 컷에 적용되는 필수 규칙의 누락·중복·오래된 집계 해시·허용값 초과를 실패시킨다. 미출력 컷의 규칙은 미검증이다. **현재 자동 검사는 규칙별 metrics이며 모든 적용 컷의 개별 실제 관찰을 강제하지 않는다.** Sol 6.1 High 보고서에는 적용 컷별 신규 관찰·유효한 기존 측정 재사용·미검증을 구분해 근거와 결과를 남긴다. 대표 컷의 수치나 평균으로 다른 컷의 실패를 덮지 않는다. 필수 기준의 미검증은 미해결로 유지한다.

## 6. Sol 6.1 High 검토와 실제 출력 확인

assets 입력 해시·최종 렌더 SHA-256·시각 기준 해시와 확인 대상 구간을 별도 Sol 6.1 High 세션에 전달한다. 신규·변경·의심 구간 및 앞뒤 연결에서 원본·실제 출력·컷 대응·사용자 기준을 먼저 비교하고 최초 분석의 해석/통과 결론은 그 뒤에 대조한다. 분석 오류와 제작 오류를 구분해 시각 보고서에 실제 관찰(observed)·기존 실제 근거 재사용(reused)·미검증(unverified)의 시간/컷 범위·검사 방법·차이·영향·수정안을 각각 남긴다.

시각 검수 대상 구간에서 소스·구도·레이어 가림·등장/퇴장·배경/애니메이션 시계·필름·전환·움직임·자막/폰트 잘림을 실제 확인한다. 별도 대본 보고서는 **새 대본 전체 문장**의 인과관계·정보 공개·질문 회수·원본 대응과 `spoken_text/display_text`의 의미·숫자·단위를 검토한다. 최종 영상 전체 재분석으로 대본 검토를 대신하지 않는다. 내레이션 오독/누락은 실제 오디오 확인 범위를 기록하며 접근하지 못한 구간은 미검증이다. 로컬 전사 비교는 실제 청취와 구분한다.

제작 레시피의 [영상 문구 제한](production-guide.md#영상-문구-제한)을 대본·자막·그래픽/템플릿 문구 전체와 대조한다. 실제 출력에서는 문구가 적용된 신규·변경·의심 구간을 확인하고 유효한 기존 검토 근거는 재사용한다. 금지 문구가 발견되면 해당 시각/대본 검토를 실패로 기록하고 제거·재검수 전까지 완료본으로 전달하지 않는다. 이 판단은 Sol 6.1 High의 내용 검토 대상이며 현재 코드 검사만으로 자동 보증된다고 표시하지 않는다.

내레이션 metadata·편집 설정의 속도와 실제 렌더 처리를 함께 대조한다. 정지 캡처·효과 이름·이징 설정만으로 움직임·전환·속도를 통과시키지 않는다. 원본과 같은 시각의 전·중·후 프레임과 실제 재생을 확인하며 원본 구현값의 불확실성과 관찰 가능한 필수 재현 문제는 제작 레시피대로 구분한다.

고정 BGM은 제작 레시피의 명세·준비 소스 해시·`loop_bgm` 결과/기록·믹스 설정과 실제 출력의 0초 시작·반복·1.0배속·종료 길이를 대조한다. **현재 `check_production --stage final`은 고정 BGM 명세/루프 기록 준수나 최종 믹스의 음악을 자동 강제하지 않는다.** 입력 목록에 음원이 있거나 오디오 스트림이 존재하는 것만으로 BGM 적용 완료를 선언하지 않는다. 레퍼런스 음악 비교·효과음 제작/검사는 현재 범위에서 제외한다.

첫 테스트·본편·수정본 모두 렌더 전 전체 타이밍 코드 검사 → 새 구현/위험 구간의 짧은 실제 샘플 → 최종 신규/변경/의심 구간 확인 순서를 따른다. 최종 영상을 처음부터 끝까지 새로 재분석하는 단계를 기본으로 두지 않는다. 기존 실제 관찰·측정 근거는 이전 보고서의 원본/출력·입력·기준 해시를 보존하고 현재 대응 구간 내용·관련 의존성·기준·시간 매핑이 일치함을 확인했을 때만 재사용한다. 전체 렌더 해시가 바뀌면 현재 출력 집계와 이전 근거를 별도로 연결하며 이전 보고서의 해시만 최신 값으로 갈아끼우지 않는다.

본 적 없는 프레임은 실제 검토 완료로 표시하지 않는다. 실제 미검증 범위는 보고서에 남기며 필수 기준의 근거가 없거나 미해결이면 통과시키지 않는다. 폰트·음악·스타일·공통 코드의 전역 변경은 관련 규칙을 출력 전체에 검사하고 영향받은 구간·근거만 다시 확인한다. 영향 범위를 입증하지 못하면 해당 범위는 미검증으로 남겨 필요한 확인을 확대하며 일괄 전체 재분석으로 자동 전환하지 않는다.

## 7. conformance와 검수자 예외

현재 완료 계약의 `conformance.json` 필수 최상위 필드는 **5개**다: `visual_review`, `script_review`, `visual_measurements`, `unresolved_items`, `user_authorized_changes`. SKILL.md 보호 구역에 열거된 기존 4필드를 유지하면서 현재 기계 계약의 `visual_measurements`를 함께 저장한다.

일반 `visual_review`·`script_review` 구조:

~~~json
{
  "reviewer":"sol",
  "model":"gpt-6.1-sol",
  "reasoning_effort":"high",
  "status":"pass",
  "input_sha256":"실제 최신 소스 검사 입력 해시",
  "render_sha256":"실제 최신 렌더 해시",
  "session_id":"실제 검토 Sol 6.1 High 세션 ID",
  "report":{"file":"visual_review.json","pointer":"/findings"}
}
~~~

대본 검토는 별도 `script_review.json`의 전체 새 대본 근거에 연결한다. 두 검토와 측정의 집계는 최신 입력·렌더 해시와 일치해야 하며 `unresolved_items`는 빈 배열이어야 한다. 시각 보고서는 신규 실제 관찰과 조건을 충족한 이전 실제 근거 재사용을 합쳐 필수 기준을 판정하되, 프레임 전체 관찰로 확대하지 않는다. 이상 없음도 근거 범위를 기록한다. 시각 Sol 6.1 High 세션이 최초 `analysis_session_ids`와 다른지는 코드가 검사하며 새 실행의 baseline은 `implementation_session_ids`도 포함한다. 시각·대본 검수 모두 분석·구현 세션과 다른 실제 Sol High 세션이어야 하며 코드가 이 독립성을 검사한다.

`user_authorized_changes`는 구체적인 사용자 원문·대화/시점·대상 컷/소스/대본·적용 범위의 기록 배열이며 자동 면제 목록이 아니다. 작업별 지시를 다른 영상의 기본값으로 옮기거나 철회된 요청을 재적용하지 않는다.

시각·대본 기본 검수자는 Sol 6.1 High다. 특정 컷의 시각 검수 담당 변경을 사용자가 명시한 경우에만 baseline의 `visual_review_overrides`에 `{cut_id,reviewer,authorization}` 객체를 기록한다. `authorization`은 사용자 원문·시점·대화·범위를 담은 JSON을 가리키는 근거 객체다. `sol` 또는 명시 승인한 `codex`만 지원하며 컷당 한 항목이다. 대본 담당의 일반 override 기능은 현재 코드에 없다. 변경 담당도 분석·제작 기준과 증거를 생략하지 않는다. 사용자 지시의 진위·범위는 Sol 6.1 High가 원문과 대조한다.

예외가 출력 범위에 있으면 `visual_review`에 집계 `status`·최신 입력/렌더 해시와 `parts`를 둔다. part는 일반 검토 객체에 `cut_ids`를 추가해 모든 출력 배경 컷을 겹침·누락 없이 맡되, 그 배열이 해당 컷 모든 프레임의 신규 관찰을 의미하지는 않는다. 각 part 보고서에 실제 관찰·근거 재사용·미검증 범위를 구분한다. 담당자는 baseline과 일치하고 Sol 6.1 High part는 최초 분석과 별도 세션이어야 한다. 적용 예외를 `user_authorized_changes`에도 동일하게 기록하며 일부 담당 변경을 전체 검수 권한으로 확대하지 않는다.

## 8. 최종 통과의 범위

final은 출력 크기, 비디오/오디오 스트림, 출력 범위 대비 렌더 길이(0.1초 허용), 완성 본편의 원본 길이 ±30초 준수(유효한 추가 길이 결정이 있으면 그 결정 준수), 최신 컴파일 결과·입력 해시·필수 측정·검토 근거·미해결 항목을 검사한다. 해시는 스트리밍 SHA-256으로 계산한다. 파일명·과거 로그로 완료를 선언하지 않는다.

코드가 확인하지 않는 의미적 충실도·검토 진위·모든 실제 오디오 처리·내부 이벤트 상태까지 자동 보증하지 않는다. 전체 타이밍의 코드 검사, 필요한 실제 관찰/유효한 재사용 근거, 필수 기준의 미해결 여부를 함께 판정한다. 관찰·재사용·미검증의 실제 범위와 본편 미출력/미합성 작업을 보고하고, 본 적 없는 프레임을 전체 시청각 검토 완료로 표시하지 않는다.

호환 JSON 키 `selected6`와 `selected6_sha256`는 선정 입력/해시의 기존 이름이다. 신규 입력은 `reference_count:1`의 최신 한 편이며 키 이름 때문에 표본을 추가하지 않는다. 신규 길이 정책은 latest-one-v1과 본편 ±30초다. 기존 2편(latest-two-v1)·6편(legacy-six-v1) 계산 결과는 당시 표본·모델·기준으로 보존하며 새 허용폭을 조용히 소급 적용하지 않는다.
