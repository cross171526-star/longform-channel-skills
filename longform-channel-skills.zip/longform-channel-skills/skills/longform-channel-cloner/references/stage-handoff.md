> 구형 실행 참조: 2026-10-06 이후 `tts-first-v1` 신규 제작에는 이 문서의 주제/파일럿/독립 승인·고정 컷 80~120%·중앙 graph 절차를 적용하지 않는다. 현재 실행은 [production-guide.md](production-guide.md)를 따른다. 아래는 기존 스냅샷 결과 해석을 위해 보존한다.

# 단계 인계 계약

전체 대화 대신 아래 파일을 전달하고 필요한 원본 근거를 직접 열 수 있게 한다. 요약은 탐색용이며 관찰값·원본/프레임·사용자 지시·미해결을 대체하지 않는다. 기계 검사 통과는 실제 시각/대본 판단 통과가 아니다.

`analysis-handoff.json`, `planning-handoff.json`, `production-handoff.json`, `review-handoff.json`은 `schema:"lfc-stage-handoff-v1"`, `stage`, 실제 `model:"gpt-6.1-sol"`, `reasoning_effort:"high"`, `session_id`, `basis_sha256`(경로→해시), `completed_scope`, `user_instructions`, `unresolved_items`, `files`를 가진다. 경로는 인계 파일 기준 또는 절대 경로다. `user_instructions`에는 사용자 원문·출처·범위·철회 여부를 기록한다. 파일별 `files` 항목은 `role`, `path`, `sha256`이며 원본별 파일은 `video_id`도 가진다.

| stage | 필수 role |
|---|---|
| analysis | reference_ids의 최신 ID 1개에 source, visual_analysis, script_analysis, speech_rate, evidence, analysis_validation + 공통 selected_references, style |
| planning | full_script, baseline, reference_map, asset_requirements, renderer_readiness |
| production | baseline, reference_map, render, render_inputs, numeric_validation |
| review | conformance, visual_review, script_review, final_validation, render, baseline, reference_map, render_inputs |

신규 topic_materials_version2의 planning 인계에는 `topic_materials:{request:{path,sha256},assessment:{path,sha256},independent_review:{path,sha256}}`로 실제 주제 자료 확인과 원 사용자 지시를 연결한다. 핵심 미해결은 전체 대본 확정/인계 통과가 아니며 후보 조사는 prepare/collection으로 계속한다. 자료 역할·접근 결과와 내부 예시는 [통합 계약](integrated-production-contract.md)을 따른다.

선정 파일은 `reference_count:1`, `selection_complete:true`와 같은 ID·실제 길이의 `references` 원소 하나를 가진다. 인계·기획·제작·검수의 ID는 이 한 편으로 연결하며 본편 목표는 원본 길이 ±30초다. 과거 2편·6편 인계는 당시 고정 검사기로 확인하고 신규 인계로 자동 변환하지 않는다.

분석의 `states`에는 `observed`, `production_ready`, `render_verified`를 독립 boolean으로 둔다. 원본 관찰 완료만으로 제작 인수·렌더 검증 완료를 표시하지 않는다. `production_ready=false`이면 미확인 항목을 ID별로 보완하며 독립적인 계획은 진행할 수 있다. 제작 인계에는 실제 `implementation_session_ids`를 함께 남긴다. 검증 role의 보고서는 실제 `passed:true`와 `output_sha256`·필요한 `dependencies_sha256`로 결과물에 연결한다. `check_production`처럼 입력 지문만 반환하는 검사는 그 보고서 및 출력 해시를 별도 완료 계약에 묶어 전달한다. 검증되지 않은 결과에 성공 래퍼를 만들지 않는다.

분석 이후 인계는 `previous_handoff:{path,sha256}`로 바로 앞 인계에 연결한다. 검사기는 선행 인계와 의존 파일도 재확인한다. `reference_ids`는 순서까지 계승한다. 같은 role의 파일을 수정하면 이전 파일을 보존하고 새 경로를 사용하며 `artifact_changes`에 `role`, `previous_sha256`, `sha256`, `reason`, `affected_scope`를 남긴다. 제작·검수의 `input_sha256`는 실제 제작 검사 입력 지문이며 검수는 제작 인계의 지문을 계승한다. 수정 제작물은 제작 인계부터 개정한다.

`numeric_validation.output_sha256`에는 실제 render를 넣고, 출력/의존 해시에는 baseline·reference_map·render_inputs 파일을 모두 포함한다. `final_validation.output_sha256`는 render·conformance·visual_review·script_review를 모두 연결하며 동일한 제작 입력 파일을 의존 해시에 포함한다. 두 검증 보고서의 `input_sha256`도 인계와 일치해야 한다. baseline의 `implementation_provenance`는 실제 제작 세션을 기록한 JSON 경로이고 그 `session_ids`는 `implementation_session_ids`와 일치해야 한다. 원본 근거의 `analysis_provenance.session_id`를 baseline에서 누락할 수 없다. 이 기록은 실제 실행에서 작성하며 임의 세션명을 만들어 독립성을 가장하지 않는다.

```bash
bash "$S/scripts/run.sh" workflow handoff "$P/analysis-handoff.json" --out "$P/analysis-handoff-check.json"
bash "$S/scripts/run.sh" workflow doctor --out "$R/environment-check.json"
bash "$S/scripts/run.sh" workflow impact "$P/new/SLUG/reference_map.json" --component scene:text --out "$P/new/SLUG/review-impact.json"
```

검사기는 선언한 모든 파일·기준·검증 결과의 해시를 대조하고 실제 의미 판단을 대신하지 않는다. 분석 인계 전 `validate_analysis_bundle`과 실제 원본 관찰 근거를 확인한다. 과거 분석을 재사용할 때 당시 실제 모델 기록을 바꾸지 않는다. 모든 신규 작업과 인계는 `gpt-6.1-sol / high`로 수행한다. 인계의 `files`에서 원본 분석 이력과 재사용 범위를 보존하고, 원본 검사 기록은 당시 고정된 검사기로 확인한다.

영향 범위 명령은 `scene:text` 등 렌더 노드 종류, `effect:<이름>`, `font:<경로>`, 계획의 `component_id`를 찾는다. `--cut`는 명시한 컷과 앞뒤 연결, `--global-change`는 전체 출력의 관련 규칙 검사를 뜻한다. 매핑되지 않은 변경은 빈 영향 목록으로 통과시키지 않는다. 실제 공통 코드·음악·시간축·폰트 변경은 관련 전체 사용처와 대조하고 재검수 범위를 확정한다.

입력 매니페스트는 실행에 필요한 원본·폰트·음원·코드·자료·실제 근거를 명시한다. 입력과 산출물, 재생성 가능한 cache/logs/telemetry, 과거 등록 증빙을 구분한다. 디렉터리를 통째로 입력으로 넣어 가변 캐시·옛 등록 문서가 실행 의존성으로 누적되지 않게 한다. 필요한 파일의 누락을 허용한다는 뜻은 아니다.

신규 front_review_version2의 최종 검수는 [앞단 판단·현재 review-plan/record](integrated-production-contract.md)의 review_evidence.record를 conformance와 최종 handoff에 연결한다. 앞단 전체대본·모든 컷 역할과 실제 출력 자료 판단을 유효 범위에서 재사용하되 최초 실제 전체 영상과 매 현재 출력의 통합·청취 검증은 유지한다.

검토본은 완료 review 인계를 작성하지 않고 `workflow review-draft PRODUCTION_PACKET --preflight PREFLIGHT --out DRAFT`로 실제 출력·입력·기술검증과 미검증 목록을 연결한다. 완료승인 false 및 미출력 본편 미완료를 유지한다. 기존 인계 재귀 확인은 새 run의 topic 조건을 과거 계획에 소급하지 않는다.
