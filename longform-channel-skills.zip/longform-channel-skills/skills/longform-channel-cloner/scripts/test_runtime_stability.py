import contextlib
import io
import json
import os
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
from runtime import initialize, frozen_skill, invoke, collect_usage
from work_guard import execute, digest
from fetch_channel import cached_meta
from validate_analysis_bundle import check

class RuntimeTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.p=Path(self.tmp.name)
        self.env=patch.dict(os.environ,{'LFC_RUNTIME_HOME':str(self.p/'shared'),'LFC_RUN_DIR':'','LFC_LEASE':''});self.env.start();self.addCleanup(self.env.stop)
    def dispatch_after_real_preflight(self, tool, changed=None):
        """환경/소유권 경계만 격리하고 실제 preflight와 _invoke subprocess를 실행한다."""
        import runtime
        from production_preflight import run as preflight
        from PIL import Image
        with tempfile.TemporaryDirectory(dir=self.p) as folder:
            root=Path(folder).resolve();(root/'work').mkdir();(root/'skill/scripts').mkdir(parents=True)
            (root/'run.json').write_text('{"scheduler_version":3}')
            image=root/'source.png';Image.new('RGB',(8,8),'blue').save(image)
            probe=root/'probe.md';probe.write_text('Technical fixture: capability not actually observed.')
            spec=root/'preflight-spec.json';spec.write_text(json.dumps({'files':[str(image)],'capabilities':{'direct_listening':{'status':'unverified','probe_evidence':[{'path':str(probe),'sha256':digest(probe)}]}}}))
            with patch('workflow.doctor',return_value={'passed':True,'checks':{'fixture_environment':True}}):
                report=preflight(spec)
            self.assertTrue(report['passed'],report['errors'])
            (root/'work/preflight-report.json').write_text(json.dumps(report))
            marker=root/'dispatched.txt';target=root/'skill/scripts'/f'{tool}.py'
            target.write_text('from pathlib import Path\nPath('+repr(str(marker))+').write_text('+repr(tool)+')\nraise SystemExit(17)\n')
            manifest=root/'manifest.json';manifest.write_text('{}')
            graph=root/'graph.json';graph.write_text(json.dumps({'scopes':{'preview':{'path':str(manifest)}}}))
            if changed=='file':image.write_bytes(b'changed source')
            if changed=='spec':spec.write_text('{"changed":true}')
            if changed=='probe':probe.write_text('changed probe')
            env={'LFC_RUN_DIR':str(root),'LFC_LEASE':'isolated-test-owner','LFC_VERBOSE':'1','LFC_REVISION_GRAPH':str(graph)}
            with patch.dict(os.environ,env),patch.object(runtime,'frozen_skill',return_value=root/'skill'),patch.object(runtime,'bound_rollout',return_value=None),patch.object(runtime,'execute'),patch('scheduler.modern_run',return_value=True),patch('revision_graph.validate',return_value={'passed':True}),patch('compile_timeline.parse_arguments',return_value=SimpleNamespace(manifest=manifest,also_manifest=[])),patch('quality_contract.guard_tool'):
                if changed:
                    with self.assertRaisesRegex(ValueError,'Preflight input changed' if changed=='file' else 'Preflight probe/spec changed'):
                        runtime._invoke(tool,[],{'started':0,'enter':lambda _:None})
                    self.assertFalse(marker.exists())
                else:
                    self.assertEqual(runtime._invoke(tool,[],{'started':0,'enter':lambda _:None}),17)
                    self.assertEqual(marker.read_text(),tool)
    def test_preflight_dependencies_preserve_requested_tool_dispatch(self):
        for tool in ('pilot_render','tts','build_timeline','compile_timeline'):
            with self.subTest(tool=tool):self.dispatch_after_real_preflight(tool)
    def test_preflight_changed_source_still_blocks_dispatch(self):
        for tool in ('pilot_render','tts','build_timeline','compile_timeline'):
            with self.subTest(tool=tool):self.dispatch_after_real_preflight(tool,'file')
    def test_preflight_changed_spec_or_probe_still_blocks_dispatch(self):
        for tool in ('pilot_render','tts','build_timeline','compile_timeline'):
            for changed in ('spec','probe'):
                with self.subTest(tool=tool,changed=changed):self.dispatch_after_real_preflight(tool,changed)
    def test_session_snapshots_and_immutable_code(self):
        source=Path(__file__).resolve().parent.parent
        a=initialize(source,self.p/'channel','first');b=initialize(source,self.p/'channel','second')
        self.assertNotEqual(a['work_dir'],b['work_dir']);frozen_skill(a['run_dir'])
        (Path(a['skill'])/'scripts/work_guard.py').write_text('modified')
        with self.assertRaises(ValueError):frozen_skill(a['run_dir'])
        frozen_skill(b['run_dir'])
    def test_expensive_and_retired_commands_stop_before_execution(self):
        for name in ['tts','build_timeline','whole_video_session','generate_channel_skill']:
            with self.assertRaises(ValueError),patch('runtime.subprocess.run') as cmd:
                invoke(name,[])
            cmd.assert_not_called()
    def test_metadata_cache_hit_and_duration_invalidation(self):
        with patch('fetch_channel.video_meta',return_value={'id':'A','duration':10}) as get:
            for _ in range(2):cached_meta('A',None,self.p/'cache',10)
            self.assertEqual(get.call_count,1)
            cached_meta('A',None,self.p/'cache',11);self.assertEqual(get.call_count,2)
    def test_incomplete_bundle_rejected(self):
        source=self.p/'source';source.write_bytes(b'video')
        for name,doc in [('visual_analysis.json',{'cuts':[{'id':'c1','start_s':0,'end_s':10,'parent_background_id':'missing'}]}),('script.json',{}),('speech_rate.json',{})]:
            (self.p/name).write_text(json.dumps(doc))
        self.assertFalse(check(self.p,source,'A')['passed'])
    def test_prepared_media_collision_and_same_size_edits(self):
        import build_timeline as bt
        (self.p/'assets').mkdir()
        for name,data in [('a',b'AAAA'),('b',b'BBBB')]:
            (self.p/name).mkdir();(self.p/name/'source.mp4').write_bytes(data)
        (self.p/'assets/manifest.json').write_text(json.dumps({'items':{k:{'file':f'{k}/source.mp4','kind':'video','probe':{'duration_s':10}} for k in ['a','b']}}))
        edl=self.p/'edl.json';edl.write_text(json.dumps({'fps':30,'duration_s':20,'cuts':[{'id':k,'asset_key':k,'start_s':i*10,'end_s':(i+1)*10} for i,k in enumerate(['a','b'])]}))
        def prepare():
            with patch('sys.argv',['build_timeline','--edl',str(edl),'--project',str(self.p),'--no-render']),patch.object(bt,'mix_audio',return_value='mock'),contextlib.redirect_stdout(io.StringIO()):bt.main()
            return json.loads((self.p/'render/props.json').read_text())['cuts']
        cuts=prepare();self.assertNotEqual(cuts[0]['asset']['file'],cuts[1]['asset']['file'])
        (self.p/'a/source.mp4').write_bytes(b'CCCC');cuts=prepare()
        self.assertEqual((self.p/'render/public'/cuts[0]['asset']['file']).read_bytes(),b'CCCC')
        self.assertEqual((self.p/'render/public'/cuts[1]['asset']['file']).read_bytes(),b'BBBB')

    def test_complete_bundle_and_changed_evidence(self):
        source=self.p/'source';source.write_bytes(b'video')
        evidence=self.p/'frame.jpg';evidence.write_bytes(b'frame')
        arrays=['captions','chrome','uncertainties','implementation_recommendations','state_timeline','color_adjustments']
        visual={k:[] for k in arrays}
        visual.update(video_read=True,audio_read=False,full_video_analyzed=True,method='frames',
            coverage={'duration_s':10,'reviewed_ranges':[{'start_s':0,'end_s':10}],'missing_ranges':[]},
            analysis_provenance={'video_id':'A','source_sha256':digest(source),'model':'gpt-6.1-sol','reasoning_effort':'high','session_id':'actual'},
            background_segments=[{'id':'b1','start_s':0,'end_s':10}],counting={},audio={},production_rules={},
            cuts=[{'id':'c1','start_s':0,'end_s':10,'duration_s':10,'parent_background_id':'b1','event_type':'background_entry',
                   'new_element_ids':[],'active_element_ids':[],'animation_ids':[],'precision':{'step_s':.1},'evidence':{'file':'frame.jpg'}}],
            layers=[{'cut_id':'c1','status':'observed','stack':[{'layer_id':'l1','role':'L1'}]}],animations=[{'cut_id':'c1','presence':'absent','events':[]}],
            film_overlays=[{'cut_id':'c1','presence':'absent','events':[]}])
        script={'video_id':'A','language':'ko','duration_s':10,'hook':{'first_sentence':'문장','technique':['question'],'seconds_to_topic':0,'promise':'설명'},
                'sections':[{'id':str(i),'role':'hook' if i==0 else 'explanation','start_s':i*5,'end_s':(i+1)*5,'purpose':'설명','text':'내용'} for i in range(2)],'formula':'hook then explanation'}
        for name,doc in [('visual_analysis.json',visual),('script.json',script),('speech_rate.json',{'status':'unknown','reason':'timestamps unavailable'})]:
            (self.p/name).write_text(json.dumps(doc))
        with patch('validate_analysis_bundle.probe',return_value={'duration_s':10}):report=check(self.p,source,'A')
        self.assertTrue(report['passed'],report['errors']);self.assertIn(str(evidence.resolve()),report['dependencies_sha256'])
        visual['coverage']['reviewed_ranges'][0]['end_s']=5;(self.p/'visual_analysis.json').write_text(json.dumps(visual))
        with patch('validate_analysis_bundle.probe',return_value={'duration_s':10}):self.assertFalse(check(self.p,source,'A')['passed'])
    def test_observation_precision_and_evidence_invalidation(self):
        from observation_index import query
        from work_guard import hashes
        source=self.p/'source';source.write_bytes(b'video');frame=self.p/'frame';frame.write_bytes(b'frame')
        index={'observations':[{'source_sha256':digest(source),'purpose':'layers','step_s':.5,'width':1000,'start_s':0,'end_s':5,'evidence_sha256':hashes([frame])}]}
        self.assertEqual(query(index,source,0,10,.5,1000,'layers')['missing_ranges'],[[5,10]])
        self.assertEqual(query(index,source,0,10,.1,1000,'layers')['missing_ranges'],[[0,10]])
        frame.write_bytes(b'changed');self.assertEqual(query(index,source,0,10,.5,1000,'layers')['missing_ranges'],[[0,10]])
    def test_same_names_fonts_and_brand_copy_distinctly(self):
        from build_timeline import copy_public
        for name,data in [('x',b'AAA'),('y',b'BBB')]:
            (self.p/name).mkdir();(self.p/name/'font.ttf').write_bytes(data)
        a,_=copy_public(self.p/'x/font.ttf',self.p/'public');b,_=copy_public(self.p/'y/font.ttf',self.p/'public')
        self.assertNotEqual(a,b)

    def test_command_entrypoint_checks_then_executes_snapshot(self):
        source=Path(__file__).resolve().parent.parent
        info=initialize(source,self.p/'channel','entry')
        request=self.p/'request.json';request.write_text('{"url":"test"}')
        job=execute(info['run_dir'],'claim','fetch',[request],resource='channel:A',stage='collection',pool='local')
        with patch.dict(os.environ,{'LFC_RUN_DIR':info['run_dir'],'LFC_LEASE':job['lease']}),patch('runtime.subprocess.run',return_value=SimpleNamespace(returncode=0)) as run:
            self.assertEqual(invoke('fetch_channel',['--help']),0)
            self.assertEqual(Path(run.call_args.args[0][1]),Path(info['skill'])/'scripts/fetch_channel.py')
        request.write_text('{"url":"changed"}')
        with patch.dict(os.environ,{'LFC_RUN_DIR':info['run_dir'],'LFC_LEASE':job['lease']}),patch('runtime.subprocess.run') as run:
            with self.assertRaises(ValueError):invoke('fetch_channel',['--help'])
            run.assert_not_called()
    def test_usage_collection_ignores_inherited_and_deduplicates(self):
        import datetime
        source=self.p/'source';source.write_text('fixed');root=self.p/'run';root.mkdir()
        job=execute(root,'claim','analyze',[source],resource='youtube:A',stage='analysis')
        timestamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
        rows=[{'type':'session_meta','payload':{'id':'actual-thread'}},
              {'type':'token_usage_record','timestamp':timestamp,'payload':{'thread_id':'actual-thread','response_id':'r1','usage':{'input_tokens':100,'cached_input_tokens':90,'output_tokens':5}}},
              {'type':'token_usage_record','timestamp':timestamp,'payload':{'thread_id':'parent-thread','response_id':'inherited','usage':{'input_tokens':10000,'cached_input_tokens':9000,'output_tokens':500}}}]
        log=self.p/'rollout.jsonl';log.write_text(''.join(json.dumps(r)+'\n' for r in rows))
        collect_usage(root,job['lease'],log);result=collect_usage(root,job['lease'],log)
        self.assertEqual(result['calls'],1);self.assertEqual(result['uncached_input'],10)

if __name__=='__main__':unittest.main()
