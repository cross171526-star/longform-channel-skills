"""Frozen per-session workspace and checked local command entrypoint."""
import argparse
import fcntl
from contextlib import contextmanager
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
from work_guard import digest, execute, hashes

# Kept as archival source; never part of the current execution path.
RETIRED={'analyze_videos','whole_video_session','gemini_direct','media_transport','media_doctor',
         'agy_video_analysis','generate_channel_skill','auto_annotate','plan_video','make_edl',
         'audio_analysis','sfx_filter','sound_match','compare_new'}
EXPENSIVE={'fetch_channel','detect_cuts','motion_track','captions','font_match','detect_chrome',
           'source_signals','transcribe','tts','gen_video','render_graphic','build_timeline','fetch_assets','pilot_render'}


def initialize(source, project, run_id, started_at=None):
    if not run_id or Path(run_id).name!=run_id or run_id in ('.','..'): raise ValueError('Simple unique run ID required')
    started_at = time.time() if started_at is None else float(started_at)
    if not __import__('math').isfinite(started_at) or started_at > time.time(): raise ValueError('Actual request start time required')
    source=Path(source).resolve();root=Path(project).expanduser().resolve()/'runs'/run_id
    root.mkdir(parents=True,exist_ok=False)
    snapshot=root/'skill'
    try:
        for folder in ('scripts','references','assets','agents'):
            shutil.copytree(source/folder,snapshot/folder,ignore=shutil.ignore_patterns('__pycache__','node_modules','*.pyc','.DS_Store'))
        shutil.copy2(source/'SKILL.md',snapshot/'SKILL.md')
        for stage in ('analysis','planning','production','review'):
            origin=source.parent/f'longform-channel-{stage}'
            if not (origin/'SKILL.md').is_file():
                raise ValueError('Missing stage skill: '+str(origin))
            shutil.copytree(origin,snapshot/'stages'/origin.name,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
        frozen={str(p.relative_to(snapshot)):digest(p) for p in snapshot.rglob('*') if p.is_file()}
        config={'schema':'lfc-run-v3','project':str(Path(project).expanduser().resolve()),'created_at':time.time(),
                'snapshot':str(snapshot),'files':frozen,
                'models':{role:['gpt-6.1-sol','high'] for role in ('analysis','planning','implementation','review')},
                'reference_policy':{'mode':'latest-one-v1','count':1,'max_duration_s':1800},
                'duration_policy':{'full_tolerance_s':30,'cut_basis':'reference_sentence_length_ratio'},
                'workflow_profile':'tts-first-v1','request_started_at':started_at,
                'limits':{'production_deadline_s':None,'stage_deadline_s':None,'model_response_limit':None},
                'topic_approval_required':True,'topic_proposal_target_s':300,
                'delivery_target_s':3600,'on_delivery_overrun':'continue_to_draft_delivery',
                'status':'ready','scheduler_version':3,'front_review_version':0,'topic_materials_version':0,'quality_contract_version':0,'revision_graph_version':0}
        (root/'run.json').write_text(json.dumps(config,ensure_ascii=False,indent=2))
        (root/'work').mkdir();(root/'usage.json').write_text('{"measured":false,"tasks":{}}\n')
        return {'run_dir':str(root),'skill':str(snapshot),'work_dir':str(root/'work')}
    except Exception:
        (root/'INITIALIZATION_FAILED').write_text('Preserved for diagnosis; use a new run ID after fixing initialization.')
        raise


def frozen_skill(root):
    root=Path(root).resolve();config=json.loads((root/'run.json').read_text());snapshot=Path(config['snapshot'])
    actual={str(p.relative_to(snapshot)) for p in snapshot.rglob('*') if p.is_file()}
    if actual!=set(config['files']):
        raise ValueError('Frozen runtime file inventory changed')
    for relative,expected in config['files'].items():
        if digest(snapshot/relative)!=expected: raise ValueError('Frozen runtime modified: '+relative)
    return snapshot


@contextmanager
def command_resource_guard(name):
    base=Path(os.environ.get('LFC_RUNTIME_HOME',str(Path.home()/'.longform-cloner/runtime')))
    base.mkdir(parents=True,exist_ok=True)
    # 24 GB host: one ASR/generation command, two other heavy local commands.
    group,capacity=('accelerator',1) if name in ('transcribe','gen_video') else ('process',2)
    handle=None
    for i in range(capacity):
        candidate=(base/f'{group}-{i}.lock').open('a')
        try:
            fcntl.flock(candidate,fcntl.LOCK_EX|fcntl.LOCK_NB);handle=candidate;break
        except BlockingIOError:candidate.close()
    if handle is None:raise BlockingIOError('Concurrent heavy command limit reached; retry after that command finishes')
    try:yield
    finally:handle.close()


def require_topic_approval(root, name, args):
    """사용자가 요청한 최초 주제 승인만 확인한다. 구형 실행은 변경하지 않는다."""
    root = Path(root)
    config = json.loads((root / 'run.json').read_text())
    if not config.get('topic_approval_required'): return
    metadata_only = name == 'fetch_channel' and args and args[0] in ('titles', 'list')
    needs_approval = (name in EXPENSIVE and not metadata_only) or name in ('draft_delivery', 'compile_timeline')
    if not needs_approval: return
    proposal_path = root / 'work/topic-proposal.json'
    approval_path = root / 'work/topic-approval.json'
    if not proposal_path.is_file() or not approval_path.is_file():
        raise ValueError('First propose a title-based test topic within 5 minutes and wait for explicit user approval before downloading/analyzing/producing video')
    proposal = json.loads(proposal_path.read_text()); approval = json.loads(approval_path.read_text())
    if (not isinstance(proposal.get('topic'), str) or not proposal['topic'].strip()
            or approval.get('topic') != proposal['topic'] or approval.get('approved') is not True
            or not isinstance(approval.get('user_message'), str) or not approval['user_message'].strip()):
        raise ValueError('Current proposed topic needs explicit user approval; silence/time elapsed is not approval')


def _invoke(name,args,timing):
    name=name.removesuffix('.py')
    if name in RETIRED: raise ValueError('Retired workflow: use SKILL.md current analysis/production contracts')
    if not name.replace('_','').isalnum(): raise ValueError('Invalid tool name')
    root=os.environ.get('LFC_RUN_DIR');source=Path(__file__).resolve().parent.parent
    if root: source=frozen_skill(root)
    from draft_delivery import active
    draft = active(root) if root else False
    if root: require_topic_approval(root, name, args)
    if draft and name in ('pilot_render','compile_timeline','check_duration_feasibility'):
        raise ValueError('Use TTS-first draft sequence; no pilot or legacy fixed-cut approval')
    if name in EXPENSIVE:
        if not root or not os.environ.get('LFC_LEASE'): raise ValueError('Initialize a run and register task ownership before this command')
        execute(root,'check',lease=os.environ['LFC_LEASE'])
    rollout=bound_rollout(root) if root else None
    if root and name=='work_guard' and args and args[0] in ('claim','wait-claim','ack','heartbeat') and rollout and '--worker-rollout' not in args:
        args=[*args,'--worker-rollout',rollout]
    if root and os.environ.get('LFC_LEASE') and rollout:
        from work_guard import connection
        with connection() as db:
            job=db.execute('SELECT pool,run FROM jobs WHERE lease=?',(os.environ['LFC_LEASE'],)).fetchone()
        if job and job['pool']=='model' and Path(job['run']).resolve()==Path(root).resolve():
            from scheduler import modern_run, provenance
            if modern_run(root):
                provenance(rollout)
                from scheduler import verify_owner
                with connection() as db:verify_owner(db,os.environ['LFC_LEASE'],rollout)
            collect_usage(root,os.environ['LFC_LEASE'],rollout)
    if root and not draft and name in ('tts','build_timeline','pilot_render','compile_timeline'):
        from scheduler import modern_run
        if modern_run(root):
            report_path=Path(root)/'work/preflight-report.json'
            if not report_path.is_file():raise ValueError('Run workflow preflight before production/compile')
            report=json.loads(report_path.read_text())
            if report.get('passed') is not True:raise ValueError('Production environment/file preflight failed')
            for row in report.get('files',[]):
                if digest(row['path'])!=row['sha256']:raise ValueError('Preflight input changed: '+row['path'])
            for dependency_path,wanted in report.get('dependencies_sha256',{}).items():
                if digest(dependency_path)!=wanted:raise ValueError('Preflight probe/spec changed: '+dependency_path)
    if root and not draft and name in ('compile_timeline','build_timeline'):
        from scheduler import modern_run
        if modern_run(root) and (name=='compile_timeline' or '--production-manifest' in args):
            from revision_graph import validate
            graph=os.environ.get('LFC_REVISION_GRAPH')
            if not graph:raise ValueError('Current central revision graph required before expensive gates/render')
            report=validate(graph)
            if not report['passed']:raise ValueError('; '.join(report['errors']))
            scopes=json.loads(Path(graph).read_text())['scopes']
            if name=='compile_timeline':
                from compile_timeline import parse_arguments
                parsed=parse_arguments(args)
                requested_scopes=[p.resolve() for p in [parsed.manifest,*parsed.also_manifest]]
            else:
                requested_scopes=[Path(args[args.index('--production-manifest')+1]).resolve()]
            if any(str(p) not in {x['path'] for x in scopes.values()} for p in requested_scopes):raise ValueError('Requested production scope is not current graph scope')
    if root and not draft and name in ('tts','build_timeline'):
        from quality_contract import guard_tool
        guard_tool(root,name,args)
    target=source/'scripts'/f'{name}.py'
    if not target.is_file(): raise ValueError('Unknown tool')
    start=timing['started']
    timing['enter']('admission')
    # Local tools do not invoke model turns to wait for completion.
    from contextlib import nullcontext
    with command_resource_guard(name) if name in EXPENSIVE else nullcontext():
        timing['enter']('command')
        command=[sys.executable,str(target),*args]
        env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','OMP_NUM_THREADS':'4','OPENBLAS_NUM_THREADS':'4','MKL_NUM_THREADS':'4'}
        compact=root and name not in ('work_guard','runtime') and os.environ.get('LFC_VERBOSE')!='1'
        if compact:
            import uuid
            log=Path(root)/'logs'/(str(time.time_ns())+'-'+uuid.uuid4().hex[:8]+'-'+name+'.log')
            log.parent.mkdir(exist_ok=True)
            with log.open('w') as stream:
                result=subprocess.run(command,env=env,stdout=stream,stderr=subprocess.STDOUT)
            summary={'tool':name,'exit_code':result.returncode,'log':str(log),'elapsed_s':round(time.time()-start,3)}
            if result.returncode:
                with log.open('rb') as stream:
                    stream.seek(max(0,log.stat().st_size-3000));summary['error_tail']=stream.read().decode('utf-8',errors='replace')
            timing['summary']=summary
        else:
            result=subprocess.run(command,env=env)
    timing['enter']('postcheck')
    if root:
        if not draft and name=='build_timeline' and result.returncode==0 and '--no-render' not in args and not any(x in args for x in ('--sample-frames','--sample-spec')) and os.environ.get('LFC_REVISION_GRAPH'):
            from revision_graph import render_record
            graph=os.environ['LFC_REVISION_GRAPH'];g=json.loads(Path(graph).read_text())
            current=str(Path(args[args.index('--production-manifest')+1]).resolve())
            scope=next(k for k,v in g['scopes'].items() if v['path']==current)
            edl_dir=Path(args[args.index('--edl')+1]).resolve().parent
            render_record(graph,scope,edl_dir/'output.mp4',edl_dir/('render-verification-'+str(time.time_ns())+'.json'))
    if draft:
        cfg=json.loads((Path(root)/'run.json').read_text())
        elapsed=time.time()-cfg['request_started_at']
        (Path(root)/'delivery-time.json').write_text(json.dumps({'elapsed_s':elapsed,'target_s':3600,'over_target':elapsed>3600,'action':'continue_to_draft_delivery'}))
    return result.returncode


def invoke(name,args):
    """Total monotonic wall includes admission checks and post-render proofs."""
    start=time.perf_counter();timing={'started':time.time(),'phases':{},'phase':'preflight','mark':start}
    def enter(phase):
        now=time.perf_counter();old=timing['phase']
        timing['phases'][old]=timing['phases'].get(old,0)+now-timing['mark']
        timing['phase'],timing['mark']=phase,now
    timing['enter']=enter
    code=2;failure=None
    try:
        code=_invoke(name,args,timing)
        return code
    except BaseException as exc:
        failure={'type':type(exc).__name__,'phase':timing['phase'],'reason':str(exc)}
        code=3 if isinstance(exc,BlockingIOError) else 2
        raise
    finally:
        enter('finished')
        elapsed=sum(timing['phases'].values())
        row={'tool':name.removesuffix('.py'),'started':timing['started'],
             'elapsed_s':elapsed,'exit_code':code,'phase_elapsed_s':timing['phases']}
        if failure:row['failure']=failure
        root=os.environ.get('LFC_RUN_DIR')
        if root and Path(root).is_dir():
            with (Path(root)/'commands.jsonl').open('a') as f:f.write(json.dumps(row,ensure_ascii=False)+'\n')
            from work_guard import connection
            from scheduler import emit
            with connection() as db:
                emit(db,str(Path(root).resolve()),os.environ.get('LFC_LEASE'),'command_completed',row)
                if not failure and code==0 and row['tool']=='build_timeline' and '--no-render' not in args and not any(x in args for x in ('--sample-frames','--sample-spec')):
                    emit(db,str(Path(root).resolve()),os.environ.get('LFC_LEASE'),'preview_rendered',row)
        if 'summary' in timing:
            summary={**timing['summary'],'elapsed_s':round(elapsed,3),'phase_elapsed_s':timing['phases']}
            if failure:summary['failure']=failure;summary['exit_code']=code
            print(json.dumps(summary,ensure_ascii=False))


def collect_usage(root,lease,rollout):
    """작업에 명시적으로 연결된 로그의 새 레코드만 계측한다. 본문/인증정보는 복사하지 않는다."""
    from work_guard import connection, usage_summary
    import datetime
    import hashlib
    root=Path(root).resolve();rollout=Path(rollout).resolve()
    with connection() as db:
        job=db.execute('SELECT * FROM jobs WHERE lease=? AND run=?',(lease,str(root))).fetchone()
        if not job:raise ValueError('Unknown task lease')
    folder=root/'telemetry';folder.mkdir(exist_ok=True)
    key=hashlib.sha256((lease+str(rollout)).encode()).hexdigest()
    cursor_path=folder/(key+'.json')
    with (folder/'collection.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        stat=rollout.stat()
        previous=json.loads(cursor_path.read_text()) if cursor_path.exists() else {}
        identity=[stat.st_dev,stat.st_ino]
        # 교체·축소된 로그는 처음부터 다시 읽어 response_id 중복 제거에 맡긴다.
        offset=previous.get('offset',0) if previous.get('identity')==identity and stat.st_size>=previous.get('offset',0) else 0
        thread_id=previous.get('thread_id') if offset else None
        records=[]
        with rollout.open('rb') as stream:
            stream.seek(offset)
            while True:
                start=stream.tell();line=stream.readline()
                if not line:break
                if not line.endswith(b'\n'):
                    stream.seek(start);break
                e=json.loads(line)
                if e.get('type')=='session_meta':thread_id=e['payload']['id']
                if e.get('type')!='token_usage_record':continue
                timestamp=datetime.datetime.fromisoformat(e['timestamp'].replace('Z','+00:00')).timestamp()
                if timestamp<job['started'] or (job['ended'] and timestamp>job['ended']):continue
                payload=e['payload']
                if not thread_id or payload.get('thread_id')!=thread_id:continue
                records.append({'response_id':payload['response_id'],'usage':payload['usage']})
            offset=stream.tell()
        result=execute(root,'usage',lease=lease,records=records)
        cursor={'identity':identity,'offset':offset,'thread_id':thread_id}
        tmp=cursor_path.with_suffix('.tmp');tmp.write_text(json.dumps(cursor));tmp.replace(cursor_path)
        with connection() as db:
            tasks={r['lease']:{**usage_summary(db,r['lease']),'stage':r['stage'],'task':r['task']} for r in db.execute('SELECT lease,stage,task FROM jobs WHERE run=?',(str(root),))}
        data={'measured':any(v['calls'] for v in tasks.values()),'tasks':tasks,
              'source':'bound rollout token_usage_record; cached counts are not quota percentages',
              'production_deadline_s':None,'response_limit':None,
              'delivery_target_s':json.loads((root/'run.json').read_text()).get('delivery_target_s')}
        path=root/'usage.json';tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(data,indent=2));tmp.replace(path)
        return result


def bound_rollout(root):
    """현재 thread ID의 로그만 연결. 다른 채팅의 로그는 자동 계측하지 않는다."""
    explicit=os.environ.get('LFC_ROLLOUT')
    if explicit:return explicit
    thread=os.environ.get('CODEX_THREAD_ID')
    if not thread:return None
    matches=list((Path.home()/'.codex/sessions').glob(f'*/*/*/*{thread}.jsonl'))
    return str(matches[0]) if len(matches)==1 else None


def main():
    p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='cmd',required=True)
    a=sub.add_parser('init');a.add_argument('--project',required=True);a.add_argument('--run-id',required=True);a.add_argument('--started-at',type=float)
    a=sub.add_parser('invoke');a.add_argument('name');a.add_argument('args',nargs=argparse.REMAINDER)
    a=sub.add_parser('collect-usage');a.add_argument('--run-dir',required=True);a.add_argument('--lease',required=True);a.add_argument('--rollout',required=True)
    a=p.parse_args()
    try:
        if a.cmd=='invoke': return invoke(a.name,a.args)
        if a.cmd=='init':result=initialize(Path(__file__).resolve().parent.parent,a.project,a.run_id,a.started_at)
        else:result=collect_usage(a.run_dir,a.lease,a.rollout)
        print(json.dumps(result,ensure_ascii=False));return 0
    except BlockingIOError as e:
        print(json.dumps({'decision':'wait','reason':str(e)},ensure_ascii=False));return 3
    except (OSError,ValueError,KeyError,TypeError) as e:
        print(json.dumps({'decision':'blocked','reason':str(e)},ensure_ascii=False));return 2

if __name__=='__main__':sys.exit(main())
