"""Second review: missing-input creation, report protection and parser parity."""
import contextlib
import io
import json
import os
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import check_production as cp
import compile_timeline as ct
import runtime
import test_check_production as fixtures


class BoundaryTests(unittest.TestCase):
    def setUp(self):
        self.f=fixtures.ProductionGateTest();self.f.setUp();self.addCleanup(self.f.doCleanups)
        self.path=(self.f.root/'reference_map.json').resolve()

    def test_optional_creation_blocks_cached_pass_and_close_then_fresh_recovers(self):
        path=self.f.root/'timeline.json';payload=path.read_bytes();path.unlink()
        context=cp.VerificationContext();self.assertTrue(cp.check(self.path,'plan',context=context)['passed'])
        path.write_bytes(payload)
        with self.assertRaisesRegex(ValueError,'Optional input appeared'):cp.check(self.path,'plan',context=context)
        with self.assertRaisesRegex(ValueError,'Optional input appeared'):context.close()
        self.assertTrue(cp.check(self.path,'plan')['passed'])

    def test_missing_symlink_target_appearance_is_not_ignored(self):
        path=self.f.root/'timeline.json';payload=path.read_bytes();path.unlink()
        target=self.f.root/'late-timeline.json';path.symlink_to(target)
        context=cp.VerificationContext();self.assertTrue(cp.check(self.path,'plan',context=context)['passed'])
        target.write_bytes(payload)
        with self.assertRaises(ValueError):context.close()

    def test_compiler_keeps_original_manifest_alias_until_close(self):
        alias=self.f.root/'alias.json';alias.symlink_to(self.path)
        other=self.f.root/'other.json';other.write_bytes(self.path.read_bytes())
        original=ct._compile_timeline
        def retarget(*args):
            result=original(*args);alias.unlink();alias.symlink_to(other);return result
        with patch.object(ct,'_compile_timeline',side_effect=retarget):
            with self.assertRaises(ValueError):ct.compile_timeline(alias)

    def test_report_cannot_replace_manifest_baseline_symlink_hardlink_or_compiled(self):
        baseline=self.f.root/'baseline.json';alias=self.f.root/'report-link.json';alias.symlink_to(baseline)
        hard=self.f.root/'report-hardlink.json';hard.hardlink_to(baseline)
        for out in (self.path,baseline,alias,hard,self.f.root/'compiled.json'):
            before={p:p.read_bytes() for p in (self.path,baseline)}
            with patch('sys.argv',['check_production',str(self.path),'--stage','plan','--out',str(out)]),contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(cp.main(),1)
            self.assertEqual(before,{p:p.read_bytes()for p in before})
            if out.name=='compiled.json':self.assertFalse(out.exists())

    def test_batch_report_cannot_replace_additional_manifest(self):
        other=fixtures.ProductionGateTest();other.setUp();self.addCleanup(other.doCleanups)
        path=other.root/'reference_map.json';before=path.read_bytes()
        with patch('sys.argv',['check_production',str(self.path),'--stage','plan','--also',str(path),'plan','--out',str(path)]),contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(cp.main(),1)
        self.assertEqual(before,path.read_bytes())

    def test_invalid_gate_still_cannot_replace_input_and_normal_failure_report_saved(self):
        self.f.m['cuts'][0]['effects']={};self.f.save()
        before=self.path.read_bytes()
        for out in (self.path,self.f.root/'failed-report.json'):
            with patch('sys.argv',['check_production',str(self.path),'--stage','plan','--out',str(out)]),contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(cp.main(),1)
        self.assertEqual(before,self.path.read_bytes())
        self.assertFalse(json.loads((self.f.root/'failed-report.json').read_text())['passed'])

    def test_successful_report_preserves_legacy_shape(self):
        out=self.f.root/'report.json'
        with patch('sys.argv',['check_production',str(self.path),'--stage','plan','--out',str(out)]),contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(cp.main(),0)
        report=json.loads(out.read_text());self.assertTrue(report['passed']);self.assertEqual(report['stage'],'plan')

    def test_cheap_failure_still_protects_declared_evidence_not_yet_read(self):
        (self.f.root/'code.js').unlink();out=self.f.root/'evidence.json';before=out.read_bytes()
        with patch('sys.argv',['check_production',str(self.path),'--stage','plan','--out',str(out)]),contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(cp.main(),1)
        self.assertEqual(before,out.read_bytes())

    def test_runtime_parser_handles_equals_abbreviation_and_reordered_options(self):
        run=self.f.root/'run';(run/'work').mkdir(parents=True);(run/'work/preflight-report.json').write_text('{"passed":true,"files":[]}')
        outside=self.f.root/'outside.json';outside.write_bytes(self.path.read_bytes());outside=outside.resolve()
        graph=self.f.root/'graph.json';graph.write_text(json.dumps({'scopes':{'full':{'path':str(self.path)}}}))
        suffixes=[['--also-manifest='+str(outside)],['--also-man='+str(outside)],['--also-manifest',str(outside)]]
        env={'LFC_RUN_DIR':str(run),'LFC_RUNTIME_HOME':str(run/'shared'),'LFC_REVISION_GRAPH':str(graph),'LFC_LEASE':''}
        for suffix in suffixes:
            args=['--out',str(self.f.root/'compiled.json'),*suffix,str(self.path)]
            self.assertEqual(ct.parse_arguments(args).also_manifest,[outside])
            with patch.dict(os.environ,env),patch('runtime.frozen_skill',return_value=Path(runtime.__file__).parent.parent),patch('runtime.bound_rollout',return_value=None),patch('scheduler.modern_run',return_value=True),patch('revision_graph.validate',return_value={'passed':True}),patch('runtime.subprocess.run',return_value=SimpleNamespace(returncode=0)) as child:
                with self.assertRaisesRegex(ValueError,'not current graph scope'):runtime.invoke('compile_timeline',args)
                child.assert_not_called()
        graph.write_text(json.dumps({'scopes':{'full':{'path':str(self.path)},'preview':{'path':str(outside)}}}))
        with patch.dict(os.environ,env),patch('runtime.frozen_skill',return_value=Path(runtime.__file__).parent.parent),patch('runtime.bound_rollout',return_value=None),patch('scheduler.modern_run',return_value=True),patch('revision_graph.validate',return_value={'passed':True}),patch('runtime.subprocess.run',return_value=SimpleNamespace(returncode=0)) as child,contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(runtime.invoke('compile_timeline',['--out',str(self.f.root/'compiled.json'),'--also-manifest='+str(outside),str(self.path)]),0)
            child.assert_called_once()


if __name__=='__main__':unittest.main()
