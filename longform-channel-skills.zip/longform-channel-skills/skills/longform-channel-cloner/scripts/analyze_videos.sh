#!/usr/bin/env bash
# Retired: the former pipeline included out-of-scope sound analysis and unsafe done markers.
printf '%s\n' 'This legacy pipeline is disabled. Follow SKILL.md: runtime init, frozen input manifest, Astra analysis, validate_analysis_bundle.' >&2
exit 2
