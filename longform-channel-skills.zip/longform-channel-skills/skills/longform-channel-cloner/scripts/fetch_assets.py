#!/usr/bin/env python3
"""Search, download and register licensed source media for each cut, SFX and BGM.

  run.sh fetch_assets search  --project DIR --key c001 --kind video|image|audio --query "..." [--query ...]
                              [--providers pexels,pixabay,commons,nasa,archive,openverse] [--n 6]
                              [--orientation landscape] [--audio-category sound_effect|music]
  run.sh fetch_assets pick     --project DIR --key c001 --candidate 3
  run.sh fetch_assets register --project DIR --key c001 --file PATH --method ai_image|ai_video|render_graphic|screen_capture
                              [--prompt "..."] [--tool "..."] [--notes "..."]
  run.sh fetch_assets status   --project DIR [--keys c001 c002 ...]

Keys: "<video_id>:<cut_id>" for recreation, "<cut_id>" inside a new-video plan, "sfx:<id>", "bgm:<n>".
search downloads previews of the top candidates into assets/candidates/<key>/ and writes a contact sheet
(assets/candidates/<key>/sheet.jpg) for visual choice. pick downloads the full file into assets/final/ and
records provider, url, license and attribution in assets/manifest.json. Nothing is picked automatically.

Providers without keys: commons (Wikimedia Commons), nasa, archive (Internet Archive), openverse
(images, audio incl. Freesound/Jamendo/ccMixter). Pexels / Pixabay need PEXELS_API_KEY / PIXABAY_API_KEY.
Only licenses that allow reuse are returned (CC0, PD, CC BY, CC BY-SA, Pexels/Pixabay license).
"""
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import sys
import time
import urllib.parse
import urllib.request
from pathlib import Path

from common import grid, label_image, probe, read_json, resize_w, write_json

UA = "longform-channel-cloner/1.0 (research tool; contact: local user)"
OK_LICENSES = ("cc0", "pdm", "by", "by-sa", "public domain", "cc-by", "cc by", "pd", "pexels", "pixabay")
NO_ATTRIBUTION = ("cc0", "pdm", "public domain", "publicdomain", "pexels", "pixabay", "nasa", "mixkit")


def http_json(url, headers=None, retries=3):
    h = {"User-Agent": UA, **(headers or {})}
    for k in range(retries):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=h), timeout=30) as r:
                return json.loads(r.read().decode("utf-8"))
        except Exception as e:
            if k == retries - 1:
                print(f"  ! {url[:90]}: {e}", file=sys.stderr)
                return None
            time.sleep(1.5 * (k + 1))


def download(url, dest: Path, headers=None) -> Path | None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    import subprocess
    # --retry-all-errors + growing delay: Wikimedia answers bursts with HTTP 429 (seen on 11 of 11 files in a row)
    cmd = ["curl", "-fsSL", "--retry", "5", "--retry-delay", "4", "--retry-all-errors", "--connect-timeout", "15",
           "--speed-limit", "10000", "--speed-time", "30", "-A", UA, "-o", str(dest), url]
    for k, v in (headers or {}).items():
        cmd[1:1] = ["-H", f"{k}: {v}"]
    for attempt in range(3):
        p = subprocess.run(cmd)
        if p.returncode == 0 and dest.exists() and dest.stat().st_size > 0:
            if "wikimedia.org" in url:
                time.sleep(1.5)  # stay under the Commons rate limit when picking several files
            return dest
        time.sleep(15 * (attempt + 1))
    print(f"  ! download failed ({p.returncode}) {url[:90]}", file=sys.stderr)
    dest.unlink(missing_ok=True)
    return None


def lic_ok(s: str | None) -> bool:
    s = (s or "").lower()
    if "nc" in re.split(r"[\s\-_/]", s) or "noncommercial" in s or "-nd" in s or " nd" in s:
        return False
    return any(k in s for k in OK_LICENSES)


def needs_attribution(s: str | None) -> bool:
    s = (s or "").lower()
    return not any(k in s for k in NO_ATTRIBUTION)


# ---------------------------------------------------------------- providers

def p_pexels(kind, q, n, orientation, **_):
    key = os.environ.get("PEXELS_API_KEY")
    if not key or kind == "audio":
        return []
    base = "https://api.pexels.com/videos/search" if kind == "video" else "https://api.pexels.com/v1/search"
    d = http_json(f"{base}?{urllib.parse.urlencode({'query': q, 'per_page': n, 'orientation': orientation})}",
                  {"Authorization": key}) or {}
    out = []
    for it in d.get("videos" if kind == "video" else "photos", []):
        if kind == "video":
            files = sorted([f for f in it["video_files"] if f.get("width")], key=lambda f: -f["width"])
            best = next((f for f in files if f["width"] <= 1920), files[-1] if files else None)
            if not best:
                continue
            out.append({"provider": "pexels", "id": str(it["id"]), "url": best["link"], "preview": it.get("image"),
                        "page": it["url"], "w": best["width"], "h": best["height"], "duration": it.get("duration"),
                        "license": "Pexels License", "author": it.get("user", {}).get("name")})
        else:
            out.append({"provider": "pexels", "id": str(it["id"]), "url": it["src"]["original"], "preview": it["src"]["medium"],
                        "page": it["url"], "w": it["width"], "h": it["height"], "license": "Pexels License",
                        "author": it.get("photographer")})
    return out


def p_pixabay(kind, q, n, orientation, **_):
    key = os.environ.get("PIXABAY_API_KEY")
    if not key or kind == "audio":
        return []
    base = "https://pixabay.com/api/videos/" if kind == "video" else "https://pixabay.com/api/"
    params = {"key": key, "q": q[:100], "per_page": max(3, n), "safesearch": "true"}
    if kind == "image":
        params["orientation"] = "horizontal" if orientation == "landscape" else "vertical"
    d = http_json(f"{base}?{urllib.parse.urlencode(params)}") or {}
    out = []
    for it in d.get("hits", []):
        if kind == "video":
            v = it["videos"].get("large") or it["videos"].get("medium")
            if not v or not v.get("url"):
                continue
            out.append({"provider": "pixabay", "id": str(it["id"]), "url": v["url"], "preview": v.get("thumbnail"),
                        "page": it["pageURL"], "w": v["width"], "h": v["height"], "duration": it.get("duration"),
                        "license": "Pixabay Content License", "author": it.get("user")})
        else:
            out.append({"provider": "pixabay", "id": str(it["id"]), "url": it.get("largeImageURL"),
                        "preview": it.get("webformatURL"), "page": it["pageURL"], "w": it["imageWidth"],
                        "h": it["imageHeight"], "license": "Pixabay Content License", "author": it.get("user")})
    return out


def p_commons(kind, q, n, orientation, **_):
    ft = {"video": "filetype:video", "image": "filetype:bitmap", "audio": "filetype:audio"}[kind]
    params = {"action": "query", "format": "json", "generator": "search", "gsrnamespace": 6, "gsrlimit": n * 3,
              "gsrsearch": f"{q} {ft}", "prop": "imageinfo", "iiprop": "url|size|mime|extmetadata",
              "iiurlwidth": 480}
    d = http_json("https://commons.wikimedia.org/w/api.php?" + urllib.parse.urlencode(params)) or {}
    out = []
    for p in (d.get("query", {}).get("pages", {}) or {}).values():
        ii = (p.get("imageinfo") or [{}])[0]
        md = ii.get("extmetadata", {})
        lic = md.get("LicenseShortName", {}).get("value", "")
        if not lic_ok(lic):
            continue
        w, h = ii.get("width") or 0, ii.get("height") or 0
        if kind != "audio" and orientation == "landscape" and w and h and w < h:
            continue
        author = re.sub(r"<[^>]+>", "", md.get("Artist", {}).get("value", "")).strip()
        out.append({"provider": "commons", "id": str(p["pageid"]), "url": ii.get("url"), "preview": ii.get("thumburl"),
                    "page": ii.get("descriptionurl"), "w": w, "h": h, "duration": ii.get("duration"),
                    "license": lic, "license_url": md.get("LicenseUrl", {}).get("value"), "author": author,
                    "title": p.get("title")})
    out.sort(key=lambda c: -(c["w"] or 0))
    return out[:n]


def p_nasa(kind, q, n, orientation=None, **_):
    if kind == "audio":
        return []
    d = http_json("https://images-api.nasa.gov/search?" + urllib.parse.urlencode(
        {"q": q, "media_type": kind, "page_size": n})) or {}
    out = []
    for it in d.get("collection", {}).get("items", [])[:n]:
        data = (it.get("data") or [{}])[0]
        coll = http_json(it["href"].replace(" ", "%20")) or []
        files = [u for u in coll if isinstance(u, str)]
        if kind == "video":
            pick = next((u for u in files if u.endswith("~orig.mp4")), None) or next((u for u in files if u.endswith(".mp4")), None)
        else:
            pick = next((u for u in files if "~orig." in u), None) or next((u for u in files if u.endswith(".jpg")), None)
        prev = next((l.get("href") for l in it.get("links", []) if l.get("render") == "image"), None)
        if pick:
            out.append({"provider": "nasa", "id": data.get("nasa_id"), "url": pick.replace(" ", "%20").replace("http://", "https://"),
                        "preview": prev, "page": f"https://images.nasa.gov/details/{urllib.parse.quote(data.get('nasa_id', ''))}",
                        "license": "Public Domain (NASA)", "author": data.get("center"), "title": data.get("title")})
    return out


def p_archive(kind, q, n, orientation=None, **_):
    mt = {"video": "movies", "image": "image", "audio": "audio"}[kind]
    query = f"({q}) AND mediatype:{mt} AND (licenseurl:*publicdomain* OR licenseurl:*creativecommons.org/licenses/by/* OR licenseurl:*creativecommons.org/licenses/by-sa/* OR licenseurl:*zero*)"
    d = http_json("https://archive.org/advancedsearch.php?" + urllib.parse.urlencode(
        {"q": query, "fl[]": ["identifier", "title", "licenseurl", "creator"], "rows": n, "output": "json"}, doseq=True)) or {}
    out = []
    for doc in d.get("response", {}).get("docs", []):
        md = http_json(f"https://archive.org/metadata/{doc['identifier']}") or {}
        files = md.get("files", [])
        want = {"video": ("h.264", "mpeg4", "512kb mpeg4"), "image": ("jpeg", "png"), "audio": ("vbr mp3", "mp3", "flac")}[kind]
        f = next((f for f in files if f.get("format", "").lower() in want), None)
        if not f:
            continue
        url = f"https://archive.org/download/{doc['identifier']}/{urllib.parse.quote(f['name'])}"
        out.append({"provider": "archive", "id": doc["identifier"], "url": url,
                    "preview": f"https://archive.org/services/img/{doc['identifier']}", "page": f"https://archive.org/details/{doc['identifier']}",
                    "license": doc.get("licenseurl"), "author": doc.get("creator"), "title": doc.get("title")})
    return out


def p_openverse(kind, q, n, orientation, audio_category=None, no_attribution=False, **_):
    if kind == "video":
        return []
    params = {"q": q, "page_size": n}
    if no_attribution:
        params["license"] = "cc0,pdm"
    else:
        params["license"] = "cc0,pdm,by,by-sa"
    if kind == "image":
        params.update(size="large", aspect_ratio="wide" if orientation == "landscape" else "tall")
    elif audio_category:
        params["category"] = audio_category
    base = f"https://api.openverse.org/v1/{'images' if kind == 'image' else 'audio'}/?"
    d = http_json(base + urllib.parse.urlencode(params)) or {}
    if kind == "audio" and audio_category and not d.get("results"):
        # Openverse's category tag is sparse (many CC0 Freesound effects are untagged): retry without it
        params.pop("category", None)
        d = http_json(base + urllib.parse.urlencode(params)) or {}
    out = []
    for it in d.get("results", []):
        lic = f"{it.get('license')} {it.get('license_version') or ''}".strip()
        if not lic_ok(lic):
            continue
        out.append({"provider": f"openverse/{it.get('source')}", "id": it["id"], "url": it["url"],
                    "preview": it.get("thumbnail") if kind == "image" else None, "page": it.get("foreign_landing_url"),
                    "w": it.get("width"), "h": it.get("height"), "duration": (it.get("duration") or 0) / 1000 or None,
                    "license": lic, "license_url": it.get("license_url"), "author": it.get("creator"),
                    "attribution": it.get("attribution"), "title": it.get("title")})
    return out


PROVIDERS = {"pexels": p_pexels, "pixabay": p_pixabay, "commons": p_commons, "nasa": p_nasa, "archive": p_archive,
             "openverse": p_openverse}


def key_dir(project: Path, key: str) -> Path:
    return project / "assets" / "candidates" / re.sub(r"[^\w\-]+", "_", key)


def manifest(project: Path) -> dict:
    p = project / "assets" / "manifest.json"
    return read_json(p) if p.exists() else {"items": {}}


def cmd_search(a):
    project = Path(a.project)
    kd = key_dir(project, a.key)
    kd.mkdir(parents=True, exist_ok=True)
    provs = [p.strip() for p in a.providers.split(",") if p.strip()]
    cands = []
    for q in a.query:
        for p in provs:
            try:
                res = PROVIDERS[p](a.kind, q, a.n, a.orientation, audio_category=a.audio_category,
                                   no_attribution=a.no_attribution)
            except Exception as e:
                print(f"  ! {p}: {e}", file=sys.stderr)
                res = []
            for r in res:
                r["query"] = q
            cands += res
            print(f"  {p:<9} '{q}': {len(res)}")
    seen, uniq = set(), []
    for c in cands:
        c["attribution_required"] = needs_attribution(c.get("license"))
        if a.no_attribution and c["attribution_required"]:
            continue
        if c.get("url") and c["url"] not in seen:
            seen.add(c["url"])
            uniq.append(c)
    import cv2
    import numpy as np
    thumbs = []
    for i, c in enumerate(uniq, 1):
        c["n"] = i
        if c.get("preview"):
            pv = download(c["preview"], kd / f"prev_{i:02d}.jpg")
            img = cv2.imread(str(pv)) if pv else None
            if img is not None:
                img = resize_w(img, 320)
                img = img[:180] if img.shape[0] >= 180 else cv2.copyMakeBorder(img, 0, 180 - img.shape[0], 0, 0, cv2.BORDER_CONSTANT)
                thumbs.append(label_image(img, f"#{i} {c['provider'][:14]} {c.get('w') or ''}x{c.get('h') or ''} {c.get('duration') or ''}", 0.38))
    if thumbs:
        cv2.imwrite(str(kd / "sheet.jpg"), grid(thumbs, 4))
    write_json(kd / "candidates.json", {"key": a.key, "kind": a.kind, "queries": a.query, "candidates": uniq})
    print(f"{len(uniq)} candidates -> {kd / 'candidates.json'}" + (f", sheet {kd / 'sheet.jpg'}" if thumbs else ""))
    if not os.environ.get("PEXELS_API_KEY") and not os.environ.get("PIXABAY_API_KEY") and a.kind == "video":
        print("note: PEXELS_API_KEY / PIXABAY_API_KEY not set - stock video search limited to commons/nasa/archive")


def register(project: Path, key: str, entry: dict):
    m = manifest(project)
    m["items"][key] = entry
    write_json(project / "assets" / "manifest.json", m)


def cmd_pick(a):
    project = Path(a.project)
    kd = key_dir(project, a.key)
    cands = read_json(kd / "candidates.json")
    c = next((c for c in cands["candidates"] if c["n"] == a.candidate), None)
    if not c:
        sys.exit("no such candidate")
    ext = Path(urllib.parse.urlparse(c["url"]).path).suffix.lower() or {"video": ".mp4", "image": ".jpg", "audio": ".mp3"}[cands["kind"]]
    dest = project / "assets" / "final" / f"{re.sub(r'[^\w\-]+', '_', a.key)}{ext}"
    headers = {"Authorization": os.environ["PEXELS_API_KEY"]} if c["provider"] == "pexels" and os.environ.get("PEXELS_API_KEY") else None
    if not download(c["url"], dest, headers):
        sys.exit(1)
    if ext in (".webm", ".ogv", ".mov", ".mkv", ".mpg", ".mpeg", ".avi") and cands["kind"] == "video":
        from common import FFMPEG, run
        mp4 = dest.with_suffix(".mp4")
        run([FFMPEG, "-hide_banner", "-loglevel", "error", "-y", "-i", str(dest), "-c:v", "libx264", "-crf", "18",
             "-preset", "fast", "-pix_fmt", "yuv420p", "-an", str(mp4)])
        dest.unlink()
        dest = mp4
    info = probe(dest) if cands["kind"] != "image" else {}
    entry = {"file": str(dest.relative_to(project)), "kind": cands["kind"], "method": "stock_search" if cands["kind"] != "audio" else "library",
             "provider": c["provider"], "url": c["url"], "page": c.get("page"), "license": c.get("license"),
             "license_url": c.get("license_url"), "author": c.get("author"), "attribution": c.get("attribution"),
             "title": c.get("title"), "query": c.get("query"), "attribution_required": needs_attribution(c.get("license")),
             "probe": info}
    if cands["kind"] == "audio":
        entry["onset_s"] = c.get("onset_s", 0.0)
        entry["match"] = c.get("match")
    register(project, a.key, entry)
    print(f"picked #{a.candidate} -> {dest} ({entry['license']})")


def cmd_register(a):
    project = Path(a.project)
    src = Path(a.file)
    if not src.exists():
        sys.exit(f"missing {src}")
    dest = project / "assets" / "final" / f"{re.sub(r'[^\w\-]+', '_', a.key)}{src.suffix.lower()}"
    dest.parent.mkdir(parents=True, exist_ok=True)
    if src.resolve() != dest.resolve():
        shutil.copy2(src, dest)
    kind = "image" if src.suffix.lower() in (".png", ".jpg", ".jpeg", ".webp") else ("audio" if src.suffix.lower() in (".wav", ".mp3", ".m4a", ".ogg") else "video")
    register(project, a.key, {"file": str(dest.relative_to(project)), "kind": kind, "method": a.method,
                              "prompt": a.prompt, "tool": a.tool, "notes": a.notes,
                              "probe": probe(dest) if kind != "image" else {}})
    print(f"registered {a.key} -> {dest}")


def cmd_status(a):
    m = manifest(Path(a.project))["items"]
    keys = a.keys or sorted(m)
    missing = [k for k in keys if k not in m]
    for k in keys:
        if k in m:
            e = m[k]
            flag = " [attribution required]" if e.get("attribution_required") else ""
            print(f"  {k:<28} {e['method']:<13} {e.get('provider') or e.get('tool') or '':<18} {e.get('license') or ''}{flag}")
    if missing:
        print(f"MISSING {len(missing)}: {missing}")
        sys.exit(1)


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("search")
    s.add_argument("--project", required=True); s.add_argument("--key", required=True)
    s.add_argument("--kind", choices=["video", "image", "audio"], required=True)
    s.add_argument("--query", action="append", required=True)
    s.add_argument("--providers", default="pexels,pixabay,commons,nasa,archive,openverse")
    s.add_argument("--n", type=int, default=6)
    s.add_argument("--orientation", default="landscape")
    s.add_argument("--audio-category", choices=["sound_effect", "music"])
    s.add_argument("--no-attribution", action="store_true",
                   help="only licenses that need no credit (use when the reference shows no credit for this cut)")
    p = sub.add_parser("pick")
    p.add_argument("--project", required=True); p.add_argument("--key", required=True)
    p.add_argument("--candidate", type=int, required=True)
    r = sub.add_parser("register")
    r.add_argument("--project", required=True); r.add_argument("--key", required=True)
    r.add_argument("--file", required=True)
    r.add_argument("--method", choices=["ai_image", "ai_video", "render_graphic", "screen_capture", "library"], required=True)
    r.add_argument("--prompt"); r.add_argument("--tool"); r.add_argument("--notes")
    st = sub.add_parser("status")
    st.add_argument("--project", required=True); st.add_argument("--keys", nargs="*")
    a = ap.parse_args()
    {"search": cmd_search, "pick": cmd_pick, "register": cmd_register, "status": cmd_status}[a.cmd](a)


if __name__ == "__main__":
    main()
