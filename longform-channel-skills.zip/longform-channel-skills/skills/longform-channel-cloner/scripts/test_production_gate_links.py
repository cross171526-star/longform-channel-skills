"""연결 누락·오래된 입력·경계 단축 우회에 대한 회귀 검증."""
import copy
import json
import subprocess
import sys
import unittest
from pathlib import Path
from check_production import digest
from compile_timeline import compile_timeline
from plan_duration import plan_duration
from production_gate_links import validate_scope
import test_check_production as fixtures


class GateLinkTests(unittest.TestCase):
    def setUp(self):
        self.f = fixtures.ProductionGateTest()
        self.f.setUp()
        self.addCleanup(self.f.doCleanups)

    def doc(self, name):
        return json.loads((self.f.root / name).read_text())

    def one_reference(self, target=300):
        f=self.f
        selected={'reference_count':1,'references':[{'id':'v1','duration_s':target}]}
        f.write('selected6.json',selected);f.write('duration_input.json',selected)
        f.write('duration_plan.json',plan_duration(selected,digest(f.root/'duration_input.json')))
        f.set_backgrounds([target])

    def test_latest_one_full_plan_thirty_second_boundaries(self):
        self.one_reference()
        for duration,expected in ((270,True),(330,True),(269.99,False),(330.01,False)):
            with self.subTest(duration=duration):
                self.f.m['cuts'][0]['duration_s']=duration
                result=self.f.run_gate('plan')
                self.assertEqual(result['passed'],expected,result['errors'])
                self.assertEqual(result['duration_link']['delta_s'],duration-300)

    def test_total_tolerance_does_not_widen_cut_ratio(self):
        self.one_reference(100)
        self.f.m['cuts'][0]['duration_s']=125
        result=self.f.run_gate('plan')
        self.assertFalse(result['passed'])
        self.assertTrue(any('80–120%' in e for e in result['errors']),result['errors'])

    def test_latest_one_final_duration_cannot_add_render_tolerance(self):
        self.one_reference()
        for planned,outside in ((270,269.99),(330,330.01)):
            self.f.m['cuts'][0]['duration_s']=planned
            self.f.probe=lambda p:dict(fixtures.ProductionGateTest.probe(p),format={'format_name':'mp4','duration':str(planned)})
            self.f.reviews()
            self.assertTrue(self.f.run_gate('final')['passed'])
            self.f.probe=lambda p:dict(fixtures.ProductionGateTest.probe(p),format={'format_name':'mp4','duration':str(outside)})
            self.f.assert_gate_error('Full render duration outside reference target','final')

    def test_latest_one_preview_keeps_170_to_210_seconds(self):
        self.one_reference()
        self.f.m['cuts'][0]['duration_s']=300
        self.f.m['output_scope']={'kind':'preview','start_s':0,'end_s':180,'full_plan':'full.json'}
        full=copy.deepcopy(self.f.m);full['output_scope']={'kind':'full'}
        full['tts']['timeline']='full-timeline.json'
        full['render_inputs']=[name if name!='timeline.json' else 'full-timeline.json' for name in full['render_inputs']]
        self.f.write('full-timeline.json',self.f.timeline)
        self.f.write('full.json',full)
        for end,expected in ((170,True),(210,True),(160,False),(220,False)):
            self.f.m['output_scope']['end_s']=end
            result=self.f.run_gate('plan')
            self.assertEqual(result['passed'],expected,result['errors'])

    def test_mandatory_plan_links(self):
        f = self.f
        for key in ('compiled_timeline', 'visual_acceptance', 'duration_link'):
            with self.subTest(key=key):
                old = f.m.pop(key)
                self.assertFalse(f.run_gate()['passed'])
                f.m[key] = old
        baseline = self.doc('baseline.json')
        for key in ('narration_windows', 'required_visual_rule_ids'):
            with self.subTest(key=key):
                changed = copy.deepcopy(baseline)
                changed.pop(key)
                f.write('baseline.json', changed)
                self.assertFalse(f.run_gate()['passed'])
        f.write('baseline.json', baseline)

    def test_window_widening_inside_same_cut_fails(self):
        f = self.f
        f.timeline['segments'][0]['allowed_end_s'] = 5
        f.save_narration()
        f.assert_gate_error('window differs from baseline')

    def test_windows_validated_at_plan(self):
        f = self.f
        original = self.doc('baseline.json')
        for replacement in ([], [dict(original['narration_windows'][0], cut_ids=['unknown'])],
                            [dict(original['narration_windows'][0], allowed_end_s=11)],
                            [dict(original['narration_windows'][0], allowed_end_s=True)],
                            [original['narration_windows'][0]] * 2):
            with self.subTest(replacement=replacement):
                f.write('baseline.json', dict(original, narration_windows=replacement))
                self.assertFalse(f.run_gate()['passed'])

    def test_swapped_six_even_when_input_and_plan_agree_fails(self):
        f = self.f
        input_doc = self.doc('duration_input.json')
        input_doc['references'][-1]['id'] = 'different-sixth'
        f.write('duration_input.json', input_doc)
        f.write('duration_plan.json', plan_duration(input_doc, digest(f.root / 'duration_input.json')))
        f.assert_gate_error('authoritative selected6', 'plan')

    def test_duration_mismatch_and_stale_plan(self):
        f = self.f
        original = self.doc('duration_input.json')
        for key in ('id', 'duration_s'):
            changed = copy.deepcopy(original)
            changed['references'][0][key] = 'other' if key == 'id' else 11
            f.write('duration_input.json', changed)
            f.assert_gate_error('authoritative selected6', 'plan')
        f.write('duration_input.json', original)
        for key, value in (('source_input_sha256', 'old'), ('target_duration_s', 180),
                           ('preview_end_s', 180), ('preview_duration_s', True)):
            plan = plan_duration(original, digest(f.root / 'duration_input.json'))
            plan[key] = value
            f.write('duration_plan.json', plan)
            f.assert_gate_error('recomputed plan', 'plan')

    def test_authoritative_order_can_differ(self):
        f = self.f
        selected = self.doc('selected6.json')
        selected['references'].reverse()
        f.write('selected6.json', selected)
        self.assertTrue(f.run_gate()['passed'])

    def test_impossible_mean_fails_and_preserves_original_delta(self):
        f = self.f
        f.set_duration(500)
        result = f.run_gate()
        self.assertFalse(result['passed'], result)
        self.assertFalse(result['duration_link']['preflight']['mean_feasible'])
        self.assertEqual(result['duration_link']['full_planned_duration_s'], 10)
        self.assertEqual(result['duration_link']['target_duration_s'], 500)
        self.assertEqual(result['duration_link']['delta_s'], -490)

    def test_compiler_needs_no_compiled_output_or_future_synthesis(self):
        f = self.f
        (f.root / 'narration.json').unlink()
        (f.root / 'timeline.json').unlink()
        self.assertTrue(f.run_gate()['passed'])
        result = compile_timeline(f.root / 'reference_map.json')
        self.assertEqual(result['duration_s'], 10)
        self.assertEqual(result['narration_segments'], [])

    def test_missing_compiled_output_fails_assets(self):
        f = self.f
        result = f.run_gate('assets', refresh_compile=False)
        self.assertFalse(result['passed'])
        self.assertIn('Missing compiled_timeline output', result['errors'])

    def test_compiled_and_acceptance_must_be_in_inventory(self):
        f = self.f
        for name in ('compiled.json', 'visual_acceptance.json'):
            f.m['render_inputs'].remove(name)
            f.assert_gate_error('missing from render_inputs', 'plan')
            f.m['render_inputs'].append(name)

    def test_compiled_semantics_and_provenance_must_match(self):
        f = self.f
        self.assertTrue(f.run_gate('assets')['passed'])
        valid = self.doc('compiled.json')
        for key, value in (('source_manifest_sha256', 'old'), ('plan_input_sha256', 'old'),
                           ('duration_s', 11), ('narration_windows', []), ('cuts', []),
                           ('narration_segments', [])):
            f.write('compiled.json', dict(valid, **{key: value}))
            result = f.run_gate('assets', refresh_compile=False)
            self.assertFalse(result['passed'], key)
            self.assertTrue(any('compiled_timeline' in e for e in result['errors']))

    def test_latest_code_and_baseline_and_assets_invalidate_compilation(self):
        f = self.f
        for name in ('code.js', 'asset.mp4', 'baseline.json', 'evidence.json'):
            with self.subTest(name=name):
                self.assertTrue(f.run_gate('assets')['passed'])
                original = (f.root / name).read_text()
                (f.root / name).write_text(original + '\n')
                result = f.run_gate('assets', refresh_compile=False)
                self.assertFalse(result['passed'])
                self.assertTrue(any('compiled_timeline' in e for e in result['errors']))

    def test_compiled_hash_excluded_avoids_cycles(self):
        f = self.f
        before = f.run_gate('assets')
        (f.root / 'compiled.json').write_text('{}')
        after = f.run_gate('assets', refresh_compile=False)
        self.assertEqual(before['input_sha256'], after['input_sha256'])
        self.assertFalse(after['passed'])
        result = f.run_gate('assets')
        self.assertTrue(result['passed'])
        self.assertEqual(before['input_sha256'], result['input_sha256'])
        self.assertFalse(result['renderer_usage_verified'])

    def test_missing_visual_acceptance_evidence_or_metrics_fails(self):
        f = self.f
        original = self.doc('visual_acceptance.json')
        variants = [dict(original, rules=[]), dict(original, tolerance_status='pending')]
        for key in ('evidence', 'metrics'):
            changed = copy.deepcopy(original)
            changed['rules'][0].pop(key)
            variants.append(changed)
        changed = copy.deepcopy(original)
        changed['rules'][0]['evidence']['pointer'] = '/missing'
        variants.append(changed)
        for changed in variants:
            f.write('visual_acceptance.json', changed)
            self.assertFalse(f.run_gate()['passed'])

    def test_provisional_tolerance_passes_assets_but_missing_effect_does_not(self):
        f = self.f
        self.assertTrue(f.run_gate('assets')['passed'])
        f.m['cuts'][0]['effects'] = {}
        f.assert_gate_error('missing grain', 'assets')

    def test_visual_measurements_missing_failed_stale_or_outside_tolerance(self):
        f = self.f
        f.reviews()
        original = copy.deepcopy(f.c)
        changed = copy.deepcopy(original)
        changed.pop('visual_measurements')
        variants = [changed]
        for key, value in (('status', 'fail'), ('input_sha256', 'old'), ('render_sha256', 'old'),
                           ('visual_acceptance_sha256', 'old'), ('rules', [])):
            changed = copy.deepcopy(original)
            changed['visual_measurements'][key] = value
            variants.append(changed)
        for value in (.23, None, True, float('nan')):
            changed = copy.deepcopy(original)
            changed['visual_measurements']['rules'][0]['metrics'][0]['value'] = value
            variants.append(changed)
        for changed in variants:
            f.write('conformance.json', changed)
            self.assertFalse(f.run_gate('final')['passed'])

    def test_final_measurement_evidence_and_metric_coverage_mandatory(self):
        f = self.f
        f.reviews()
        original = copy.deepcopy(f.c)
        for key in ('evidence', 'metrics'):
            changed = copy.deepcopy(original)
            changed['visual_measurements']['rules'][0].pop(key)
            f.write('conformance.json', changed)
            self.assertFalse(f.run_gate('final')['passed'])

    def test_changed_acceptance_invalidates_measurements_even_after_recompile(self):
        f = self.f
        f.reviews()
        acceptance = self.doc('visual_acceptance.json')
        acceptance['rules'][0]['metrics'][0]['tolerance'] = .03
        f.write('visual_acceptance.json', acceptance)
        f.assert_gate_error('Stale visual measurements', 'final')

    def setup_preview(self, full_length=300):
        f = self.f
        base = self.doc('baseline.json')
        original_cut, actual_cut = base['cuts'][0], f.m['cuts'][0]
        durations = [90, 100, full_length - 190] if full_length > 190 else [full_length]
        base['cuts'] = [dict(original_cut, id='c' + str(i + 1), duration_s=d) for i, d in enumerate(durations)]
        f.m['cuts'] = [dict(actual_cut, id='c' + str(i + 1), duration_s=d) for i, d in enumerate(durations)]
        if full_length > 190:
            f.m['cuts'][2]['assets'] = [dict(actual_cut['assets'][0], path='future.mp4')]
            f.m['render_inputs'].append('future.mp4')
            full_segments = [
                dict(line_id='l1', cut_ids=['c1'], allowed_start_s=0, allowed_end_s=90, start_s=0, end_s=3, playback_rate=1),
                dict(line_id='l2', cut_ids=['c2'], allowed_start_s=90, allowed_end_s=190, start_s=170, end_s=184, playback_rate=1),
                dict(line_id='l3', cut_ids=['c3'], allowed_start_s=190, allowed_end_s=full_length, start_s=200, end_s=210, playback_rate=1)]
        else:
            full_segments = copy.deepcopy(f.timeline['segments'])
        base['narration_windows'] = [{k: s[k] for k in ('line_id', 'cut_ids', 'allowed_start_s', 'allowed_end_s')} for s in full_segments]
        f.write('baseline.json', base)
        f.set_backgrounds(durations)
        f.set_duration(500)  # Deliberately differs from actual full plan.
        f.authorize_duration()
        full = copy.deepcopy(f.m)
        full['compiled_timeline'] = 'full-compiled.json'
        full['tts'].update(timeline='full-timeline.json', narration_metadata='future-narration.json')
        full['render_inputs'] = [n for n in full['render_inputs'] if n not in ('compiled.json', 'timeline.json', 'narration.json')]
        full['render_inputs'] += ['full-compiled.json', 'full-timeline.json', 'future-narration.json']
        f.write('full-timeline.json', {'segments': full_segments})
        f.write('full-plan.json', full)
        end = min(180, full_length)
        f.m['output_scope'] = dict(kind='preview', full_plan='full-plan.json', start_s=0, end_s=end)
        f.timeline['segments'] = copy.deepcopy([s for s in full_segments if s['start_s'] < end])
        for segment in f.timeline['segments']:
            if segment['start_s'] < end < segment['end_s']:
                segment['output_clip'] = dict(start_s=segment['start_s'], end_s=end)
        for line, segment in zip(f.narration['lines'], f.timeline['segments']):
            line.update(placed_start_s=segment['start_s'], placed_end_s=segment['end_s'])
        f.save_narration()
        f.save()
        return f

    def test_preview_boundary_clips_output_only_and_skips_future_assets_tts(self):
        f = self.setup_preview()
        probed = []
        def probe(path):
            probed.append(path.name)
            return fixtures.ProductionGateTest.probe(path)
        f.probe = probe
        result = f.run_gate('assets')
        self.assertTrue(result['passed'], result)
        self.assertNotIn('future.mp4', probed)
        self.assertEqual(result['visible_cut_ids'], ['c1', 'c2'])
        compiled = self.doc('compiled.json')
        self.assertEqual(compiled['duration_s'], 300)
        self.assertEqual(compiled['output_duration_s'], 180)
        self.assertIsNone(compiled['cuts'][2]['output_clip'])
        self.assertEqual(compiled['narration_segments'][1]['end_s'], 184)
        self.assertEqual(compiled['narration_segments'][1]['output_clip']['end_s'], 180)
        self.assertEqual(result['duration_link']['delta_s'], -200)

    def test_preview_cannot_shorten_placement_and_metadata_together(self):
        f = self.setup_preview()
        f.timeline['segments'][1]['end_s'] = 180
        f.timeline['segments'][1].pop('output_clip')
        f.narration['lines'][1]['placed_end_s'] = 180
        f.save_narration()
        f.assert_gate_error('arbitrary shortening')

    def test_preview_missing_or_arbitrary_boundary_clip_fails(self):
        f = self.setup_preview()
        for clip in (None, {'start_s': 170, 'end_s': 179}, {'start_s': 171, 'end_s': 180},
                     {'start_s': 170, 'end_s': 184}):
            if clip is None:
                f.timeline['segments'][1].pop('output_clip', None)
            else:
                f.timeline['segments'][1]['output_clip'] = clip
            f.save_narration()
            f.assert_gate_error('boundary output_clip')

    def test_preview_non_crossing_line_cannot_have_output_clip(self):
        f = self.setup_preview()
        f.timeline['segments'][0]['output_clip'] = {'start_s': 0, 'end_s': 2}
        f.save_narration()
        f.assert_gate_error('only allowed for boundary crossing')

    def test_preview_full_plan_link_and_length_mandatory(self):
        f = self.setup_preview()
        f.m['output_scope']['end_s'] = 169
        f.assert_gate_error('end within min(170', 'plan')
        f.m['output_scope']['end_s'] = 180
        f.m['output_scope'].pop('full_plan')
        f.assert_gate_error('full_plan', 'plan')

    def test_preview_range_inclusive_uses_actual_full_length(self):
        f = self.setup_preview()
        for end in (170, 179, 195, 210):
            with self.subTest(end=end):
                f.m['output_scope']['end_s'] = end
                result = f.run_gate('plan')
                self.assertTrue(result['passed'], result)
                self.assertEqual(result['output_bounds'], {'start_s': 0, 'end_s': end})
                compiled = compile_timeline(f.root / 'reference_map.json')
                self.assertEqual(compiled['output_duration_s'], end)
        for end in (169.99, 210.01, 301):
            with self.subTest(end=end):
                f.m['output_scope']['end_s'] = end
                f.assert_gate_error('end within min(170', 'plan')

    def test_preview_range_capped_by_full_length(self):
        f = self.setup_preview(full_length=180)
        for end in (170, 175, 180):
            with self.subTest(end=end):
                f.m['output_scope']['end_s'] = end
                result = f.run_gate('plan')
                self.assertTrue(result['passed'], result)
                self.assertEqual(result['output_bounds']['end_s'], end)
        f.m['output_scope']['end_s'] = 180.01
        f.assert_gate_error('end within min(170', 'plan')

    def test_preview_rejects_invalid_start_and_nonfinite_bounds(self):
        f = self.setup_preview()
        original = copy.deepcopy(f.m['output_scope'])
        for key, invalid in (
                ('start_s', 1), ('start_s', -1), ('start_s', True),
                ('start_s', float('nan')), ('start_s', float('inf')),
                ('start_s', float('-inf')), ('end_s', float('nan')),
                ('end_s', float('inf')), ('end_s', float('-inf')),
                ('end_s', True), ('end_s', '180')):
            with self.subTest(key=key, invalid=invalid):
                f.m['output_scope'] = dict(original, **{key: invalid})
                with self.assertRaisesRegex(ValueError, 'end within min\\(170'):
                    validate_scope(f.m, f.root, {'full_planned_duration_s': 300}, self.doc)

    def test_short_preview_uses_actual_full_length_not_reference_mean(self):
        f = self.setup_preview(full_length=10)
        result = f.run_gate('assets')
        self.assertTrue(result['passed'], result)
        self.assertEqual(result['output_bounds']['end_s'], 10)
        self.assertEqual(result['duration_link']['target_duration_s'], 500)
        for end in (9.99, 10.01, 170):
            with self.subTest(end=end):
                f.m['output_scope']['end_s'] = end
                f.assert_gate_error('end within min(170', 'plan')

    def test_preview_final_render_duration_checks_output(self):
        f = self.setup_preview()
        f.probe = lambda p: dict(fixtures.ProductionGateTest.probe(p), format={'format_name': 'mp4', 'duration': '180'})
        f.reviews()
        result = f.run_gate('final')
        self.assertTrue(result['passed'], result)

    def test_visual_rule_cut_scope_mandatory_known_unique(self):
        f = self.f
        original = self.doc('visual_acceptance.json')
        for cut_ids in (None, [], ['unknown'], ['c1', 'c1']):
            changed = copy.deepcopy(original)
            changed['rules'][0]['cut_ids'] = cut_ids
            f.write('visual_acceptance.json', changed)
            f.assert_gate_error('rule cut_ids scope', 'plan')

    def test_preview_measures_only_visible_rules_but_validates_all_definitions(self):
        f = self.setup_preview()
        acceptance = self.doc('visual_acceptance.json')
        future = copy.deepcopy(acceptance['rules'][0])
        future.update(id='post180', cut_ids=['c3'])
        acceptance['rules'].append(future)
        f.write('visual_acceptance.json', acceptance)
        baseline = self.doc('baseline.json')
        baseline['required_visual_rule_ids'].append('post180')
        f.write('baseline.json', baseline)
        f.authorize_duration()
        full = self.doc('full-plan.json')
        full['duration_link'] = copy.deepcopy(f.m['duration_link'])
        f.write('full-plan.json', full)
        f.probe = lambda p: dict(fixtures.ProductionGateTest.probe(p), format={'format_name': 'mp4', 'duration': '180'})
        f.reviews()
        result = f.run_gate('final')
        self.assertTrue(result['passed'], result)
        self.assertEqual(result['required_visual_measurement_rule_ids'], ['grain'])
        future.pop('metrics')
        f.write('visual_acceptance.json', acceptance)
        f.assert_gate_error('Missing visual_acceptance metrics', 'plan')

    def preview_override(self, cut_id):
        f = self.setup_preview()
        baseline = self.doc('baseline.json')
        override = dict(cut_id=cut_id, reviewer='codex', authorization={'file': 'authorization.json', 'pointer': '/instruction'})
        f.write('authorization.json', {'instruction': {'text': 'authorized', 'scope': [cut_id]}})
        baseline['visual_review_overrides'] = [override]
        f.write('baseline.json', baseline)
        f.authorize_duration()
        f.probe = lambda p: dict(fixtures.ProductionGateTest.probe(p), format={'format_name': 'mp4', 'duration': '180'})
        f.reviews()
        return f, override

    def test_preview_future_override_needs_no_conformance_authorization(self):
        f, override = self.preview_override('c3')
        self.assertEqual(f.c['user_authorized_changes'], [])
        self.assertTrue(f.run_gate('final')['passed'])

    def test_preview_visible_override_parts_cover_only_visible_cuts(self):
        f, override = self.preview_override('c1')
        review = f.c['visual_review']
        f.c['visual_review'] = {k: review[k] for k in ('status', 'input_sha256', 'render_sha256')}
        f.c['visual_review']['parts'] = [dict(review, reviewer='codex', cut_ids=['c1']),
                                         dict(review, reviewer='sol', cut_ids=['c2'])]
        f.c['user_authorized_changes'] = [override]
        f.write('conformance.json', f.c)
        self.assertTrue(f.run_gate('final')['passed'])
        f.c['visual_review']['parts'][1]['cut_ids'].append('c3')
        f.write('conformance.json', f.c)
        f.assert_gate_error('Reviewer exceeds authorized cut scope', 'final')

    def test_compiler_cli_rejects_undeclared_output(self):
        f = self.f
        f.save()
        result = subprocess.run([sys.executable, str(Path(__file__).with_name('compile_timeline.py')),
                                 str(f.root / 'reference_map.json'), '--out', str(f.root / 'wrong.json')],
                                capture_output=True, text=True)
        self.assertEqual(result.returncode, 1)
        self.assertIn('--out must match', result.stderr)
        self.assertFalse((f.root / 'wrong.json').exists())


if __name__ == '__main__':
    unittest.main()
