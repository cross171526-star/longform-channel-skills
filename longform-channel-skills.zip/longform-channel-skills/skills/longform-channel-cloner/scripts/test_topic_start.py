"""제목 우선 수집과 최초 사용자 승인 경계를 네트워크 없이 검증한다."""
import argparse
import json
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch
import fetch_channel
import runtime


class TopicStartTests(unittest.TestCase):
    def test_before_approval_only_metadata_can_run(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);(root/'run.json').write_text('{"topic_approval_required":true}');(root/'work').mkdir()
            for cmd in ('titles','list'):runtime.require_topic_approval(root,'fetch_channel',[cmd])
            for name,args in [('fetch_channel',['download']),('detect_cuts',[]),('tts',[]),('build_timeline',[])]:
                with self.subTest(name=name),self.assertRaises(ValueError):runtime.require_topic_approval(root,name,args)
            (root/'work/topic-proposal.json').write_text('{"topic":"A"}')
            (root/'work/topic-approval.json').write_text('{"topic":"A","approved":true,"user_message":"그 주제로 진행해"}')
            runtime.require_topic_approval(root,'fetch_channel',['download'])
            runtime.require_topic_approval(root,'tts',[])
            (root/'work/topic-proposal.json').write_text('{"topic":"B"}')
            with self.assertRaises(ValueError):runtime.require_topic_approval(root,'tts',[])

    def test_missing_user_response_is_not_approval(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);(root/'run.json').write_text('{"topic_approval_required":true}');(root/'work').mkdir()
            (root/'work/topic-proposal.json').write_text('{"topic":"A"}')
            (root/'work/topic-approval.json').write_text('{"topic":"A","approved":true,"user_message":""}')
            with self.assertRaises(ValueError):runtime.require_topic_approval(root,'tts',[])

    def test_quick_titles_are_bounded_metadata_not_download(self):
        with tempfile.TemporaryDirectory() as tmp:
            args=argparse.Namespace(channel_url='@test',project=tmp,cookies_from_browser=None,quick=True)
            response=subprocess.CompletedProcess([],0,json.dumps({'entries':[{'id':'one','title':'A'}]}),'')
            with patch.object(fetch_channel,'ytdlp',return_value=response) as call:fetch_channel.cmd_titles(args)
            self.assertEqual(call.call_count,1)
            options=call.call_args.args[0]
            self.assertIn('--flat-playlist',options);self.assertIn('--playlist-end',options)
            self.assertEqual(call.call_args.kwargs['timeout_s'],90)
            doc=json.loads((Path(tmp)/'analysis/channel_titles.json').read_text())
            self.assertFalse(doc['all_tabs_retrieved']);self.assertTrue(doc['quick_topic_proposal'])
            self.assertEqual(doc['title_limit'],100)

    def test_old_runs_not_changed(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);(root/'run.json').write_text('{}')
            runtime.require_topic_approval(root,'fetch_channel',['download'])


if __name__=='__main__':unittest.main()
