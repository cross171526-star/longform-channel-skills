"""Blinded empirical audiovisual test; a pass is a prerequisite, not proof of accuracy."""
import argparse
from array import array
import json
import math
from pathlib import Path
import secrets
import subprocess
import tempfile
import time
import wave

from common import FFMPEG
from media_transport import ask, identity, save, TransportError

SCHEMA = {'type': 'object', 'properties': {
    'pixels_available': {'type': 'boolean'}, 'audio_available': {'type': 'boolean'},
    'colors': {'type': 'array', 'items': {'type': 'string'}},
    'beep_counts': {'type': 'array', 'items': {'type': 'integer'}},
    'limitation': {'type': 'string'}},
    'required': ['pixels_available', 'audio_available', 'colors', 'beep_counts', 'limitation']}

def challenge(folder):
    colors = secrets.SystemRandom().sample(['red', 'green', 'blue', 'yellow', 'magenta', 'cyan'], 4)
    counts = [secrets.randbelow(4) + 1 for _ in colors]
    samples = array('h')
    sr = 16000
    for count in counts:
        for n in range(sr * 3):
            t = n / sr
            active = any(0.25 + j * 0.55 <= t < 0.5 + j * 0.55 for j in range(count))
            samples.append(int(9000 * math.sin(2 * math.pi * 700 * t)) if active else 0)
    wav = folder / 'sound.wav'
    with wave.open(str(wav), 'wb') as f:
        f.setparams((1, 2, sr, 0, 'NONE', 'not compressed'))
        f.writeframes(samples.tobytes())
    target = folder / (secrets.token_hex(10) + '.mp4')
    cmd = [FFMPEG, '-v', 'error', '-y']
    for color in colors:
        cmd += ['-f', 'lavfi', '-i', f'color=c={color}:s=320x180:r=10:d=3']
    cmd += ['-i', str(wav), '-filter_complex', '[0:v][1:v][2:v][3:v]concat=n=4:v=1:a=0[v]',
            '-map', '[v]', '-map', '4:a', '-c:v', 'libx264', '-pix_fmt', 'yuv420p',
            '-c:a', 'aac', '-t', '12', str(target)]
    subprocess.run(cmd, check=True, capture_output=True)
    wav.unlink()  # Only opaque MP4 is accessible in the media directory.
    return target, {'colors': colors, 'beep_counts': counts}

def doctor(out, model, timeout):
    out = Path(out).resolve()
    out.mkdir(parents=True, exist_ok=True)
    ident = identity(model)
    report = {'status': 'failed', 'identity': ident, 'checked_at': time.time(),
              'purpose': 'empirical pixels and non-speech audio transport test', 'issues': []}
    try:
        with tempfile.TemporaryDirectory(prefix='lfc-media-') as tmp:
            media, expected = challenge(Path(tmp))
            prompt = ('This 12-second synthetic clip has four 3-second slots (0-3,3-6,6-9,9-12). '
                      'For each slot name the solid background color and count distinct audible beeps. '
                      'colors: lower-case English basic color names; beep_counts: four integers. '
                      'Use pixels and actual audio, not OCR or guesses. No tools besides view_file. '
                      'If unavailable use false and empty arrays. Return JSON only.')
            answer = ask(media, prompt, SCHEMA, out / 'call', model, timeout)
            # Ground truth is persisted only AFTER the model finishes.
            save(out / 'ground_truth.json', expected)
            visual = answer.get('pixels_available') is True and answer.get('colors') == expected['colors']
            audio = answer.get('audio_available') is True and answer.get('beep_counts') == expected['beep_counts']
            report.update(visual_pass=visual, audio_pass=audio)
            if visual and audio:
                report['status'] = 'passed'
            else:
                report['issues'] = ['ACTUAL_MEDIA_TEST_FAILED']
    except TransportError as e:
        report['issues'] = [e.code]
    save(out / 'doctor.json', report)
    return report

def valid(report, ident, now=None):
    now = time.time() if now is None else now
    return (report.get('status') == 'passed' and report.get('visual_pass') is True
            and report.get('audio_pass') is True and report.get('identity') == ident
            and 0 <= now - report.get('checked_at', 0) < 24 * 3600)

if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--model', default='gemini-3.1-pro-high')
    p.add_argument('--timeout', type=int, default=180)
    a = p.parse_args()
    result = doctor(a.out, a.model, a.timeout)
    print(json.dumps(result, ensure_ascii=False))
    raise SystemExit(0 if result['status'] == 'passed' else 2)
