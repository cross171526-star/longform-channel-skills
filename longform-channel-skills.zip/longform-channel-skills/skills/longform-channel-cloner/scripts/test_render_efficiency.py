import contextlib
import io
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import build_timeline as bt
from sample_batch import validate_spec
from renderer_runtime import setup


class RenderEfficiencyTests(unittest.TestCase):
    def setUp(self):
        tmp=tempfile.TemporaryDirectory();self.addCleanup(tmp.cleanup);self.p=Path(tmp.name).resolve()
        self.r=self.p/'render';self.r.mkdir();(self.r/'public').mkdir()
        (self.r/'props.json').write_text('{}');(self.p/'mix.wav').write_bytes(b'audio')
        self.manifest=self.p/'manifest.json'
        self.manifest.write_text(json.dumps({'render_timing':{'props':'render/props.json'},'render':'output.mp4',
            'render_inputs':['mix.wav'],'canvas':[320,180]}))
        self.args=SimpleNamespace(production_manifest=str(self.manifest),preview=False,concurrency=1,sample_frames=None,remux_only=False)
        self.report={'passed':True,'input_sha256':'input','render_timing_check':{'output_frames':60,'fps':30,'template_sha256':'template'}}

    def render(self,frames=60):
        with patch('check_production.check',return_value=self.report),patch('renderer_runtime.setup'),\
             patch('build_timeline.subprocess.run',side_effect=lambda *a,**k:(self.p/'video_only.mp4').write_bytes(b'video')) as render,\
             patch('build_timeline.run',side_effect=lambda *a:(self.p/'output.mp4').write_bytes(b'output')) as mux,\
             patch('build_timeline.probe',return_value={'duration_s':2,'nb_frames':frames,'fps':30,'width':320,'height':180}),\
             contextlib.redirect_stdout(io.StringIO()):
            bt.render_prepared(self.args,self.p,self.r,self.r/'public')
        return render,mux

    def test_complete_mux_preserves_frames_and_remux_skips_video_render(self):
        render,mux=self.render();self.assertEqual(render.call_count,1)
        cmd=mux.call_args.args[0];self.assertNotIn('-shortest',cmd);self.assertEqual(cmd[cmd.index('-c:v')+1],'copy')
        self.args.remux_only=True;render,mux=self.render();render.assert_not_called();self.assertEqual(mux.call_count,1)

    def test_remux_rejects_changed_video_or_inputs(self):
        self.render();self.args.remux_only=True
        (self.p/'video_only.mp4').write_bytes(b'changed')
        with self.assertRaisesRegex(ValueError,'not bound'):self.render()
        (self.p/'video_only.mp4').write_bytes(b'video');self.report['input_sha256']='new-input'
        with self.assertRaisesRegex(ValueError,'not bound'):self.render()

    def test_missing_last_frame_cannot_pass(self):
        with self.assertRaisesRegex(ValueError,'frame count'):self.render(frames=59)

    def test_sample_plan_cannot_reduce_observations_or_reset_clock(self):
        clip={'id':'clip','frames_inclusive':[30,59],'absolute_composition_frames':True,'reset_clock_or_rebase_props':False,'extract_absolute_frames':[30,59]}
        spec={'schema':'inspection-sample-batch-v1','fps':30,'clips':[clip],'standalone_stills':[],
              'all_observation_frames':[{'frame':f,'render_source':{'kind':'extract_from_clip','clip_id':'clip','absolute_frame':f,'clip_local_frame':f-30}} for f in (30,59)],'caption_state_map':[]}
        plan=json.loads(json.dumps(spec));validate_spec(spec,plan,120,30)
        spec['all_observation_frames'].pop()
        with self.assertRaises(ValueError):validate_spec(spec,plan,120,30)
        spec=json.loads(json.dumps(plan));spec['clips'][0]['reset_clock_or_rebase_props']=True
        with self.assertRaises(ValueError):validate_spec(spec,spec,120,30)

    def test_renderer_dependency_copy_is_isolated_and_identity_checked(self):
        source=self.p/'source';cache=self.p/'cache';target=self.p/'target';source.mkdir();cache.mkdir()
        for root in (source,cache):(root/'package.json').write_text('{"dependencies":{"example":"1.0.0"}}')
        package=cache/'node_modules/example';package.mkdir(parents=True);(package/'package.json').write_text('{"version":"1.0.0"}')
        (cache/'node_modules/remotion').mkdir()
        deps=[source/'package.json'];setup(source,cache,target,deps)
        self.assertFalse((target/'node_modules').is_symlink())
        (target/'node_modules/example/package.json').write_text('{"version":"2.0.0"}')
        self.assertEqual(json.loads((package/'package.json').read_text())['version'],'1.0.0')
        with self.assertRaisesRegex(ValueError,'version differs'):setup(source,cache,target,deps)


if __name__=='__main__':unittest.main()
