#!/usr/bin/env python3
"""모든 문장을 provider 기본 합성 단계에서 동일한 1.2배속으로 생성하고 단어 타임스탬프를 배치한다.

  run.sh tts --lines lines.json --out DIR [--provider typecast|edge] [--voice ID] [--emotion normal]
             [--tempo 1.2] [--lead-in 0.0] [--total-s S]

Default provider: Typecast (ssfm-v30), voice 진우 (tc_632293f759d649937b97f323). Needs TYPECAST_API_KEY in the
environment or in $LFC_HOME/secrets.env. Word timestamps come from /v1/text-to-speech/with-timestamps.
Fallback provider "edge" (edge-tts, voice ko-KR-SunHiNeural) needs no key.

lines.json: [{"id": "l1", "text": "...", "start_s": 0.42, "end_s": 3.10, "gap_after_s": 0.25}, ...]
--tempo는 1.2만 허용하며 --fit은 금지한다. 문장별 길이에 맞춘 배속 조정이나 추가 atempo 처리는 없다.
문장별 tempo/speed는 1.2, atempo는 1.0만 허용한다. 문장은 --lead-in부터 gap_after_s 간격으로 배치한다.
단어 타임스탬프는 provider의 1.2배속 결과에 앞 무음 제거량과 배치 시작 시각만 반영한다.
출력 메타데이터는 uniform_speed=1.2, speed_method="provider"를 기록한다.
Writes DIR/narration.wav (48 kHz mono), DIR/narration.json (placed lines + word timings), DIR/lines/*.wav.
Text is sent to the provider's online service. Responses are cached per (provider, voice, text, settings).
"""
from __future__ import annotations

import argparse
import asyncio
import base64
import hashlib
import json
import math
import os
import time
import urllib.error
import urllib.request
from pathlib import Path

import numpy as np
import soundfile as sf

from common import FFMPEG, LFC_HOME, probe, read_json, run, write_json

SR = 48000
UNIFORM_SPEED = 1.2
TYPECAST_URL = "https://api.typecast.ai/v1/text-to-speech/with-timestamps"
DEFAULT_VOICES = {"typecast": "tc_632293f759d649937b97f323", "edge": "ko-KR-SunHiNeural"}


def typecast_key() -> str:
    key = os.environ.get("TYPECAST_API_KEY")
    if not key:
        f = LFC_HOME / "secrets.env"
        if f.exists():
            for line in f.read_text().splitlines():
                if line.startswith("TYPECAST_API_KEY="):
                    key = line.split("=", 1)[1].strip()
    if not key:
        raise SystemExit("TYPECAST_API_KEY missing (env or $LFC_HOME/secrets.env)")
    return key


def synth_typecast(text, voice, tempo, emotion, out_wav: Path, seed=42, language="kor"):
    body = {"voice_id": voice, "text": text, "model": "ssfm-v30", "language": language,
            "prompt": {"emotion_type": "preset", "emotion_preset": emotion, "emotion_intensity": 1.0},
            "output": {"volume": 100, "audio_pitch": 0, "audio_tempo": round(max(0.5, min(2.0, tempo)), 3),
                       "audio_format": "wav"},
            "seed": seed, "timestamp_granularity": "word"}
    req = urllib.request.Request(TYPECAST_URL, data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
                                 headers={"X-API-KEY": typecast_key(), "Content-Type": "application/json"})
    for k in range(4):
        try:
            with urllib.request.urlopen(req, timeout=120) as r:
                d = json.loads(r.read().decode("utf-8"))
            break
        except urllib.error.HTTPError as e:
            msg = e.read().decode("utf-8", "replace")[:300]
            if e.code in (429, 500, 502, 503) and k < 3:
                time.sleep(2 * (k + 1))
                continue
            raise SystemExit(f"Typecast HTTP {e.code}: {msg}")
    out_wav.write_bytes(base64.b64decode(d["audio"]))
    return [{"w": w["text"], "start": float(w["start"]), "end": float(w["end"])} for w in d.get("words", [])]


async def _edge(text, voice, rate, mp3: Path):
    import edge_tts
    words = []
    c = edge_tts.Communicate(text, voice, rate=rate, boundary="WordBoundary")
    with open(mp3, "wb") as f:
        async for ch in c.stream():
            if ch["type"] == "audio":
                f.write(ch["data"])
            elif ch["type"] == "WordBoundary":
                words.append({"w": ch["text"], "start": ch["offset"] / 1e7, "end": (ch["offset"] + ch["duration"]) / 1e7})
    return words


def synth_edge(text, voice, tempo, emotion, out_wav: Path, **_):
    pct = int(round((tempo - 1) * 100))
    return asyncio.run(_edge(text, voice, f"{pct:+d}%", out_wav))


PROVIDERS = {"typecast": synth_typecast, "edge": synth_edge}


def synth_cached(provider, text, voice, tempo, emotion, cache: Path):
    h = hashlib.sha1(json.dumps([provider, voice, text, round(tempo, 3), emotion]).encode()).hexdigest()[:16]
    raw = cache / f"{h}.{'wav' if provider == 'typecast' else 'mp3'}"
    meta = cache / f"{h}.json"
    if raw.exists() and meta.exists():
        return raw, read_json(meta)
    cache.mkdir(parents=True, exist_ok=True)
    words = PROVIDERS[provider](text, voice, tempo, emotion, raw)
    write_json(meta, words)
    return raw, words


def to_wav(src: Path, dst: Path) -> tuple[float, float]:
    """배속 변경 없이 앞뒤 무음을 제거하고 48k mono로 변환한다. (길이, 제거한 앞 무음)을 반환한다."""
    lead = leading_silence(src)
    af = [f"atrim=start={lead:.4f}", "asetpts=PTS-STARTPTS",
          "areverse", "silenceremove=start_periods=1:start_threshold=-50dB:start_silence=0.05", "areverse"]
    run([FFMPEG, "-hide_banner", "-loglevel", "error", "-y", "-i", str(src), "-af", ",".join(af), "-ac", "1",
         "-ar", str(SR), str(dst)])
    return probe(dst)["duration_s"], lead


def leading_silence(src: Path, thr_db=-50.0) -> float:
    from common import load_mono, rms_db
    y = load_mono(src, SR)
    e = rms_db(y, SR, 0.005)
    on = np.nonzero(e > thr_db)[0]
    return max(0.0, on[0] * 0.005 - 0.02) if len(on) else 0.0


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--lines", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--provider", choices=list(PROVIDERS), default="typecast")
    ap.add_argument("--voice")
    ap.add_argument("--emotion", default="normal")
    ap.add_argument("--tempo", type=float, default=UNIFORM_SPEED, help="모든 문장의 provider 배속 (1.2만 허용)")
    ap.add_argument("--fit", action="store_true", help="사용 금지: 문장별 배속 조정은 허용하지 않음")
    ap.add_argument("--lead-in", type=float, default=0.0)
    ap.add_argument("--total-s", type=float)
    ap.add_argument("--silence-policy", choices=("compact", "legacy"), help="신규 제작은 compact; 이전 스냅샷 동작은 legacy")
    a = ap.parse_args()
    from draft_delivery import active
    policy = a.silence_policy or ("compact" if active() else "legacy")
    if a.fit:
        ap.error("--fit is prohibited: narration must use uniform provider tempo 1.2")
    if not math.isfinite(a.tempo) or a.tempo != UNIFORM_SPEED:
        ap.error("--tempo must be finite and exactly 1.2")
    lines = read_json(a.lines)
    for ln in lines:
        for key, expected in (("tempo", UNIFORM_SPEED), ("speed", UNIFORM_SPEED), ("atempo", 1.0)):
            if key in ln:
                value = ln[key]
                if (isinstance(value, bool) or not isinstance(value, (int, float))
                        or value != expected or not math.isfinite(value)):
                    ap.error(f"line {ln.get('id', '?')}: {key} must be finite and exactly {expected}")
    if policy == "compact":
        if a.lead_in != 0 or a.total_s is not None:
            ap.error("compact TTS does not add lead-in or tail padding")
        if a.provider != "typecast":
            ap.error("compact production requires Typecast")
        if not lines:
            ap.error("At least one narration line required")
        for ln in lines:
            if not isinstance(ln.get("id"), str) or Path(ln["id"]).name != ln["id"] or ln["id"] in (".", ".."):
                ap.error("Safe unique line ID required")
        if len({ln["id"] for ln in lines}) != len(lines): ap.error("Duplicate line ID")
    voice = a.voice or DEFAULT_VOICES[a.provider]
    out = Path(a.out)
    (out / "lines").mkdir(parents=True, exist_ok=True)
    cache = LFC_HOME / "tts_cache"
    placed, cursor = [], a.lead_in
    for ln in lines:
        wav = out / "lines" / f"{ln['id']}.wav"
        tempo = UNIFORM_SPEED
        raw, words = synth_cached(a.provider, ln["text"], voice, tempo, ln.get("emotion", a.emotion), cache)
        removed = []
        if policy == "compact":
            from compact_speech import convert
            dur, words, removed = convert(raw, wav, words)
            lead = 0.
        else:
            dur, lead = to_wav(raw, wav)
        start = cursor
        end_abs = start + dur
        ws = [{"w": w["w"], "start": round(min(end_abs, start + max(0.0, w["start"] - lead)), 3),
               "end": round(min(end_abs, start + max(0.0, w["end"] - lead)), 3)} for w in words]
        placed.append({**ln, "placed_start_s": round(start, 3), "placed_end_s": round(start + dur, 3),
                       "provider_tempo": tempo, "atempo": 1.0, "wav": f"lines/{ln['id']}.wav",
                       "words": ws, "silence_removed_ranges_s": removed,
                       "effective_gap_after_s": 0 if policy == "compact" else ln.get("gap_after_s", .25)})
        cursor = start + dur + (0 if policy == "compact" else ln.get("gap_after_s", 0.25))
        print(f"{ln['id']} {start:7.2f}-{start + dur:7.2f} tempo {tempo:.2f}/1.000 {ln['text'][:40]}")
    total = cursor if policy == "compact" else max(a.total_s or 0, max(p["placed_end_s"] for p in placed) + 0.1)
    mix = np.zeros(int(total * SR) + 1, np.float32)
    for p in placed:
        y, _ = sf.read(str(out / p["wav"]), dtype="float32")
        i = int(p["placed_start_s"] * SR)
        mix[i:i + len(y)] += y[: len(mix) - i]
    peak = float(np.abs(mix).max()) or 1.0
    if peak > 0.99:
        mix *= 0.99 / peak
    sf.write(str(out / "narration.wav"), mix, SR)
    write_json(out / "narration.json", {"provider": a.provider, "voice": voice, "fit": a.fit, "duration_s": round(total, 3),
                                        "uniform_speed": UNIFORM_SPEED, "speed_method": "provider", "silence_policy": policy,
                                        "lines": placed, "words": [w for p in placed for w in p["words"]]})
    print(f"narration {total:.2f}s ({a.provider}:{voice}) -> {out / 'narration.wav'}")


if __name__ == "__main__":
    main()
