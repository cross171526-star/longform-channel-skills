#!/usr/bin/env bash
# Usage: scripts/run.sh <script-name> [args...]
# Runs a skill script with the managed venv and ffmpeg on PATH.
set -euo pipefail
LFC_HOME="${LFC_HOME:-$HOME/.longform-cloner}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PY="$LFC_HOME/venv/bin/python"
[ -x "$PY" ] || { echo "Environment missing. Run: bash $SCRIPT_DIR/setup_env.sh" >&2; exit 2; }
export PATH="$LFC_HOME/bin:$PATH"
export LFC_HOME
# API keys (PEXELS_API_KEY, PIXABAY_API_KEY, TYPECAST_API_KEY) from the private secrets file; never printed
if [ -f "$LFC_HOME/secrets.env" ]; then
  set -a; . "$LFC_HOME/secrets.env"; set +a
fi
export PYTHONWARNINGS="${PYTHONWARNINGS:-ignore}"
export TOKENIZERS_PARALLELISM=false
export PYTHONDONTWRITEBYTECODE=1
name="${1:?script name required}"; shift
if [ "${name%.py}" = runtime ]; then
  exec "$PY" "$SCRIPT_DIR/runtime.py" "$@"
fi
exec "$PY" "$SCRIPT_DIR/runtime.py" invoke "${name%.py}" "$@"
