#!/usr/bin/env python3
"""Rank candidate fonts against caption crops by rendering the same text and comparing glyph shapes.

  run.sh font_match --crop <crop.png> --text "자막 텍스트" [--fonts-dir DIR] [--top 5]
  run.sh font_match --captions <captions.json> [--ids t0001 t0002] [--fonts-dir DIR]

Binarizes the crop on the detected fill colour, renders the text with every font in --fonts-dir
(default $LFC_HOME/fonts, filled by fetch_fonts.sh) and scores glyph-mask IoU, aspect and stroke width.
Scores below ~0.55 mean no candidate is close: record the closest one and say so.
"""
from __future__ import annotations

import argparse
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

from common import LFC_HOME, read_json, write_json


def binarize(crop_bgr, fill_hex=None):
    if fill_hex:
        rgb = (int(fill_hex[1:3], 16), int(fill_hex[3:5], 16), int(fill_hex[5:7], 16))
        ref = cv2.cvtColor(np.uint8([[rgb[::-1]]]), cv2.COLOR_BGR2LAB)[0, 0].astype(np.float32)
        lab = cv2.cvtColor(crop_bgr, cv2.COLOR_BGR2LAB).astype(np.float32)
        return (np.linalg.norm(lab - ref, axis=2) < 28).astype(np.uint8)
    g = cv2.cvtColor(crop_bgr, cv2.COLOR_BGR2GRAY)
    _, m = cv2.threshold(g, 0, 1, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    return 1 - m if m.mean() > 0.5 else m


def tight(mask):
    ys, xs = np.nonzero(mask)
    if len(xs) == 0:
        return None
    return mask[ys.min():ys.max() + 1, xs.min():xs.max() + 1]


def render(text, font_path, size, index=0):
    try:
        font = ImageFont.truetype(str(font_path), size=max(8, int(size)), index=index)
    except OSError:
        return None
    l, t, r, b = font.getbbox(text)
    img = Image.new("L", (r - l + 20, b - t + 20), 0)
    ImageDraw.Draw(img).text((10 - l, 10 - t), text, fill=255, font=font)
    return (np.array(img) > 127).astype(np.uint8)


def stroke_width(mask):
    if mask is None or mask.sum() == 0:
        return 0.0
    dist = cv2.distanceTransform(mask, cv2.DIST_L2, 3)
    return float(np.percentile(dist[mask > 0], 90)) * 2


def score(target, cand):
    cand = tight(cand) if cand is not None else None
    if cand is None:
        return 0.0
    h, w = target.shape
    c = cv2.resize(cand, (w, h), interpolation=cv2.INTER_NEAREST)
    iou = float((c & target).sum()) / (float((c | target).sum()) or 1.0)
    ra, rb = cand.shape[1] / cand.shape[0], w / h
    aspect = min(ra, rb) / max(ra, rb)
    sw_t, sw_c = stroke_width(target) / h, stroke_width(c) / h
    sw = min(sw_t, sw_c) / max(sw_t, sw_c, 1e-6)
    return round(0.6 * iou + 0.2 * aspect + 0.2 * sw, 4)


def fonts_in(d: Path):
    out = []
    for p in sorted(d.rglob("*")):
        suf = p.suffix.lower()
        if suf in (".ttf", ".otf"):
            out.append((p, 0))
        elif suf == ".ttc":
            out.extend((p, i) for i in range(4))
    return out


def match(crop_path, text, fonts, fill=None, top=5):
    crop = cv2.imread(str(crop_path))
    if crop is None:
        return []
    target = tight(binarize(crop, fill))
    if target is None or target.shape[0] < 6:
        return []
    res = []
    for fp, idx in fonts:
        s = score(target, render(text, fp, target.shape[0] * 1.25, idx))
        if s > 0:
            try:
                name = " ".join(ImageFont.truetype(str(fp), 20, index=idx).getname())
            except OSError:
                name = fp.stem
            res.append({"font": name, "file": str(fp), "index": idx, "score": s})
    best = {}
    for r in sorted(res, key=lambda r: -r["score"]):
        best.setdefault(r["font"], r)
    return list(best.values())[:top]


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--crop")
    ap.add_argument("--text")
    ap.add_argument("--captions")
    ap.add_argument("--ids", nargs="*")
    ap.add_argument("--fonts-dir", default=str(LFC_HOME / "fonts"))
    ap.add_argument("--top", type=int, default=5)
    a = ap.parse_args()
    fonts = fonts_in(Path(a.fonts_dir))
    if not fonts:
        raise SystemExit(f"no fonts in {a.fonts_dir}; run scripts/fetch_fonts.sh")
    if a.crop:
        for r in match(a.crop, a.text, fonts, top=a.top):
            print(f"{r['score']:.3f}  {r['font']}  ({r['file']})")
        return
    cpath = Path(a.captions)
    doc = read_json(cpath)
    evs = [e for e in doc["events"] if e.get("crop") and (not a.ids or e["id"] in a.ids)]
    if not a.ids:  # one representative per (zone, fill colour)
        seen, reps = set(), []
        for e in sorted(evs, key=lambda e: -e.get("conf", 0)):
            key = (e.get("zone"), (e.get("style") or {}).get("fill"))
            if key not in seen and len(e["text"].replace(" ", "")) >= 3:
                seen.add(key)
                reps.append(e)
        evs = reps
    for e in evs:
        r = match(cpath.parent / e["crop"], e["text"], fonts, (e.get("style") or {}).get("fill"), a.top)
        e["font_candidates"] = r
        print(e["id"], e.get("zone"), e["text"][:24], "->", [(x["font"], x["score"]) for x in r[:3]])
    # zone vote: one font per text zone (a channel uses one subtitle font; per-event picks are noisy)
    from collections import defaultdict
    for z in doc.get("zones", []):
        tot, files, n = defaultdict(float), {}, 0
        for e in doc["events"]:
            if e.get("zone") == z["id"] and e.get("font_candidates"):
                n += 1
                for f in e["font_candidates"][:5]:
                    tot[f["font"]] += f["score"]
                    files[f["font"]] = f
        if n:
            rank = sorted(tot.items(), key=lambda x: -x[1])
            z["font"] = {**files[rank[0][0]], "score": round(rank[0][1] / n, 4), "votes_from": n,
                         "runner_up": [(k, round(v / n, 4)) for k, v in rank[1:4]]}
            print(f"zone {z['id']}: {z['font']['font']} (mean {z['font']['score']}, {n} events), runner-up {z['font']['runner_up'][:2]}")
    write_json(cpath, doc)


if __name__ == "__main__":
    main()
