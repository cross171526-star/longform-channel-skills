#!/usr/bin/env python3
"""Plan a NEW video by recombining treatments observed in the reference videos (step 11).

  run.sh plan_video lines --project P --script NEW/script.json --out NEW
  (then: run.sh tts --lines NEW/lines.json --out NEW/tts)
  run.sh plan_video edl   --project P --script NEW/script.json --out NEW [--seed 7]

NEW/script.json (written by the agent, following the channel formula in style/style_profile.json):
  {"title": "...", "topic": "...", "formula_from": "<video_id>",
   "sections": [{"role": "hook", "lines": ["첫 문장", "..."]}, ...]}

Nothing is invented: every cut copies the complete treatment of a real reference cut ("donor") with the same
script role - source type, layer/fit, measured keyframe curves, clip animation, effects, incoming transition
(+ its SFX), overlays, keyword pop-up style and source-credit behaviour. Donors are drawn at random from all
analyzed videos, so features mix across videos with their observed frequencies. Cut lengths, pauses between
lines, subtitle chunking and style, BGM moods per section and mix levels come from the reference measurements.
What the agent must still supply is content: per-cut visuals for the new topic (needs.json lists the donor's
source type/style and the narration to illustrate) and the text of copied keyword pop-ups (texts with
"text": null).
"""
from __future__ import annotations

import argparse
import random
import sys
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

from common import read_json, write_gen_jobs, write_json


def load_refs(project: Path, only=None, confirmed_only=True):
    """Reference analyses. Donor cuts must be confirmed annotations (no "draft" flag) unless confirmed_only=False."""
    if only:
        vids = [v for v in only if (project / "analysis" / v / "cuts.json").exists()]
    else:
        ch = read_json(project / "channel.json")
        sel = ch["selection"]
        vids = [v for v in dict.fromkeys(sel["top_views"] + sel["recent"]) if (project / "analysis" / v / "cuts.json").exists()]
    refs = {}
    for v in vids:
        ad = project / "analysis" / v
        if not all((ad / f"{name}.json").exists() for name in ("cuts", "captions", "audio", "transcript")):
            continue
        cuts = read_json(ad / "cuts.json")
        if confirmed_only and not any(c.get("annotation") and not c["annotation"].get("draft") for c in cuts["cuts"]):
            continue
        if confirmed_only:
            for c in cuts["cuts"]:
                if (c.get("annotation") or {}).get("draft"):
                    c["annotation"] = None
        refs[v] = {"cuts": cuts, "captions": read_json(ad / "captions.json"),
                   "audio": read_json(ad / "audio.json"), "transcript": read_json(ad / "transcript.json"),
                   "script": read_json(ad / "script.json") if (ad / "script.json").exists() else None, "dir": ad}
    return refs


def _gen_seconds(d, new_dur):
    """Seconds of footage to generate so that, retimed to the new cut, it plays at the donor's speed."""
    cd = (d["cut"].get("motion") or {}).get("cadence") or {}
    sp = ((cd.get("retime") or {}).get("24fps") or {}).get("speed")
    return round(max(1.0, new_dur * sp), 2) if sp else round(new_dur, 2)


def _donor_animation(ann, d, first):
    an = {k: ann["animation"].get(k) for k in ("in", "in_s", "out", "out_s")}
    # a fade from black at the very start of the reference video is the video opening, not a per-clip effect
    if an.get("in") == "fade" and d["cut"]["start_s"] < 0.05 and not first:
        an["in"], an["in_s"] = "none", None
    return an


GRAPHIC_TYPES = {"motion_graphic", "text_card", "map_or_chart"}


def chrome_rects(project: Path):
    """Normalized rects of persistent overlays (style/chrome.json from detect_chrome)."""
    cp = project / "style" / "chrome.json"
    return [e["rect"] for e in read_json(cp).get("elements", [])] if cp.exists() else []


def in_rects(bbox, rects, min_cover=0.5):
    x, y, w, h = bbox
    for rx, ry, rw, rh in rects:
        ix = max(0.0, min(x + w, rx + rw) - max(x, rx))
        iy = max(0.0, min(y + h, ry + rh) - max(y, ry))
        if w * h > 0 and ix * iy / (w * h) >= min_cover:
            return True
    return False


def graphic_spec(d, refs, chrome=()):
    """Layout of a generated-graphic donor for rebuilding it with new content: every text element of the donor cut
    with its box, size, colour, alignment, entrance time and the reference text (role hint), plus the donor frame.
    render_graphic reads this; the agent fills new_text per element (same count/placement, new facts)."""
    cap = refs[d["video"]]["captions"]
    c = d["cut"]
    els = []
    for e in cap["events"]:
        if e["end_s"] <= c["start_s"] or e["start_s"] >= c["end_s"] or e.get("credit_like"):
            continue
        z = e.get("zone")
        pol = cap.get("render_policy") or {}
        chrome_ids = set((pol.get("chrome") or {}).get("brand_logo_ids", [])) | set((pol.get("chrome") or {}).get("topic_tag_ids", []))
        if z in set(pol.get("subtitle_zones") or []) or z in set(pol.get("brand_zones") or []) or e["id"] in chrome_ids:
            continue
        if chrome and in_rects(e.get("ink_bbox") or e["bbox"], chrome):
            continue
        st = e.get("style") or {}
        els.append({"ref_text": e.get("text_corrected") or e["text"], "new_text": None,
                    "bbox": e.get("ink_bbox") or e["bbox"], "font_px": e.get("font_size_px_1080p_est"),
                    "color": st.get("fill"), "outline": st.get("outline"), "box": st.get("box"),
                    "align": e.get("align", "center"), "appear_s": round(max(0.0, e["start_s"] - c["start_s"]), 3),
                    "anim_in": (e.get("animation") or {}).get("in"), "font": (e.get("font_candidates") or [{}])[0].get("file")})
    els.sort(key=lambda x: (round(x["bbox"][1], 2), x["bbox"][0]))
    for x in els:  # captions' align is positional; inside graphics anchor on the element centre
        x["align"] = "left" if x["bbox"][0] < 0.12 and x["bbox"][2] > 0.3 else "center"
    # everything textual in the donor frame must go from the background: subtitles, credits, reference chrome
    erase = [list(e.get("ink_bbox") or e["bbox"]) for e in cap["events"]
             if e["end_s"] > c["start_s"] and e["start_s"] < c["end_s"]] + [list(r) for r in chrome]
    return {"donor": f"{d['video']}:{c['id']}", "donor_frame": str(refs[d["video"]]["dir"] / "frames" / "src" / f"{c['id']}.jpg"),
            "donor_duration_s": c["duration_s"], "subtype": d["ann"]["source"].get("subtype"),
            "description": d["ann"]["source"].get("description"), "elements": els,
            "background": {"mode": "donor", "erase": erase,
                           "note": "donor frame with all reference text/chrome inpainted; check the preview"}}


def donor_pool(refs, chrome=()):
    pool = defaultdict(list)
    for v, r in refs.items():
        cap = {e["id"]: e for e in r["captions"]["events"]}
        sfx = r["audio"].get("sfx_events", [])
        for c in r["cuts"]["cuts"]:
            ann = c.get("annotation")
            if not ann:
                continue
            texts = []
            graphic = ann["source"]["type"] in GRAPHIC_TYPES
            for o in ann.get("overlays", []):
                # text drawn inside a generated graphic (tables, charts, quote cards) belongs to the graphic's
                # layout (graphic_spec), not to separate pop-ups
                if graphic and o["kind"] in ("keyword_popup", "number"):
                    continue
                if o["kind"] in ("keyword_popup", "title", "lower_third", "number"):
                    for tid in o.get("text_event_ids", []):
                        if tid in cap and not (chrome and in_rects(cap[tid].get("ink_bbox") or cap[tid]["bbox"], chrome)):
                            e = cap[tid]
                            texts.append({"kind": o["kind"], "ref_text": e["text"], "rel_start": e["start_s"] - c["start_s"],
                                          "rel_end": e["end_s"] - c["start_s"], "event": e})
            cut_sfx = [s for s in sfx if s.get("likely_sfx") and not s.get("rejected") and c["start_s"] - 0.15 <= s["t"] < c["end_s"]]
            rng_end = (r["cuts"].get("range") or {}).get("end_s", r["cuts"]["video"]["duration_s"])
            truncated = c["end_s"] >= rng_end - 0.05 and rng_end < r["cuts"]["video"]["duration_s"] - 0.5
            pool[ann.get("script_role", "unknown")].append({"video": v, "cut": c, "ann": ann, "texts": texts, "sfx": cut_sfx,
                                                            "motion_file": r["dir"] / "motion" / f"{c['id']}.json",
                                                            "truncated": truncated})
    return pool


def subtitle_template(refs):
    """Dominant rendered subtitle zone across references + a representative styled event and chunk lengths."""
    lens, reps = [], []
    for v, r in refs.items():
        cap = r["captions"]
        pol = cap.get("render_policy") or {}
        zones = pol.get("subtitle_zones") or pol.get("zones") or []
        if not zones:
            continue
        z = zones[0]
        evs = [e for e in cap["events"] if e.get("zone") == z and e.get("style")]
        lens += [len(e["text"].replace(" ", "")) for e in evs]
        reps += [e for e in evs if e.get("font_candidates")] or evs[:1]
    if not reps:
        return None
    rep = max(reps, key=lambda e: e.get("conf", 0))
    return {"event": rep, "chars_median": int(np.median(lens)) if lens else 16,
            "chars_p90": int(np.percentile(lens, 90)) if lens else 22}


def chunk_words(words, target, max_chars):
    """Split narration words into subtitle chunks: never across a sentence end, prefer breaks after commas,
    about target characters per chunk (reference median), hard limit max_chars (reference p90)."""
    chunks, cur, n = [], [], 0
    for w in words:
        wl = len(w["w"].replace(" ", ""))
        if cur and n + wl > max_chars:
            chunks.append(cur)
            cur, n = [], 0
        cur.append(w)
        n += wl
        t = w["w"].rstrip()
        if t.endswith((".", "?", "!")) or (t.endswith(",") and n >= 0.6 * target) or n >= target:
            chunks.append(cur)
            cur, n = [], 0
    if cur:
        chunks.append(cur)
    return chunks


def _fit_width(style, text):
    """Reuse a reference subtitle style for new text: keep vertical geometry and centre, scale the horizontal
    extent by character count (Hangul glyphs are near-monospace; a space counts 0.35), resize the plate with it."""
    import copy
    ink = list(style.get("ink_bbox") or style["bbox"])
    bbox = list(style["bbox"])
    n = len(text.replace(" ", "")) + 0.35 * text.count(" ")
    per = ink[2] / max(1.0, style.get("_ref_units") or 1.0)
    w = per * n
    cx = ink[0] + ink[2] / 2
    new_ink = [cx - w / 2, ink[1], w, ink[3]]
    extra = bbox[2] - ink[2]
    new_bbox = [cx - (w + extra) / 2, bbox[1], w + extra, bbox[3]]
    box = copy.deepcopy(style.get("box"))
    if box and box.get("rect"):
        r = box["rect"]
        if box.get("width_follows_text") and box.get("pad_x") is None:
            # zone plate rect spans the widest line; the per-line pad is the plate's side margin at that width
            box["pad_x"] = max(0.008, min(0.05, (r[2] - ink[2]) / 2)) if r[2] > ink[2] else 0.018
        pad = box.get("pad_x") if box.get("pad_x") is not None else ink[0] - r[0]
        box["rect"] = [new_ink[0] - pad, r[1], w + 2 * pad, r[3]]
    return new_bbox, new_ink, box


def scaled_keyframes(d, new_dur):
    from make_edl import motion_keyframes
    has = d["motion_file"].exists() or d["ann"]["keyframes"].get("override")
    kf = motion_keyframes(d["motion_file"].parent.parent, d["cut"], d["ann"], d.get("fps", 30)) if has else {}
    old = d["cut"]["duration_s"] or new_dur
    k = new_dur / old if old else 1.0
    return {name: [{**p, "t": round(p["t"] * k, 4)} for p in pts] for name, pts in kf.items()}


def cmd_lines(a):
    project = Path(a.project)
    refs = load_refs(project, a.refs)
    script = read_json(a.script)
    gaps, sec_gaps = [], []
    for r in refs.values():
        seg = r["transcript"]["segments"]
        gaps += [b["start"] - x["end"] for x, b in zip(seg, seg[1:]) if 0.05 < b["start"] - x["end"] < 2.0]
    gaps = gaps or [0.3]
    rng = random.Random(a.seed)
    lines = []
    for si, sec in enumerate(script["sections"]):
        for li, text in enumerate(sec["lines"]):
            last = li == len(sec["lines"]) - 1
            g = float(np.percentile(gaps, 80)) if last else rng.choice(gaps)
            lines.append({"id": f"l{len(lines) + 1:03d}", "text": text, "section": si, "role": sec["role"],
                          "gap_after_s": round(g, 3)})
    first = [r["transcript"].get("first_word_s") for r in refs.values() if r["transcript"].get("first_word_s") is not None]
    out = Path(a.out)
    write_json(out / "lines.json", lines)
    lead = float(np.median(first)) if first else 0.0
    print(f"{len(lines)} lines -> {out / 'lines.json'}")
    print(f"next: run.sh tts --lines {out / 'lines.json'} --out {out / 'tts'} --lead-in {lead:.2f}")


def cmd_edl(a):
    project = Path(a.project)
    out = Path(a.out)
    refs = load_refs(project, a.refs)
    script = read_json(a.script)
    nar = read_json(out / "tts" / "narration.json")
    pool = donor_pool(refs, chrome_rects(project))
    chrome = chrome_rects(project)
    if not pool:
        sys.exit("no annotated reference cuts")
    rng = random.Random(a.seed)
    anchor = script.get("formula_from")
    if anchor in refs:
        pool = {role: [d for d in donors if d["video"] == anchor] for role, donors in pool.items()}
    all_donors = [d for donors in pool.values() for d in donors]
    if not all_donors:
        sys.exit(f"no confirmed donors for formula_from {anchor!r}")
    roles_seen = {role for role, donors in pool.items() if donors}
    missing_roles = sorted({sec["role"] for sec in script["sections"]} - roles_seen)
    if missing_roles:
        sys.exit(f"no confirmed donor cuts for script roles {missing_roles}; analyze matching reference cuts or revise the script")
    fps = float(np.median([r["cuts"]["video"]["fps"] for r in refs.values()]))
    for d in all_donors:
        d["fps"] = refs[d["video"]]["cuts"]["video"]["fps"]
    words = nar["words"]
    lines = nar["lines"]
    # section spans on the narration timeline
    spans = []
    for si, sec in enumerate(script["sections"]):
        ls = [l for l in lines if l.get("section") == si]
        if not ls:
            continue
        spans.append((si, sec["role"], ls[0]["placed_start_s"] if si else 0.0, ls[-1]["placed_end_s"] + ls[-1].get("gap_after_s", 0.25)))
    total = spans[-1][3] + 0.5
    # boundary snapping: how often reference cuts land on word starts
    rel = Counter()
    for r in refs.values():
        rel.update(x.get("boundary_vs_word") for x in r["transcript"].get("cut_text", []))
    snap_p = rel["word_start"] / max(1, sum(rel.values()))
    word_starts = np.array([w["start"] for w in words]) if words else np.array([])
    cuts, texts, sfx, needs = [], [], [], {}
    donor_index = defaultdict(int)
    t = 0.0
    for si, role, s0, s1 in spans:
        donors = pool[role]
        while t < s1 - 0.05:
            d = donors[donor_index[role] % len(donors)]
            donor_index[role] += 1
            dur = max(0.4, d["cut"]["duration_s"])
            if d.get("truncated"):
                dur = max(dur, float(np.median([x["cut"]["duration_s"] for x in all_donors if not x.get("truncated")])))
            end = min(s1, t + dur)
            if s1 - end < 0.5 * dur and s1 - end < 1.0:
                end = s1
            if word_starts.size and end < s1 and rng.random() < snap_p:
                near = word_starts[np.argmin(np.abs(word_starts - end))]
                if abs(near - end) < 0.3 and near > t + 0.3:
                    end = float(near)
            cid = f"n{len(cuts) + 1:03d}"
            ann = d["ann"]
            new_dur = end - t
            tr = dict(ann["transition_in"]) if cuts else {"type": "cut", "frames": 0}
            tr["frames"] = int(round(tr.get("frames", 0) * fps / d["fps"]))
            cred = ann.get("source_credit", {"shown": False})
            cred_style = None
            if cred.get("shown") and cred.get("text_event_ids"):
                capd = {e["id"]: e for e in refs[d["video"]]["captions"]["events"]}
                ev = capd.get(cred["text_event_ids"][0])
                if ev:
                    from make_edl import text_style
                    cred_style = text_style(ev, refs[d["video"]]["captions"])
            narr = " ".join(w["w"] for w in words if t <= (w["start"] + w["end"]) / 2 < end)
            cuts.append({"id": cid, "start_s": round(t, 4), "end_s": round(end, 4), "asset_key": f"new:{cid}",
                         "donor": f"{d['video']}:{d['cut']['id']}", "source_type": ann["source"]["type"],
                         "media": ann["source"].get("media"), "layer": ann.get("layer", {"fit": "cover"}),
                         "keyframes": scaled_keyframes(d, new_dur), "keyframe_preset": ann["keyframes"].get("preset"),
                         "retime": ("fit_to_cut" if (d["cut"].get("motion") or {}).get("motion_origin") == "in_source" else None),
                         "ref_cut": {"offset_s": 0.0, "duration_s": round(new_dur, 4)},
                         "trim_start_s": 0.0, "speed": ann["animation"].get("speed", 1.0),
                         "effects": ann["animation"].get("effects", []), "effect_params": ann["animation"].get("effect_params", {}),
                         "animation": _donor_animation(ann, d, first=not cuts),
                         "transition_in": tr,
                         "overlays": [o for o in ann.get("overlays", []) if o["kind"] in ("arrow", "circle", "underline", "map_marker", "image_pip", "progress_bar", "other")],
                         "credit": {"shown": bool(cred.get("shown")), "format": cred.get("format"), "style": cred_style,
                                    "time": [round(t, 3), round(end, 3)] if cred.get("shown") else None},
                         "narration": narr, "section": si, "role": role})
            needs[f"new:{cid}"] = {"kind": "clip", "source_type": ann["source"]["type"], "media": ann["source"].get("media"),
                                   "duration_s": round(new_dur, 3), "orientation": ann["source"].get("orientation", "landscape"),
                                   "narration": narr, "donor": f"{d['video']}:{d['cut']['id']}",
                                   "donor_description": ann["source"]["description"],
                                   "donor_style_notes": (ann["source"].get("acquire") or {}).get("style_notes"),
                                   "donor_ai_prompt": (ann["source"].get("acquire") or {}).get("ai_prompt"),
                                   "donor_frame": str(refs[d["video"]]["dir"] / "frames" / "src" / f"{d['cut']['id']}.jpg"),
                                   "keyframe_preset": ann["keyframes"].get("preset"),
                                   "gen_seconds": _gen_seconds(d, new_dur),
                                   "no_attribution_required": not cred.get("shown")}
            if ann["source"]["type"] in GRAPHIC_TYPES:
                needs[f"new:{cid}"]["graphic_spec"] = graphic_spec(d, refs, chrome)
            for tx in d["texts"]:
                from make_edl import text_style
                ts = t + tx["rel_start"] * new_dur / max(d["cut"]["duration_s"], 1e-6)
                te = t + tx["rel_end"] * new_dur / max(d["cut"]["duration_s"], 1e-6)
                ev = tx["event"]
                texts.append({"id": f"k{len(texts) + 1:03d}", "kind": tx["kind"], "text": None, "reference_text": tx["ref_text"],
                              "hint": "rewrite for this narration: " + narr[:80], "start_s": round(max(t, ts), 3),
                              "end_s": round(min(end, te), 3), "style": text_style(ev, refs[d["video"]]["captions"]),
                              "animation": {"in": ev["animation"].get("in"), "in_s": ev["animation"].get("in_s_est"),
                                            "growth": None}})
            for s in d["sfx"]:
                off = s["t"] - d["cut"]["start_s"]
                label = s.get("label_corrected") or (s["labels"][0][0] if s.get("labels") else "sfx")
                key = f"sfx:label:{label}"
                sfx.append({"id": f"x{len(sfx) + 1:03d}", "t": round(max(0.0, t + off), 3), "asset_key": key,
                            "ref_clip": str(refs[d["video"]]["dir"] / s["clip"]), "label": label})
                needs.setdefault(key, {"kind": "sfx", "label": label, "ref_clip": sfx[-1]["ref_clip"], "no_attribution_required": True})
            t = end
    if cuts:  # last picture holds until the end of the timeline (no black tail)
        cuts[-1]["end_s"] = round(total, 4)
        cuts[-1]["ref_cut"]["duration_s"] = round(total - cuts[-1]["start_s"], 4)
    # subtitles from narration words, styled like the reference subtitle zone
    tpl = subtitle_template(refs)
    if tpl:
        from make_edl import text_style
        ref_ev = tpl["event"]
        cap_doc = next(r["captions"] for r in refs.values() if any(e is ref_ev for e in r["captions"]["events"]))
        style = text_style(ref_ev, cap_doc)
        # measured zone plate (captions.zone_plate: see-through plates + accent bars) wins over per-event boxes
        zp = next((z.get("plate") for z in cap_doc.get("zones", []) if z["id"] == ref_ev.get("zone") and z.get("plate")), None)
        if zp:
            style["box"] = {"color": zp["color"], "rect": zp["rect"], "alpha": zp.get("alpha"),
                            "accent_bars": zp.get("accent_bars"), "inferred": False, "width_follows_text": True}
            style["color"] = style.get("color") if (style.get("color") or "#FFFFFF").upper() not in ("#000000",) else "#FFFFFF"
        ref_text = ref_ev.get("text_corrected") or ref_ev["text"]
        style["_ref_units"] = len(ref_text.replace(" ", "")) + 0.35 * ref_text.count(" ")
        for ch in chunk_words(words, tpl["chars_median"], tpl["chars_p90"]):
            st = dict(style)
            txt = " ".join(w["w"] for w in ch)
            st["bbox"], st["ink_bbox"], st["box"] = _fit_width(style, txt)
            texts.append({"id": f"s{len(texts) + 1:04d}", "kind": "subtitle", "text": txt,
                          "start_s": ch[0]["start"], "end_s": ch[-1]["end"] + 0.05, "style": style,
                          **{"style": st},
                          "animation": {"in": ref_ev["animation"].get("in") if ref_ev["animation"].get("in") != "unknown" else None,
                                        "in_s": ref_ev["animation"].get("in_s_est"), "growth": None}})
    subs = [t for t in texts if t.get("kind") == "subtitle"]
    for a_, b_ in zip(subs, subs[1:]):
        if 0 <= b_["start_s"] - a_["end_s"] < 1.2:
            a_["end_s"] = b_["start_s"]
    # brand (channel logo) zones: same place/size as in the reference, text from brand.json at build time
    brand = []
    for v, r in refs.items():
        cap = r["captions"]
        for z in (cap.get("render_policy") or {}).get("brand_zones", []):
            evs = [e for e in cap["events"] if e.get("zone") == z]
            if evs:
                rep = max(evs, key=lambda e: (e["end_s"] - e["start_s"], e.get("conf", 0)))
                from make_edl import text_style as _ts
                brand.append({"zone": z, "reference_text": rep["text"], "start_s": 0.0, "end_s": None, "style": _ts(rep, cap)})
        if brand:
            break
    # BGM by section role
    role_moods = defaultdict(list)
    for v, r in refs.items():
        sc = r["script"]
        if not sc:
            continue
        for sg in r["audio"].get("bgm_segments", []):
            if sg["music_present_ratio"] < 0.3 or not sg.get("mood_tags"):
                continue
            mid = (sg["start_s"] + sg["end_s"]) / 2
            sec = next((s for s in sc["sections"] if s["start_s"] <= mid < s["end_s"]), None)
            if sec:
                role_moods[sec["role"]].append((sg["mood_tags"][0][0], sg.get("tempo_bpm"), v, sg))
    bgm = []
    for si, role, s0, s1 in spans:
        opts = role_moods.get(role) or [x for v in role_moods.values() for x in v]
        if not opts:
            continue
        mood, tempo, v, sg = rng.choice(opts)
        if bgm and bgm[-1]["mood"] == mood:
            bgm[-1]["end_s"] = round(s1, 3)
            continue
        key = f"bgm:new:{len(bgm)}"
        bgm.append({"asset_key": key, "start_s": round(s0, 3), "end_s": round(s1, 3), "offset_s": 0.0, "mood": mood, "tempo_bpm": tempo})
        needs[key] = {"kind": "bgm", "mood": mood, "tempo_bpm": tempo, "no_attribution_required": True,
                      "ref_excerpt": {"file": str(refs[v]["dir"] / "stems" / "music.wav"), "start_s": sg["start_s"], "end_s": sg["end_s"]}}
    for b in bgm:
        needs[b["asset_key"]]["duration_s"] = round(b["end_s"] - b["start_s"], 2)
    lv = defaultdict(list)
    for r in refs.values():
        L = r["audio"].get("levels", {})
        for k in ("voice_lufs", "music_lufs", "mix_lufs"):
            if L.get(k) is not None:
                lv[k].append(L[k])
        if (L.get("ducking") or {}).get("ducking_db") is not None:
            lv["ducking_db"].append(L["ducking"]["ducking_db"])
    edl = {"mode": "new", "title": script.get("title"), "seed": a.seed, "fps": round(fps, 3), "width": 1920, "height": 1080,
           "duration_s": round(total, 3), "narration": {"lines_file": "lines.json", "tts_dir": "tts"},
           "cuts": cuts, "texts": texts, "brand": [dict(b, end_s=round(total, 3)) for b in brand], "sfx": sfx, "bgm": bgm,
           "levels": {k: round(float(np.median(v)), 2) for k, v in lv.items()}}
    write_json(out / "edl.json", edl)
    write_json(out / "needs.json", needs)
    nj = write_gen_jobs(out, needs, a.project, seed0=a.seed * 10)
    if nj:
        print(f"gen_jobs.json: {nj} ai_video jobs; rewrite each prompt for the new content before queueing")
    todo = [x["id"] for x in texts if x["text"] is None]
    donors_used = Counter(c["donor"].split(":")[0] for c in cuts)
    print(f"EDL {len(cuts)} cuts from donors {dict(donors_used)}, {len(texts)} texts ({len(todo)} need text), "
          f"{len(sfx)} sfx, {len(bgm)} bgm -> {out / 'edl.json'}")
    if todo:
        print(f"fill 'text' for: {todo[:20]}")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("lines", "edl"):
        p = sub.add_parser(name)
        p.add_argument("--project", required=True)
        p.add_argument("--script", required=True)
        p.add_argument("--out", required=True)
        p.add_argument("--seed", type=int, default=7)
        p.add_argument("--refs", nargs="*", help="analysis dir names to use as references (default: channel selection)")
    a = ap.parse_args()
    cmd_lines(a) if a.cmd == "lines" else cmd_edl(a)


if __name__ == "__main__":
    main()
