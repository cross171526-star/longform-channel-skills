#!/usr/bin/env python3
"""Detect format drift between the analyzed videos (e.g. old top-viewed videos vs. recent uploads).

  run.sh era_check --project P

Channels change format over the years. Top-viewed videos are often old, recent ones show the current format,
and mixing both makes a new video that matches neither. Per video it measures cut pace, source-type mix,
background brightness/texture share and text density, clusters videos into formats, and writes
P/style/era_check.json. When two clusters differ clearly, the agent must ask the user which format to follow
and then set channel.json selection (the other videos stay analyzed but are no longer donors / style input).
"""
from __future__ import annotations

import argparse
import statistics as st
from collections import Counter
from pathlib import Path

import numpy as np
from PIL import Image

from common import read_json, write_json


def feats(ad: Path):
    cuts = read_json(ad / "cuts.json")["cuts"]
    durs = [c["duration_s"] for c in cuts]
    types = Counter(((c.get("annotation") or {}).get("source") or {}).get("type", "unknown") for c in cuts)
    n = max(1, sum(types.values()))
    bright = []
    for c in cuts[:: max(1, len(cuts) // 80)]:
        f = ad / "frames" / "src" / f"{c['id']}.jpg"
        if f.exists():
            a = np.asarray(Image.open(f).convert("L").resize((96, 54)), float)
            bright.append((a.mean(), a.std()))
    light_flat = sum(1 for m, s in bright if m > 215 and s < 45) / max(1, len(bright))
    dark = sum(1 for m, _ in bright if m < 50) / max(1, len(bright))
    vid = read_json(ad / "cuts.json")["video"]
    return {"median_cut_s": round(float(np.median(durs)), 2), "cuts_per_min": round(len(cuts) / vid["duration_s"] * 60, 2),
            "graphic_share": round((types["motion_graphic"] + types["text_card"] + types["map_or_chart"]) / n, 3),
            "footage_share": round((types["external_footage"] + types["stock_video"] + types["ai_video"]) / n, 3),
            "light_flat_share": round(light_flat, 3), "dark_share": round(dark, 3)}


def dist(a, b):
    return (abs(np.log(a["median_cut_s"] / b["median_cut_s"])) * 2 + abs(a["graphic_share"] - b["graphic_share"]) * 3
            + abs(a["light_flat_share"] - b["light_flat_share"]) * 3 + abs(a["footage_share"] - b["footage_share"]) * 2)


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--project", required=True)
    a = ap.parse_args()
    P = Path(a.project)
    ch = read_json(P / "channel.json")
    sel = ch.get("selection_all") or ch["selection"]
    vids = [v for v in dict.fromkeys(sel["top_views"] + sel["recent"]) if (P / "analysis" / v / "cuts.json").exists()]
    rows = {}
    for v in vids:
        meta = ch.get("videos", {}).get(v, {})
        md = P / "videos" / v / "meta.json"
        up = (read_json(md).get("upload_date") if md.exists() else None) or meta.get("upload_date")
        rows[v] = {"title": meta.get("title"), "upload_date": up, "roles": meta.get("roles"), **feats(P / "analysis" / v)}
    # compare the channel's recent uploads with the other (usually older, top-viewed) videos; that is the choice the
    # user has to make. A format change = the two sets differ much more than videos inside each set differ.
    ids = list(rows)
    recent = [v for v in sel["recent"] if v in rows]
    other = [v for v in ids if v not in recent]
    best, drift = None, False
    if recent and other:
        inter = st.mean(dist(rows[x], rows[y]) for x in recent for y in other)
        intra_l = [dist(rows[x], rows[y]) for g in (recent, other) for x in g for y in g if x != y]
        intra = st.mean(intra_l) if intra_l else 0.0
        years = lambda g: sorted(int((rows[v]["upload_date"] or "0")[:4] or 0) for v in g)
        gap = (min(years(recent)) - max(years(other))) if years(recent) and years(other) else 0
        best = (inter - intra, recent, other, inter, intra)
        drift = inter > 0.8 and inter > 1.6 * max(intra, 0.3) or (gap >= 2 and inter > 0.6)
    groups = []
    if best:
        for g in best[1:3]:
            dates = sorted(rows[v]["upload_date"] or "" for v in g)
            groups.append({"videos": g, "upload_dates": [dates[0], dates[-1]],
                           "median_cut_s": st.median(rows[v]["median_cut_s"] for v in g),
                           "graphic_share": round(st.mean(rows[v]["graphic_share"] for v in g), 3),
                           "light_flat_share": round(st.mean(rows[v]["light_flat_share"] for v in g), 3)})
    groups.sort(key=lambda g: g["upload_dates"][1], reverse=True)
    doc = {"videos": rows, "format_drift": drift, "groups": groups,
           "note": "format_drift=true: ask the user which group to follow (recent = current channel look), then set "
                   "channel.json selection to that group (keep selection_all) and re-run aggregate."}
    write_json(P / "style" / "era_check.json", doc)
    for v, r in rows.items():
        print(f"{v} {r['upload_date']} cut {r['median_cut_s']}s graphics {r['graphic_share']:.0%} footage {r['footage_share']:.0%} "
              f"light-flat {r['light_flat_share']:.0%}  {r['title']}")
    print(f"format drift: {drift}" + (f" -> groups {[g['videos'] for g in groups]}" if drift else ""))


if __name__ == "__main__":
    main()

