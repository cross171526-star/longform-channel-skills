#!/usr/bin/env python3
"""Detect burned-in captions / on-screen text: text, timing, position, size, colours, box, entrance animation.

  run.sh captions <video> --out <analysis_dir> [--fps 4] [--detail-range 0:30] [--detail-fps 15]
                  [--ocr-width 800] [--lang ko-KR,en-US]

Samples frames (denser inside --detail-range), runs Apple Vision OCR, and merges consecutive detections of the
same text at the same place into text events. For each event it measures on the full-resolution frame:
bbox (normalized + px on a 1920x1080 canvas), line height (~font size), fill / outline colour and outline
thickness, background box, alignment, and the entrance animation inside the detail range
(fade / pop_scale / slide / typewriter / word_by_word / none) from the change of bbox, characters and
OCR confidence over the first 0.6 s. Events are clustered into zones (e.g. bottom subtitle line, top title).

Writes <out>/captions.json and <out>/frames/captions/<event_id>.png crops (input for font_match).
"""
from __future__ import annotations

import argparse
from pathlib import Path

import cv2
import numpy as np

from common import (CANVAS_H, CANVAS_W, bbox_iou, grab_frames, hex_color, iter_frames, parse_range, probe,
                    resize_w, text_similarity, vision_ocr, write_json)

CREDIT_WORDS = ("출처", "자료", "사진", "영상 제공", "제공", "화면", "source", "courtesy", "credit", "©", "(c)", "getty",
                "shutterstock", "reuters", "ap photo", "afp", "연합뉴스", "wikimedia", "pexels", "pixabay", "unsplash",
                "nasa", "cc by", "youtube", "유튜브", "캡처", "캡쳐")


def credit_like(text: str, bbox) -> bool:
    t = text.lower()
    small = bbox[3] < 0.04
    return any(w in t for w in CREDIT_WORDS) and (small or t.startswith(("출처", "source", "자료", "©")))


def sample_frames(fps, n_frames, rng, fps_main, detail, fps_detail):
    t0, t1 = rng
    ts = set(np.round(np.arange(t0, t1, 1 / fps_main), 4))
    ts |= set(np.round(np.arange(max(t0, detail[0]), min(detail[1], t1), 1 / fps_detail), 4))
    return sorted({min(n_frames - 1, int(round(t * fps))) for t in ts})


def group_events(dets, max_gap):
    """dets: [(t, [ocr items])] in time order -> events with per-sample observations."""
    events, active = [], []
    for t, items in dets:
        used = set()
        for ev in active:
            last = ev["obs"][-1]
            best, bi = 0.0, None
            for k, it in enumerate(items):
                if k in used:
                    continue
                iou = bbox_iou(last["bbox"], it["bbox"])
                sim = text_similarity(last["text"], it["text"])
                a0, b0 = last["text"].replace(" ", ""), it["text"].replace(" ", "")
                # typewriter / word-by-word growth: one text is a prefix of the other
                grow = len(a0) >= 2 and len(b0) >= 2 and (b0.startswith(a0) or a0.startswith(b0))
                same_line = abs((last["bbox"][1] + last["bbox"][3] / 2) - (it["bbox"][1] + it["bbox"][3] / 2)) < 0.03
                # consecutive subtitles often share words ("상징도 다르고," -> "경전도 다르고,"): require near-identical
                # text so they are not merged; OCR noise on the same text stays above ~0.85
                ok = (iou > 0.3 and sim > 0.85) or (grow and same_line and iou > 0.05)
                score = sim + iou if ok else 0.0
                if score > best:
                    best, bi = score, k
            if bi is not None:
                used.add(bi)
                ev["obs"].append({"t": t, **items[bi]})
                ev["last"] = t
        for k, it in enumerate(items):
            if k not in used:
                ev = {"obs": [{"t": t, **it}], "first": t, "last": t}
                events.append(ev)
                active.append(ev)
        active = [ev for ev in active if t - ev["last"] <= max_gap]
    return events


def colours(crop):
    """Fill / outline / background colours of a text crop via 3-cluster k-means in Lab."""
    h, w = crop.shape[:2]
    if h < 6 or w < 6:
        return {}
    lab = cv2.cvtColor(crop, cv2.COLOR_BGR2LAB).reshape(-1, 3).astype(np.float32)
    k = 3
    _, labels, centers = cv2.kmeans(lab, k, None, (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 20, 0.5),
                                    3, cv2.KMEANS_PP_CENTERS)
    labels = labels.reshape(h, w)
    border = np.concatenate([labels[0], labels[-1], labels[:, 0], labels[:, -1]])
    bg = int(np.bincount(border, minlength=k).argmax())
    counts = np.bincount(labels.ravel(), minlength=k)
    others = [i for i in range(k) if i != bg]
    L = centers[:, 0]
    fill = max(others, key=lambda i: abs(L[i] - L[bg]) * np.sqrt(counts[i]))
    rest = [i for i in others if i != fill]

    def to_rgb(c):
        return cv2.cvtColor(np.uint8([[c]]), cv2.COLOR_LAB2BGR)[0, 0][::-1]

    res = {"fill": hex_color(to_rgb(centers[fill])), "background": hex_color(to_rgb(centers[bg])),
           "fill_ratio": round(float(counts[fill] / counts.sum()), 3)}
    res["background_uniform"] = bool(float(crop.reshape(-1, 3)[labels.ravel() == bg].std()) < 12)
    if rest:
        o = rest[0]
        fm = (labels == fill).astype(np.uint8)
        om = (labels == o).astype(np.uint8)
        ring = cv2.dilate(fm, np.ones((3, 3), np.uint8), iterations=2) - fm
        adj = float((om & ring).sum()) / max(1, int(ring.sum()))
        if adj > 0.35 and counts[o] > 0.05 * counts.sum():
            res["outline"] = hex_color(to_rgb(centers[o]))
            dist = cv2.distanceTransform(1 - fm, cv2.DIST_L2, 3)
            thick = dist[om.astype(bool) & (dist < 20)]
            res["outline_px_on_crop"] = round(float(np.percentile(thick, 90)), 1) if thick.size else None
    return res


def box_detect(frame, bbox, tol=20, min_frac=0.85, ink=None):
    """Solid background box behind text (subtitle plates).

    Starts from the glyph ink box when known (OCR boxes overshoot and cut into plate edges), takes the dominant
    colour of the rows/columns just outside the glyphs, and grows each edge while the next line stays that
    colour. Returns exact extents (normalized and px on 1080p) or None when the text sits on the scene."""
    H, W = frame.shape[:2]
    bx = ink or bbox
    x0, y0 = int(bx[0] * W), int(bx[1] * H)
    x1, y1 = int(round((bx[0] + bx[2]) * W)), int(round((bx[1] + bx[3]) * H))
    g = 2
    lim = 2 * (y1 - y0) + 12
    # edges can only grow lim px, so colour matching runs in that window (was the whole 1080p frame)
    wy0, wy1 = max(0, y0 - lim - g - 2), min(H, y1 + lim + g + 2)
    wx0, wx1 = max(0, x0 - lim - g - 2), min(W, x1 + lim + g + 2)
    img = frame[wy0:wy1, wx0:wx1].astype(np.int16)
    lines = [frame[max(0, y0 - g - 1), x0:x1], frame[min(H - 1, y1 + g), x0:x1],
             frame[y0:y1, max(0, x0 - g - 1)], frame[y0:y1, min(W - 1, x1 + g)]]
    lines = [l.astype(np.int16) for l in lines]
    seeds = [np.median(l, axis=0) for l in lines if l.size]
    if len(seeds) < 4:
        return None
    seed = np.median(np.stack(seeds), axis=0)
    match = (np.abs(img - seed).max(axis=-1) < tol)

    def ok_row(r, c0, c1):
        return 0 <= r < H and c1 > c0 and float(match[r - wy0, c0 - wx0:c1 - wx0].mean()) >= min_frac

    def ok_col(c, r0, r1):
        return 0 <= c < W and r1 > r0 and float(match[r0 - wy0:r1 - wy0, c - wx0].mean()) >= min_frac

    if not (ok_row(y0 - g - 1, x0, x1) and ok_row(y1 + g, x0, x1) and ok_col(x0 - g - 1, y0, y1) and ok_col(x1 + g, y0, y1)):
        return None
    Y0 = y0 - g
    while Y0 > 0 and y0 - Y0 < lim and ok_row(Y0 - 1, x0, x1):
        Y0 -= 1
    Y1 = y1 + g
    while Y1 < H and Y1 - y1 < lim and ok_row(Y1, x0, x1):
        Y1 += 1
    X0 = x0 - g
    while X0 > 0 and x0 - X0 < lim and ok_col(X0 - 1, Y0, Y1):
        X0 -= 1
    X1 = x1 + g
    while X1 < W and X1 - x1 < lim and ok_col(X1, Y0, Y1):
        X1 += 1
    pads = (x0 - X0, y0 - Y0, X1 - x1, Y1 - y1)
    if max(pads) >= lim:  # no edge: text on a large uniform area (sky, black frame), not a plate
        return None
    sx, sy = CANVAS_W / W, CANVAS_H / H
    return {"color": hex_color(seed[::-1]), "rect_px_1080p": [round(X0 * sx, 1), round(Y0 * sy, 1),
                                                              round((X1 - X0) * sx, 1), round((Y1 - Y0) * sy, 1)],
            "rect": [round(X0 / W, 5), round(Y0 / H, 5), round((X1 - X0) / W, 5), round((Y1 - Y0) / H, 5)],
            "pad_px_1080p": [round(p * sy, 1) for p in pads]}


def translucent_box_detect(frame, bbox, ink=None, max_pad_ratio=2.5):
    """Semi-transparent plate behind text (common subtitle style: 30-70 % black over footage).

    box_detect() needs a uniform colour, which a see-through plate never has. Here a plate is a rectangle around the
    glyphs whose edge rows/cols are clearly darker (or lighter) than the pixels just outside it, over most of the
    edge length. Returns rect + colour + estimated alpha, or None."""
    H, W = frame.shape[:2]
    bx = ink or bbox
    x0, y0 = int(bx[0] * W), int(bx[1] * H)
    x1, y1 = int(round((bx[0] + bx[2]) * W)), int(round((bx[1] + bx[3]) * H))
    th = max(4, y1 - y0)
    lim = int(max_pad_ratio * th)
    L = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY).astype(np.float32)

    def edge(axis, start, step, a0, a1):
        """walk outwards; return index where luminance jumps (plate edge) and the jump sign"""
        prev = None
        best, pos = 0.0, None
        for k in range(1, lim):
            i = start + step * k
            if not (0 <= i < (H if axis == 0 else W)):
                break
            line = L[i, a0:a1] if axis == 0 else L[a0:a1, i]
            if line.size < 4:
                break
            v = float(np.median(line))
            if prev is not None and abs(v - prev) > best:
                best, pos = abs(v - prev), (i - step, prev, v)
            prev = v
        return pos, best

    top, jt = edge(0, y0, -1, x0, x1)
    bot, jb = edge(0, y1, 1, x0, x1)
    if not top or not bot or min(jt, jb) < 12:
        return None
    Y0, Y1 = top[0], bot[0]
    lef, jl = edge(1, x0, -1, Y0, Y1)
    rig, jr = edge(1, x1, 1, Y0, Y1)
    if not lef or not rig or min(jl, jr) < 10:
        return None
    X0, X1 = lef[0], rig[0]
    inside = frame[Y0:Y1, X0:X1].reshape(-1, 3).astype(np.float32)
    ring = np.concatenate([frame[max(0, Y0 - 6):Y0, X0:X1].reshape(-1, 3), frame[Y1:min(H, Y1 + 6), X0:X1].reshape(-1, 3)]).astype(np.float32)
    if inside.size == 0 or ring.size == 0:
        return None
    # keep plate pixels (exclude glyph ink: the brightest / darkest 25 %)
    li = inside.mean(1)
    lo_, hi_ = np.percentile(li, [5, 70])
    plate = inside[(li >= lo_) & (li <= hi_)]
    pm, rm = plate.mean(0), ring.mean(0)
    darker = pm.mean() < rm.mean()
    target = np.zeros(3) if darker else np.full(3, 255.0)
    # composite: plate = a*target + (1-a)*background  ->  a = (bg - plate) / (bg - target)
    denom = np.clip(np.abs(rm - target).mean(), 1, None)
    alpha = float(np.clip(np.abs(rm - pm).mean() / denom, 0.1, 1.0))
    sx, sy = CANVAS_W / W, CANVAS_H / H
    col = "#000000" if darker else "#FFFFFF"
    return {"color": col, "alpha": round(alpha, 2), "translucent": True,
            "rect_px_1080p": [round(X0 * sx, 1), round(Y0 * sy, 1), round((X1 - X0) * sx, 1), round((Y1 - Y0) * sy, 1)],
            "rect": [round(X0 / W, 5), round(Y0 / H, 5), round((X1 - X0) / W, 5), round((Y1 - Y0) / H, 5)],
            "pad_px_1080p": [round((x0 - X0) * sy, 1), round((y0 - Y0) * sy, 1), round((X1 - x1) * sy, 1), round((Y1 - y1) * sy, 1)]}


def accent_bars(frame, rect_norm):
    """Thin saturated vertical bars at the plate's left/right edge (e.g. a yellow stripe). Returns list of
    {side, x_px_1080p, w_px_1080p, color}."""
    H, W = frame.shape[:2]
    X0, Y0 = int(rect_norm[0] * W), int(rect_norm[1] * H)
    X1, Y1 = int((rect_norm[0] + rect_norm[2]) * W), int((rect_norm[1] + rect_norm[3]) * H)
    out = []
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    for side, xs in (("left", range(max(0, X0 - 4), min(W, X0 + 24))), ("right", range(max(0, X1 - 24), min(W, X1 + 4)))):
        cols = [x for x in xs if Y1 > Y0 and float((hsv[Y0:Y1, x, 1] > 120).mean()) > 0.8 and float((hsv[Y0:Y1, x, 2] > 120).mean()) > 0.8]
        if cols:
            c = frame[Y0:Y1, cols[0]:cols[-1] + 1].reshape(-1, 3).mean(0)
            out.append({"side": side, "x_px_1080p": round(cols[0] * CANVAS_W / W, 1),
                        "w_px_1080p": round((cols[-1] - cols[0] + 1) * CANVAS_W / W, 1), "color": hex_color(c[::-1])})
    return out



def zone_plate(video_path, events, n=40):
    """Measure a subtitle plate for a whole text zone from many frames.

    A see-through plate darkens (or lightens) the footage behind it by a constant factor, so across frames the
    plate area has ~alpha times the luminance spread of the surroundings. Rows/cols where the spread drops by
    >30 % relative to just outside the zone bound the plate. Also finds accent bars that stay the same colour in
    >60 % of frames. Works for opaque plates too (spread ~0). Returns None when no plate edge is found."""
    evs = sorted(events, key=lambda e: e["start_s"])
    if len(evs) < 5:
        return None
    cap = cv2.VideoCapture(str(video_path))
    frames = []
    for e in evs[::max(1, len(evs) // n)][:n]:
        cap.set(cv2.CAP_PROP_POS_MSEC, (e["start_s"] + e["end_s"]) / 2 * 1000)
        ok, f = cap.read()
        if ok:
            frames.append(cv2.resize(f, (CANVAS_W, CANVAS_H)))
    cap.release()
    if len(frames) < 5:
        return None
    st = np.stack(frames).astype(np.float32)
    L = st.mean(-1)
    sd = L.std(0)
    # median glyph box (zone extents include OCR outliers)
    bb = np.array([e.get("ink_bbox") or e["bbox"] for e in evs], np.float32)
    ys0 = int(np.median(bb[:, 1]) * CANVAS_H)
    ys1 = int(np.median(bb[:, 1] + bb[:, 3]) * CANVAS_H)
    xs0 = int(np.percentile(bb[:, 0], 10) * CANVAS_W)
    xs1 = int(np.percentile(bb[:, 0] + bb[:, 2], 90) * CANVAS_W)
    cx0, cx1 = int(0.5 * (xs0 + xs1)) - 150, int(0.5 * (xs0 + xs1)) + 150
    pad = max(30, ys1 - ys0)
    top_ref = float(np.median(sd[max(0, ys0 - pad):max(1, ys0 - pad // 2), cx0:cx1]))
    bot_ref = float(np.median(sd[min(CANVAS_H - 2, ys1 + pad // 2):min(CANVAS_H - 1, ys1 + pad), cx0:cx1]))
    ref = max(1.0, min(top_ref, bot_ref))
    rows = np.median(sd[:, cx0:cx1], 1)
    lum = np.median(np.median(L, 0)[:, cx0:cx1], 1)
    # plate rows = low spread; text rows inside the plate have high spread (glyphs change) -> take the outer
    # low-spread bands just above and below the glyphs
    low = rows < 0.7 * ref
    Y0 = ys0
    while Y0 > max(0, ys0 - 2 * pad) and (low[Y0 - 1] or Y0 > ys0 - 3):
        Y0 -= 1
    Y1 = ys1
    while Y1 < min(CANVAS_H - 1, ys1 + 2 * pad) and (low[Y1] or Y1 < ys1 + 3):
        Y1 += 1
    if not (low[max(0, ys0 - 4)] and low[min(CANVAS_H - 1, ys1 + 3)]):
        return None
    band = slice(Y0, Y1)
    colsd = np.median(sd[max(0, Y0 + 2):max(Y0 + 3, int(ys0) - 2), :], 0)
    side_ref = max(1.0, float(np.median(colsd[:max(1, xs0 - pad)])) if xs0 - pad > 10 else ref)
    lowc = colsd < 0.7 * side_ref
    X0 = xs0
    while X0 > 0 and lowc[X0 - 1]:
        X0 -= 1
    X1 = xs1
    while X1 < CANVAS_W - 1 and lowc[X1]:
        X1 += 1
    alpha = float(np.clip(1 - np.median(rows[Y0:Y0 + 4]) / ref, 0.05, 1.0))
    outside = float(np.median(lum[max(0, Y0 - pad):Y0 - 2])) if Y0 - 2 > 0 else 128.0
    inside = float(np.median(lum[Y0:Y0 + 4]))
    color = "#000000" if inside < outside else "#FFFFFF"
    hsv = np.stack([cv2.cvtColor(f, cv2.COLOR_BGR2HSV) for f in frames])
    sat = ((hsv[..., 1] > 130) & (hsv[..., 2] > 130)).mean(0)[band]
    cols = np.where(sat.mean(0) > 0.6)[0]
    bars = []
    if cols.size:
        groups = np.split(cols, np.where(np.diff(cols) > 1)[0] + 1)
        for g in groups:
            c = np.median(st[:, band, g[0]:g[-1] + 1].reshape(-1, 3), 0)
            bars.append({"x_px_1080p": int(g[0]), "w_px_1080p": int(len(g)), "color": hex_color(c[::-1]),
                         "side": "left" if g[0] < (X0 + X1) / 2 else "right"})
    return {"color": color, "alpha": round(alpha, 2), "translucent": alpha < 0.95,
            "rect_px_1080p": [X0, Y0, X1 - X0, Y1 - Y0],
            "rect": [round(X0 / CANVAS_W, 5), round(Y0 / CANVAS_H, 5), round((X1 - X0) / CANVAS_W, 5), round((Y1 - Y0) / CANVAS_H, 5)],
            "width_follows_text": True, "accent_bars": bars, "frames_used": len(frames),
            "note": "rect = widest line seen; plate width follows text width (pad_x from glyph ink)"}



def text_colours(crop, box_color_hex=None):
    """Fill colour = pixels most different from the box/background colour; outline = ring around fill."""
    if box_color_hex is None:
        return colours(crop)
    ref = np.array([int(box_color_hex[5:7], 16), int(box_color_hex[3:5], 16), int(box_color_hex[1:3], 16)], np.int16)
    d = np.abs(crop.astype(np.int16) - ref).max(axis=-1)
    m = d > 80
    if m.sum() < 20:
        return colours(crop)
    fill = np.median(crop[m], axis=0)
    res = {"fill": hex_color(fill[::-1]), "background": box_color_hex, "fill_ratio": round(float(m.mean()), 3),
           "background_uniform": True}
    fm = m.astype(np.uint8)
    ring = (cv2.dilate(fm, np.ones((3, 3), np.uint8), iterations=3) - fm).astype(bool)
    rv = crop[ring]
    if rv.size:
        rc = np.median(rv, axis=0)
        if np.abs(rc.astype(np.int16) - ref).max() > 40 and np.abs(rc.astype(np.int16) - fill).max() > 60:
            res["outline"] = hex_color(rc[::-1])
    return res


def ink_bbox(frame, bbox, fill_hex):
    """Tight bbox of fill-coloured pixels inside the OCR box (normalized frame coords) = glyph ink extent."""
    if not fill_hex:
        return None
    H, W = frame.shape[:2]
    x, y, w, h = bbox
    X0, Y0 = max(0, int((x - 0.01) * W)), max(0, int((y - 0.015) * H))
    X1, Y1 = min(W, int((x + w + 0.01) * W)), min(H, int((y + h + 0.015) * H))
    crop = frame[Y0:Y1, X0:X1]
    if crop.size == 0:
        return None
    rgb = (int(fill_hex[1:3], 16), int(fill_hex[3:5], 16), int(fill_hex[5:7], 16))
    ref = cv2.cvtColor(np.uint8([[rgb[::-1]]]), cv2.COLOR_BGR2LAB)[0, 0].astype(np.float32)
    lab = cv2.cvtColor(crop, cv2.COLOR_BGR2LAB).astype(np.float32)
    m = (np.linalg.norm(lab - ref, axis=2) < 25).astype(np.uint8)
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((2, 2), np.uint8))
    # keep only the run of ink rows that overlaps the OCR box core (stacked lines such as logos are separate runs)
    has = m.sum(1) > 1
    core0 = int((y + 0.3 * h) * H) - Y0
    core1 = int((y + 0.7 * h) * H) - Y0
    runs, start = [], None
    for i, v in enumerate(list(has) + [False]):
        if v and start is None:
            start = i
        elif not v and start is not None:
            runs.append((start, i))
            start = None
    keep = [r for r in runs if r[1] > core0 and r[0] < core1]
    if not keep:
        return None
    r0, r1 = min(r[0] for r in keep), max(r[1] for r in keep)
    m[:r0] = 0
    m[r1:] = 0
    rows, cols = np.nonzero(m.sum(1) > 1)[0], np.nonzero(m.sum(0) > 1)[0]
    if len(rows) < 3 or len(cols) < 3:
        return None
    ix0, ix1, iy0, iy1 = cols.min() + X0, cols.max() + 1 + X0, rows.min() + Y0, rows.max() + 1 + Y0
    return [round(ix0 / W, 5), round(iy0 / H, 5), round((ix1 - ix0) / W, 5), round((iy1 - iy0) / H, 5)]


def animation(ev, detail):
    """Entrance animation from observations in the first 0.6 s (needs dense sampling)."""
    if not (detail[0] <= ev["first"] < detail[1]):
        return {"in": "unknown", "reason": "outside detail range (sparse sampling)"}
    obs = [o for o in ev["obs"] if o["t"] - ev["first"] <= 0.6]
    if len(obs) < 3:
        return {"in": "unknown", "reason": "too few samples"}
    final = ev["obs"][min(len(ev["obs"]) - 1, len(obs) + 2)]
    h0, hf = obs[0]["bbox"][3], final["bbox"][3]
    y0, yf = obs[0]["bbox"][1], final["bbox"][1]
    n0, nf = len(obs[0]["text"].replace(" ", "")), len(final["text"].replace(" ", ""))
    c0, cf = obs[0]["conf"], final["conf"]
    res = {"samples": len(obs), "height_ratio_first": round(h0 / hf, 3) if hf else None,
           "y_shift_first": round(y0 - yf, 4), "chars_first": n0, "chars_final": nf, "first_seen_s": ev["first"]}
    growth, last_n = [], -1
    for o_ in ev["obs"]:
        n_ = len(o_["text"].replace(" ", ""))
        if n_ != last_n:
            growth.append([round(o_["t"] - ev["first"], 3), n_])
            last_n = n_
    if len(growth) > 1:
        res["growth"] = growth
    in_end = next((o_["t"] - ev["first"] for o_ in ev["obs"]
                   if abs(o_["bbox"][3] - hf) / max(hf, 1e-6) < 0.03 and len(o_["text"].replace(" ", "")) >= nf), None)
    res["in_s_est"] = round(in_end, 3) if in_end is not None else None
    if nf and n0 / nf < 0.7:
        steps = sorted({len(o["text"].split()) for o in ev["obs"]})
        res["in"] = "word_by_word" if len(steps) > 1 and all(b - a <= 2 for a, b in zip(steps, steps[1:])) else "typewriter"
    elif hf and abs(h0 / hf - 1) > 0.08:
        res["in"] = "pop_scale" if h0 < hf else "scale_down"
    elif abs(y0 - yf) > 0.01:
        res["in"] = "slide_up" if y0 > yf else "slide_down"
    elif c0 < cf - 0.2:
        res["in"] = "fade"
    else:
        res["in"] = "none"
    return res


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("video")
    ap.add_argument("--out", required=True)
    ap.add_argument("--range", help="START:END seconds (default whole video)")
    ap.add_argument("--fps", type=float, default=4.0)
    ap.add_argument("--detail-range", default="0:30")
    ap.add_argument("--detail-fps", type=float, default=15.0)
    ap.add_argument("--ocr-width", type=int, default=800)
    ap.add_argument("--lang", default="ko-KR,en-US")
    ap.add_argument("--min-conf", type=float, default=0.45)
    ap.add_argument("--workers", type=int, default=4, help="OCR worker processes")
    ap.add_argument("--zones-only", action="store_true",
                    help="keep OCR events, only (re)measure zone plates (see-through subtitle/tag plates, accent bars)")
    a = ap.parse_args()
    if a.zones_only:
        from common import read_json
        cp = Path(a.out) / "captions.json"
        doc = read_json(cp)
        for z in doc.get("zones", []):
            mem = [e for e in doc["events"] if e.get("zone") == z["id"]]
            z["plate"] = zone_plate(a.video, mem) if len(mem) >= 20 else None
            if z["plate"]:
                print(f"{z['id']}: plate {z['plate']['color']} alpha {z['plate']['alpha']} rect {z['plate']['rect_px_1080p']} bars {z['plate']['accent_bars']}")
        write_json(cp, doc)
        return
    info = probe(a.video)
    fps, W, H = info["fps"], info["width"], info["height"]
    detail = parse_range(a.detail_range, info["duration_s"])
    rng = parse_range(a.range, info["duration_s"])
    fidx = sample_frames(fps, info["nb_frames"], rng, a.fps, detail, a.detail_fps)
    langs = tuple(a.lang.split(","))
    wanted = set(fidx)
    dets = []
    print(f"OCR on {len(fidx)} frames ...")
    # decode once through ffmpeg at OCR width, OCR in worker processes. Threads were measured at ~40 ms/frame
    # (the PyObjC bridge serializes them); 4 processes ~12 ms/frame. The pending window bounds memory.
    from concurrent.futures import FIRST_COMPLETED, ProcessPoolExecutor, wait
    pending = {}

    def drain(block_until):
        while len(pending) > block_until:
            done, _ = wait(list(pending), return_when=FIRST_COMPLETED)
            for fu in done:
                i = pending.pop(fu)
                dets.append((round(i / fps, 4), [o for o in fu.result() if o["conf"] >= a.min_conf]))

    with ProcessPoolExecutor(max_workers=a.workers) as ex:
        for i, frame in iter_frames(a.video, fidx[0], fidx[-1] + 1, width=a.ocr_width):
            if i in wanted:
                pending[ex.submit(vision_ocr, frame, langs)] = i
                drain(a.workers * 6)
        drain(0)
    dets.sort(key=lambda d: d[0])
    events = group_events(dets, max(1 / a.fps, 1 / a.detail_fps) * 1.6)
    events = [ev for ev in events if len(ev["obs"]) >= 2 or detail[0] <= ev["first"] < detail[1]]
    crop_dir = Path(a.out) / "frames" / "captions"
    crop_dir.mkdir(parents=True, exist_ok=True)
    mids = {k: ev["obs"][len(ev["obs"]) // 2] for k, ev in enumerate(events)}
    full = grab_frames(a.video, [int(round(o["t"] * fps)) for o in mids.values()])
    out_events = []
    for k, ev in enumerate(events):
        o = mids[k]
        texts = [x["text"] for x in ev["obs"]]
        text = max(set(texts), key=lambda s: (texts.count(s), len(s)))
        x, y, w, h = o["bbox"]
        e = {"id": f"t{k + 1:04d}", "text": text, "start_s": ev["first"], "end_s": round(ev["last"] + 0.5 / a.fps, 3),
             "bbox": o["bbox"], "conf": o["conf"], "samples": len(ev["obs"]),
             "px_1080p": {"x": round(x * CANVAS_W), "y": round(y * CANVAS_H), "w": round(w * CANVAS_W),
                          "h": round(h * CANVAS_H)},
             "center_x": round(x + w / 2, 4),
             "align": "center" if abs(x + w / 2 - 0.5) < 0.04 else ("left" if x < 0.2 else "right"),
             "line_height_px_1080p": round(h * CANVAS_H, 1), "font_size_px_1080p_est": round(h * CANVAS_H / 1.15, 1)}
        if credit_like(text, o["bbox"]):
            e["credit_like"] = True
        frame = full.get(int(round(o["t"] * fps)))
        if frame is not None:
            X0, Y0 = max(0, int((x - 0.01) * W)), max(0, int((y - 0.02) * H))
            X1, Y1 = min(W, int((x + w + 0.01) * W)), min(H, int((y + h + 0.02) * H))
            crop = frame[Y0:Y1, X0:X1]
            if crop.size:
                cv2.imwrite(str(crop_dir / f"{e['id']}.png"), crop)
                e["crop"] = f"frames/captions/{e['id']}.png"
                col0 = colours(crop)
                ib0 = ink_bbox(frame, o["bbox"], col0.get("fill"))
                bx = box_detect(frame, o["bbox"], ink=ib0) or translucent_box_detect(frame, o["bbox"], ink=ib0)
                if bx:
                    bars_ = accent_bars(frame, bx["rect"])
                    if bars_:
                        bx["accent_bars"] = bars_
                col = text_colours(crop, None if (not bx or bx.get("translucent")) else bx["color"])
                px = col.pop("outline_px_on_crop", None)
                if px:
                    col["outline_px_1080p"] = round(px * CANVAS_H / H, 1)
                if bx:
                    col["box"] = bx
                e["style"] = col
                ib = ink_bbox(frame, o["bbox"], col.get("fill"))
                if ib:
                    e["ink_bbox"] = ib
                    e["ink_px_1080p"] = {"x": round(ib[0] * CANVAS_W, 1), "y": round(ib[1] * CANVAS_H, 1),
                                         "w": round(ib[2] * CANVAS_W, 1), "h": round(ib[3] * CANVAS_H, 1)}
        e["animation"] = animation(ev, detail)
        out_events.append(e)
    # consecutive texts in the same place: the next one starts exactly where the previous one ends
    by_pos = sorted(out_events, key=lambda e: e["start_s"])
    for i, e in enumerate(by_pos):
        for f in by_pos[i + 1:]:
            if f["start_s"] >= e["end_s"] + 0.5:
                break
            if f["start_s"] > e["start_s"] and bbox_iou(e["bbox"], f["bbox"]) > 0.05 and \
                    abs((e["bbox"][1] + e["bbox"][3] / 2) - (f["bbox"][1] + f["bbox"][3] / 2)) < 0.03:
                e["end_s"] = min(e["end_s"], f["start_s"])
                break
    zones = []
    for e in out_events:
        cy = e["bbox"][1] + e["bbox"][3] / 2
        for z in zones:
            if abs(z["cy"] - cy) < 0.05 and abs(z["h"] - e["bbox"][3]) < 0.03:
                z["members"].append(e["id"])
                z["cy"] += (cy - z["cy"]) / len(z["members"])
                break
        else:
            zones.append({"cy": cy, "h": e["bbox"][3], "members": [e["id"]]})
    zones.sort(key=lambda z: -len(z["members"]))
    zdoc = []
    for n, z in enumerate(zones):
        mem = [e for e in out_events if e["id"] in z["members"]]
        zid = f"z{n + 1}"
        for e in mem:
            e["zone"] = zid
        x0 = min(e["bbox"][0] for e in mem)
        y0 = min(e["bbox"][1] for e in mem)
        x1 = max(e["bbox"][0] + e["bbox"][2] for e in mem)
        y1 = max(e["bbox"][1] + e["bbox"][3] for e in mem)
        plate = zone_plate(a.video, mem) if len(mem) >= 20 else None
        zdoc.append({"id": zid, "count": len(mem), "center_y": round(z["cy"], 4), "plate": plate,
                     "bbox": [round(x0, 4), round(y0, 4), round(x1 - x0, 4), round(y1 - y0, 4)],
                     "median_line_height_px_1080p": round(float(np.median([e["bbox"][3] for e in mem])) * CANVAS_H, 1),
                     "fills": sorted({(e.get("style") or {}).get("fill") for e in mem} - {None})[:6]})
    doc = {"video": str(Path(a.video).resolve()), "range": list(rng), "fps_sampled": a.fps, "detail_range": list(detail),
           "detail_fps": a.detail_fps, "events": out_events, "zones": zdoc,
           "credit_events": [e["id"] for e in out_events if e.get("credit_like")],
           "render_policy": None,
           "note": "font_size_px_1080p_est ~= line box height / 1.15. Verify colours/box on crops; run font_match. "
                   "Set render_policy {zones:[...], include_ids:[...], exclude_ids:[...]} after review: which text is "
                   "an edit overlay (rendered in recreation) vs text baked into the source footage (not rendered)."}
    write_json(Path(a.out) / "captions.json", doc)
    print(f"{len(out_events)} text events in {len(zdoc)} zones -> {Path(a.out) / 'captions.json'}")


if __name__ == "__main__":
    main()
