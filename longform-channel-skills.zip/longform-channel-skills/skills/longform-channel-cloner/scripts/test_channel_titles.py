import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from fetch_channel import cmd_titles

class TitleInventoryTests(unittest.TestCase):
    def run_inventory(self, results):
        with tempfile.TemporaryDirectory() as folder:
            with patch('fetch_channel.ytdlp', side_effect=results) as request:
                cmd_titles(SimpleNamespace(channel_url='https://www.youtube.com/@example',project=folder,cookies_from_browser=None))
            self.assertEqual(request.call_count, 3)
            for call in request.call_args_list:
                self.assertNotIn('--playlist-end', call.args[0])
            return json.loads((Path(folder)/'analysis/channel_titles.json').read_text())

    def response(self, entries):
        return SimpleNamespace(returncode=0,stdout=json.dumps({'entries':entries}),stderr='')

    def test_all_titles_kept_and_deduplicated(self):
        a={'id':'a','title':'Short duration kept','duration':10}
        b={'id':'b','title':'No duration kept'}
        result=self.run_inventory([self.response([a,b]),self.response([a]),self.response([])])
        self.assertEqual(result['count'],2)
        self.assertTrue(result['all_tabs_retrieved'])
        self.assertEqual(len(result['videos'][0]['appearances']),2)
        self.assertIsNone(result['videos'][1]['upload_date'])

    def test_failure_and_missing_titles_are_reported(self):
        result=self.run_inventory([self.response([{'id':'a','title':'Found'},None]),
            SimpleNamespace(returncode=1,stdout='',stderr='unavailable'),self.response([])])
        self.assertEqual(result['count'],1)
        self.assertFalse(result['all_tabs_retrieved'])
        self.assertEqual(result['tabs']['videos']['status'],'partial')
        self.assertEqual(result['tabs']['shorts']['status'],'unavailable')

if __name__=='__main__': unittest.main()
