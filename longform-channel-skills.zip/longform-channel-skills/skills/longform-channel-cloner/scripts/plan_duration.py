#!/usr/bin/env python3
"""최신 원본 1편의 길이와 본편 ±30초 허용 범위·미리보기 길이를 계산한다.

사용법: python plan_duration.py REFERENCES_JSON --out OUTPUT_JSON
신규 references는 최신 1편이다. 기존 2편·6편 입력은 당시 평균 계산을 보존한다. 구조 탐색용 추가
레퍼런스는 이 목록에 넣지 않는다. excluded_references는
판단하거나 계산에 넣지 않고 전달받은 기록 그대로 출력에 보존한다.
초 단위 결과에는 별도의 반올림이나 고정 본편 길이를 적용하지 않는다.
프리뷰 범위는 목표 길이 기준의 잠정값이며 게이트는 실제 본편 길이로 검증한다.
preview_end_s와 preview_duration_s는 호환용 기본 예시로, 실제 끝점은 별도 선택한다.
"""

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import statistics
import sys
import tempfile


def plan_duration(document, source_input_sha256):
    """입력을 검증하고 길이 계획을 반환한다. 렌더링·의미 판단은 하지 않는다."""
    if not isinstance(document, dict):
        raise ValueError("입력은 JSON 객체여야 합니다.")
    references = document.get("references")
    legacy_count = len(references) if isinstance(references, list) and len(references) in (2, 6) else 1
    expected = document.get("reference_count", legacy_count)
    if type(expected) is not int or expected not in (1, 2, 6):
        raise ValueError("reference_count는 최신 1편 또는 기존 2편·6편이어야 합니다.")
    if not isinstance(references, list) or len(references) != expected:
        raise ValueError(f"references는 중복 없이 정확히 {expected}편이어야 합니다.")
    excluded = document.get("excluded_references", [])
    if not isinstance(excluded, list):
        raise ValueError("excluded_references는 배열이어야 합니다.")

    included = []
    seen = set()
    for index, reference in enumerate(references):
        if not isinstance(reference, dict):
            raise ValueError(f"references[{index}]는 객체여야 합니다.")
        reference_id = reference.get("id")
        if not isinstance(reference_id, str) or not reference_id.strip():
            raise ValueError(f"references[{index}].id는 비어 있지 않은 문자열이어야 합니다.")
        if reference_id.strip() in seen:
            raise ValueError(f"references[{index}].id가 중복됩니다.")
        seen.add(reference_id.strip())
        duration = reference.get("duration_s")
        if isinstance(duration, bool) or not isinstance(duration, (int, float)):
            raise ValueError(f"references[{index}].duration_s는 숫자여야 합니다.")
        try:
            valid_duration = math.isfinite(duration) and duration > 0
        except OverflowError:
            valid_duration = False
        if not valid_duration:
            raise ValueError(f"references[{index}].duration_s는 유한한 양수여야 합니다.")
        included.append({"id": reference_id, "duration_s": duration})

    # statistics.mean은 큰 유한값들의 합이 float 범위를 넘는 경우도 처리한다.
    target = statistics.mean(reference["duration_s"] for reference in included)
    preview = min(180, target)
    result = {
        "target_duration_s": target,
        "preview_start_s": 0,
        "preview_end_s": preview,
        "preview_duration_s": preview,
        "preview_min_duration_s": min(170, target),
        "preview_max_duration_s": min(210, target),
        "preview_selection_required": True,
        "references": included,
        "excluded_references": excluded,
        "reference_count": expected,
        "reference_policy": {1: "latest-one-v1", 2: "latest-two-v1", 6: "legacy-six-v1"}[expected],
        "formula": f"sum(reference.duration_s for reference in references) / {expected}",
        "source_input_sha256": source_input_sha256,
    }
    # 과거 계산 파일의 재검증 값과 해시는 유지하며 신규 1편 정책에만 적용한다.
    if expected == 1:
        result.update(full_duration_tolerance_s=30,
                      full_min_duration_s=max(0, target - 30),
                      full_max_duration_s=target + 30)
    return result


def write_plan(output_path, plan):
    """검증·직렬화·쓰기 성공 후에만 기존 출력 파일을 원자적으로 교체한다."""
    serialized = json.dumps(plan, ensure_ascii=False, indent=2, allow_nan=False) + "\n"
    output_path.parent.mkdir(parents=True, exist_ok=True)
    temporary_path = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", dir=output_path.parent,
            prefix=f".{output_path.name}.", suffix=".tmp", delete=False,
        ) as stream:
            temporary_path = Path(stream.name)
            stream.write(serialized)
        os.replace(temporary_path, output_path)
    finally:
        if temporary_path is not None:
            temporary_path.unlink(missing_ok=True)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("references_json", type=Path)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args(argv)
    try:
        source = args.references_json.read_bytes()
        document = json.loads(source)
        plan = plan_duration(document, hashlib.sha256(source).hexdigest())
        write_plan(args.out, plan)
    except (OSError, ValueError, TypeError, OverflowError) as error:
        print(f"오류: {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
