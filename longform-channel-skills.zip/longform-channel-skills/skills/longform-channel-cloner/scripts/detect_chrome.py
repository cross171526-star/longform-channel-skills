#!/usr/bin/env python3
"""Detect persistent screen chrome (channel logo, corner icon, topic-tag plate, subtitle plate, watermark).

  run.sh detect_chrome <video> [<video> ...] --out <dir> [--samples 80]

For each video, frames are sampled over the whole runtime; pixels that keep their colour while the footage under
them changes are chrome. Translucent plates are only partly stable, so the threshold is relative to the video's
own background stability. Nearby pieces on one row are merged (logo letters, plate + accent bar).
With several videos (recommended: all analyzed videos of the channel), only elements found in at least two videos
are kept - long static shots in one video can't fake chrome then.
Writes <dir>/chrome.json and RGBA cut-outs <dir>/frames/chrome/<id>.png (measurement only, never render them):
  {"elements": [{"id", "rect_px_1080p", "rect", "position", "kind_guess", "presence", "videos", "crop"}]}
Always check the cut-outs visually. In a new video each element is replaced by your own brand element in the same
rect (P/brand.json "chrome"), see SKILL.md.
"""
from __future__ import annotations

import argparse
from pathlib import Path

import cv2
import numpy as np

from common import CANVAS_H, CANVAS_W, hex_color, probe, write_json

SW, SH = CANVAS_W // 2, CANVAS_H // 2


def sample(video, n, skip):
    dur = probe(video)["duration_s"]
    t0, t1 = min(skip, dur * 0.1), max(dur - skip, dur * 0.9)
    cap = cv2.VideoCapture(str(video))
    fr = []
    for t in np.linspace(t0, t1, n):
        cap.set(cv2.CAP_PROP_POS_MSEC, t * 1000)
        ok, f = cap.read()
        if ok:
            fr.append(cv2.resize(f, (SW, SH)))
    cap.release()
    st = np.stack(fr).astype(np.float32)
    # drop near-duplicate samples (same shot) so static footage can't look like chrome
    keep = [0]
    for k in range(1, len(st)):
        if min(float(np.abs(st[k] - st[j]).mean()) for j in keep[-6:]) > 10:
            keep.append(k)
    return st[keep] if len(keep) >= 12 else st


def boxes_for(st):
    med = np.median(st, 0)
    close = (np.abs(st - med).max(-1) < 18).mean(0)
    cl = cv2.GaussianBlur(close.astype(np.float32), (0, 0), 2.0)
    bg = float(np.percentile(cl, 60))
    thr = max(0.1, bg * 3.0) if bg < 0.3 else min(0.9, bg + 0.25)
    # structure in the median frame: edges/contrast that survive averaging over many shots
    g = cv2.cvtColor(med.astype(np.uint8), cv2.COLOR_BGR2GRAY).astype(np.float32)
    struct = cv2.GaussianBlur(np.abs(cv2.Laplacian(g, cv2.CV_32F)), (0, 0), 3.0)
    lum_dev = np.abs(g - cv2.GaussianBlur(g, (0, 0), 25.0))
    visible = (struct > np.percentile(struct, 90)) | (lum_dev > 18)
    mask = ((cl > thr) & visible).astype(np.uint8) if bg >= 0.3 else (cl > thr).astype(np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((2, 2), np.uint8))
    n, lab, stats, _ = cv2.connectedComponentsWithStats(cv2.dilate(mask, np.ones((5, 5), np.uint8)))
    raw = []
    for i in range(1, n):
        x, y, w, h, area = stats[i]
        if area < 60:
            continue
        pres = float(close[y:y + h, x:x + w][lab[y:y + h, x:x + w] == i].mean())
        raw.append([x, y, x + w, y + h, pres])
    # merge pieces on one row with small gaps
    raw.sort(key=lambda b: (b[1], b[0]))
    merged = []
    for b in raw:
        for m in merged:
            ov = min(m[3], b[3]) - max(m[1], b[1])
            gap = max(b[0] - m[2], m[0] - b[2])
            if ov > 0.5 * min(m[3] - m[1], b[3] - b[1]) and gap < 40:
                m[0], m[1], m[2], m[3] = min(m[0], b[0]), min(m[1], b[1]), max(m[2], b[2]), max(m[3], b[3])
                m[4] = max(m[4], b[4])
                break
        else:
            merged.append(list(b))
    out = []
    for x0, y0, x1, y1, pres in merged:
        w, h = x1 - x0, y1 - y0
        if w * h > 0.12 * SW * SH or h > 0.35 * SH:
            continue
        if not (y0 < 0.2 * SH or y1 > 0.8 * SH or x0 < 0.12 * SW or x1 > 0.88 * SW):
            continue
        out.append({"box": [x0, y0, w, h], "presence": pres, "med": med})
    return out, bg


def iou(a, b):
    ax0, ay0, aw, ah = a; bx0, by0, bw, bh = b
    ix = max(0, min(ax0 + aw, bx0 + bw) - max(ax0, bx0)); iy = max(0, min(ay0 + ah, by0 + bh) - max(ay0, by0))
    inter = ix * iy
    return inter / max(1, aw * ah + bw * bh - inter)


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("videos", nargs="+")
    ap.add_argument("--out", required=True)
    ap.add_argument("--samples", type=int, default=80)
    ap.add_argument("--skip-edges-s", type=float, default=20.0, help="ignore intro/outro seconds")
    a = ap.parse_args()
    per = []
    for v in a.videos:
        st = sample(v, a.samples, a.skip_edges_s)
        bx, bg = boxes_for(st)
        per.append((v, bx, bg, len(st)))
        print(f"{Path(v).parent.name}: {len(bx)} candidates, background stability {bg:.2f}, {len(st)} distinct frames")
    groups = []
    for vi, (_, bx, _, _) in enumerate(per):
        for b in bx:
            for g in groups:
                if iou(g["box"], b["box"]) > 0.4:
                    g["hits"].add(vi); g["pres"].append(b["presence"])
                    g["box"] = [min(g["box"][0], b["box"][0]), min(g["box"][1], b["box"][1]),
                                max(g["box"][0] + g["box"][2], b["box"][0] + b["box"][2]) - min(g["box"][0], b["box"][0]),
                                max(g["box"][1] + g["box"][3], b["box"][1] + b["box"][3]) - min(g["box"][1], b["box"][1])]
                    break
            else:
                groups.append({"box": list(b["box"]), "hits": {vi}, "pres": [b["presence"]], "med": b["med"]})
    need = 2 if len(per) >= 2 else 1
    out = Path(a.out)
    cdir = out / "frames" / "chrome"
    cdir.mkdir(parents=True, exist_ok=True)
    els = []
    for g in sorted(groups, key=lambda g: (g["box"][1], g["box"][0])):
        if len(g["hits"]) < need:
            continue
        x, y, w, h = g["box"]
        eid = f"ch{len(els) + 1:02d}"
        crop = g["med"][y:y + h, x:x + w].astype(np.uint8)
        cv2.imwrite(str(cdir / f"{eid}.png"), cv2.resize(crop, (w * 2, h * 2), interpolation=cv2.INTER_CUBIC))
        cx, cy = (x + w / 2) / SW, (y + h / 2) / SH
        pos = ("top" if cy < 0.5 else "bottom") + "_" + ("left" if cx < 0.33 else "right" if cx > 0.67 else "center")
        pres = float(np.median(g["pres"]))
        kind = ("subtitle_plate" if w > 0.35 * SW and cy > 0.7 else
                "translucent_plate" if pres < 0.4 and w > 2.5 * h else
                "logo_or_text" if cv2.cvtColor(crop, cv2.COLOR_BGR2HSV)[..., 2].std() > 50 else "icon")
        rect = [int(x * 2), int(y * 2), int(w * 2), int(h * 2)]
        els.append({"id": eid, "rect_px_1080p": rect,
                    "rect": [round(rect[0] / CANVAS_W, 4), round(rect[1] / CANVAS_H, 4), round(rect[2] / CANVAS_W, 4), round(rect[3] / CANVAS_H, 4)],
                    "position": pos, "kind_guess": kind, "presence": round(pres, 3), "videos": len(g["hits"]),
                    "mean_color": hex_color(crop.reshape(-1, 3).mean(0)[::-1]), "crop": f"frames/chrome/{eid}.png"})
    doc = {"videos": [str(Path(v).resolve()) for v, *_ in per], "elements": els,
           "background_stability": {Path(v).parent.name: round(bg, 3) for v, _, bg, _ in per},
           "note": "Persistent overlays found in >=2 videos. Replace each with your own element in the same rect via "
                   "P/brand.json {\"chrome\": {\"<id>\": {\"image\": \"path.png\"} | {\"text\": \"...\", \"font_file\": \"...\", "
                   "\"color\": \"#fff\"}}}. Subtitle/tag plates are drawn from captions plate data, not from here."}
    write_json(out / "chrome.json", doc)
    print(f"{len(els)} chrome elements -> {out / 'chrome.json'}")
    for e in els:
        print(f"  {e['id']} {e['position']:<14} {e['rect_px_1080p']} presence {e['presence']} in {e['videos']} videos  {e['kind_guess']}")


if __name__ == "__main__":
    main()

