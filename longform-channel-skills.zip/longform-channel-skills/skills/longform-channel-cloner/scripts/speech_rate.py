#!/usr/bin/env python3
"""로컬 전사 JSON의 단어 타임스탬프(초)로 레퍼런스 발화 속도를 추정한다.

사용법: python speech_rate.py TRANSCRIPT_JSON --out PATH
기존 전사의 words: [{w, start, end, p?}]와 선택적 language만 사용한다.
문자 수는 Unicode 공백을 제외한 코드 포인트 수이며, 단어 토큰 수는
ASR 토크나이저에 의존한다. 전체 발화 시간은 첫 시작부터 마지막 끝까지
(쉼 포함), 활성 시간은 단어 구간 합집합(구간 사이 공백 제외)이다.
빈 words와 길이 0인 구간은 허용하며, 분모가 0인 속도는 null이다.
음원·음성 특성·쉼 패턴 분석이나 재생 배속 환산은 수행하지 않는다.
"""

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import sys
import tempfile


def _timestamp(value, label):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{label}는 초 단위 숫자여야 합니다.")
    try:
        value = float(value)
    except OverflowError as error:
        raise ValueError(f"{label}는 유한한 값이어야 합니다.") from error
    if not math.isfinite(value) or value < 0:
        raise ValueError(f"{label}는 유한한 0 이상의 값이어야 합니다.")
    return value


def speech_rate(document, source_input_sha256):
    """words만 검증·집계한다. 기존 rate, segments 등의 값은 사용하지 않는다."""
    if not isinstance(document, dict):
        raise ValueError("입력은 JSON 객체여야 합니다.")
    words = document.get("words")
    if not isinstance(words, list):
        raise ValueError("words는 배열이어야 합니다.")
    if "language" in document and document["language"] is not None:
        if not isinstance(document["language"], str) or not document["language"].strip():
            raise ValueError("language는 비어 있지 않은 문자열 또는 null이어야 합니다.")

    intervals = []
    char_count = 0
    for index, word in enumerate(words):
        if not isinstance(word, dict):
            raise ValueError(f"words[{index}]는 객체여야 합니다.")
        text = word.get("w")
        if not isinstance(text, str) or not text.strip():
            raise ValueError(f"words[{index}].w는 비어 있지 않은 문자열이어야 합니다.")
        start = _timestamp(word.get("start"), f"words[{index}].start")
        end = _timestamp(word.get("end"), f"words[{index}].end")
        if end < start:
            raise ValueError(f"words[{index}].end는 start 이상이어야 합니다.")
        intervals.append((start, end))
        char_count += sum(not character.isspace() for character in text)

    # 입력 순서에 의존하지 않고 겹침·포함·맞닿은 구간을 한 번씩 센다.
    merged = []
    for start, end in sorted(intervals):
        if merged and start <= merged[-1][1]:
            merged[-1] = (merged[-1][0], max(merged[-1][1], end))
        else:
            merged.append((start, end))
    span = merged[-1][1] - merged[0][0] if merged else 0.0
    active = math.fsum(end - start for start, end in merged)
    span_rate = char_count / span if span > 0 else None
    active_rate = char_count / active if active > 0 else None
    if any(value is not None and not math.isfinite(value)
           for value in (span, active, span_rate, active_rate)):
        raise ValueError("계산 결과가 숫자 범위를 초과합니다.")
    result = {
        "char_count": char_count,
        "word_token_count": len(words),
        "word_token_count_note": "tokenizer-dependent (로컬 ASR words 항목 수)",
        "speech_span_s": span,
        "speech_active_s": active,
        "chars_per_s_span": span_rate,
        "chars_per_s_active": active_rate,
        "estimated": True,
        "method": "local_asr_word_timestamps",
        "source_input_sha256": source_input_sha256,
    }
    if "language" in document:
        result["language"] = document["language"]
    return result


def write_rate(output_path, result):
    """직렬화·쓰기 성공 후 같은 디렉터리의 임시 파일을 원자적으로 교체한다."""
    serialized = json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n"
    output_path.parent.mkdir(parents=True, exist_ok=True)
    temporary_path = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", dir=output_path.parent,
            prefix=f".{output_path.name}.", suffix=".tmp", delete=False,
        ) as stream:
            temporary_path = Path(stream.name)
            stream.write(serialized)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary_path, output_path)
    finally:
        if temporary_path is not None:
            temporary_path.unlink(missing_ok=True)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("transcript_json", type=Path)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args(argv)
    try:
        if (args.transcript_json.resolve() == args.out.resolve()
                or (args.out.exists() and args.transcript_json.exists()
                    and os.path.samefile(args.transcript_json, args.out))):
            raise ValueError("입력 전사와 출력 경로는 달라야 합니다.")
        source = args.transcript_json.read_bytes()
        result = speech_rate(json.loads(source), hashlib.sha256(source).hexdigest())
        write_rate(args.out, result)
    except (OSError, ValueError, TypeError, OverflowError) as error:
        print(f"오류: {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
