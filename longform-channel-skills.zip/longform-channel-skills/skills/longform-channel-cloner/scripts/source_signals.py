#!/usr/bin/env python3
"""Collect evidence for classifying each clip's source (AI-generated / stock / external footage / ...).

  run.sh source_signals <video> --cuts <cuts.json> [--range 0:30] [--ids c010 c011]

Per cut: letterbox/pillarbox bars, blur-background pillarbox (vertical footage), sharpness, noise, saturation,
content motion (from motion block if present), text/watermark hints (OCR on the mid frame), aspect of the
active picture, duplicate-source groups (perceptual hash across cuts), and a 1024px keyframe image saved for
visual inspection. Writes <analysis_dir>/source_signals.json and <analysis_dir>/frames/src/<cut_id>.jpg.

These are signals, not verdicts. The agent decides "source_type" after looking at the frames.
"""
from __future__ import annotations

import argparse
from pathlib import Path

import cv2
import imagehash
import numpy as np
from PIL import Image

from common import grab_frames, parse_range, read_json, resize_w, vision_ocr, write_json


def bars(img):
    g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY).astype(np.float32)
    h, w = g.shape
    rows, cols = g.mean(1), g.mean(0)
    rstd, cstd = g.std(1), g.std(0)

    def edge(vals, stds, n):
        k = 0
        while k < n // 3 and vals[k] < 20 and stds[k] < 6:
            k += 1
        return k

    top = edge(rows, rstd, h)
    bottom = edge(rows[::-1], rstd[::-1], h)
    left = edge(cols, cstd, w)
    right = edge(cols[::-1], cstd[::-1], w)
    return {"top": round(top / h, 3), "bottom": round(bottom / h, 3), "left": round(left / w, 3),
            "right": round(right / w, 3)}


def blur_pillarbox(img):
    """Vertical/phone footage placed over a blurred copy of itself: side bands much blurrier than centre."""
    g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    h, w = g.shape
    lap = cv2.Laplacian(g, cv2.CV_64F)
    side = np.concatenate([lap[:, : w // 6].ravel(), lap[:, -w // 6:].ravel()]).var()
    centre = lap[:, w // 3: 2 * w // 3].var()
    return bool(centre > 8 * max(side, 1e-6) and centre > 50), round(float(side), 2), round(float(centre), 2)


def noise_level(img):
    g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY).astype(np.float32)
    hp = g - cv2.GaussianBlur(g, (0, 0), 1.2)
    flat = cv2.Laplacian(cv2.GaussianBlur(g, (0, 0), 2), cv2.CV_32F)
    sel = np.abs(flat) < np.percentile(np.abs(flat), 30)
    return round(float(hp[sel].std()) if sel.any() else 0.0, 3)


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("video")
    ap.add_argument("--cuts", required=True)
    ap.add_argument("--range")
    ap.add_argument("--ids", nargs="*", help="only these cuts; other cuts keep their existing signals")
    ap.add_argument("--hash-dist", type=int, default=8, help="max pHash distance to group cuts as same source")
    a = ap.parse_args()
    cpath = Path(a.cuts)
    doc = read_json(cpath)
    lo, hi = parse_range(a.range, doc["video"]["duration_s"]) if a.range else (0, 1e9)
    cuts = [c for c in doc["cuts"] if lo <= c["start_s"] < hi and (not a.ids or c["id"] in a.ids)]
    picks = {}
    for c in cuts:
        s, e = c["start_frame"], c["end_frame"]
        bi = c.get("boundary_in") or {}
        if bi.get("auto_type", "cut") != "cut":
            s = min(max(s, bi.get("end_frame", s) + 1), e - 1)
        picks[c["id"]] = [s + max(1, (e - s) // 5), (s + e) // 2, e - 1 - max(1, (e - s) // 5)]
    frames = grab_frames(doc["video"]["path"], [f for v in picks.values() for f in v])
    src_dir = cpath.parent / "frames" / "src"
    src_dir.mkdir(parents=True, exist_ok=True)
    out = {}
    hashes = {}
    for c in cuts:
        fa, fm, fb = (frames.get(f) for f in picks[c["id"]])
        if fm is None:
            continue
        cv2.imwrite(str(src_dir / f"{c['id']}.jpg"), resize_w(fm, 1024), [cv2.IMWRITE_JPEG_QUALITY, 90])
        g = cv2.cvtColor(fm, cv2.COLOR_BGR2GRAY)
        hsv = cv2.cvtColor(fm, cv2.COLOR_BGR2HSV)
        b = bars(fm)
        bp, side_var, centre_var = blur_pillarbox(fm)
        h, w = g.shape
        act_w = w * (1 - b["left"] - b["right"])
        act_h = h * (1 - b["top"] - b["bottom"])
        content_change = None
        if fa is not None and fb is not None:
            sa = cv2.resize(cv2.cvtColor(fa, cv2.COLOR_BGR2GRAY), (64, 36)).astype(np.int16)
            sb = cv2.resize(cv2.cvtColor(fb, cv2.COLOR_BGR2GRAY), (64, 36)).astype(np.int16)
            content_change = round(float(np.mean(np.abs(sa - sb))), 2)
        ocr = [o for o in vision_ocr(resize_w(fm, 800)) if o["conf"] >= 0.5]
        corner = [o for o in ocr if (o["bbox"][0] > 0.7 or o["bbox"][0] + o["bbox"][2] < 0.3)
                  and (o["bbox"][1] < 0.15 or o["bbox"][1] > 0.85) and o["bbox"][3] < 0.06]
        ph = imagehash.phash(Image.fromarray(cv2.cvtColor(fm, cv2.COLOR_BGR2RGB)))
        hashes[c["id"]] = ph
        m = c.get("motion") or {}
        out[c["id"]] = {
            "start_s": c["start_s"], "duration_s": c["duration_s"], "image": f"frames/src/{c['id']}.jpg",
            "bars": b, "active_aspect": round(act_w / act_h, 3) if act_h else None,
            "blur_pillarbox": bp, "laplacian_var": round(float(cv2.Laplacian(g, cv2.CV_64F).var()), 1),
            "noise": noise_level(fm), "saturation_mean": round(float(hsv[..., 1].mean()), 1),
            "content_change_in_clip": content_change,
            "motion_preset": m.get("preset_guess"), "motion_inlier": m.get("median_inlier"),
            "on_screen_text": [o["text"] for o in ocr][:12], "corner_text": [o["text"] for o in corner],
            "phash": str(ph),
        }
    # group cuts that reuse the same source image/footage
    ids = list(hashes)
    group, gid = {}, 0
    for i, ci in enumerate(ids):
        if ci in group:
            continue
        gid += 1
        group[ci] = gid
        for cj in ids[i + 1:]:
            if cj not in group and hashes[ci] - hashes[cj] <= a.hash_dist:
                group[cj] = gid
    for cid, g in group.items():
        members = [k for k, v in group.items() if v == g]
        out[cid]["same_source_group"] = f"g{g:03d}" if len(members) > 1 else None
    sp = cpath.parent / "source_signals.json"
    if (a.ids or a.range) and sp.exists():
        prev = read_json(sp).get("cuts", {})
        valid = {c["id"] for c in doc["cuts"]}
        prev = {k: v for k, v in prev.items() if k in valid}
        prev.update(out)
        out = prev
    write_json(sp, {"video": doc["video"]["path"], "cuts": out})
    print(f"signals for {len(out)} cuts -> {cpath.parent / 'source_signals.json'}; frames in {src_dir}")


if __name__ == "__main__":
    main()
