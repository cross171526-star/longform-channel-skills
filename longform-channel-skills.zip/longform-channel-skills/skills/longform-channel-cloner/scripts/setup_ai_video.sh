#!/usr/bin/env bash
# One-time setup for local AI video generation (LTX-2.3 q8 via ltx-2-mlx, Apple Silicon, >= 24 GB RAM).
# Downloads ~58 GB of weights (resumable). Safe to re-run.
set -euo pipefail
LFC_HOME="${LFC_HOME:-$HOME/.longform-cloner}"
PY="$(command -v python3.12 || command -v python3.13 || echo "$HOME/.local/bin/python3.12")"
cd "$LFC_HOME"
[ -d ltx-2-mlx ] || git clone -q --depth 1 https://github.com/dgrauet/ltx-2-mlx.git
[ -x ltx-venv/bin/python ] || "$PY" -m venv ltx-venv
ltx-venv/bin/python -m pip install -q --upgrade pip
ltx-venv/bin/python -m pip install -q -e ltx-2-mlx/packages/ltx-core-mlx -e ltx-2-mlx/packages/ltx-pipelines-mlx
M="$LFC_HOME/models"
dl() {
  local url="https://huggingface.co/$1/resolve/main/$2" out="$3/$2"
  mkdir -p "$(dirname "$out")"
  for k in 1 2 3 4 5 6 7 8; do
    curl -fL --retry 5 --retry-delay 3 -C - -s -o "$out" "$url" && { echo "ok $2"; return 0; }
    echo "retry $k $2"; sleep 5
  done
  echo "FAIL $2"; return 1
}
for f in LICENSE README.md config.json embedded_config.json quantize_config.json split_model.json \
         spatial_upscaler_x2_v1_1_config.json audio_vae.safetensors vocoder.safetensors vae_encoder.safetensors \
         vae_decoder.safetensors spatial_upscaler_x2_v1_1.safetensors connector.safetensors \
         ltx-2.3-22b-distilled-lora-384.safetensors transformer-distilled.safetensors transformer-dev.safetensors; do
  dl dgrauet/ltx-2.3-mlx-q8 "$f" "$M/ltx-2.3-mlx-q8"
done
G=mlx-community/gemma-3-12b-it-4bit
for f in $(curl -s "https://huggingface.co/api/models/$G/tree/main" | python3 -c "import json,sys;[print(x['path']) for x in json.load(sys.stdin) if x.get('type')=='file']"); do
  dl "$G" "$f" "$M/gemma-3-12b-it-4bit"
done
echo "AI video ready: $M"
