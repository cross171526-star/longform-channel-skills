"""네트워크·ASR 실행 없이 로컬 전사 집계와 원자적 출력 보존을 검증한다."""

import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from speech_rate import speech_rate, write_rate


SCRIPT = Path(__file__).with_name("speech_rate.py")


def word(text="말", start=1, end=2, **extra):
    return {"w": text, "start": start, "end": end, **extra}


class SpeechRateTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.addCleanup(self.folder.cleanup)
        self.input_path = Path(self.folder.name) / "transcript.json"
        self.output_path = Path(self.folder.name) / "rate.json"

    def run_cli(self, document=None, raw=None):
        if raw is None:
            raw = json.dumps(document, ensure_ascii=False).encode("utf-8")
        self.input_path.write_bytes(raw)
        return subprocess.run(
            [sys.executable, "-B", str(SCRIPT), str(self.input_path),
             "--out", str(self.output_path)],
            capture_output=True, text=True, check=False,
        )

    def successful_rate(self, document=None, raw=None):
        result = self.run_cli(document, raw)
        self.assertEqual(result.returncode, 0, result.stderr)
        rate = json.loads(self.output_path.read_text(encoding="utf-8"))
        self.assertIs(rate["estimated"], True)
        self.assertEqual(rate["method"], "local_asr_word_timestamps")
        self.assertEqual(rate["source_input_sha256"],
                         hashlib.sha256(self.input_path.read_bytes()).hexdigest())
        self.assertIn("tokenizer-dependent", rate["word_token_count_note"])
        expected_keys = {
            "char_count", "word_token_count", "word_token_count_note", "speech_span_s",
            "speech_active_s", "chars_per_s_span", "chars_per_s_active", "estimated",
            "method", "source_input_sha256",
        }
        if "language" in json.loads(self.input_path.read_bytes()):
            expected_keys.add("language")
        self.assertEqual(set(rate), expected_keys)
        return rate

    def test_existing_schema_uses_words_only_and_seconds(self):
        rate = self.successful_rate({
            "language": "ko", "media": "unused.wav", "model": "unused",
            "words": [word("안녕", 10, 11, p=0.9, seg=0),
                      word("세상!", 13, 14, p=0.1, seg=1)],
            "segments": [{"text": "계산에 포함하면 안 되는 텍스트", "start": 0, "end": 999}],
            "rate": {"chars_per_s_speech": 999},
            "pauses": [{"dur": 999}], "range": [0, 999],
            "bgm": "unused", "sfx": "unused", "voice": "unused",
        })
        self.assertEqual(rate["language"], "ko")
        self.assertEqual(rate["char_count"], 5)
        self.assertEqual(rate["word_token_count"], 2)
        self.assertEqual(rate["speech_span_s"], 4)
        self.assertEqual(rate["speech_active_s"], 2)
        self.assertEqual(rate["chars_per_s_span"], 1.25)
        self.assertEqual(rate["chars_per_s_active"], 2.5)

    def test_union_overlapping_nested_touching_and_unordered_intervals(self):
        rate = self.successful_rate({"words": [
            word("a", 8, 9), word("b", 2, 5), word("c", 1, 4),
            word("d", 2.5, 3), word("e", 5, 6), word("f", 3, 3),
        ]})
        self.assertEqual(rate["char_count"], 6)
        self.assertEqual(rate["word_token_count"], 6)
        self.assertEqual(rate["speech_span_s"], 8)
        self.assertEqual(rate["speech_active_s"], 6)
        self.assertEqual(rate["chars_per_s_span"], 0.75)
        self.assertEqual(rate["chars_per_s_active"], 1)

    def test_nested_last_word_does_not_shorten_span(self):
        rate = self.successful_rate({"words": [word("a", 1, 10), word("b", 2, 3)]})
        self.assertEqual(rate["speech_span_s"], 9)
        self.assertEqual(rate["speech_active_s"], 9)

    def test_unicode_whitespace_and_code_points(self):
        rate = self.successful_rate({"words": [
            word(" 한\t글\n\u00a0世\u3000界🙂 ", 0, 0.5),
            word("e\u0301", 1, 1.5),
        ]})
        self.assertEqual(rate["char_count"], 7)
        self.assertEqual(rate["word_token_count"], 2)
        self.assertEqual(rate["speech_active_s"], 1)
        self.assertEqual(rate["speech_span_s"], 1.5)
        self.assertEqual(rate["chars_per_s_active"], 7)
        self.assertEqual(rate["chars_per_s_span"], 7 / 1.5)

    def test_optional_language_and_probability(self):
        for language in ("en", "ko", None):
            with self.subTest(language=language):
                rate = self.successful_rate({"language": language, "words": [word(p=None)]})
                self.assertEqual(rate["language"], language)
        rate = self.successful_rate({"words": [word()]})
        self.assertNotIn("language", rate)

    def test_zero_length_intervals_have_undefined_active_rate(self):
        rate = self.successful_rate({"words": [word("ab", 0, 0), word("c", 2, 2)]})
        self.assertEqual(rate["char_count"], 3)
        self.assertEqual(rate["word_token_count"], 2)
        self.assertEqual(rate["speech_span_s"], 2)
        self.assertEqual(rate["speech_active_s"], 0)
        self.assertEqual(rate["chars_per_s_span"], 1.5)
        self.assertIsNone(rate["chars_per_s_active"])
        rate = self.successful_rate({"words": [word("abc", 0, 0)]})
        self.assertEqual(rate["speech_span_s"], 0)
        self.assertIsNone(rate["chars_per_s_span"])
        self.assertIsNone(rate["chars_per_s_active"])

    def test_empty_words_are_zero_with_null_rates(self):
        rate = self.successful_rate({"words": [], "language": "ko"})
        for key in ("char_count", "word_token_count", "speech_span_s", "speech_active_s"):
            self.assertEqual(rate[key], 0)
        self.assertIsNone(rate["chars_per_s_span"])
        self.assertIsNone(rate["chars_per_s_active"])

    def assert_invalid(self, document=None, raw=None):
        for existing in (False, True):
            with self.subTest(existing_output=existing):
                if existing:
                    self.output_path.write_bytes(b"previous output\x00")
                else:
                    self.output_path.unlink(missing_ok=True)
                result = self.run_cli(document, raw)
                self.assertEqual(result.returncode, 1, result.stderr)
                self.assertTrue(result.stderr)
                if existing:
                    self.assertEqual(self.output_path.read_bytes(), b"previous output\x00")
                else:
                    self.assertFalse(self.output_path.exists())
                self.assertEqual(list(self.output_path.parent.glob(".rate.json.*.tmp")), [])

    def test_invalid_structure_and_words(self):
        for document in (None, [], {}, {"words": None}, {"words": {}},
                         {"words": "word"}, {"words": [None]}, {"words": [[]]}):
            with self.subTest(document=document):
                self.assert_invalid(document)
        for text in (None, "", " \t\u3000", 123, True, [], {}):
            with self.subTest(text=text):
                self.assert_invalid({"words": [word(text)]})
        self.assert_invalid({"words": [{"start": 1, "end": 2}]})

    def test_missing_timestamps_do_not_fall_back_to_segments(self):
        for field in ("start", "end"):
            with self.subTest(field=field):
                entry = word()
                del entry[field]
                self.assert_invalid({"words": [entry],
                                     "segments": [{"text": "말", "start": 1, "end": 2}]})

    def test_invalid_timestamps_and_reversed_intervals(self):
        for field in ("start", "end"):
            for value in (None, True, False, "1.0", [], {}, -1,
                          float("nan"), float("inf"), float("-inf"), 10 ** 400):
                with self.subTest(field=field, value=value):
                    entry = word()
                    entry[field] = value
                    self.assert_invalid({"words": [entry]})
        self.assert_invalid({"words": [word(start=3, end=2)]})

    def test_invalid_language(self):
        for language in ("", " \t", 1, True, [], {}):
            with self.subTest(language=language):
                self.assert_invalid({"words": [], "language": language})

    def test_unrepresentable_rate_is_rejected(self):
        with self.assertRaises(ValueError):
            speech_rate({"words": [word("a", 0, 5e-324)]}, "sha")

    def test_malformed_empty_and_non_utf8_source(self):
        for raw in (b"", b"{", b"not JSON", b"\xff"):
            with self.subTest(raw=raw):
                self.assert_invalid(raw=raw)

    def test_hash_tracks_exact_source_bytes(self):
        document = {"language": "ko", "words": [word("한글")]}
        raw = json.dumps(document, ensure_ascii=False, indent=4).encode("utf-8") + b"\n"
        first = self.successful_rate(raw=raw)
        second = self.successful_rate(raw=raw + b" \n")
        self.assertEqual(first["source_input_sha256"], hashlib.sha256(raw).hexdigest())
        self.assertEqual(second["source_input_sha256"], hashlib.sha256(raw + b" \n").hexdigest())
        self.assertNotEqual(first["source_input_sha256"], second["source_input_sha256"])
        self.assertEqual(first["chars_per_s_span"], second["chars_per_s_span"])

    def test_missing_source_preserves_output(self):
        self.output_path.write_bytes(b"previous output")
        result = subprocess.run(
            [sys.executable, "-B", str(SCRIPT), str(self.input_path),
             "--out", str(self.output_path)], capture_output=True, text=True,
        )
        self.assertEqual(result.returncode, 1)
        self.assertEqual(self.output_path.read_bytes(), b"previous output")

    def test_cannot_overwrite_input_or_its_alias(self):
        self.output_path = self.input_path
        raw = b'{"words": []}'
        result = self.run_cli(raw=raw)
        self.assertEqual(result.returncode, 1)
        self.assertEqual(self.input_path.read_bytes(), raw)
        self.output_path = Path(self.folder.name) / "alias.json"
        self.output_path.hardlink_to(self.input_path)
        result = self.run_cli(raw=raw)
        self.assertEqual(result.returncode, 1)
        self.assertEqual(self.input_path.read_bytes(), raw)

    def test_creates_parent_and_replaces_existing_output(self):
        self.output_path = Path(self.folder.name) / "new" / "nested" / "rate.json"
        self.successful_rate({"words": []})
        self.output_path.write_bytes(b"previous output")
        rate = self.successful_rate({"words": [word()]})
        self.assertEqual(rate["char_count"], 1)
        self.assertEqual(list(self.output_path.parent.iterdir()), [self.output_path])

    def test_write_and_replace_failure_preserve_output_and_clean_temp(self):
        for operation in ("os.fsync", "os.replace"):
            with self.subTest(operation=operation):
                self.output_path.write_bytes(b"previous output")
                with patch(f"speech_rate.{operation}", side_effect=OSError("쓰기 실패")):
                    with self.assertRaises(OSError):
                        write_rate(self.output_path, {"char_count": 1})
                self.assertEqual(self.output_path.read_bytes(), b"previous output")
                self.assertEqual(list(Path(self.folder.name).iterdir()), [self.output_path])

    def test_serialization_failure_preserves_output(self):
        self.output_path.write_bytes(b"previous output")
        with self.assertRaises(ValueError):
            write_rate(self.output_path, {"chars_per_s_span": float("nan")})
        self.assertEqual(self.output_path.read_bytes(), b"previous output")
        self.assertEqual(list(Path(self.folder.name).iterdir()), [self.output_path])


if __name__ == "__main__":
    unittest.main()
