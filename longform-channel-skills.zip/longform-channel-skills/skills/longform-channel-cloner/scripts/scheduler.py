"""작업 소유권·실제 세션·완료 기록. 동시 작업 수와 대기 순서를 관리하지 않는다."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time


def modern_run(root):
    p=Path(root)/'run.json'
    return p.is_file() and json.loads(p.read_text()).get('scheduler_version',1)>=2


def provenance(path):
    """로그 본문·인증정보는 복사하지 않고 실제 최신 턴 설정만 반환한다."""
    session=None;turn=None;last=None
    with Path(path).open() as f:
        for line in f:
            try:e=json.loads(line)
            except json.JSONDecodeError:continue
            if e.get('type')=='session_meta':session=e.get('payload',{}).get('id')
            if e.get('type')=='turn_context':
                turn=e.get('payload',{});last=None
            if e.get('type')=='event_msg':last=e.get('payload',{}).get('type')
    if not session or not turn:raise ValueError('Actual rollout session/turn_context unavailable')
    if turn.get('model')!='gpt-6.1-sol' or turn.get('effort',turn.get('reasoning_effort'))!='high':
        raise ValueError('Actual active turn must be gpt-6.1-sol/high; app settings were not changed')
    return {'session':session,'model':turn['model'],'effort':'high','last_event':last}


def process_identity(pid):
    try:
        r=subprocess.run(['ps','-p',str(pid),'-o','lstart='],capture_output=True,text=True,timeout=5)
        return r.stdout.strip() if r.returncode==0 else None
    except (OSError,subprocess.SubprocessError):return None


def emit(db,root,lease,kind,payload):
    db.execute('INSERT INTO events(run,lease,kind,at,payload) VALUES (?,?,?,?,?)',(root,lease,kind,time.time(),json.dumps(payload,ensure_ascii=False)))


def register_owner(db,lease,actual,rollout):
    # Historical column layout stays compatible; no acceptance/liveness timer is required.
    db.execute('INSERT INTO owners VALUES (?,?,?,?,?,?,?,?)',
               (lease,str(Path(rollout).resolve()) if rollout else None,(actual or {}).get('session'),None,None,None,None,None))


def verify_owner(db,lease,rollout):
    owner=db.execute('SELECT * FROM owners WHERE lease=?',(lease,)).fetchone()
    if not owner or not owner['session']:return
    actual=provenance(rollout)
    if actual['session']!=owner['session']:raise ValueError('Wrong actual task owner session')
    if actual['last_event'] in ('turn_aborted','task_complete'):raise ValueError('Inactive task owner')


def diagnose(db,job):
    owner=db.execute('SELECT * FROM owners WHERE lease=?',(job['lease'],)).fetchone()
    result={'lease':job['lease'],'state':job['state'],'classification':'unknown_owner','safe_to_recover':False}
    if not owner:return result
    owner=dict(owner);result.update({'owner_session':owner['session']})
    if owner['pid'] and process_identity(owner['pid'])==owner['pid_identity']:
        result['classification']='live_process';return result
    if not owner['rollout']:return result
    try:actual=provenance(owner['rollout'])
    except (OSError,ValueError):return result
    if actual['session']!=owner['session']:return result
    if actual['last_event']=='turn_aborted':
        result['classification']='aborted_owner';result['safe_to_recover']=True
    else:result['classification']='unconfirmed_or_live_owner'
    # Recovery evidence binds the actual task, owner and current rollout bytes.
    result['evidence_token']=hashlib.sha256(json.dumps([job,owner,hashlib.sha256(Path(owner['rollout']).read_bytes()).hexdigest()],sort_keys=True).encode()).hexdigest()
    return result


def dispatch(root,action,**kw):
    from work_guard import connection,_job,usage_summary
    with connection() as db:
        now=time.time()
        if action in ('enqueue','cancel'):
            # Accepted only for older callers. No request table, scheduling or polling.
            return {'decision':'ready' if action=='enqueue' else 'cancelled',
                    'deprecated_action':action,'scheduling_required':False}
        if action=='events':
            cursor=0
            if kw.get('validation'):cursor=json.loads(Path(kw['validation']).read_text()).get('after_event',0)
            rows=[dict(r) for r in db.execute('SELECT * FROM events WHERE id>? ORDER BY id LIMIT 100',(cursor,))]
            for r in rows:r['payload']=json.loads(r['payload'])
            return {'events':rows,'cursor':rows[-1]['id'] if rows else cursor,'automatic_chat_wakeup':False}
        if action=='metrics':
            jobs=[dict(r) for r in db.execute('SELECT * FROM jobs WHERE run=?',(root,))]
            return {'measurement':'lease wall time, not pure inference or waste','tasks':[
              {'lease':j['lease'],'stage':j['stage'],'pool':j['pool'],'state':j['state'],
               'lease_s':(j['ended'] or now)-j['started'],'usage':usage_summary(db,j['lease'])} for j in jobs],
               'events':[dict(r) for r in db.execute('SELECT id,lease,kind,at,payload FROM events WHERE run=? ORDER BY id',(root,))],
               'unmeasured':['pure inference time','total idle time','first independent content pass unless recorded','account cost'],
               'automatic_chat_wakeup':False}
        job=_job(db,root,kw.get('lease'))
        if action=='diagnose':return diagnose(db,job)
        if job['state']!='running':raise ValueError('Lease no longer running')
        if action=='recover':
            proof=json.loads(Path(kw['validation']).read_text()) if kw.get('validation') else {}
            actual=diagnose(db,job)
            if not kw.get('note') or not actual['safe_to_recover'] or proof.get('evidence_token')!=actual.get('evidence_token'):
                raise ValueError('Recovery needs current confirmed aborted-owner evidence and outcome note; never timeout alone')
            db.execute("UPDATE jobs SET state='failed',ended=?,error=? WHERE lease=?",(now,kw['note'],job['lease']))
            emit(db,root,job['lease'],'recovered_orphan',{'note':kw['note']})
            return {'decision':'recovered','processes_terminated':False,'outputs_preserved':True}
        # Compatibility acknowledgements never update timers or influence execution.
        if kw.get('worker_rollout'):verify_owner(db,job['lease'],kw['worker_rollout'])
        return {'decision':'active','lease':job['lease'],'deprecated_action':action,'scheduling_required':False}
