#!/usr/bin/env python3
"""Structural gate; perceptual judgments require an independent review.

TTS declarations and recorded placement are checked, not arbitrary render code's
audio processing. End-to-end render speed still needs an independent audit.
"""
import argparse
import copy
import hashlib
import json
import math
import os
import tempfile
import shutil
import subprocess
from pathlib import Path
from work_guard import FileSnapshot, validate_output_paths
from timing_contract import reference_background
from production_gate_links import (WINDOW_KEYS, validate_windows, validate_duration,
                                   validate_scope, validate_acceptance, validate_measurements,
                                   build_expected_timeline, output_clip, full_narration_segments)


def digest(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def canonical(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                     allow_nan=False).encode()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


class VerificationContext:
    """One content-bound verification transaction; no persistent PASS cache."""
    def __init__(self):
        self.snapshot = FileSnapshot(hasher=digest, reader=read)
        self.reports, self.active = {}, set()
        self.closed = False

    def document(self, path):
        if self.closed: raise ValueError('Verification transaction is closed')
        return self.snapshot.document(path)

    def digest(self, path):
        if self.closed: raise ValueError('Verification transaction is closed')
        return self.snapshot.add(path)[1]

    def key(self, path, stage, probe):
        from check_render_timing import TEMPLATE, renderer_dependencies
        self.snapshot.add(path)  # Retain the lexical alias as well as its target.
        # Bind imported checker code, tool binaries and renderer inventory, not
        # just a prior passed flag. Each new transaction reads current content.
        tools = sorted(Path(__file__).parent.glob('*.py'))
        tools += renderer_dependencies()
        for name in ('node', 'ffprobe'):
            binary = shutil.which(name)
            if binary: tools.append(Path(binary))
        version = canonical([(str(p.resolve()), self.digest(p)) for p in tools])
        run = os.environ.get('LFC_RUN_DIR')
        if run and (Path(run)/'run.json').is_file(): self.digest(Path(run)/'run.json')
        return (str(Path(path).resolve()), stage, id(probe), version,
                str(TEMPLATE.resolve()), run)

    def close(self):
        if not self.closed:
            self.snapshot.unchanged(verify_content=True)
            self.closed = True


def check(manifest_path, stage, probe=None, context=None):
    if stage not in ('plan', 'assets', 'final'): raise ValueError('Invalid production gate stage')
    owner = context is None
    context = context or VerificationContext()
    try:
        key = context.key(manifest_path, stage, probe)
        context.snapshot.unchanged()
        if key in context.active: raise ValueError('Cyclic production full_plan reference')
        if probe is None and key in context.reports:
            return copy.deepcopy(context.reports[key])
        context.active.add(key)
        try: report = _check(manifest_path, stage, probe, context)
        finally: context.active.remove(key)
        if report['passed'] and probe is None: context.reports[key] = copy.deepcopy(report)
        return report
    finally:
        if owner: context.close()


def check_many(requests, probe=None):
    """Official batch API: same rules, shared current inputs, atomic boundary."""
    context = VerificationContext()
    try: return [check(path, stage, probe, context) for path, stage in requests]
    finally: context.close()


def _check(manifest_path, stage, probe, context):
    read, digest = context.document, context.digest
    path = Path(manifest_path).resolve()
    root = path.parent
    m = read(path)
    errors, files = [], {}
    # Cheap structural/path failures precede thousands of evidence pointers.
    inventory_names = m.get('render_inputs')
    if not isinstance(inventory_names, list) or not all(isinstance(n, str) for n in inventory_names):
        raise ValueError('Invalid render input inventory')
    inventory_early = {(root / n).resolve() for n in inventory_names}
    compiled_early = (root / m['compiled_timeline']).resolve() if isinstance(m.get('compiled_timeline'), str) else None
    assets_early = {(root / a['path']).resolve() for c in m.get('cuts', []) for a in c.get('assets', [])}
    optional_early = set(assets_early)
    if stage == 'plan':
        optional_early.update((root / m['tts'][k]).resolve() for k in ('narration_metadata', 'timeline')
                              if isinstance(m.get('tts', {}).get(k), str))
        optional_early.add(compiled_early)
    for required in inventory_early - optional_early:
        if not required.is_file():
            errors.append('Missing compiled_timeline output' if required == compiled_early
                          else 'Missing file: ' + str(required))
    if stage in ('assets', 'final'):
        from check_render_timing import renderer_dependencies
        config = m.get('render_timing')
        if not isinstance(config, dict) or config.get('kind') != 'remotion-template':
            errors.append('Missing/unsupported render_timing.kind; a real renderer adapter is required')
        elif not isinstance(config.get('props'), str) or not config['props']:
            errors.append('Missing render_timing.props')
        else:
            for required in [(root / config['props']).resolve(), *renderer_dependencies()]:
                if required not in inventory_early:
                    errors.append('Render timing dependency missing from render_inputs: ' + str(required))
                elif not required.is_file(): errors.append('Missing file: ' + str(required))
    if errors:
        return {'stage': stage, 'passed': False, 'errors': errors,
                'output_scope': m.get('output_scope', {'kind': 'full'})}
    from scheduler import modern_run
    new_run=bool(os.environ.get('LFC_RUN_DIR')) and modern_run(os.environ['LFC_RUN_DIR'])
    capability_preflight=None
    if new_run:
        preflight=Path(os.environ['LFC_RUN_DIR'])/'work/preflight-report.json'
        if preflight.is_file():capability_preflight=read(preflight)
        else:errors.append('Missing current production capability preflight')
    observed_analysis_sessions = set()
    compiled_name = m.get('compiled_timeline')
    compiled_path = (root / compiled_name).resolve() if isinstance(compiled_name, str) and compiled_name.strip() else None
    windows, duration_link, output_bounds, acceptance_rules = {}, {}, None, []
    timeline_document = None
    visible_ids, invisible_asset_paths = set(), set()
    full_segments = {}
    cache_base = Path(os.environ.get('LFC_RUN_DIR', str(root))) / 'cache' / 'probe'
    cache_path = cache_base / (hashlib.sha256(str(path).encode()).hexdigest()+'.json')
    cache_base.mkdir(parents=True,exist_ok=True)
    try:
        # This generated probe cache is rewritten by this check; it is not a
        # source dependency. Media keys still bind actual content and ffprobe.
        cache = globals()['read'](cache_path) if probe is None and cache_path.exists() else {}
        if not isinstance(cache,dict):cache={}
    except (OSError,ValueError):cache={}
    binary = shutil.which('ffprobe') or str(Path.home() / '.longform-cloner/bin/ffprobe')
    tool_signature = digest(binary) if Path(binary).is_file() else binary

    def require(condition, message):
        if not condition:
            errors.append(message)

    def file(name):
        lexical = root / name
        p = lexical.resolve()
        if p == compiled_path:
            raise ValueError('compiled_timeline cannot also be a source input')
        if not p.is_file():
            raise ValueError('Missing file: ' + str(p))
        files[str(p)] = digest(lexical)
        return p

    def evidence(ref):
        data = read(file(ref['file']))
        provenance = data.get('analysis_provenance', {}) if isinstance(data, dict) else {}
        if provenance.get('session_id'):
            observed_analysis_sessions.add(provenance['session_id'])
        # JSON Pointer (RFC 6901), including array indices.
        pointer = ref['pointer']
        require(isinstance(pointer, str) and pointer.startswith('/'), 'Evidence needs a non-root JSON Pointer')
        for token in pointer.split('/')[1:]:
            token = token.replace('~1', '/').replace('~0', '~')
            data = data[int(token)] if isinstance(data, list) else data[token]
        require(data is not None and data != '' and data != [] and data != {}, 'Empty evidence: ' + pointer)

    def media(p):
        key = canonical({"content":files[str(p)],"tool":tool_signature,"schema":"ffprobe-streams-format-v1"})
        if key not in cache:
            if probe:
                cache[key] = probe(p)
            else:
                binary = shutil.which('ffprobe') or str(Path.home() / '.longform-cloner/bin/ffprobe')
                result = subprocess.run([binary, '-v', 'error', '-show_streams', '-show_format',
                                         '-of', 'json', str(p)], check=True, capture_output=True, text=True)
                cache[key] = json.loads(result.stdout)
        return cache[key]

    def positive(value):
        return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) and value > 0

    def finite(value):
        return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)

    def exact(value, expected):
        return finite(value) and value == expected

    def narration_gate(tts):
        nonlocal timeline_document
        # Speeds are exact policy values; only timestamp comparisons allow 10 ms.
        tolerance = .01 + 1e-9
        inventory = {(root / name).resolve() for name in m['render_inputs']}

        def document(key):
            name = tts.get(key)
            if not isinstance(name, str) or not name.strip():
                require(False, 'Missing tts.' + key)
                return None
            p = (root / name).resolve()
            require(p in inventory, 'tts.' + key + ' missing from render_inputs')
            if key == 'narration_metadata':
                require(p.name == 'narration.json', 'tts.narration_metadata must point to narration.json')
            try:
                data = read(file(name))
            except (OSError, ValueError) as exc:
                require(False, 'Invalid tts.' + key + ': ' + str(exc))
                return None
            if not isinstance(data, dict):
                require(False, 'tts.' + key + ' must contain a JSON object')
                return None
            return data

        def interval(record, start_key, end_key, label):
            start, end = record.get(start_key), record.get(end_key)
            valid = finite(start) and finite(end) and start >= 0 and end > start
            require(valid, label + ': invalid ' + start_key + '/' + end_key + ' interval')
            return (start, end) if valid else None

        def identifier(value):
            return isinstance(value, str) and bool(value.strip())

        def no_overlap(intervals, label):
            intervals.sort()
            furthest_end = 0
            for start, end in intervals:
                require(start >= furthest_end - tolerance, label + ': overlapping intervals')
                furthest_end = max(furthest_end, end)

        metadata = document('narration_metadata')
        timeline = document('timeline')
        timeline_document = timeline
        placed, placement_intervals = {}, []
        line_ids = []
        if metadata is not None:
            require(metadata.get('provider') == tts['provider'], 'Narration provider mismatch')
            require(metadata.get('voice') == tts['voice_id'], 'Narration voice mismatch')
            require(metadata.get('fit') is False, 'Narration fit must be false')
            require(exact(metadata.get('uniform_speed'), 1.2), 'Narration uniform_speed must be 1.2')
            require(metadata.get('speed_method') == 'provider', 'Narration speed_method must be provider')
            lines = metadata.get('lines')
            if not isinstance(lines, list) or not lines:
                require(False, 'Narration needs non-empty lines')
                lines = []
            for line in lines:
                if not isinstance(line, dict):
                    require(False, 'Narration line must be an object')
                    continue
                line_id = line.get('id')
                valid_id = identifier(line_id)
                require(valid_id, 'Narration line needs a non-empty string ID')
                label = 'Narration line ' + str(line_id)
                require(exact(line.get('provider_tempo'), 1.2), label + ': provider_tempo must be 1.2')
                require(exact(line.get('atempo'), 1.0), label + ': atempo must be 1.0')
                timing = interval(line, 'placed_start_s', 'placed_end_s', label)
                if timing:
                    placement_intervals.append(timing)
                if valid_id:
                    line_ids.append(line_id)
                    placed[line_id] = timing
            require(len(line_ids) == len(set(line_ids)), 'Duplicate narration line IDs')
            no_overlap(placement_intervals, 'Narration')

        # Derive absolute cut intervals from the manifest, never from declarations
        # in the timeline. Merge adjoining referenced cuts to allow cross-cut lines.
        cut_bounds, cursor = {}, 0
        for cut in m['cuts']:
            if not positive(cut['duration_s']):
                return  # Already rejected by the cut gate.
            cut_bounds[cut['id']] = (cursor, cursor + cut['duration_s'])
            cursor += cut['duration_s']
        segment_ids, segment_intervals = [], []
        if timeline is not None:
            segments = timeline.get('segments')
            if not isinstance(segments, list) or not segments:
                require(False, 'Timeline needs non-empty segments')
                segments = []
            for segment in segments:
                if not isinstance(segment, dict):
                    require(False, 'Timeline segment must be an object')
                    continue
                line_id = segment.get('line_id')
                valid_id = identifier(line_id)
                require(valid_id, 'Timeline segment needs a non-empty string line_id')
                label = 'Timeline line ' + str(line_id)
                if valid_id and line_id in windows:
                    declared = {k: segment.get(k) for k in WINDOW_KEYS}
                    same_window = linked_gate(lambda: canonical(declared) == canonical({k: windows[line_id][k] for k in WINDOW_KEYS}))
                    require(same_window is True,
                            label + ': window differs from baseline.narration_windows')
                else:
                    require(False, label + ': unknown baseline narration window')
                if valid_id:
                    segment_ids.append(line_id)
                    require(line_id in placed, label + ': unknown narration line')
                require(exact(segment.get('playback_rate'), 1.0), label + ': playback_rate must be 1.0')
                allowed = interval(segment, 'allowed_start_s', 'allowed_end_s', label)
                timing = interval(segment, 'start_s', 'end_s', label)
                if valid_id and full_segments.get(line_id):
                    original = full_segments[line_id]
                    require(all(finite(segment.get(k)) and segment[k] == original[k] for k in ('start_s', 'end_s')),
                            label + ': placement differs from full_plan (arbitrary shortening)')
                if timing:
                    segment_intervals.append(timing)
                    scope = m.get('output_scope', {'kind': 'full'})
                    clip = segment.get('output_clip')
                    if scope.get('kind') == 'preview' and output_bounds:
                        intersection = output_clip(*timing, output_bounds)
                        crossing = (timing[0] < output_bounds['end_s'] < timing[1])
                        if crossing:
                            require(clip is not None and canonical(clip) == canonical(intersection),
                                    label + ': boundary output_clip must equal output intersection')
                        else:
                            require('output_clip' not in segment,
                                    label + ': output_clip only allowed for boundary crossing narration')
                    else:
                        require('output_clip' not in segment, label + ': output_clip only allowed in preview')
                if timing and allowed:
                    require(timing[0] >= allowed[0] - tolerance and timing[1] <= allowed[1] + tolerance,
                            label + ': placement outside allowed window')
                if valid_id and timing and placed.get(line_id):
                    require(all(abs(a - b) <= tolerance for a, b in zip(timing, placed[line_id])),
                            label + ': timing differs from narration placement')
                placement = placed.get(line_id) if valid_id else None
                if placement and allowed:
                    require(placement[0] >= allowed[0] - tolerance and placement[1] <= allowed[1] + tolerance,
                            label + ': narration placement outside allowed window')
                cut_ids = segment.get('cut_ids')
                valid_cuts = isinstance(cut_ids, list) and bool(cut_ids) and all(identifier(c) for c in cut_ids)
                require(valid_cuts, label + ': cut_ids must be a non-empty string list')
                if valid_cuts:
                    require(len(cut_ids) == len(set(cut_ids)), label + ': duplicate cut IDs')
                    known = all(c in cut_bounds for c in cut_ids)
                    require(known, label + ': unknown cut ID')
                    if known and allowed:
                        spans = []
                        for start, end in sorted(cut_bounds[c] for c in set(cut_ids)):
                            if spans and start <= spans[-1][1]:
                                spans[-1] = (spans[-1][0], max(spans[-1][1], end))
                            else:
                                spans.append((start, end))
                        require(any(allowed[0] >= start - tolerance and allowed[1] <= end + tolerance
                                    for start, end in spans), label + ': allowed window outside referenced cuts')
                        if timing:
                            require(any(timing[0] >= start - tolerance and timing[1] <= end + tolerance
                                        for start, end in spans), label + ': placement outside referenced cuts')
                        if placement:
                            require(any(placement[0] >= start - tolerance and placement[1] <= end + tolerance
                                        for start, end in spans), label + ': narration placement outside referenced cuts')
            require(sorted(segment_ids) == sorted(line_ids), 'Timeline must cover each narration line exactly once')
            visible_windows = {key for key, window in windows.items() if not preview or not output_bounds
                               or (full_segments.get(key, window).get('start_s', window['allowed_start_s']) < output_bounds['end_s'])}
            require(sorted(segment_ids) == sorted(visible_windows), 'Timeline must cover each visible baseline narration window exactly once')
            require(len(segment_ids) == len(set(segment_ids)), 'Duplicate timeline line IDs')
            no_overlap(segment_intervals, 'Timeline')

    baseline = read(file(m['baseline']))
    implementation_sessions = set()
    implementation_ref = baseline.get('implementation_provenance')
    if implementation_ref:
        implementation = read(file(implementation_ref))
        implementation_sessions.update(implementation.get('session_ids', []))
    def linked_gate(operation):
        try:
            return operation()
        except (OSError, ValueError, KeyError, TypeError, IndexError, OverflowError,
                subprocess.SubprocessError) as exc:
            require(False, str(exc))
            return None

    def load(name):
        return read(file(name))

    def file_hash(name):
        return digest(file(name))

    require(compiled_path is not None, 'Missing compiled_timeline')
    require(compiled_path != path, 'compiled_timeline cannot overwrite source manifest')
    inventory = {(root / name).resolve() for name in m['render_inputs']}
    require(compiled_path in inventory, 'compiled_timeline missing from render_inputs')
    windows = linked_gate(lambda: validate_windows(baseline, m)) or {}
    duration_link = linked_gate(lambda: validate_duration(m, load, file_hash, baseline)) or {}
    if duration_link:
        for error in duration_link['preflight']['errors']:
            require(False, error)
        output_bounds = linked_gate(lambda: validate_scope(m, root, duration_link, load))
        if output_bounds and m.get('output_scope', {}).get('kind') == 'preview':
            full_path = (root / m['output_scope']['full_plan']).resolve()
            full_report = linked_gate(lambda: check(full_path, 'plan', probe, context))
            require(bool(full_report and full_report['passed']), 'Preview full_plan did not pass plan gate')
            full_segments = linked_gate(lambda: full_narration_segments(m, root, windows, load)) or {}
    acceptance_name = m.get('visual_acceptance')
    require(isinstance(acceptance_name, str) and bool(acceptance_name.strip()), 'Missing visual_acceptance')
    acceptance_path = (root / acceptance_name).resolve() if isinstance(acceptance_name, str) else None
    require(acceptance_path in inventory, 'visual_acceptance missing from render_inputs')
    if acceptance_path:
        acceptance = linked_gate(lambda: load(acceptance_name))
        if acceptance is not None:
            acceptance_rules = linked_gate(lambda: validate_acceptance(baseline, acceptance, evidence)) or []
    cursor = 0
    preview = m.get('output_scope', {}).get('kind') == 'preview'
    for cut in m['cuts']:
        d = cut.get('duration_s')
        if not finite(d) or d <= 0:
            continue
        visible = not preview or not output_bounds or output_clip(cursor, cursor + d, output_bounds) is not None
        if visible:
            visible_ids.add(cut['id'])
        else:
            invisible_asset_paths.update((root / a['path']).resolve() for a in cut.get('assets', []))
        cursor += d
    visible_asset_paths = {(root / a['path']).resolve() for cut in m['cuts'] if cut['id'] in visible_ids
                           for a in cut.get('assets', [])}
    invisible_asset_paths -= visible_asset_paths
    require(m['structure_id'] == baseline['structure_id'], 'Structure changed')
    expected, actual = baseline['cuts'], m['cuts']
    require(bool(expected), 'Empty baseline')
    ids = [c['id'] for c in actual]
    require(len(ids) == len(set(ids)), 'Duplicate cut IDs')
    require(ids == [c['id'] for c in expected], 'Cut count/order differs from baseline')
    for target, cut in zip(expected, actual):
        label = cut['id']
        for key in ('reference_video_id', 'reference_cut_id', 'media_kind', 'source_kind'):
            require(bool(target[key]) and cut[key] == target[key], label + ': ' + key + ' differs')
        for key in ('visual_evidence', 'script_evidence'):
            require(cut[key] == target[key], label + ': evidence changed')
            evidence(target[key])
        evidence(cut['new_script'])
        reference = linked_gate(lambda: reference_background(target, load))
        d, r = cut['duration_s'], reference['original_duration_s'] if reference else None
        require(positive(d), label + ': invalid duration')
        if positive(d) and reference:
            require(.8 * r - 1e-9 <= d <= 1.2 * r + 1e-9, label + ': duration outside 80–120%')
        for key in ('layers', 'effects'):
            required = target['required_' + key]
            require(isinstance(required, list), label + ': required components must be lists')
            require(isinstance(cut[key], dict), label + ': configurations must be objects')
            for component in required:
                require(bool(cut[key].get(component)), label + ': missing ' + component)
        if isinstance(cut.get('layers'), dict) and 'renderer_layers' in cut['layers']:
            # The actual template consumes the same strict scene contract. No diagnostic or guessed nodes in plans.
            from check_render_timing import TEMPLATE
            inspector = "const s=require(process.argv[1]);const n=JSON.parse(process.argv[2]);s.validateScenes(n,Number(process.argv[3]));process.stdout.write(JSON.stringify(s.sceneEvidence(n)));"
            try:
                result = subprocess.run(['node', '-e', inspector, str(TEMPLATE / 'src/sceneContract.cjs'),
                                         json.dumps(cut['layers']['renderer_layers'], allow_nan=False), str(d)],
                                        capture_output=True, text=True, check=True, timeout=30)
                for ref in json.loads(result.stdout):
                    evidence(ref)
            except (OSError, ValueError, TypeError, KeyError, subprocess.SubprocessError) as exc:
                require(False, label + ': invalid/unmeasured independent renderer layer: ' + str(exc))
        for asset in cut.get('assets', []):
            if cut['id'] in visible_ids and context.snapshot.optional_file(root / asset['path']):
                file(asset['path'])
        if stage in ('assets', 'final') and cut['id'] in visible_ids:
            require(bool(cut['assets']), label + ': no assets')
            primary = 0
            for asset in cut['assets']:
                p = file(asset['path'])
                info = media(p)
                streams = info.get('streams', [])
                visual = [s for s in streams if s.get('codec_type') == 'video']
                fmt = info.get('format', {}).get('format_name', '')
                kind = ('image' if any(x in fmt for x in ('image2', '_pipe')) else 'video') if visual else 'audio'
                require(kind == asset['media_kind'], label + ': actual asset type mismatch')
                if asset.get('primary') is True:
                    primary += 1
                    require(kind == cut['media_kind'], label + ': primary source type mismatch')
                    require(asset['source_kind'] == cut['source_kind'], label + ': source category mismatch')
            require(primary >= 1, label + ': no primary visual asset')
    # Every render input, including code, music, narration and configuration, must be listed.
    require(bool(m['render_inputs']), 'Missing render input inventory')
    optional_plan_paths = {(root / a['path']).resolve() for c in m['cuts'] for a in c.get('assets', [])}
    optional_plan_paths.update((root / m['tts'][key]).resolve() for key in ('narration_metadata', 'timeline')
                               if isinstance(m['tts'].get(key), str))
    for name in m['render_inputs']:
        input_path = (root / name).resolve()
        if stage == 'plan' and input_path in optional_plan_paths and not context.snapshot.optional_file(root / name):
            continue
        if input_path != compiled_path and input_path not in invisible_asset_paths:
            linked_gate(lambda: file(name))
    for ref in baseline['rule_evidence']:
        evidence(ref)
    require(bool(baseline['rule_evidence']), 'Missing style rules')
    require(m['tts']['provider'] == 'typecast' and m['tts']['voice_name'] in ('진우', '시연'), 'Invalid TTS')
    require(bool(m['tts']['voice_id']), 'Missing voice ID')
    if m['tts']['voice_name'] == '진우':
        require(m['tts']['voice_id'] == 'tc_632293f759d649937b97f323', 'Wrong Jinwoo ID')
    else:
        evidence(m['tts']['official_voice_evidence'])
    tts = m['tts']
    require(exact(tts.get('uniform_speed'), 1.2), 'tts.uniform_speed must be 1.2')
    require(tts.get('speed_method') == 'provider', 'tts.speed_method must be provider')
    require(exact(tts.get('playback_rate'), 1.0), 'tts.playback_rate must be 1.0')
    if stage in ('assets', 'final'):
        narration_gate(tts)
    overrides = baseline.get('visual_review_overrides', [])
    reviewers = {cut_id: 'sol' for cut_id in ids}
    overridden = set()
    for override in overrides:
        cut_id = override['cut_id']
        require(cut_id in reviewers and cut_id not in overridden, 'Invalid/duplicate reviewer override scope')
        require(override['reviewer'] in ('sol', 'codex'), 'Unsupported reviewer override')
        evidence(override['authorization'])
        overridden.add(cut_id)
        reviewers[cut_id] = override['reviewer']
    analysis_sessions = set(observed_analysis_sessions)
    if stage == 'final':
        require(bool(analysis_sessions) and analysis_sessions <= set(baseline.get('analysis_session_ids', [])),
                'Baseline omits actual analysis sessions from source evidence')
        require(bool(implementation_sessions) and implementation_sessions == set(baseline.get('implementation_session_ids', [])),
                'Baseline implementation sessions differ from implementation provenance')
    fingerprint = canonical({'manifest': m, 'files': files})
    report = {'stage': stage, 'input_sha256': fingerprint,
              'duration_link': duration_link, 'output_bounds': output_bounds,
              'visual_acceptance_sha256': files.get(str(acceptance_path)),
              'compiled_timeline': str(compiled_path) if compiled_path else None,
              'excluded_render_inputs': sorted(str(p) for p in invisible_asset_paths),
              'visible_cut_ids': [c['id'] for c in actual if c['id'] in visible_ids],
              'required_visual_measurement_rule_ids': [r['id'] for r in acceptance_rules if set(r['cut_ids']) & visible_ids],
              'renderer_usage_verified': False,
              'capability_preflight':capability_preflight,
              'content_completion_eligible':False,
              'unverified_final_requirements':(capability_preflight or {}).get('unverified_final_requirements',['direct_listening','continuous_playback']) if new_run else []}
    if output_bounds and windows:
        # Read valid JSON timeline in plan too, without requiring synthesis outputs.
        if stage == 'plan' and isinstance(tts.get('timeline'), str):
            timeline_path = (root / tts['timeline']).resolve()
            if context.snapshot.optional_file(root / tts['timeline']):
                timeline_document = linked_gate(lambda: load(tts['timeline']))
        expected_compiled = build_expected_timeline(path, m, baseline, fingerprint, digest(path),
                                                   output_bounds, timeline_document)
        report['expected_compiled_sha256'] = linked_gate(lambda: canonical(expected_compiled))
        if stage in ('assets', 'final'):
            def validate_compiled():
                if compiled_path is None or not compiled_path.is_file():
                    raise ValueError('Missing compiled_timeline output')
                actual_compiled = read(compiled_path)
                if canonical(actual_compiled) != canonical(expected_compiled):
                    raise ValueError('Stale/different compiled_timeline source, input or semantic payload')
            linked_gate(validate_compiled)
    if stage in ('assets', 'final'):
        def renderer_timing_gate():
            # 렌더 도구와의 순환 import를 피하고 실제 소비 props를 검사한다.
            from check_render_timing import validate_render_timing
            return validate_render_timing(path, context=context)
        report['render_timing_check'] = linked_gate(renderer_timing_gate)
    if stage == 'final':
        render = file(m['render'])
        render_hash = files[str(render)]
        report['render_sha256'] = render_hash
        info = media(render)
        video = [s for s in info.get('streams', []) if s.get('codec_type') == 'video']
        require(bool(video), 'Render has no video')
        if video:
            require([video[0]['width'], video[0]['height']] == m['canvas'], 'Wrong render dimensions')
        require(any(s.get('codec_type') == 'audio' for s in info.get('streams', [])), 'Render has no audio')
        # Cut intervals are non-overlapping timeline intervals, including transition allocation.
        duration = float(info.get('format', {}).get('duration', 0))
        expected_duration = (output_bounds['end_s'] - output_bounds['start_s']) if output_bounds else sum(c['duration_s'] for c in actual)
        require(math.isfinite(duration) and abs(duration - expected_duration) <= .1, 'Render duration differs from output scope')
        preflight = duration_link.get('preflight', {})
        if (m.get('output_scope', {'kind': 'full'}).get('kind') == 'full'
                and preflight.get('full_duration_tolerance_s') is not None
                and preflight.get('decision') is None):
            require(math.isfinite(duration) and abs(duration - duration_link['target_duration_s'])
                    <= preflight['full_duration_tolerance_s'] + 1e-9,
                    'Full render duration outside reference target ±30 seconds')
        conformance = read(root / m['conformance'])
        linked_gate(lambda: validate_measurements(conformance.get('visual_measurements'),
                    [rule for rule in acceptance_rules if set(rule['cut_ids']) & visible_ids],
                    fingerprint, render_hash, files.get(str(acceptance_path)), evidence))
        run=os.environ.get('LFC_RUN_DIR')
        front_required=bool(run) and json.loads((Path(run)/'run.json').read_text()).get('front_review_version',0)>=1
        if front_required or conformance.get('review_evidence'):
            def scoped_review_gate():
                from review_evidence import validate_current
                link=conformance.get('review_evidence',{}).get('record',{})
                if not link.get('path') or not link.get('sha256'):raise ValueError('Current independent scoped review record required')
                record_path=(root/link['path']).resolve()
                if digest(record_path)!=link['sha256']:raise ValueError('Changed scoped review record')
                result=validate_current(record_path,render)
                for key in ('visual_review','script_review'):
                    if conformance.get(key,{}).get('session_id')!=result['reviewer_session']:raise ValueError('Current final reviewer differs from scoped integration judgment')
                return result
            report['scoped_review_check']=linked_gate(scoped_review_gate)
        require(conformance['unresolved_items'] == [], 'Unresolved items remain')
        require(isinstance(conformance['user_authorized_changes'], list), 'Invalid authorized changes')
        def review_record(review, reviewer, visual=False):
            require(review['reviewer'] == reviewer and review['status'] == 'pass', 'Review not passed / wrong reviewer')
            require(review['input_sha256'] == fingerprint and review['render_sha256'] == render_hash, 'Stale review')
            evidence(review['report'])
            require(review.get('model')=='gpt-6.1-sol' and review.get('reasoning_effort')=='high', 'Review must record actual Sol 6.1 High provenance')
            prior=analysis_sessions | implementation_sessions | set(baseline.get('analysis_session_ids',[])) | set(baseline.get('implementation_session_ids',[]))
            require(bool(review.get('session_id')) and bool(analysis_sessions) and bool(implementation_sessions) and review['session_id'] not in prior, 'Review must be independent of analysis and implementation')

        review_record(conformance['script_review'], 'sol')
        visual = conformance['visual_review']
        visible_overrides = [o for o in overrides if o['cut_id'] in visible_ids]
        if visible_overrides:
            require(all(o in conformance['user_authorized_changes'] for o in visible_overrides), 'Reviewer authorization missing from conformance')
            require(visual['status'] == 'pass' and visual['input_sha256'] == fingerprint and
                    visual['render_sha256'] == render_hash, 'Aggregate visual review stale/not passed')
            covered = []
            for part in visual['parts']:
                require(bool(part['cut_ids']), 'Empty review scope')
                review_record(part, part['reviewer'], visual=True)
                for cut_id in part['cut_ids']:
                    require(cut_id in visible_ids and reviewers.get(cut_id) == part['reviewer'], 'Reviewer exceeds authorized cut scope')
                    covered.append(cut_id)
            require(sorted(covered) == sorted(visible_ids), 'Visual review scope missing/duplicated')
        else:
            review_record(visual, 'sol', visual=True)
    if probe is None:
        with tempfile.NamedTemporaryFile(mode="w",dir=cache_base,delete=False) as stream:
            json.dump(cache,stream,ensure_ascii=False); temporary=Path(stream.name)
        temporary.replace(cache_path)
    report.update(passed=not errors, errors=errors, output_scope=m.get('output_scope', {'kind': 'full'}))
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('manifest', type=Path)
    parser.add_argument('--stage', choices=['plan', 'assets', 'final'], required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--also', nargs=2, action='append', default=[], metavar=('MANIFEST', 'STAGE'),
                        help='Check additional scopes/stages in the same content-bound transaction')
    args = parser.parse_args()
    requests = [(args.manifest, args.stage), *args.also]
    context = VerificationContext()
    def protect_output():
        protected = [*context.snapshot.signatures, *context.snapshot.absent]
        for path, doc in context.snapshot.documents.items():
            if not isinstance(doc, dict) or not isinstance(doc.get('render_inputs'), list): continue
            root = Path(path).parent
            protected += [root/n for n in doc['render_inputs'] if isinstance(n, str)]
            protected += [root/doc[k] for k in ('baseline','visual_acceptance','compiled_timeline','render','conformance')
                          if isinstance(doc.get(k), str)]
            stack = [doc]
            while stack:
                item = stack.pop()
                if isinstance(item, dict):
                    if isinstance(item.get('file'), str): protected.append(root/item['file'])
                    stack.extend(item.values())
                elif isinstance(item, list): stack.extend(item)
        validate_output_paths([p for p, _ in requests], [args.out], protected)
    try:
        reports = [check(path, stage, context=context) for path, stage in requests]
        if args.also:
            result = {'passed': all(r['passed'] for r in reports), 'reports': reports,
                      'errors': [e for r in reports for e in r['errors']]}
        else: result = reports[0]
    except (OSError, ValueError, KeyError, TypeError, IndexError, subprocess.SubprocessError) as exc:
        result = {'stage': args.stage, 'passed': False, 'errors': [str(exc)]}
    try:
        protect_output()
        context.close()
    except (OSError, ValueError, KeyError, TypeError) as exc:
        result = {'stage': args.stage, 'passed': False, 'errors': [str(exc)]}
        print(json.dumps(result, ensure_ascii=False))
        return 1
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, ensure_ascii=False, indent=2))
    print(json.dumps(result, ensure_ascii=False))
    return 0 if result['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
