import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from types import SimpleNamespace
from check_render_timing import validate_render_timing, renderer_dependencies, digest


class RenderTimingTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.m = {'canvas':[320,180], 'compiled_timeline':'compiled.json',
                  'render_timing':{'kind':'remotion-template','props':'props.json'},
                  'render_inputs':['props.json', *map(str,renderer_dependencies())]}
        self.props = {'fps':30,'width':320,'height':180,'duration_s':20,
                      'cuts':[{'id':'c1','start_s':0,'end_s':10,'transition_in':{'frames':0}},
                              {'id':'c2','start_s':10,'end_s':20,'transition_in':{'frames':0}}]}
        self.compiled = {'output_bounds':{'start_s':0,'end_s':20},'cuts':[
            {'id':'c1','start_s':0,'end_s':10,'duration_s':10,'output_clip':{'start_s':0,'end_s':10}},
            {'id':'c2','start_s':10,'end_s':20,'duration_s':10,'output_clip':{'start_s':10,'end_s':20}}]}
    def write(self,name,obj):
        (self.root/name).write_text(json.dumps(obj))
    def run_check(self):
        self.write('manifest.json', self.m)
        self.compiled['source_manifest_sha256']=digest(self.root/'manifest.json')
        self.write('compiled.json',self.compiled)
        self.write('props.json',self.props)
        return validate_render_timing(self.root/'manifest.json')
    def test_shared_scheduler_normal(self):
        result=self.run_check()
        self.assertTrue(result['passed'])
        self.assertEqual(result['cuts'][1]['from'],300)
        self.assertFalse(result['visual_accuracy_verified'])
    def test_actual_cut_boundary_changed_same_total_rejected(self):
        self.props['cuts'][0]['end_s']=9
        self.props['cuts'][1]['start_s']=9
        with self.assertRaisesRegex(ValueError,'actual renderer frames'):self.run_check()
    def test_wrong_id_order_rejected(self):
        self.props['cuts'].reverse()
        with self.assertRaisesRegex(ValueError,'count/order'):self.run_check()
    def test_composition_length_rejected(self):
        self.props['duration_s']=19
        with self.assertRaisesRegex(ValueError,'composition frame'):self.run_check()
    def test_preview_clips_output_not_source_interval(self):
        self.props['duration_s']=17
        self.compiled['output_bounds']['end_s']=17
        self.compiled['cuts'][1]['output_clip']['end_s']=17
        result=self.run_check()
        self.assertEqual(result['cuts'][1]['end'],600)
        self.assertEqual(result['cuts'][1]['output_end_frame'],510)
    def test_chopping_last_source_duration_rejected(self):
        self.props['duration_s']=17
        self.props['cuts'][1]['end_s']=17
        self.compiled['output_bounds']['end_s']=17
        with self.assertRaisesRegex(ValueError,'actual renderer frames'):self.run_check()
    def test_transition_tail_separate_from_clip_occupancy(self):
        self.props['cuts'][1]['transition_in']={'type':'dissolve','frames':12}
        self.compiled['cuts'][1]['transition_in']={'type':'dissolve','frames':12}
        result=self.run_check()
        self.assertEqual(result['cuts'][0]['end'],300)
        self.assertEqual(result['cuts'][0]['durationInFrames'],312)
    def test_fractional_endpoints_share_occupancy_and_transition_start(self):
        self.props['duration_s']=2
        self.props['cuts']=[{'id':'a','start_s':0,'end_s':.02,'transition_in':{'frames':0}},
                            {'id':'b','start_s':.02,'end_s':1.04,'transition_in':{'frames':0}},
                            {'id':'c','start_s':1.04,'end_s':2,'transition_in':{'frames':1}}]
        self.compiled['output_bounds']['end_s']=2
        self.compiled['cuts']=[{**c,'duration_s':c['end_s']-c['start_s'],'output_clip':{'start_s':c['start_s'],'end_s':c['end_s']}} for c in self.props['cuts']]
        row=self.run_check()['cuts'][1]
        self.assertEqual(row['end']-row['from'],30)
        self.assertEqual(row['durationInFrames'],31)
        # Main passes exactly this 30-frame occupancy to Clip's outgoing transition.
        self.assertNotEqual(row['end']-row['from'],round((1.04-.02)*30))
    def test_unplanned_transition_rejected(self):
        self.props['cuts'][1]['transition_in']={'frames':20}
        with self.assertRaisesRegex(ValueError,'transition differs'):self.run_check()
    def test_renderer_dependency_must_be_hashed(self):
        self.m['render_inputs'].pop()
        with self.assertRaisesRegex(ValueError,'dependency missing'):self.run_check()
    def test_custom_renderer_not_falsely_certified(self):
        self.m['render_timing']['kind']='custom'
        with self.assertRaisesRegex(ValueError,'unsupported'):self.run_check()
    def test_pre_render_failure_prevents_subprocess(self):
        from build_timeline import render_prepared
        (self.root/'render').mkdir()
        (self.root/'mix.wav').write_bytes(b'test')
        self.m.update(render='output.mp4',render_timing={'props':'render/props.json'})
        self.m['render_inputs'].append('mix.wav')
        self.write('manifest.json',self.m)
        args=SimpleNamespace(production_manifest=str(self.root/'manifest.json'),preview=False)
        with patch('check_production.check',return_value={'passed':False,'errors':['timing mismatch']}), patch('build_timeline.subprocess.run') as run:
            with self.assertRaisesRegex(ValueError,'Pre-render gate failed'):
                render_prepared(args,self.root,self.root/'render',self.root/'render/public')
            run.assert_not_called()

class PreparedSampleTest(unittest.TestCase):
    def test_only_requested_frames_and_audio_offset_are_rendered(self):
        from build_timeline import render_prepared
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);(root/'render').mkdir();(root/'mix.wav').write_bytes(b'test');(root/'render/props.json').write_text('{}')
            manifest={'canvas':[320,180],'render':'output.mp4','render_timing':{'props':'render/props.json'},'render_inputs':['mix.wav']}
            (root/'manifest.json').write_text(json.dumps(manifest))
            args=SimpleNamespace(production_manifest=str(root/'manifest.json'),preview=False,concurrency=1,sample_frames='30-59')
            report={'passed':True,'input_sha256':'test-input','render_timing_check':{'fps':30,'output_frames':60,'template_sha256':'template'}}
            with patch('check_production.check',return_value=report), patch('renderer_runtime.setup'), patch('build_timeline.subprocess.run',side_effect=lambda *args,**kwargs:(root/'sample-30-59.video.mp4').write_bytes(b'video')) as render, patch('build_timeline.run', side_effect=lambda _: (root/'sample-30-59.mp4').write_bytes(b'sample')) as mux, patch('build_timeline.probe',return_value={'duration_s':1,'nb_frames':30,'fps':30,'width':320,'height':180}):
                render_prepared(args,root,root/'render',root/'render/public')
                cmd=render.call_args.args[0]
                self.assertIn('--frames=30-59',cmd)
                self.assertIn(str(root/'sample-30-59.video.mp4'),cmd)
                audio=mux.call_args.args[0]
                self.assertEqual(audio[audio.index('-ss')+1],'1.0')
            info=json.loads((root/'sample-30-59.json').read_text())
            self.assertFalse(info['complete_video'])
            self.assertEqual(info['input_sha256'],'test-input')
            self.assertEqual(info['render_sha256'],digest(root/'sample-30-59.mp4'))
            self.assertFalse((root/'output.mp4').exists())
    def test_sample_outside_scope_fails_before_render(self):
        from build_timeline import render_prepared
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);(root/'render').mkdir();(root/'mix.wav').write_bytes(b'test');(root/'render/props.json').write_text('{}')
            (root/'manifest.json').write_text(json.dumps({'render':'output.mp4','render_timing':{'props':'render/props.json'},'render_inputs':['mix.wav']}))
            args=SimpleNamespace(production_manifest=str(root/'manifest.json'),preview=False,sample_frames='30-60')
            report={'passed':True,'render_timing_check':{'fps':30,'output_frames':60,'template_sha256':'template'}}
            with patch('check_production.check',return_value=report),patch('renderer_runtime.setup'), patch('build_timeline.subprocess.run',side_effect=lambda *args,**kwargs:(root/'sample-30-59.video.mp4').write_bytes(b'video')) as render:
                with self.assertRaisesRegex(ValueError,'outside checked output'):
                    render_prepared(args,root,root/'render',root/'render/public')
                render.assert_not_called()

if __name__=='__main__':unittest.main()
