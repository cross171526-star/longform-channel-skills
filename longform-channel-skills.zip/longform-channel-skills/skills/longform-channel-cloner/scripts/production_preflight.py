"""환경·파일 실체·실제 청취/재생 가능성·절대 프레임 경계를 시작 시 기록한다."""
import json
import math
from pathlib import Path
import shutil
import subprocess
from work_guard import digest


def inspect_file(path):
    path=Path(path).resolve()
    with path.open('rb') as f:prefix=f.read(512).lstrip().lower()
    if prefix.startswith((b'<!doctype html',b'<html',b'<?xml')) and path.suffix.lower() not in ('.svg','.xml'):
        raise ValueError('Downloaded document is HTML/XML, not expected media: '+str(path))
    suffix=path.suffix.lower();kind='binary'
    if suffix in ('.png','.jpg','.jpeg','.webp','.gif'):
        from PIL import Image
        with Image.open(path) as im:im.verify()
        kind='image'
    elif suffix in ('.mp4','.mov','.mkv','.wav','.mp3','.m4a','.aac','.webm'):
        ffprobe=shutil.which('ffprobe') or str(Path.home()/'.longform-cloner/bin/ffprobe')
        r=subprocess.run([ffprobe,'-v','error','-show_streams','-show_format','-of','json',str(path)],capture_output=True,text=True,timeout=30,check=True)
        doc=json.loads(r.stdout)
        if not doc.get('streams'):raise ValueError('Media has no actual stream')
        kind='media'
    elif suffix=='.json':json.loads(path.read_text());kind='json'
    elif suffix in ('.ttf','.otf'):
        from PIL import ImageFont
        ImageFont.truetype(str(path),24);kind='font'
    return {'path':str(path),'sha256':digest(path),'kind':kind}


def clock_check(spec):
    fps=spec.get('fps');master=spec.get('master_duration_s');composition=spec.get('composition_frames')
    if not isinstance(fps,(int,float)) or isinstance(fps,bool) or not math.isfinite(fps) or fps<=0:
        raise ValueError('Finite actual fps required')
    if not isinstance(master,(int,float)) or isinstance(master,bool) or not math.isfinite(master) or master<=0:
        raise ValueError('Finite full master duration required')
    total=round(fps*master)
    if type(composition) is not int or composition!=total:raise ValueError('Diagnostic composition must retain full master frame count, not sample count')
    if spec.get('reset_clock_or_rebase_props') is not False:raise ValueError('Diagnostic clock must not be reset/rebased')
    frames=spec.get('absolute_frames',[])
    if not frames or any(type(x) is not int or not 0<=x<total for x in frames):raise ValueError('Absolute observation frame outside full composition')
    if total>1 and not {0,total-1}<=set(spec.get('functional_boundary_frames',[])):
        raise ValueError('Clock function probe must include first and last full-master frame')
    return {'passed':True,'master_frames':total,'absolute_frames':frames,'perceptual_verified':False}


def run(spec_path):
    from workflow import doctor
    spec_path=Path(spec_path).resolve();spec=json.loads(spec_path.read_text());env=doctor();files=[];errors=[]
    for p in spec.get('files',[]):
        try:files.append(inspect_file(spec_path.parent/p))
        except (OSError,ValueError,subprocess.SubprocessError) as e:errors.append(str(e))
    caps={}
    for name in ('direct_listening','continuous_playback'):
        item=spec.get('capabilities',{}).get(name,{'status':'unverified'})
        if item.get('status') not in ('available','unsupported','denied','unverified'):errors.append('Invalid capability status: '+name)
        evidence=[]
        for row in item.get('probe_evidence',[]):
            p=(spec_path.parent/row['path']).resolve()
            if digest(p)!=row['sha256']:errors.append('Capability probe changed: '+name)
            evidence.append({'path':str(p),'sha256':digest(p)})
        if item.get('status') in ('available','unsupported','denied') and not evidence:errors.append('Actual capability probe evidence required: '+name)
        caps[name]={**item,'probe_evidence':evidence,'heard_or_played':False}
    clock=None
    if 'diagnostic_clock' in spec:
        try:clock=clock_check(spec['diagnostic_clock'])
        except ValueError as e:errors.append(str(e))
    state=capability_state({'capabilities':caps})
    return {'passed':env['passed'] and not errors,'errors':errors,'environment':env,'files':files,'capabilities':caps,
            'spec':{'path':str(spec_path),'sha256':digest(spec_path)},'delivery_route':state['delivery_route'],'next_action':state['next_action'],
            'dependencies_sha256':{str(spec_path):digest(spec_path),**{x['path']:x['sha256'] for x in files},**{x['path']:x['sha256'] for c in caps.values() for x in c['probe_evidence']}},
            'diagnostic_clock':clock,'unverified_final_requirements':[k for k,v in caps.items() if v.get('status')!='available'],
            'actual_listening_passed':False,'continuous_playback_passed':False,'access_denial_bypassed':False}


def capability_state(preflight):
    names=('direct_listening','continuous_playback')
    missing=[name for name in names if preflight.get('capabilities',{}).get(name,{}).get('status')!='available']
    return {'delivery_route':'review_draft_then_actual_observation' if missing else 'independent_final_review',
            'unverified_final_requirements':missing,'completion_passed':False,
            'next_action':'허용된 실제 관찰 경로로 전체 청취·연속 재생 확인; 현재 파일은 검토본으로 전달' if missing else '독립 검수에서 현재 영상 전체 청취·연속 재생·내용 확인'}


def final_capabilities(preflight_path,resolution_path,render_path,input_sha256,reviewer_session):
    """필수 청취·연속 재생의 현재 독립 근거를 최종 승인에 연결한다. 기술검사 통과와 분리한다."""
    from scheduler import provenance
    from common import probe
    preflight_path,resolution_path,render_path=map(lambda p:Path(p).resolve(),(preflight_path,resolution_path,render_path))
    initial=json.loads(preflight_path.read_text());current=json.loads(resolution_path.read_text());errors=[]
    def require(ok,msg):
        if not ok:errors.append(msg)
    require(initial.get('passed') is True,'Initial production preflight failed')
    require(current.get('preflight_sha256')==digest(preflight_path),'Capability resolution not bound to initial preflight')
    require(current.get('render_sha256')==digest(render_path) and current.get('input_sha256')==input_sha256,'Final capability evidence belongs to different render/input')
    actual=provenance(current['reviewer_rollout']);require(actual['session']==reviewer_session==current.get('session_id'),'Final capability observer session differs')
    duration=probe(render_path)['duration_s'];dependencies={str(preflight_path):digest(preflight_path),str(resolution_path):digest(resolution_path),str(render_path):digest(render_path)}
    for name,kind in [('direct_listening','direct_listening_observation'),('continuous_playback','continuous_playback_observation')]:
        item=current.get('capabilities',{}).get(name,{})
        require(item.get('status')=='available' and item.get('passed') is True and item.get('method')==kind,'Required actual '+name+' remains unverified; ASR/signals/stills are not completion')
        intervals=sorted(item.get('coverage_s',[]));end=0
        for a,b in intervals:
            require(0<=a<=end+.1 and a<b<=duration+.1,'Capability coverage gap/outside output: '+name);end=max(end,b)
        require(end>=duration-.1,'Incomplete actual capability coverage: '+name)
        require(bool(item.get('evidence')),'Actual approved observation evidence missing: '+name)
        for row in item.get('evidence',[]):
            p=(resolution_path.parent/row['path']).resolve();h=digest(p);dependencies[str(p)]=h
            require(h==row['sha256'],'Changed observation evidence: '+name)
        if initial.get('capabilities',{}).get(name,{}).get('status')!='available':
            require(bool(item.get('resolution_reason')) and item.get('approved_access') is True,'Unsupported/denied path needs actual permitted resolution evidence, not a waiver')
    return {'passed':not errors,'content_completion_eligible':not errors,'errors':errors,'dependencies_sha256':dependencies,'access_denial_bypassed':False}
