"""배경 클립의 원본 시간 근거와 본편 길이 실행 가능성을 검사한다.

분석 이벤트 컷의 등장·동작 시각은 배경 클립 길이 허용폭의 대상이 아니다.
사용자 결정의 진위는 직접 검토해야 하며 여기서는 범위와 근거 연결을 검사한다.
"""
import math
import re


def finite(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def nonempty(value):
    return isinstance(value, str) and bool(value.strip())


def close(a, b):
    return finite(a) and finite(b) and math.isclose(a, b, rel_tol=0, abs_tol=1e-9)


def resolve_evidence(ref, load):
    """실제 JSON 항목을 읽는다. load는 파일 해시 추적도 담당한다."""
    if not isinstance(ref, dict) or not nonempty(ref.get('file')):
        raise ValueError('Invalid timing evidence file')
    pointer = ref.get('pointer')
    if not nonempty(pointer) or not pointer.startswith('/'):
        raise ValueError('Timing evidence needs a non-root JSON Pointer')
    value = load(ref['file'])
    for token in pointer.split('/')[1:]:
        token = token.replace('~1', '/').replace('~0', '~')
        if isinstance(value, list):
            if not re.fullmatch(r'0|[1-9][0-9]*', token):
                raise ValueError('Invalid timing evidence array index')
            value = value[int(token)]
        else:
            value = value[token]
    return value


def reference_background(cut, load):
    """baseline 길이를 신뢰하지 않고 실제 background_segments에서 도출한다."""
    ref = cut.get('visual_evidence')
    label = str(cut.get('id', '?'))
    if (not isinstance(ref, dict) or not isinstance(ref.get('pointer'), str)
            or not re.fullmatch(r'/background_segments/(0|[1-9][0-9]*)', ref['pointer'])):
        raise ValueError(label + ': visual_evidence must point to a background_segments object')
    document = load(ref['file'])
    provenance = document.get('analysis_provenance') if isinstance(document, dict) else None
    if (not isinstance(provenance, dict) or not nonempty(provenance.get('video_id'))
            or provenance['video_id'] != cut.get('reference_video_id')):
        raise ValueError(label + ': reference_video_id differs from analysis_provenance.video_id')
    backgrounds = document.get('background_segments')
    if not isinstance(backgrounds, list):
        raise ValueError(label + ': background_segments must be an array')
    item = backgrounds[int(ref['pointer'].rsplit('/', 1)[1])]
    if not isinstance(item, dict) or not nonempty(item.get('id')):
        raise ValueError(label + ': invalid reference background ID')
    if item['id'] != cut.get('reference_cut_id'):
        raise ValueError(label + ': reference_cut_id differs from reference background ID')
    start, end = item.get('start_s'), item.get('end_s')
    if not finite(start) or not finite(end) or start < 0 or end <= start:
        raise ValueError(label + ': invalid reference background start_s/end_s')
    duration = end - start
    if not finite(duration) or duration <= 0:
        raise ValueError(label + ': invalid reference background duration')
    if 'duration_s' in item and not close(item['duration_s'], duration):
        raise ValueError(label + ': reference background duration_s differs from end_s-start_s')
    if not close(cut.get('duration_s'), duration):
        raise ValueError(label + ': baseline duration differs from reference background end_s-start_s')
    return {'cut_id': cut['id'], 'reference_video_id': cut['reference_video_id'],
            'reference_cut_id': item['id'], 'start_s': start, 'end_s': end,
            'original_duration_s': duration, 'minimum_duration_s': .8 * duration,
            'maximum_duration_s': 1.2 * duration, 'visual_evidence': dict(ref)}


def validate_reference_clips(reference_clips):
    seen = set()
    for clip in reference_clips:
        key = (clip['reference_video_id'], clip['reference_cut_id'])
        if key in seen:
            raise ValueError('Duplicate source background reference; cannot inflate structure duration')
        seen.add(key)


def duration_preflight(manifest, baseline, reference_clips, mean, planned,
                       selected6_hash, baseline_hash, load, tolerance_s=None):
    """신규 본편은 목표 ±30초와 컷별 가능 범위를 함께 검사한다. 과거 계약은 보존한다."""
    validate_reference_clips(reference_clips)
    total = math.fsum(c['original_duration_s'] for c in reference_clips)
    minimum, maximum = .8 * total, 1.2 * total
    if not reference_clips or not all(finite(v) and v > 0 for v in (total, minimum, maximum, mean, planned)):
        raise ValueError('Invalid duration preflight inputs')
    feasible = minimum - 1e-9 <= mean <= maximum + 1e-9
    result = {'original_total_s': total, 'minimum_duration_s': minimum,
              'maximum_duration_s': maximum, 'mean_feasible': feasible,
              'effective_target_duration_s': mean, 'decision': None,
              'passed': True, 'errors': []}
    if tolerance_s is not None:
        if not finite(tolerance_s) or tolerance_s < 0:
            raise ValueError('Invalid full duration tolerance')
        target_min, target_max = max(0, mean - tolerance_s), mean + tolerance_s
        allowed_min, allowed_max = max(minimum, target_min), min(maximum, target_max)
        result.update(full_duration_tolerance_s=tolerance_s,
                      allowed_min_duration_s=allowed_min, allowed_max_duration_s=allowed_max,
                      target_range_feasible=allowed_min <= allowed_max + 1e-9,
                      planned_within_target_range=target_min - 1e-9 <= planned <= target_max + 1e-9)
    ref = manifest['duration_link'].get('decision')
    if ref is not None:
        try:
            decision = resolve_evidence(ref, load)
            if not isinstance(decision, dict) or decision.get('authorized_by') != 'user':
                raise ValueError('Duration decision must be explicitly authorized_by user')
            for key in ('instruction', 'source', 'recorded_at'):
                if not nonempty(decision.get(key)):
                    raise ValueError('Missing duration decision ' + key)
            scope = decision.get('scope')
            expected = {'structure_id': baseline['structure_id'],
                        'cut_ids': [c['id'] for c in baseline['cuts']],
                        'selected6_sha256': selected6_hash, 'baseline_sha256': baseline_hash}
            if not isinstance(scope, dict) or scope != expected:
                raise ValueError('Duration decision scope differs from current structure/cuts/selected6/baseline')
            chosen = decision.get('planned_duration_s')
            if not finite(chosen) or not minimum - 1e-9 <= chosen <= maximum + 1e-9:
                raise ValueError('Duration decision planned_duration_s outside feasible range')
            if not close(chosen, planned):
                raise ValueError('Duration decision planned_duration_s differs from actual full plan')
            result.update(effective_target_duration_s=chosen, decision={'evidence': dict(ref), **decision})
        except (OSError, ValueError, KeyError, TypeError, IndexError) as exc:
            result['errors'].append(str(exc))
    elif tolerance_s is not None:
        if not result['target_range_feasible']:
            result['errors'].append('Reference target tolerance does not intersect feasible background duration range; scoped user duration decision required')
        if not result['planned_within_target_range']:
            result['errors'].append('Full planned duration outside reference target ±30 seconds; scoped user duration decision required')
        if not minimum - 1e-9 <= planned <= maximum + 1e-9:
            result['errors'].append('Full planned duration outside feasible background duration range')
    elif not feasible:
        result['errors'].append('Reference mean outside feasible background duration range; scoped user duration decision required')
    result['passed'] = not result['errors']
    return result
