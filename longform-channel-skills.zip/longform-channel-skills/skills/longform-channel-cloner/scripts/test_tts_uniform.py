#!/usr/bin/env python3
"""유료 호출 없이 균일한 provider 1.2배속과 사전 입력 검증을 확인한다."""
from __future__ import annotations

from contextlib import ExitStack, redirect_stderr, redirect_stdout
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parent))
import tts


class UniformTTSTests(unittest.TestCase):
    def assert_rejected(self, options, lines=None, message=""):
        """잘못된 CLI는 읽기 전, 잘못된 문장 옵션은 모든 쓰기·합성 전에 거부되어야 한다."""
        with ExitStack() as stack:
            stack.enter_context(mock.patch.object(sys, "argv", [
                "tts.py", "--lines", "missing.json", "--out", "unused-output", *options,
            ]))
            read = stack.enter_context(mock.patch.object(tts, "read_json", return_value=lines))
            effects = [stack.enter_context(mock.patch.object(owner, name)) for owner, name in (
                (tts.Path, "mkdir"), (tts, "write_json"), (tts, "synth_cached"),
                (tts, "to_wav"), (tts, "run"), (tts.sf, "write"),
                (tts.urllib.request, "urlopen"), (tts, "typecast_key"),
            )]
            stderr = stack.enter_context(redirect_stderr(io.StringIO()))
            with self.assertRaises(SystemExit) as error:
                tts.main()
            self.assertEqual(error.exception.code, 2)
            self.assertIn(message, stderr.getvalue())
            if lines is None:
                read.assert_not_called()
            else:
                read.assert_called_once_with("missing.json")
            for effect in effects:
                effect.assert_not_called()

    def test_fit_rejected_before_io(self):
        self.assert_rejected(["--fit"], message="--fit is prohibited")

    def test_noncanonical_cli_tempo_rejected_before_io(self):
        for tempo in ("1", "1.0", "1.19", "1.20001", "0", "-1", "2", "nan", "inf", "-inf", "1e999"):
            with self.subTest(tempo=tempo):
                self.assert_rejected([f"--tempo={tempo}"], message="--tempo must be finite and exactly 1.2")
        self.assert_rejected(["--tempo=invalid"], message="invalid float value")

    def test_line_overrides_rejected_before_any_write_or_synthesis(self):
        for key, canonical in (("tempo", 1.2), ("speed", 1.2), ("atempo", 1.0)):
            for value in (1.0 if canonical == 1.2 else 1.2, 0, 1.1, 1.20001, 2,
                          float("nan"), float("inf"), float("-inf"),
                          None, True, "1.2", [], {}, 10**400):
                with self.subTest(key=key, value=value):
                    lines = [{"id": "valid", "text": "첫 문장"},
                             {"id": "invalid", "text": "두 번째 문장", key: value}]
                    self.assert_rejected([], lines=lines,
                                         message=f"line invalid: {key} must be finite and exactly {canonical}")

    def test_unequal_lines_use_native_uniform_speed_and_timings(self):
        for provider in tts.PROVIDERS:
            for options in ([], ["--tempo=1.2"]):
                with self.subTest(provider=provider, options=options), tempfile.TemporaryDirectory() as directory:
                    root = Path(directory)
                    out = root / "output"
                    lines_path = root / "lines.json"
                    lines_path.write_text(json.dumps([
                        {"id": "short", "text": "짧은 문장", "start_s": 10, "end_s": 10.1,
                         "gap_after_s": 0.15, "tempo": 1.2, "speed": 1.2, "atempo": 1.0},
                        {"id": "long", "text": "길이가 다른 훨씬 긴 문장", "start_s": 60, "end_s": 80,
                         "emotion": "happy"},
                    ], ensure_ascii=False), encoding="utf-8")
                    raw_durations = {}
                    provider_words = {
                        "짧은 문장": [{"w": "짧은", "start": 0.2, "end": 0.45}],
                        "길이가 다른 훨씬 긴 문장": [{"w": "긴", "start": 0.3, "end": 1.7}],
                    }

                    def synth(text, voice, tempo, emotion, raw):
                        self.assertEqual(tempo, 1.2)
                        raw.write_bytes(b"mock provider audio")
                        raw_durations[raw] = 0.7 if text == "짧은 문장" else 1.9
                        return provider_words[text]

                    def convert(raw, wav):
                        duration = raw_durations[raw] - 0.1
                        tts.sf.write(str(wav), tts.np.full(round(duration * tts.SR), 0.1, tts.np.float32), tts.SR)
                        return duration, 0.1

                    with (mock.patch.object(sys, "argv", [
                        "tts.py", "--lines", str(lines_path), "--out", str(out),
                        "--provider", provider, "--lead-in", "0.4", *options,
                    ]), mock.patch.object(tts, "LFC_HOME", root / "home"),
                          mock.patch.dict(tts.PROVIDERS, {provider: mock.Mock(side_effect=synth)}),
                          mock.patch.object(tts, "to_wav", side_effect=convert) as to_wav,
                          mock.patch.object(tts, "run") as run,
                          mock.patch.object(tts.urllib.request, "urlopen") as network,
                          redirect_stdout(io.StringIO())):
                        tts.main()
                        calls = tts.PROVIDERS[provider].call_args_list
                        self.assertEqual(len(calls), 2)
                        self.assertEqual([call.args[2] for call in calls], [1.2, 1.2])
                        self.assertEqual([call.args[3] for call in calls], ["normal", "happy"])
                        self.assertEqual(to_wav.call_count, 2)
                        for call in to_wav.call_args_list:
                            self.assertEqual(len(call.args), 2)
                            self.assertEqual(call.kwargs, {})
                        run.assert_not_called()
                        network.assert_not_called()

                    metadata = json.loads((out / "narration.json").read_text())
                    self.assertEqual(metadata["uniform_speed"], 1.2)
                    self.assertEqual(metadata["speed_method"], "provider")
                    self.assertFalse(metadata["fit"])
                    placed = metadata["lines"]
                    self.assertEqual([line["provider_tempo"] for line in placed], [1.2, 1.2])
                    self.assertEqual([line["atempo"] for line in placed], [1.0, 1.0])
                    self.assertEqual([line["placed_start_s"] for line in placed], [0.4, 1.15])
                    self.assertEqual([line["placed_end_s"] for line in placed], [1.0, 2.95])
                    self.assertEqual(metadata["words"], [
                        {"w": "짧은", "start": 0.5, "end": 0.75},
                        {"w": "긴", "start": 1.35, "end": 2.75},
                    ])
                    audio, sample_rate = tts.sf.read(str(out / "narration.wav"))
                    self.assertEqual(sample_rate, tts.SR)
                    self.assertEqual(len(audio), int(metadata["duration_s"] * tts.SR) + 1)

    def test_conversion_has_no_speed_filter(self):
        with (mock.patch.object(tts, "leading_silence", return_value=0.1),
              mock.patch.object(tts, "run") as run,
              mock.patch.object(tts, "probe", return_value={"duration_s": 0.6})):
            self.assertEqual(tts.to_wav(Path("raw.wav"), Path("line.wav")), (0.6, 0.1))
        command = run.call_args.args[0]
        filters = command[command.index("-af") + 1]
        self.assertNotIn("atempo", filters)
        self.assertNotIn("asetrate", filters)
        self.assertIn("atrim=start=0.1000", filters)
        self.assertIn("asetpts=PTS-STARTPTS", filters)
        self.assertEqual(command[command.index("-ar") + 1], str(tts.SR))


if __name__ == "__main__":
    unittest.main()
