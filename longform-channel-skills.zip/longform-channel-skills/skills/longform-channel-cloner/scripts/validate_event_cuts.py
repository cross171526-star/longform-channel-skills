#!/usr/bin/env python3
"""Validate event-cut time/ID relations. Does not certify visual interpretation.

python3 validate_event_cuts.py visual_analysis.json
python3 validate_event_cuts.py event-cuts.json --background background-segments.json
Supports current visual_analysis fields and legacy event-cut field names.
"""
from __future__ import annotations
import argparse,json,math,sys
from pathlib import Path

def validate(doc, background_doc=None):
    errors=[]
    def fail(s):errors.append(s)
    def time(row,key,alias):
        v=row.get(key,row.get(alias))
        if not isinstance(v,(int,float)) or isinstance(v,bool) or not math.isfinite(v):
            fail(f'{row.get("id", "metadata")}: invalid {key}');return None
        return float(v)
    cuts=doc.get('cuts')
    if not isinstance(cuts,list) or not cuts:return ['cuts must be a nonempty array']
    bgrows=(background_doc or {}).get('background_segments',(background_doc or {}).get('clips',doc.get('background_segments',[])))
    if not isinstance(bgrows,list):fail('background_segments must be an array');bgrows=[]
    bgmap={}
    for b in bgrows:
        if not isinstance(b,dict):fail('background row must be object');continue
        bid=b.get('id')
        if bid is None or bid in bgmap:fail(f'invalid or duplicate background ID: {bid}')
        else:bgmap[bid]=b
    duration=doc.get('duration',doc.get('coverage',{}).get('duration_s'))
    if duration is None:duration=(background_doc or {}).get('video_duration_seconds')
    ids=set();previous_end=None;background_entry_count=0
    for i,c in enumerate(cuts):
        if not isinstance(c,dict):fail(f'cut row {i} must be object');continue
        cid=c.get('id')
        if cid is None or cid in ids:fail(f'invalid or duplicate cut ID: {cid}')
        else:ids.add(cid)
        start=time(c,'start_s','start');end=time(c,'end_s','end')
        if start is not None and end is not None:
            if end<=start:fail(f'{cid}: duration must be positive')
            if previous_end is None and i==0 and abs(start)>1e-4:fail('first cut must start at 0')
            if previous_end is not None and abs(start-previous_end)>1e-4:fail(f'{cid}: timeline gap/overlap')
            previous_end=end
            declared=c.get('duration_s',c.get('duration'))
            if declared is not None and (not isinstance(declared,(int,float)) or abs(declared-(end-start))>1e-4):fail(f'{cid}: inconsistent duration')
            sample=c.get('sample_time',c.get('evidence',{}).get('sample_time_s') if isinstance(c.get('evidence',{}),dict) else None)
            if sample is not None and (not isinstance(sample,(int,float)) or not start<=sample<end):fail(f'{cid}: sample outside cut')
        parent=c.get('parent_background_id',c.get('parent_background_clip'))
        if parent is None:fail(f'{cid}: missing parent background')
        if bgmap:
            b=bgmap.get(parent)
            if b is None:fail(f'{cid}: unknown parent background {parent}')
            else:
                bs=time(b,'start_s','start');be=time(b,'end_s','end')
                if None not in (start,end,bs,be) and (start<bs-1e-4 or end>be+1e-4):fail(f'{cid}: cut exceeds parent background')
        new=c.get('new_element_ids',c.get('new_elements',[]));active=c.get('active_element_ids',c.get('active_foreground',[]))
        if not isinstance(new,list) or not isinstance(active,list):fail(f'{cid}: elements must be arrays')
        else:
            if len(set(map(str,new)))!=len(new) or len(set(map(str,active)))!=len(active):fail(f'{cid}: duplicate element IDs')
            if not set(map(str,new))<=set(map(str,active)):fail(f'{cid}: new elements missing from active elements')
        if c.get('event_type') in ('배경 전환','background_change','background_entry'):background_entry_count+=1
    if isinstance(duration,(int,float)) and previous_end is not None and abs(previous_end-duration)>1e-4:fail('last cut must end at video duration')
    count=doc.get('counting',{})
    for value,expected,name in [(doc.get('event_cut_count',count.get('event_cut_count')),len(cuts),'event count'),(doc.get('background_count',count.get('background_count')),len(bgmap) if bgmap else background_entry_count,'background count'),(doc.get('additional_boundaries',count.get('additional_boundary_count',count.get('additional_boundaries'))),len(cuts)-background_entry_count,'additional boundaries')]:
        if value is not None and value!=expected:fail(f'inconsistent {name}: {value} != {expected}')
    return errors

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('analysis',type=Path);ap.add_argument('--background',type=Path);args=ap.parse_args()
    try:
        doc=json.loads(args.analysis.read_text(encoding='utf-8'));bg=json.loads(args.background.read_text(encoding='utf-8')) if args.background else None
        errors=validate(doc,bg)
    except (OSError,ValueError,TypeError,AttributeError) as exc:
        print(f'ERROR: {exc}',file=sys.stderr);return 1
    for error in errors:print('ERROR:',error,file=sys.stderr)
    if errors:return 1
    print(f'PASS: {len(doc["cuts"])} event cuts; timeline and element relations valid. Visual accuracy remains unverified by this check.');return 0
if __name__=='__main__':sys.exit(main())
