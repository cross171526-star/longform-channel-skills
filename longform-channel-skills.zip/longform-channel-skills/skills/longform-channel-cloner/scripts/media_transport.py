"""Auditable Gemini transport. No browser, credential scraping, or provider fallback."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time
import uuid

VERSION = 1

def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def save(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    with tmp.open('w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2, allow_nan=False)
        f.flush()
        os.fsync(f.fileno())
    tmp.replace(path)

class TransportError(RuntimeError):
    def __init__(self, code, retryable=False):
        super().__init__(code)
        self.code, self.retryable = code, retryable

def identity(model):
    cli = shutil.which('agy') or str(Path.home() / '.local/bin/agy')
    if not Path(cli).is_file():
        raise TransportError('AGY_MISSING')
    if not model.startswith('gemini-'):
        raise TransportError('GEMINI_REQUIRED')
    return {'transport': 'agy-view-file', 'version': VERSION,
            'binary': str(Path(cli).resolve()), 'binary_sha256': digest(cli), 'model': model}

def stop(proc):
    if proc.poll() is None:
        os.killpg(proc.pid, signal.SIGTERM)
        try:
            proc.wait(5)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid, signal.SIGKILL)
            proc.wait()

def ask(media, prompt, schema, folder, model, timeout=240, conversation=None):
    """Stream to disk so interruption never discards already received output."""
    media, folder = Path(media).resolve(), Path(folder).resolve()
    folder.mkdir(parents=True, exist_ok=True)
    ident = identity(model)
    save(folder / 'request.json', {'identity': ident, 'media_sha256': digest(media),
                                 'media': str(media), 'prompt': prompt, 'schema': schema})
    instruction = ('Continue using the WHOLE video already read in this conversation. '
                   'Do not read or upload files again. Do not use any tools.\n' if conversation else
                   'Read only this WHOLE media with view_file: ' + str(media) + '\n'
                   'Do not split or create files. Do not use any other tools, shell, browser, files, or filename clues. ')
    command = [ident['binary'], '-p', instruction +
               'If pixels/audio are not available say so; do not infer them from OCR.\n' + prompt,
               '--model', model, '--add-dir', str(media.parent),
               '--disable-slash-commands', '--output-format', 'stream-json',
               '--json-schema', json.dumps(schema), '--print-timeout', str(timeout) + 's']
    if conversation:
        command += ['--conversation', conversation]
    env = os.environ.copy()
    env.pop('GEMINI_API_KEY', None)
    env.pop('GOOGLE_API_KEY', None)
    started = time.time()
    with (folder / 'events.jsonl').open('wb') as stdout, (folder / 'stderr.log').open('wb') as stderr:
        proc = subprocess.Popen(command, cwd=media.parent, stdin=subprocess.DEVNULL,
                                stdout=stdout, stderr=stderr, start_new_session=True, env=env)
        try:
            proc.wait(timeout=timeout + 10)
        except subprocess.TimeoutExpired:
            stop(proc)
            save(folder / 'status.json', {'status': 'timeout', 'elapsed_s': time.time() - started})
            raise TransportError('TIMEOUT', True)
        except BaseException:
            stop(proc)
            save(folder / 'status.json', {'status': 'interrupted'})
            raise
    events = []
    for line in (folder / 'events.jsonl').read_text(errors='replace').splitlines():
        try:
            events.append(json.loads(line))
        except ValueError:
            continue
    results = [e.get('result') for e in events if e.get('event') == 'result']
    save(folder / 'status.json', {'returncode': proc.returncode, 'elapsed_s': time.time() - started})
    if len(results) != 1 or not isinstance(results[0], dict):
        raise TransportError('NO_TERMINAL_RESULT', True)
    result = results[0]
    save(folder / 'result.json', result)
    if result.get('denied_actions'):
        raise TransportError('PERMISSION_DENIED')
    if proc.returncode or result.get('status') != 'SUCCESS':
        error = str(result.get('error', '')).lower()
        transient = any(t in error for t in ('timeout', 'timed out', '429', '503', 'overload', 'connection'))
        raise TransportError('UPSTREAM_ERROR', transient)
    calls = [e.get('step_update', {}) for e in events
             if e.get('step_update', {}).get('step_type') == 'tool']
    if any(c.get('tool_name') != 'view_file' for c in calls) or (conversation and calls):
        raise TransportError('UNEXPECTED_TOOL')
    if not conversation and not any(c.get('state') == 'DONE' and c.get('tool_name') == 'view_file'
               and str(media) in json.dumps(c.get('tool_info', {}).get('parameters', {}), ensure_ascii=False)
               and not c.get('tool_info', {}).get('error') for c in calls):
        raise TransportError('MEDIA_READ_NOT_RECORDED')
    data = result.get('structured_output')
    if not isinstance(data, dict):
        raise TransportError('NO_STRUCTURED_OUTPUT')
    save(folder / 'answer.json', data)
    return data
