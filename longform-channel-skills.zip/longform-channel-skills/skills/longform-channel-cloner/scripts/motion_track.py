#!/usr/bin/env python3
"""Measure keyframe motion inside each clip (scale / position / rotation / opacity) by frame-to-frame alignment.

  run.sh motion_track <video> --cuts <cuts.json> [--ids c001 c002] [--range 0:30] [--step 1] [--width 480]
                      [--mask x,y,w,h ...]

For every cut, consecutive frames are aligned with a similarity transform (ORB + RANSAC, ECC fallback) and
the transforms are chained relative to the first clean frame. The result is the source layer's apparent
scale / translation / rotation over time, which is exactly what CapCut/Premiere keyframes produce on a still
image or on footage. Opacity is estimated from mean luminance relative to the clip's steady level.
Static overlay areas (burned-in captions, logos) should be masked with --mask (normalized x,y,w,h) or are
taken from captions.json automatically when present next to cuts.json.

Writes <analysis_dir>/motion/<cut_id>.json (per-frame curve) and adds a compact "motion" block to each cut in
cuts.json: detected keyframes (piecewise-linear fit), inferred easing, and a preset guess
(static / zoom_in / zoom_out / pan_left / pan_right / pan_up / pan_down / ken_burns / rotate / shake / camera_motion).
Content that moves by itself (real camera footage) shows up as noisy, low-inlier motion: flagged "camera_motion".
"""
from __future__ import annotations

import argparse
import math
from pathlib import Path

import cv2
import numpy as np

from common import iter_frames, parse_range, read_json, write_json


def make_mask(w, h, rects):
    m = np.full((h, w), 255, np.uint8)
    for x, y, rw, rh in rects:
        x0, y0 = int(x * w), int(y * h)
        m[max(0, y0 - 4):min(h, y0 + int(rh * h) + 4), max(0, x0 - 4):min(w, x0 + int(rw * w) + 4)] = 0
    return m


def estimate(prev, cur, mask, orb, bf, feats=None, state=None):
    """Return (2x3 similarity transform mapping prev->cur, inlier_ratio, method).

    feats: (keypoints, descriptors) of prev from the previous call, so ORB runs once per frame.
    state: dict carried across calls; receives the current frame's features.
    ECC stays at tracking resolution from identity: half-size and warm-started ECC were measured to shift
    the transforms by several px on flat illustrations, so they are not used."""
    state = state if state is not None else {}
    k1, d1 = feats if feats is not None else orb.detectAndCompute(prev, mask)
    k2, d2 = orb.detectAndCompute(cur, mask)
    state["feats"] = (k2, d2)
    if d1 is not None and d2 is not None and len(k1) >= 12 and len(k2) >= 12:
        matches = bf.match(d1, d2)
        if len(matches) >= 12:
            p1 = np.float32([k1[m.queryIdx].pt for m in matches])
            p2 = np.float32([k2[m.trainIdx].pt for m in matches])
            M, inl = cv2.estimateAffinePartial2D(p1, p2, method=cv2.RANSAC, ransacReprojThreshold=2.0,
                                                 maxIters=2000, confidence=0.995)
            if M is not None and inl is not None:
                ratio = float(inl.sum()) / len(matches)
                if ratio > 0.25 and inl.sum() >= 10:
                    return M, ratio, "orb"
    try:  # low texture (flat illustrations, gradients): ECC on intensities
        warp = np.eye(2, 3, dtype=np.float32)
        crit = (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 60, 1e-5)
        _, warp = cv2.findTransformECC(prev.astype(np.float32), cur.astype(np.float32), warp,
                                       cv2.MOTION_AFFINE, crit, mask, 3)
        a, b = warp[0, 0], warp[1, 0]
        s = math.hypot(a, b)
        th = math.atan2(b, a)
        M = np.array([[s * math.cos(th), -s * math.sin(th), warp[0, 2]],
                      [s * math.sin(th), s * math.cos(th), warp[1, 2]]], np.float32)
        return M, 0.5, "ecc"
    except cv2.error:
        return None, 0.0, "fail"


def to3(M):
    return np.vstack([M, [0, 0, 1]]).astype(np.float64)


def decompose(T, w, h):
    """Cumulative transform -> scale, rotation (deg), and translation of the frame centre (normalized)."""
    a, b = T[0, 0], T[1, 0]
    s = math.hypot(a, b)
    rot = math.degrees(math.atan2(b, a))
    c = T @ np.array([w / 2, h / 2, 1.0])
    return s, rot, (c[0] - w / 2) / w, (c[1] - h / 2) / h


def rdp(points, eps):
    """Ramer-Douglas-Peucker on (t, v) points; returns indices of kept points."""
    if len(points) < 3:
        return list(range(len(points)))
    pts = np.asarray(points, float)
    keep = [0, len(pts) - 1]

    def rec(i, j):
        if j <= i + 1:
            return
        p, q = pts[i], pts[j]
        seg = q - p
        n = np.hypot(*seg) or 1e-9
        rel = pts[i + 1:j] - p
        d = np.abs(seg[0] * rel[:, 1] - seg[1] * rel[:, 0]) / n
        k = int(np.argmax(d))
        if d[k] > eps:
            m = i + 1 + k
            keep.append(m)
            rec(i, m)
            rec(m, j)

    rec(0, len(pts) - 1)
    return sorted(set(keep))


def easing_of(t, v):
    """Classify a monotone segment's easing from where the change happens."""
    if len(v) < 5 or abs(v[-1] - v[0]) < 1e-6:
        return "linear"
    u = (np.asarray(v) - v[0]) / (v[-1] - v[0])
    x = (np.asarray(t) - t[0]) / ((t[-1] - t[0]) or 1)
    mid = float(np.interp(0.5, x, u))
    q1 = float(np.interp(0.25, x, u))
    q3 = float(np.interp(0.75, x, u))
    if abs(mid - 0.5) < 0.07 and abs(q1 - 0.25) < 0.08:
        return "linear"
    if mid > 0.6 and q1 > 0.35:
        return "ease_out"
    if mid < 0.4 and q3 < 0.65:
        return "ease_in"
    if q1 < 0.2 and q3 > 0.8:
        return "ease_in_out"
    return "custom"


def keyframes(t, v, eps, min_delta):
    if len(v) < 2 or (max(v) - min(v)) < min_delta:
        return [{"t": round(t[0], 3), "v": round(float(np.median(v)), 4)}], []
    pts = list(zip(np.asarray(t) / max(t[-1] - t[0], 1e-6), np.asarray(v) / max(max(v) - min(v), 1e-6)))
    idx = rdp(pts, eps)
    kfs = [{"t": round(t[i], 3), "v": round(float(v[i]), 4)} for i in idx]
    segs = []
    for i, j in zip(idx, idx[1:]):
        segs.append({"from_t": round(t[i], 3), "to_t": round(t[j], 3),
                     "easing": easing_of(t[i:j + 1], v[i:j + 1])})
    return kfs, segs


def preset(sc, px, py, rot, jitter, inlier):
    ds = sc[-1] - sc[0]
    dx, dy = px[-1] - px[0], py[-1] - py[0]
    if inlier < 0.35:
        return "camera_motion"
    if jitter > 0.004:
        return "shake"
    moves = []
    if abs(ds) > 0.015:
        moves.append("zoom_in" if ds > 0 else "zoom_out")
    if abs(dx) > 0.01 or abs(dy) > 0.01:
        if abs(dx) >= abs(dy):
            moves.append("pan_right" if dx > 0 else "pan_left")
        else:
            moves.append("pan_down" if dy > 0 else "pan_up")
    if abs(rot[-1] - rot[0]) > 0.8:
        moves.append("rotate")
    if not moves:
        return "static"
    if len(moves) >= 2 and moves[0].startswith("zoom"):
        return "ken_burns"
    return moves[0]


def track_cut(video, cut, fps, width, step, mask_rects):
    f0, f1 = cut["start_frame"], cut["end_frame"]
    bi = cut.get("boundary_in") or {}
    if bi.get("auto_type", "cut") != "cut":
        f0 = min(max(f0, bi.get("end_frame", f0) + 1), f1 - 1)
    orb = cv2.ORB_create(1500, fastThreshold=10)
    bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
    T = np.eye(3)
    prev = None
    mask = None
    rows = []
    base_luma = None
    first = None
    T_first = None
    raw_diffs = []
    est_state = {}
    for idx, frame in iter_frames(video, f0, f1, step=step, width=width):
        g = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        if mask is None:
            mask = make_mask(g.shape[1], g.shape[0], mask_rects)
        luma = float(g[mask > 0].mean())
        if prev is not None:
            raw_diffs.append(float(np.abs(g.astype(np.int16) - prev.astype(np.int16))[mask > 0].mean()))
        if prev is None:
            first = g
            est_state["feats"] = orb.detectAndCompute(g, mask)
            rows.append({"f": idx, "t": 0.0, "scale": 1.0, "x": 0.0, "y": 0.0, "rot": 0.0, "luma": luma,
                         "inlier": 1.0, "method": "ref", "residual": 0.0})
        else:
            M, ratio, method = estimate(prev, g, mask, orb, bf, est_state.get("feats"), est_state)
            residual = None
            if M is not None:
                T = to3(M) @ T
                # content change not explained by the layer transform: ~0 for a still image with keyframes,
                # high for generated/filmed footage where things move inside the frame
                warped = cv2.warpAffine(prev, M, (g.shape[1], g.shape[0]), flags=cv2.INTER_LINEAR,
                                        borderMode=cv2.BORDER_REFLECT)
                valid = cv2.warpAffine(mask, M, (g.shape[1], g.shape[0]), flags=cv2.INTER_NEAREST) > 0
                valid &= mask > 0
                if valid.any():
                    residual = round(float(np.abs(warped.astype(np.int16) - g.astype(np.int16))[valid].mean()), 3)
            s, r, x, y = decompose(T, g.shape[1], g.shape[0])
            rows.append({"f": idx, "t": round((idx - f0) / fps, 4), "scale": round(s, 5), "x": round(x, 5),
                         "y": round(y, 5), "rot": round(r, 4), "luma": round(luma, 2), "inlier": round(ratio, 3),
                         "method": method, "residual": residual})
        prev = g
    # long-range residual: first frame warped by the chained transform vs the last frame
    long_res = None
    if first is not None and prev is not None and len(rows) > 2:
        Wf = T[:2].astype(np.float32)
        warped = cv2.warpAffine(first, Wf, (prev.shape[1], prev.shape[0]), borderMode=cv2.BORDER_CONSTANT, borderValue=0)
        valid = cv2.warpAffine(np.full_like(first, 255), Wf, (prev.shape[1], prev.shape[0])) > 0
        valid &= mask > 0
        if valid.any():
            long_res = round(float(np.abs(warped.astype(np.int16) - prev.astype(np.int16))[valid].mean()), 3)
    if not rows:
        return None, None
    lumas = np.array([r["luma"] for r in rows])
    base_luma = float(np.percentile(lumas, 80)) or 1.0
    for r in rows:
        r["opacity_est"] = round(min(1.0, r["luma"] / base_luma), 3)
    t = [r["t"] for r in rows]
    sc = [r["scale"] for r in rows]
    px = [r["x"] for r in rows]
    py = [r["y"] for r in rows]
    rot = [r["rot"] for r in rows]
    op = [r["opacity_est"] for r in rows]
    inl = float(np.median([r["inlier"] for r in rows[1:]])) if len(rows) > 1 else 1.0
    jitter = 0.0
    if len(px) > 6:
        jitter = float(np.std(np.diff(np.diff(np.asarray(px) + np.asarray(py)))))
    comp = {}
    for name, series, eps, md in (("scale", sc, 0.06, 0.01), ("x", px, 0.06, 0.006), ("y", py, 0.06, 0.006),
                                  ("rotation_deg", rot, 0.06, 0.5), ("opacity", op, 0.1, 0.15)):
        kfs, segs = keyframes(t, series, eps, md)
        comp[name] = {"keyframes": kfs, "segments": segs, "start": round(series[0], 4), "end": round(series[-1], 4),
                      "min": round(min(series), 4), "max": round(max(series), 4)}
    dur = max(t[-1], 1e-6)
    summary = {
        "measured_from_frame": f0, "step": step, "track_width": width, "median_inlier": round(inl, 3),
        "preset_guess": preset(sc, px, py, rot, jitter, inl),
        "cadence": cadence(raw_diffs, fps, step),
        "residual_median": round(float(np.median([r["residual"] for r in rows[1:] if r.get("residual") is not None] or [0])), 3),
        "residual_first_to_last": long_res,
        "residual_note": "per-frame and first->last pixel error after removing the layer transform (0-255 scale). "
                         "still image + keyframes: ~<1.5 per frame and <6 first->last; generated/filmed footage: higher",
        "scale_rate_per_s": round((sc[-1] - sc[0]) / dur, 5),
        "x_rate_per_s": round((px[-1] - px[0]) / dur, 5), "y_rate_per_s": round((py[-1] - py[0]) / dur, 5),
        "jitter": round(jitter, 5), "components": comp,
        "note": "scale/x/y are relative to the first measured frame; x,y = frame-centre displacement / frame size",
    }
    cd = summary["cadence"]
    if cd and cd["holds_ratio"] > 0.15:
        # the picture is frozen on held frames, so nothing (no layer keyframe) moves between source frames:
        # the measured motion is baked into the source footage, which was retimed to fit the cut
        summary["motion_origin"] = "in_source"
    elif inl >= 0.35:
        summary["motion_origin"] = "edit_keyframes_or_native_rate_source"
    else:
        summary["motion_origin"] = "in_source"
    return summary, rows


def cadence(diffs, fps, step, native=(24.0, 30.0, 25.0)):
    """Unique-frame cadence inside a clip. Held (duplicated) frames show up as near-zero differences.
    Returns unique frames/s, hold ratio and, per candidate native frame rate, the implied playback speed and
    source clip length. Only meaningful with step=1."""
    if step != 1 or len(diffs) < 10:
        return None
    d = np.asarray(diffs)
    hi = float(np.percentile(d, 90))
    lo = float(np.percentile(d, 10))
    thr = lo + 0.35 * (hi - lo) if hi > 0.3 else 0.15
    changes = int((d > thr).sum())
    dur = len(d) / fps
    ups = changes / dur if dur else 0.0
    out = {"unique_frames": changes + 1, "unique_per_s": round(ups, 2), "holds_ratio": round(float((d <= thr).mean()), 3),
           "threshold": round(thr, 3), "clip_s": round(dur, 3)}
    if out["holds_ratio"] > 0.15:
        out["retime"] = {f"{int(n)}fps": {"speed": round(ups / n, 3), "source_len_s": round((changes + 1) / n, 2)}
                         for n in native if ups <= n * 1.05}
    return out


def _track_star(args):
    cv2.setNumThreads(1)
    return track_cut(*args)


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("video")
    ap.add_argument("--cuts", required=True)
    ap.add_argument("--ids", nargs="*")
    ap.add_argument("--range", help="only cuts starting inside START:END seconds")
    ap.add_argument("--step", type=int, default=1, help="frame step (1 = every frame; use 2-3 outside the pilot 30s)")
    ap.add_argument("--width", type=int, default=480)
    ap.add_argument("--mask", nargs="*", default=[], help="normalized x,y,w,h rects to ignore")
    ap.add_argument("--workers", type=int, default=4, help="cuts tracked in parallel processes")
    a = ap.parse_args()
    cpath = Path(a.cuts)
    doc = read_json(cpath)
    fps = doc["video"]["fps"]
    rects = [tuple(float(v) for v in m.split(",")) for m in a.mask]
    cap_path = cpath.parent / "captions.json"
    if cap_path.exists():
        cap = read_json(cap_path)
        for z in cap.get("zones", []):
            rects.append(tuple(z["bbox"]))
    lo, hi = parse_range(a.range, doc["video"]["duration_s"]) if a.range else (0, 1e9)
    mdir = cpath.parent / "motion"
    n = 0
    todo = [c for c in doc["cuts"] if (not a.ids or c["id"] in a.ids) and lo <= c["start_s"] < hi
            and c["duration_frames"] >= 3]
    # cuts are independent: track them in worker processes (OpenCV ECC/ORB are single-threaded per call)
    from concurrent.futures import ProcessPoolExecutor
    args = [(doc["video"]["path"], c, fps, a.width, a.step, rects) for c in todo]
    if a.workers > 1 and len(todo) > 1:
        cv2.setNumThreads(1)
        with ProcessPoolExecutor(max_workers=a.workers) as ex:
            results = list(ex.map(_track_star, args))
    else:
        results = [_track_star(x) for x in args]
    for c, (summary, rows) in zip(todo, results):
        if summary is None:
            continue
        write_json(mdir / f"{c['id']}.json", {"cut_id": c["id"], "fps": fps, "frames": rows})
        c["motion"] = summary
        n += 1
        cs = summary["components"]
        print(f"{c['id']} {summary['preset_guess']:<13} scale {cs['scale']['start']:.3f}->{cs['scale']['end']:.3f} "
              f"x {cs['x']['end']:+.3f} y {cs['y']['end']:+.3f} rot {cs['rotation_deg']['end']:+.2f} "
              f"inlier {summary['median_inlier']:.2f}")
    write_json(cpath, doc)
    print(f"tracked {n} cuts -> {mdir}")


if __name__ == "__main__":
    main()
