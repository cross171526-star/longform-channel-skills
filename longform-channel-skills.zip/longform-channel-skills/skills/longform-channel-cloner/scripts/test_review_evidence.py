import json,os,subprocess,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from PIL import Image
from work_guard import digest
from revision_graph import generate
from review_evidence import plan,record,checked_record,validate_current
from quality_contract import validate,guard_tool

class EarlyReview(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.p=Path(self.temp.name).resolve()
  self.patch=patch.dict(os.environ,{'LFC_RUNTIME_HOME':str(self.p/'isolated')});self.patch.start();self.addCleanup(self.patch.stop)
  self.public=self.p/'public';self.public.mkdir()
  for i in range(5):Image.new('RGB',(32,18),(0,0,255)).save(self.public/f'{i}.png')
  self.script=self.write('script.json',{'lines':[{'id':str(i),'text':'fixture full script'} for i in range(5)]})
  self.evidence=self.write('evidence.json',{'observed':'technical fixture, not content approval'})
  self.log=self.p/'reviewer.jsonl';self.log.write_text(json.dumps({'type':'session_meta','payload':{'id':'independent'}})+'\n'+json.dumps({'type':'turn_context','payload':{'model':'gpt-6.1-sol','effort':'high'}})+'\n')
  self.contract=self.make_contract();self.clips=[self.media(f'pilot{i}.mp4',10) for i in range(3)]
  producer=self.write('producer.json',{'passed':True,'kind':'pilot_actual_output_not_content_approval','contract_sha256':digest(self.contract),'fps':1,'output_sha256':{str(p):digest(p) for p in self.clips},'samples':[{'cut_id':k,'absolute_frames_inclusive':[a,a+9],'render':self.bind(p)} for k,a,p in zip(['0','2','4'],[0,20,40],self.clips)]})
  self.pilot=self.write('pilot-review.json',{'reviewer_rollout':str(self.log),'session_id':'independent','implementation_session_ids':['producer'],'contract_sha256':digest(self.contract),'observed_cut_ids':['0','2','4'],'direct_observation':True,'visual_passed':True,'script_passed':True,'unresolved_items':[],'pilot_render_report':self.bind(producer),'render_evidence':[self.bind(p) for p in self.clips],'front_review':{'full_script_sha256':digest(self.script),'complete_script_reviewed':True,'script_passed':True,'material_cut_ids':[str(i) for i in range(5)],'materials_passed':True,'unresolved_items':[],'evidence':[self.bind(self.evidence)]}})
  self.props=self.write('props.json',{'fps':1,'width':32,'height':18,'duration_s':50,'cuts':[{'id':str(i),'start_s':i*10,'end_s':i*10+10,'asset':{'file':f'{i}.png','kind':'image'}} for i in range(5)]})
  self.tts=self.write('tts.json',{'lines':[]});self.graph=self.make_graph('v1');self.render=self.media('actual-final.mp4',50)
 def bind(self,p):return {'path':str(p),'sha256':digest(p)}
 def write(self,name,value):
  p=self.p/name;p.write_text(json.dumps(value));return p
 def media(self,name,duration):
  p=self.p/name;subprocess.run([str(Path.home()/'.longform-cloner/bin/ffmpeg'),'-v','error','-f','lavfi','-i',f'color=c=blue:s=32x18:r=1:d={duration}','-c:v','libx264',str(p)],check=True);return p
 def make_contract(self):
  cuts=[{'id':str(i),'visual_role':'diagram','narrative_role':'evidence','ink_geometry':[1,2,3,4],'texture':'paint','anchors':{'figure':'center'},'before':'enter','middle':'hold','after':'exit','material_role':'actual source','visual_evidence':[self.bind(self.evidence)],'script_evidence':[self.bind(self.script)],'reference_states':{k:self.bind(self.public/f'{i}.png') for k in ('before','middle','after')},'claims':[],'unresolved_items':[]} for i in range(5)]
  return self.write('contract.json',{'schema':'lfc-cut-contract-v1','full_script':self.bind(self.script),'complete_cut_ids':[str(i) for i in range(5)],'cuts':cuts,'pilot':{'samples':[{'cut_id':str(i),'risk_reason':'hard actual motion','absolute_range_s':[i*10,i*10+10],'line_ids':[str(i)]} for i in (0,2,4)]}})
 def make_graph(self,name):
  full=self.write(name+'-full.json',{'tts':{'timeline':str(self.tts)},'output_scope':{'kind':'full'},'render_timing':{'props':str(self.props)},'render_inputs':[]})
  preview=self.write(name+'-preview.json',{'tts':{'timeline':str(self.tts)},'output_scope':{'kind':'preview','full_plan':str(full)},'render_timing':{'props':str(self.props)},'render_inputs':[]})
  spec=self.write(name+'-spec.json',{'schema':'lfc-revision-spec-v1','revision':name,'artifacts':[{'id':'props','role':'props','path':str(self.props)},{'id':'tts','role':'narration','path':str(self.tts)}],'scopes':[{'id':'full','template':str(full)},{'id':'preview','template':str(preview)}]})
  generate(spec,self.p/name);return self.p/name/'graph.json'
 def make_record(self,plan_path,name='record.json',**change):
  p=json.loads(plan_path.read_text());j={'reviewer_rollout':str(self.log),'session_id':'independent','implementation_session_ids':['producer'],'plan_sha256':digest(plan_path),'render_sha256':digest(self.render),'direct_observation':True,'full_integration_passed':True,'unresolved_items':[],'observed_cut_ids':p['required_cut_ids'],'reused_cut_ids':p['reusable_cut_ids'],'integration_evidence':[self.bind(self.evidence)],'cut_evidence':{k:[self.bind(self.evidence)] for k in p['required_cut_ids']},**change}
  judge=self.write(name+'-judgment.json',j);out=self.p/name;record(plan_path,self.render,judge,out);return out
 def test_first_render_pilot_is_not_all_cut_approval(self):
  p=plan(self.contract,self.pilot,self.graph);self.assertEqual(p['required_cut_ids'],[str(i) for i in range(5)]);self.assertEqual(p['reusable_cut_ids'],[]);self.assertTrue(p['requires_current_full_integration']);self.assertFalse(p['content_approved'])
  pp=self.write('plan.json',p);rr=self.make_record(pp);self.assertTrue(validate_current(rr,self.render)['passed'])
 def test_front_missing_scope_script_or_failed_judgment_blocks(self):
  original=json.loads(self.pilot.read_text())
  for bad in ({},{'material_cut_ids':['0','2','4']},{'script_passed':False},{'full_script_sha256':'wrong'}):
   value=json.loads(json.dumps(original));value['front_review']=bad if not bad else {**value['front_review'],**bad};self.pilot.write_text(json.dumps(value))
   self.assertFalse(validate(self.contract,self.pilot,require_front=True)['passed'])
  self.pilot.write_text(json.dumps(original))
 def test_local_cut_change_rechecks_neighbors_preserves_other_judgments(self):
  pp=self.write('plan.json',plan(self.contract,self.pilot,self.graph));old=self.make_record(pp)
  data=json.loads(self.props.read_text());data['cuts'][2]['animation']={'enter':'paint'};self.props.write_text(json.dumps(data));new=self.make_graph('v2')
  p=plan(self.contract,self.pilot,new,previous=old);self.assertEqual(p['affected_cut_ids'],['2']);self.assertEqual(p['required_cut_ids'],['1','2','3']);self.assertEqual(p['reusable_cut_ids'],['0','4']);self.assertTrue(p['requires_current_listening_playback_sync_transitions_flow'])
  pp2=self.write('plan2.json',p);updated=self.make_record(pp2,'record2.json');self.assertTrue(validate_current(updated,self.render)['passed'])
 def test_shared_asset_and_global_narration_affect_all_usage(self):
  pp=self.write('plan.json',plan(self.contract,self.pilot,self.graph));old=self.make_record(pp)
  self.tts.write_text('{"lines":["changed whole narration"]}');new=self.make_graph('v2')
  p=plan(self.contract,self.pilot,new,previous=old);self.assertEqual(p['required_cut_ids'],[str(i) for i in range(5)]);self.assertEqual(p['reusable_cut_ids'],[])
 def test_cut_time_shift_can_affect_far_cuts_and_requires_full_scope(self):
  pp=self.write('plan.json',plan(self.contract,self.pilot,self.graph));old=self.make_record(pp)
  data=json.loads(self.props.read_text());data['cuts'][2]['start_s']=40;data['cuts'][2]['end_s']=50;self.props.write_text(json.dumps(data));new=self.make_graph('v2')
  changed=plan(self.contract,self.pilot,new,previous=old)
  self.assertEqual(changed['reusable_cut_ids'],[]);self.assertEqual(changed['required_cut_ids'],[str(i) for i in range(5)])
 def test_content_contract_change_even_same_graph_rechecks_touched_scope(self):
  pp=self.write('plan.json',plan(self.contract,self.pilot,self.graph));old=self.make_record(pp)
  data=json.loads(self.contract.read_text());data['cuts'][2]['material_role']='illustration only, not event proof';self.contract.write_text(json.dumps(data))
  pilot=json.loads(self.pilot.read_text());pilot['contract_sha256']=digest(self.contract)
  producer=Path(pilot['pilot_render_report']['path']);source=json.loads(producer.read_text());source['contract_sha256']=digest(self.contract);producer.write_text(json.dumps(source));pilot['pilot_render_report']=self.bind(producer);self.pilot.write_text(json.dumps(pilot))
  changed=plan(self.contract,self.pilot,self.graph,previous=old)
  self.assertEqual(changed['required_cut_ids'],['1','2','3']);self.assertEqual(changed['reusable_cut_ids'],['0','4'])
 def test_invalid_or_self_approval_incomplete_output_never_reused(self):
  pp=self.write('plan.json',plan(self.contract,self.pilot,self.graph))
  for i,kwargs in enumerate(({'full_integration_passed':False},{'observed_cut_ids':['0','2','4']},{'implementation_session_ids':['independent']},{'integration_evidence':[]},{'unresolved_items':['not reviewed']})):
   with self.assertRaises(ValueError):self.make_record(pp,f'bad{i}.json',**kwargs)
  old=self.make_record(pp);r=json.loads(old.read_text());r['passed']=False;old.write_text(json.dumps(r))
  with self.assertRaises(ValueError):plan(self.contract,self.pilot,self.graph,previous=old)
 def test_changed_front_facts_even_same_render_block_stale_record(self):
  pp=self.write('plan.json',plan(self.contract,self.pilot,self.graph));old=self.make_record(pp)
  self.script.write_text('{"lines":["changed causal or factual content"]}')
  with self.assertRaises(ValueError):validate_current(old,self.render)
 def test_new_bulk_tts_needs_full_front_judgment_existing_run_compatible(self):
  run=self.p/'run';run.mkdir();(run/'work').mkdir();self.write('run/run.json',{'scheduler_version':3,'front_review_version':1})
  (run/'work/quality-contract.json').write_bytes(self.contract.read_bytes());(run/'work/pilot-review.json').write_bytes(self.pilot.read_bytes())
  # Absolute bindings survive handoff; all content decisions remain the independent record.
  lines=self.write('all-lines.json',[{'id':'outside-pilot','text':'complete'}]);guard_tool(run,'tts',['--lines',str(lines)])
  r=json.loads(self.pilot.read_text());r.pop('front_review');(run/'work/pilot-review.json').write_text(json.dumps(r))
  with self.assertRaises(ValueError):guard_tool(run,'tts',['--lines',str(lines)])
  (run/'run.json').write_text('{"scheduler_version":3}');guard_tool(run,'tts',['--lines',str(lines)])

if __name__=='__main__':unittest.main()
