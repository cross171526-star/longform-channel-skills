"""제작 게이트의 파일 연결 검증과 결정적 타임라인 빌더. 렌더 실행 증명은 아니다."""
import copy
import hashlib
import json
import math
from pathlib import Path
from plan_duration import plan_duration
from timing_contract import reference_background, duration_preflight

WINDOW_KEYS = ('line_id', 'cut_ids', 'allowed_start_s', 'allowed_end_s')


def canonical(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                     allow_nan=False).encode()).hexdigest()


def finite(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def identifier(value):
    return isinstance(value, str) and bool(value.strip())


def cut_bounds(manifest):
    cursor, bounds = 0, {}
    for cut in manifest['cuts']:
        value = cut['duration_s']
        if not finite(value) or value <= 0:
            raise ValueError('Invalid cut duration')
        bounds[cut['id']] = (cursor, cursor + value)
        cursor += value
    return bounds, cursor


def validate_windows(baseline, manifest):
    windows = baseline.get('narration_windows')
    if not isinstance(windows, list) or not windows:
        raise ValueError('Missing baseline.narration_windows')
    bounds, _ = cut_bounds(manifest)
    seen = set()
    for window in windows:
        if not isinstance(window, dict) or not identifier(window.get('line_id')):
            raise ValueError('Invalid baseline narration line_id')
        line_id = window['line_id']
        if line_id in seen:
            raise ValueError('Duplicate baseline narration line_id')
        seen.add(line_id)
        cuts = window.get('cut_ids')
        if (not isinstance(cuts, list) or not cuts or not all(identifier(c) for c in cuts)
                or len(set(cuts)) != len(cuts) or any(c not in bounds for c in cuts)):
            raise ValueError('Invalid baseline narration cut_ids')
        start, end = window.get('allowed_start_s'), window.get('allowed_end_s')
        if not finite(start) or not finite(end) or start < 0 or end <= start:
            raise ValueError('Invalid baseline narration window interval')
        spans = []
        for a, b in sorted(bounds[c] for c in cuts):
            if spans and a <= spans[-1][1]:
                spans[-1] = (spans[-1][0], max(b, spans[-1][1]))
            else:
                spans.append((a, b))
        if not any(start >= a and end <= b for a, b in spans):
            raise ValueError('Baseline narration window outside referenced cuts')
    return {w['line_id']: w for w in windows}


def validate_duration(manifest, load, file_hash, baseline):
    link = manifest.get('duration_link')
    if not isinstance(link, dict):
        raise ValueError('Missing duration_link')
    docs = {}
    for key in ('selected6', 'input', 'plan'):
        if not identifier(link.get(key)):
            raise ValueError('Missing duration_link.' + key)
        docs[key] = load(link[key])
    source_hash = file_hash(link['input'])
    computed = plan_duration(docs['input'], source_hash)
    authoritative = plan_duration(docs['selected6'], file_hash(link['selected6']))
    # Selection order is immaterial; IDs and durations are exact, without rounding.
    if sorted(computed['references'], key=lambda r: r['id']) != sorted(authoritative['references'], key=lambda r: r['id']):
        raise ValueError('Duration input differs from authoritative selected6 IDs/durations')
    if canonical(docs['plan']) != canonical(computed):
        raise ValueError('Duration plan differs from recomputed plan / source hash')
    _, full_duration = cut_bounds(manifest)
    target = computed['target_duration_s']
    delta = full_duration - target
    reference_clips = [reference_background(cut, load) for cut in baseline['cuts']]
    selected6_hash = file_hash(link['selected6'])
    preflight = duration_preflight(manifest, baseline, reference_clips, target,
                                   full_duration, selected6_hash,
                                   file_hash(manifest['baseline']), load,
                                   tolerance_s=computed.get('full_duration_tolerance_s'))
    report = {'selected6': link['selected6'], 'input': link['input'], 'plan': link['plan'],
              'source_input_sha256': source_hash, 'selected6_sha256': selected6_hash,
              'target_duration_s': target, 'full_planned_duration_s': full_duration,
              'delta_s': delta, 'reference_clips': reference_clips, 'preflight': preflight}
    return report


def validate_scope(manifest, root, duration, load):
    scope = manifest.get('output_scope', {'kind': 'full'})
    if not isinstance(scope, dict) or scope.get('kind') not in ('full', 'preview'):
        raise ValueError('Invalid output_scope')
    end = duration['full_planned_duration_s']
    if scope['kind'] == 'full':
        if set(scope) != {'kind'}:
            raise ValueError('Full output_scope must only declare kind')
        return {'start_s': 0, 'end_s': end}
    if not identifier(scope.get('full_plan')):
        raise ValueError('Preview needs output_scope.full_plan')
    start, stop = scope.get('start_s'), scope.get('end_s')
    # 목표 길이 기준의 잠정 범위가 아닌 실제 본편 길이로 끝점을 제한한다.
    if not finite(start) or not finite(stop) or start != 0 or not min(170, end) <= stop <= min(210, end):
        raise ValueError('Preview must start at 0 and end within min(170, full_planned_duration_s)..min(210, full_planned_duration_s) seconds')
    full = load(scope['full_plan'])
    if full.get('output_scope', {'kind': 'full'}) != {'kind': 'full'}:
        raise ValueError('Preview full_plan must have full output scope')
    full_root = (root / scope['full_plan']).resolve().parent
    for key in ('structure_id', 'canvas', 'cuts'):
        if full.get(key) != manifest.get(key):
            raise ValueError('Preview differs from full_plan: ' + key)
    if full.get('event_observations') != manifest.get('event_observations'):
        raise ValueError('Preview differs from full_plan event_observations')
    ignored = {'timeline', 'narration_metadata'}
    if {k: v for k, v in full.get('tts', {}).items() if k not in ignored} != {k: v for k, v in manifest['tts'].items() if k not in ignored}:
        raise ValueError('Preview differs from full_plan TTS policy')
    # Resolve paths in their respective manifests rather than accepting equal strings.
    for key in ('baseline', 'visual_acceptance'):
        if (full_root / full.get(key, '')).resolve() != (root / manifest[key]).resolve():
            raise ValueError('Preview differs from full_plan: ' + key)
    full_link = full.get('duration_link', {})
    for key in ('selected6', 'input', 'plan'):
        if (full_root / full_link.get(key, '')).resolve() != (root / manifest['duration_link'][key]).resolve():
            raise ValueError('Preview differs from full_plan duration_link.' + key)
    # 결정 근거도 동일한 파일·항목이어야 하며 프리뷰에서 예외를 바꿀 수 없다.
    decision, full_decision = manifest['duration_link'].get('decision'), full_link.get('decision')
    if (decision is None) != (full_decision is None):
        raise ValueError('Preview differs from full_plan duration decision')
    if decision is not None:
        if ((root / decision['file']).resolve() != (full_root / full_decision['file']).resolve()
                or decision['pointer'] != full_decision['pointer']):
            raise ValueError('Preview differs from full_plan duration decision')
    return {'start_s': start, 'end_s': stop}


def output_clip(start, end, bounds):
    a, b = max(start, bounds['start_s']), min(end, bounds['end_s'])
    return {'start_s': a, 'end_s': b} if b > a else None


def build_expected_timeline(source, manifest, baseline, fingerprint, source_hash, output_bounds, timeline=None):
    """검사기·컴파일러가 동일하게 호출하는 순수 결정적 빌더."""
    cursor, cuts = 0, []
    for source_cut in manifest['cuts']:
        cut = copy.deepcopy(source_cut)
        cut['start_s'], cut['end_s'] = cursor, cursor + cut['duration_s']
        cursor = cut['end_s']
        cut['output_clip'] = output_clip(cut['start_s'], cut['end_s'], output_bounds)
        cuts.append(cut)
    result = {'schema_version': 2, 'source_manifest': str(source),
            'source_manifest_sha256': source_hash, 'source_root': str(source.parent),
            'plan_input_sha256': fingerprint, 'structure_id': manifest['structure_id'],
            'canvas': manifest['canvas'], 'output_scope': manifest.get('output_scope', {'kind': 'full'}),
            'output_bounds': output_bounds, 'duration_s': cursor,
            'output_duration_s': output_bounds['end_s'] - output_bounds['start_s'],
            'narration_windows': copy.deepcopy(baseline['narration_windows']),
            'cuts': cuts, 'tts': copy.deepcopy(manifest['tts']),
            'narration_segments': copy.deepcopy(timeline.get('segments', [])) if isinstance(timeline, dict) else []}
    # 관찰 이벤트는 배경 클립과 별도이며 이벤트 간격을 ±20%로 검사하지 않는다.
    if 'event_observations' in manifest:
        result['event_observations'] = copy.deepcopy(manifest['event_observations'])
    return result


def validate_acceptance(baseline, acceptance, evidence):
    required = baseline.get('required_visual_rule_ids')
    if (not isinstance(required, list) or not required or not all(identifier(r) for r in required)
            or len(set(required)) != len(required)):
        raise ValueError('Missing/invalid baseline.required_visual_rule_ids')
    if not isinstance(acceptance, dict) or acceptance.get('tolerance_status') not in ('provisional', 'confirmed'):
        raise ValueError('Invalid visual_acceptance.tolerance_status')
    rules = acceptance.get('rules')
    if not isinstance(rules, list) or not rules:
        raise ValueError('Missing visual_acceptance rules')
    ids = []
    for rule in rules:
        if not isinstance(rule, dict) or not identifier(rule.get('id')):
            raise ValueError('Invalid visual_acceptance rule ID')
        ids.append(rule['id'])
        cut_ids = rule.get('cut_ids')
        known = {c['id'] for c in baseline['cuts']}
        if (not isinstance(cut_ids, list) or not cut_ids or not all(identifier(c) for c in cut_ids)
                or len(set(cut_ids)) != len(cut_ids) or not set(cut_ids) <= known):
            raise ValueError('Invalid visual_acceptance rule cut_ids scope')
        evidence(rule['evidence'])
        metrics = rule.get('metrics')
        if not isinstance(metrics, list) or not metrics:
            raise ValueError('Missing visual_acceptance metrics')
        names = []
        for metric in metrics:
            if not isinstance(metric, dict) or not identifier(metric.get('id')) or not identifier(metric.get('unit')):
                raise ValueError('Invalid visual_acceptance metric ID/unit')
            names.append(metric['id'])
            if not finite(metric.get('target')) or not finite(metric.get('tolerance')) or metric['tolerance'] < 0:
                raise ValueError('Invalid visual_acceptance numeric target/tolerance')
        if len(set(names)) != len(names):
            raise ValueError('Duplicate visual_acceptance metric ID')
    if sorted(ids) != sorted(required):
        raise ValueError('Visual acceptance must cover required rule IDs exactly once')
    return rules


def validate_measurements(measurements, rules, fingerprint, render_hash, acceptance_hash, evidence):
    if not isinstance(measurements, dict):
        raise ValueError('Missing conformance.visual_measurements')
    if measurements.get('status') != 'pass':
        raise ValueError('Visual measurements not passed')
    for key, value in (('input_sha256', fingerprint), ('render_sha256', render_hash),
                       ('visual_acceptance_sha256', acceptance_hash)):
        if measurements.get(key) != value:
            raise ValueError('Stale visual measurements: ' + key)
    measured = measurements.get('rules')
    if not isinstance(measured, list) or any(not isinstance(r, dict) or not identifier(r.get('rule_id')) for r in measured):
        raise ValueError('Missing/invalid visual measurements rules')
    if sorted(r['rule_id'] for r in measured) != sorted(r['id'] for r in rules):
        raise ValueError('Visual measurements must cover required rule IDs exactly once')
    actual = {r['rule_id']: r for r in measured}
    for rule in rules:
        record = actual[rule['id']]
        if record.get('status') != 'pass':
            raise ValueError('Visual rule measurement not passed: ' + rule['id'])
        evidence(record['evidence'])
        metrics = record.get('metrics')
        if not isinstance(metrics, list) or any(not isinstance(r, dict) or not identifier(r.get('id')) for r in metrics):
            raise ValueError('Missing/invalid visual metric measurements')
        if sorted(r['id'] for r in metrics) != sorted(r['id'] for r in rule['metrics']):
            raise ValueError('Visual metric measurements missing/duplicated')
        values = {r['id']: r.get('value') for r in metrics}
        for metric in rule['metrics']:
            value = values[metric['id']]
            if not finite(value) or abs(value - metric['target']) > metric['tolerance'] + 1e-9:
                raise ValueError('Visual metric outside tolerance: ' + rule['id'] + '/' + metric['id'])


def full_narration_segments(manifest, root, windows, load):
    scope = manifest.get('output_scope', {})
    if scope.get('kind') != 'preview':
        return {}
    full_path = (root / scope['full_plan']).resolve()
    full = load(str(full_path))
    name = full.get('tts', {}).get('timeline')
    if not identifier(name):
        raise ValueError('Preview full_plan needs full narration placement timeline')
    source = (full_path.parent / name).resolve()
    if source == (root / manifest['tts'].get('timeline', '')).resolve():
        raise ValueError('Preview timeline must be separate from full_plan placement timeline')
    timeline = load(str(source))
    segments = timeline.get('segments') if isinstance(timeline, dict) else None
    if not isinstance(segments, list) or not segments:
        raise ValueError('Full plan timeline needs narration segments')
    ids, intervals = [], []
    for segment in segments:
        if not isinstance(segment, dict) or not identifier(segment.get('line_id')):
            raise ValueError('Invalid full_plan narration segment')
        line_id = segment['line_id']
        ids.append(line_id)
        if line_id not in windows or canonical({k: segment.get(k) for k in WINDOW_KEYS}) != canonical({k: windows[line_id][k] for k in WINDOW_KEYS}):
            raise ValueError('Full plan narration window differs from baseline')
        a, b = segment.get('start_s'), segment.get('end_s')
        if not finite(a) or not finite(b) or a < segment['allowed_start_s'] or b > segment['allowed_end_s'] or b <= a:
            raise ValueError('Invalid full_plan narration placement interval')
        if not finite(segment.get('playback_rate')) or segment['playback_rate'] != 1 or 'output_clip' in segment:
            raise ValueError('Full plan narration must keep unmodified placement')
        intervals.append((a, b))
    if sorted(ids) != sorted(windows):
        raise ValueError('Full plan narration timeline must cover baseline windows exactly once')
    for previous, current in zip(sorted(intervals), sorted(intervals)[1:]):
        if current[0] < previous[1] - .01 - 1e-9:
            raise ValueError('Full plan narration placements overlap')
    return {s['line_id']: s for s in segments}
