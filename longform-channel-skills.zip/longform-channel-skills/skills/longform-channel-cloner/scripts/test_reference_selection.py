import datetime as dt
import json
from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest
from unittest.mock import patch
from fetch_channel import choose_references, year_boundary, cmd_list

DAY=dt.date(2026,10,1)
def video(vid,day,views,duration=600,**extra):
    return {'id':vid,'title':vid,'upload_date':day,'view_count':views,'duration':duration,**extra}

class ReferenceSelectionTests(unittest.TestCase):
    def test_year_top_and_distinct_newest(self):
        rows=[video('old','20250930',999999),video('a','20251001',1000),video('b','20260101',900),video('c','20260901',800),video('new1','20261001',10),video('new2','20260930',20),video('new3','20260929',30)]
        result=choose_references(rows,DAY,top=3,recent=3)
        self.assertEqual(result['top_views'],['a','b','c'])
        self.assertEqual(result['recent'],['new1','new2','new3'])
        self.assertEqual(result['cutoff'],'2025-10-01')
    def test_thirty_minutes_inclusive_and_above_excluded(self):
        rows=[video('exact','20261001',100,1800),video('too_long','20261001',1000,1800.01)]
        self.assertEqual(choose_references(rows,DAY,top=3,recent=3)['top_views'],['exact'])
    def test_newest_skips_top_and_does_not_repeat(self):
        rows=[video(str(i),f'202609{30-i:02d}',100-i) for i in range(6)]
        result=choose_references(rows+[rows[0]],DAY,top=3,recent=3)
        self.assertEqual(result['top_views'],['0','1','2'])
        self.assertEqual(result['recent'],['3','4','5'])
    def test_recent_not_restricted_to_one_year(self):
        result=choose_references([video('old','20240101',100)],DAY,top=3,recent=3)
        self.assertEqual(result['top_views'],[])
        self.assertEqual(result['recent'],['old'])
    def test_live_shorts_future_excluded(self):
        rows=[video('live','20261001',100,was_live=True),video('short','20261001',100,is_short=True),video('future','20261002',100)]
        self.assertEqual(choose_references(rows,DAY,top=3,recent=3)['eligible'],[])
    def test_missing_metadata_not_guessed(self):
        rows=[video('date',None,100),video('length','20261001',100,None),video('views','20261001',None)]
        result=choose_references(rows,DAY,top=3,recent=3)
        self.assertEqual(result['unresolved_ids'],['date','length','views'])
        self.assertEqual(result['top_views'],[])
    def test_short_non_shorts_video_not_artificially_excluded(self):
        self.assertEqual(choose_references([video('normal','20261001',100,150)],DAY,top=3,recent=3)['top_views'],['normal'])
    def test_calendar_year_leap_boundary(self):
        self.assertEqual(year_boundary(dt.date(2024,2,29)),dt.date(2023,2,28))
    def test_insufficient_does_not_fill_top_with_old_or_long(self):
        rows=[video('valid','20261001',1),video('old','20200101',100),video('long','20261001',100,2000)]
        result=choose_references(rows,DAY,top=3,recent=3)
        self.assertEqual(result['top_views'],['valid'])
        self.assertEqual(result['recent'],['old'])
    def test_command_filters_before_popularity_and_marks_missing(self):
        rows=[video(f'v{i}',f'202609{20+i}',10+i) for i in range(6)]
        rows.append(video('ancient','20200101',999999))
        flat={'id':'channel','entries':[{'id':e['id'],'duration':e['duration']} for e in rows]+[{'id':'missing','duration':600}]}
        byid={r['id']:r for r in rows}
        with tempfile.TemporaryDirectory() as td,patch('fetch_channel.ytdlp',return_value=SimpleNamespace(returncode=0,stdout=json.dumps(flat))),patch('fetch_channel.video_meta',side_effect=lambda vid,cookies:byid.get(vid)):
            args=SimpleNamespace(project=td,channel_url='https://www.youtube.com/@test',as_of='2026-10-01',min_duration=0,max_duration=1800,top=3,recent=3,scan=0,cookies_from_browser=None)
            cmd_list(args)
            result=json.loads((Path(td)/'channel.json').read_text())
            self.assertEqual(result['selection']['top_views'],['v5','v4','v3'])
            self.assertEqual(result['selection']['recent'],['v2','v1','v0'])
            self.assertFalse(result['selection_complete'])
            self.assertEqual(result['unresolved_ids'],['missing'])

if __name__=='__main__':unittest.main()
