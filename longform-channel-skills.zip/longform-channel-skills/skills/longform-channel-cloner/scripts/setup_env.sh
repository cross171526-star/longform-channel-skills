#!/usr/bin/env bash
# Idempotent environment setup for longform-channel-cloner (macOS arm64).
# Installs into $LFC_HOME (default ~/.longform-cloner): ffmpeg/ffprobe and a Python venv with pinned deps.
set -euo pipefail
LFC_HOME="${LFC_HOME:-$HOME/.longform-cloner}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mkdir -p "$LFC_HOME/bin" "$LFC_HOME/dl" "$LFC_HOME/fonts"

if [ "$(uname -s)" != "Darwin" ] || [ "$(uname -m)" != "arm64" ]; then
  echo "This setup targets macOS arm64. Install ffmpeg, Python 3.11+, Node 22+ manually elsewhere." >&2
fi

# ffmpeg / ffprobe (static, signed builds by Martin Riedl)
for tool in ffmpeg ffprobe; do
  if [ ! -x "$LFC_HOME/bin/$tool" ]; then
    curl -fsSL -o "$LFC_HOME/dl/$tool.zip" "https://ffmpeg.martin-riedl.de/redirect/latest/macos/arm64/release/$tool.zip"
    unzip -o -q "$LFC_HOME/dl/$tool.zip" -d "$LFC_HOME/bin"
    chmod +x "$LFC_HOME/bin/$tool"
  fi
done
"$LFC_HOME/bin/ffmpeg" -hide_banner -version | head -1

# Python >= 3.11
PYBIN=""
for c in python3.13 python3.12 python3.11 "$HOME/.local/bin/python3.12" "$HOME/.local/bin/python3.13"; do
  if command -v "$c" >/dev/null 2>&1; then
    if "$c" -c 'import sys; sys.exit(0 if sys.version_info >= (3,11) else 1)'; then PYBIN="$(command -v "$c")"; break; fi
  fi
done
[ -n "$PYBIN" ] || { echo "Python 3.11+ not found. Install it (e.g. uv python install 3.12) and rerun." >&2; exit 2; }
[ -x "$LFC_HOME/venv/bin/python" ] || "$PYBIN" -m venv "$LFC_HOME/venv"
"$LFC_HOME/venv/bin/python" -m pip install -q --upgrade pip
"$LFC_HOME/venv/bin/python" -m pip install -q -r "$SCRIPT_DIR/requirements.txt"

# Node 22+ (yt-dlp YouTube JS challenges + Remotion)
if command -v node >/dev/null 2>&1; then
  node -e 'process.exit(parseInt(process.versions.node) >= 22 ? 0 : 1)' || echo "WARN: Node 22+ required (found $(node --version))." >&2
else
  echo "WARN: node not found. Install Node 22+ for yt-dlp and Remotion." >&2
fi
echo "OK: LFC_HOME=$LFC_HOME"
