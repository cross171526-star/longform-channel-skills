"""유료 호출 없이 새 제작 경로·묵음 편집·실제 파일 기술 확인을 검사한다."""
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import numpy as np
import soundfile as sf
from PIL import Image
import compact_speech
import draft_delivery
import runtime
import tts
import sys
import io
from contextlib import redirect_stdout


class DraftTests(unittest.TestCase):
    def test_cut_count_scales_with_sentence_and_fills_actual_voice(self):
        result = draft_delivery.sentence_plan('가' * 40, [2., 4.], '나' * 60, 9.)
        self.assertEqual(result['new_cut_count'], 3)
        self.assertEqual(result['cuts'][0]['start_s'], 0)
        self.assertAlmostEqual(result['cuts'][-1]['end_s'], 9)
        self.assertLess(result['cuts'][0]['end_s'], result['cuts'][1]['end_s'] - result['cuts'][1]['start_s'])
        self.assertEqual(draft_delivery.units('2020년, 가 나.'), 7)

    def test_remove_internal_and_boundary_silence_and_map_words(self):
        sr = 48000
        tone = np.full(sr // 2, .2, dtype=np.float32)
        audio = np.concatenate([np.zeros(sr // 4), tone, np.zeros(sr // 2), tone, np.zeros(sr // 4)])
        cleaned, removed = compact_speech.compact_samples(audio, sr)
        self.assertLess(len(cleaned) / sr, 1.07)
        self.assertEqual(np.count_nonzero(cleaned), len(tone) * 2)
        self.assertAlmostEqual(compact_speech.map_time(1.25, removed), .545, places=3)
        with self.assertRaises(ValueError): compact_speech.compact_samples(np.zeros(sr), sr)

    def make_media(self, root):
        public = root / 'render/public';public.mkdir(parents=True)
        Image.new('RGB', (32, 32), '#224466').save(public / 'scene.png')
        tts = root / 'tts';tts.mkdir()
        sr = 8000
        audio = np.full(sr * 180, .1, dtype=np.float32)
        sf.write(tts / 'narration.wav', audio, sr);sf.write(root / 'mix.wav', audio, sr)
        narration = {'provider': 'typecast', 'uniform_speed': 1.2, 'silence_policy': 'compact', 'duration_s': 180,
                     'lines': [{'placed_start_s': 0, 'placed_end_s': 90}, {'placed_start_s': 90, 'placed_end_s': 180}]}
        (tts / 'narration.json').write_text(json.dumps(narration))
        props = {'fps': 30, 'width': 1920, 'height': 1080, 'duration_s': 180,
                 'cuts': [{'id': 'c1', 'start_s': 0, 'end_s': 180, 'asset': {'file': 'scene.png', 'kind': 'image'}}],
                 'texts': [{'id': 's1', 'start_s': 0, 'end_s': 180, 'text': '2020년의 이야기.'}]}
        (root / 'render/props.json').write_text(json.dumps(props))
        manifest = {'schema': 'lfc-draft-delivery-v1', 'canvas': [1920, 1080], 'render_timing': {'props': 'render/props.json'}, 'narration': 'tts/narration.json'}
        (root / 'delivery.json').write_text(json.dumps(manifest))
        return props

    def test_real_file_check_needs_no_pilot_or_independent_review(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); props = self.make_media(root)
            checked = draft_delivery.basic_check(root / 'delivery.json')
            self.assertTrue(checked['passed'], checked['errors'])
            self.assertFalse(checked['content_approved'])
            self.assertTrue(checked['user_review_pending'])
            self.assertEqual(checked['render_timing_check']['output_frames'], 5400)
            props['cuts'][0]['start_s'] = 3
            (root / 'render/props.json').write_text(json.dumps(props))
            bad = draft_delivery.basic_check(root / 'delivery.json')
            self.assertFalse(bad['passed'])
            self.assertIn('배경 컷 공백/겹침', bad['errors'])

    def test_runtime_new_profile_tts_ignores_old_approval_and_overdue_does_not_stop(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = Path(runtime.__file__).resolve().parent.parent
            (root / 'run.json').write_text(json.dumps({'workflow_profile': 'tts-first-v1', 'request_started_at': 1}))
            timing = {'started': 1, 'enter': lambda phase: None}
            with patch.dict(os.environ, {'LFC_RUN_DIR': str(root), 'LFC_LEASE': 'test', 'LFC_VERBOSE': '1'}), \
                 patch.object(runtime, 'frozen_skill', return_value=source), \
                 patch.object(runtime, 'execute') as ownership, \
                 patch.object(runtime, 'bound_rollout', return_value=None), \
                 patch.object(runtime.subprocess, 'run') as process:
                process.return_value.returncode = 0
                self.assertEqual(runtime._invoke('tts', ['--help'], timing), 0)
                ownership.assert_called_once()
                self.assertIn('tts.py', process.call_args.args[0][1])
            measured = json.loads((root / 'delivery-time.json').read_text())
            self.assertTrue(measured['over_target'])
            self.assertEqual(measured['action'], 'continue_to_draft_delivery')

    def test_new_runtime_snapshot_has_tts_first_and_no_old_approval_versions(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = runtime.initialize(Path(runtime.__file__).resolve().parent.parent, tmp, 'fresh', 100.)
            cfg = json.loads((Path(result['run_dir']) / 'run.json').read_text())
            self.assertEqual(cfg['workflow_profile'], 'tts-first-v1')
            self.assertEqual(cfg['request_started_at'], 100.)
            self.assertEqual(cfg['front_review_version'], 0)
            self.assertEqual(cfg['topic_materials_version'], 0)
            self.assertEqual(cfg['duration_policy']['cut_basis'], 'reference_sentence_length_ratio')
            self.assertTrue((Path(result['skill']) / 'scripts/compact_speech.py').is_file())

    def test_real_compact_tts_cli_keeps_display_and_removes_default_and_explicit_gaps(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); (root / 'run.json').write_text(json.dumps({'workflow_profile': 'tts-first-v1'}))
            lines = [{'id': 'one', 'text': '이천이십 년.', 'display_text': '2020년.', 'paragraph_id': 'p1', 'gap_after_s': .8},
                     {'id': 'two', 'text': '다음 문장.', 'display_text': '다음 문장.', 'paragraph_id': 'p2'}]
            (root / 'lines.json').write_text(json.dumps(lines))
            raw = root / 'raw.wav'; sr = 48000
            tone = np.full(sr // 4, .1, dtype=np.float32)
            sf.write(raw, np.concatenate([np.zeros(sr // 5), tone, np.zeros(sr // 2), tone, np.zeros(sr // 5)]), sr)
            with patch.dict(os.environ, {'LFC_RUN_DIR': str(root)}), \
                 patch.object(sys, 'argv', ['tts', '--lines', str(root / 'lines.json'), '--out', str(root / 'out')]), \
                 patch.object(tts, 'synth_cached', return_value=(raw, [{'w': '발화', 'start': .95, 'end': 1.2}])), \
                 redirect_stdout(io.StringIO()):
                tts.main()
            actual = json.loads((root / 'out/narration.json').read_text())
            self.assertEqual(actual['silence_policy'], 'compact')
            a, b = actual['lines']
            self.assertEqual(a['placed_end_s'], b['placed_start_s'])
            self.assertEqual(a['display_text'], '2020년.')
            self.assertEqual(b['paragraph_id'], 'p2')
            self.assertLess(a['words'][0]['start'], .4)
            self.assertLess(actual['duration_s'], 1.2)

    def test_legacy_profile_not_silently_migrated(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); (root / 'run.json').write_text('{"scheduler_version":3}')
            self.assertFalse(draft_delivery.active(root))


if __name__ == '__main__': unittest.main()
