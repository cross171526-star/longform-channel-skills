"""Retired generator: old donor/audio contracts are incompatible with current production."""
if __name__ == '__main__':
    raise SystemExit('Use skill-creator with the confirmed SKILL.md step 8 contracts; this legacy generator is disabled.')
