"""공식 build_timeline의 검사된 불변 입력으로 승인 표본만 배치 출력한다.
Root/Main/props/mix·프레임 시계는 바꾸지 않는다. 실제 assets 검사 1회 이후
lease에 고정된 전체 입력의 inode/ctime/mtime/size를 각 출력 전후에 확인한다.
해시는 runtime guard와 assets gate가 검증하고 검사 중 변동도 거절한다.
"""
from pathlib import Path
import hashlib,json,os,re,shutil,sqlite3,subprocess
from common import probe
from PIL import Image

def digest(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def write(p,d):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def pinned_inputs():
 base=Path(os.environ.get('LFC_RUNTIME_HOME',str(Path.home()/'.longform-cloner/runtime')))
 db=sqlite3.connect('file:'+str(base/'work.sqlite')+'?mode=ro',uri=True,timeout=10)
 try:row=db.execute('SELECT inputs,state,run FROM jobs WHERE lease=?',(os.environ['LFC_LEASE'],)).fetchone()
 finally:db.close()
 if not row or row[1]!='running' or Path(row[2]).resolve()!=Path(os.environ['LFC_RUN_DIR']).resolve():raise ValueError('Batch requires the current active registered lease')
 return json.loads(row[0])
class InputWatch:
 def __init__(self,paths):
  self.paths=sorted(set(map(str,paths)));self.signatures=self.capture()
 def capture(self):
  out={}
  for p in self.paths:
   # lstat catches replaced symlinks; stat catches a changed target, including restored mtime.
   l=Path(p).lstat();s=Path(p).stat();out[p]=(l.st_dev,l.st_ino,l.st_size,l.st_mtime_ns,l.st_ctime_ns,s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
  return out
 def unchanged(self):
  now=self.capture()
  bad=[p for p in self.paths if now[p]!=self.signatures[p]]
  if bad:raise ValueError('Batch input changed: '+bad[0])
def template_hash(template,dependencies):
 return hashlib.sha256(''.join(str(p.relative_to(template))+':'+digest(p) for p in dependencies).encode()).hexdigest()
def validate_spec(spec,plan,frames,fps):
 if spec.get('schema')!='inspection-sample-batch-v1' or spec.get('fps')!=fps:raise ValueError('Invalid sample batch schema/fps')
 if spec.get('clips')!=plan.get('clips') or spec.get('standalone_stills')!=plan.get('standalone_stills') or spec.get('all_observation_frames')!=plan.get('all_observation_frames') or spec.get('caption_state_map')!=plan.get('caption_state_map'):raise ValueError('Batch differs from the reviewed sample plan')
 clips=spec['clips'];stills=spec['standalone_stills'];ids=set();ranges=[];seen=set()
 for c in clips:
  ident=c['id'];r=c['frames_inclusive']
  if not isinstance(ident,str) or not re.fullmatch(r'[A-Za-z0-9_-]+',ident) or ident in ids:raise ValueError('Invalid/duplicate sample id')
  ids.add(ident)
  if not isinstance(r,list) or len(r)!=2 or any(not isinstance(x,int) or isinstance(x,bool) for x in r) or not 0<=r[0]<=r[1]<frames:raise ValueError('Sample range outside composition')
  if r==[0,frames-1]:raise ValueError('Full composition is not an inspection sample')
  if tuple(r) in seen:raise ValueError('Duplicate sample range')
  seen.add(tuple(r));ranges.append(r)
  if c.get('absolute_composition_frames') is not True or c.get('reset_clock_or_rebase_props') is not False:raise ValueError('Sample must retain the native composition clock')
  extract=c.get('extract_absolute_frames',[])
  if len(extract)!=len(set(extract)) or any(not isinstance(f,int) or isinstance(f,bool) or not r[0]<=f<=r[1] for f in extract):raise ValueError('Invalid clip observation frame')
 sf=[]
 for x in stills:
  f=x['frame']
  if not isinstance(f,int) or isinstance(f,bool) or not 0<=f<frames:raise ValueError('Still outside composition')
  if f in sf or any(a<=f<=b for a,b in ranges):raise ValueError('Duplicate still/clip observation')
  sf.append(f)
 if not clips and not stills:raise ValueError('Empty inspection batch')
 merged=[]
 for a,b in sorted(ranges):
  if merged and a<=merged[-1][1]+1:merged[-1][1]=max(b,merged[-1][1])
  else:merged.append([a,b])
 if merged==[[0,frames-1]]:raise ValueError('Batch cannot cover the whole composition')
 observations=spec['all_observation_frames'];of=[x['frame'] for x in observations]
 if len(of)!=len(set(of)):raise ValueError('Duplicate observation target')
 available=set(sf)|{f for c in clips for f in c.get('extract_absolute_frames',[])}
 if set(of)!=available:raise ValueError('Observation target omission/addition')
 byid={c['id']:c for c in clips}
 for x in observations:
  src=x['render_source'];f=x['frame']
  if src.get('absolute_frame')!=f:raise ValueError('Observation native frame differs')
  if src['kind']=='standalone_still':
   if f not in sf:raise ValueError('Still observation source differs')
  elif src['kind']=='extract_from_clip':
   c=byid.get(src.get('clip_id'))
   if not c or f not in c.get('extract_absolute_frames',[]) or src.get('clip_local_frame')!=f-c['frames_inclusive'][0]:raise ValueError('Clip observation source differs')
  else:raise ValueError('Unknown observation source')
 for x in spec['caption_state_map']:
  f=x['observation_frame'];a,b=x['active_frames_inclusive']
  if f not in available or not 0<=a<=f<=b<frames:raise ValueError('Caption observation omitted/outside visibility')
 return clips,stills

def setup_template(template,cached,tpl,dependencies):
 from renderer_runtime import setup
 setup(template,cached,tpl,dependencies)


def run_batch(a,edl_dir,rdir,public,template,lfc_home,ffmpeg):
 from check_production import check
 from check_render_timing import renderer_dependencies
 production_path=Path(a.production_manifest).resolve();production=read(production_path);props=rdir/'props.json';mix=edl_dir/'mix.wav';spec_path=Path(a.sample_spec).resolve()
 if a.preview:raise ValueError('Planned canvas required')
 if (production_path.parent/production['render_timing']['props']).resolve()!=props.resolve() or (production_path.parent/production['render']).resolve()!=(edl_dir/'output.mp4').resolve():raise ValueError('Batch paths differ from prepared production')
 pinned=pinned_inputs()
 for p in (spec_path,production_path,props,mix):
  if str(p.resolve()) not in pinned:raise ValueError('Batch input not registered: '+str(p))
 watch=InputWatch(pinned);spec=read(spec_path)
 if digest(spec_path)!=pinned[str(spec_path)]:raise ValueError('Registered sample spec SHA differs')
 rp=Path(spec['sample_plan']['path']).resolve()
 if str(rp) not in pinned or digest(rp)!=spec['sample_plan']['sha256'] or digest(rp)!=pinned[str(rp)]:raise ValueError('Reviewed sample plan SHA differs')
 expected=spec['expected'];deps=renderer_dependencies();observed={'production_manifest_sha256':digest(production_path),'props_sha256':digest(props),'mix_sha256':digest(mix),'template_sha256':template_hash(template,deps)}
 if any(expected.get(k)!=v for k,v in observed.items()):raise ValueError('Prepared batch input SHA differs')
 # Exactly the real pre-render assets gate; no prior report used as a substitute.
 result=check(production_path,'assets')
 if not result['passed']:raise ValueError('Batch pre-render gate failed: '+'; '.join(result['errors']))
 if expected['assets_input_sha256']!=result['input_sha256']:raise ValueError('Batch assets fingerprint changed')
 timing=result['render_timing_check'];clips,stills=validate_spec(spec,read(rp),timing['output_frames'],timing['fps']);watch.unchanged()
 write(edl_dir/'pre_render_check.json',result)
 tpl=rdir/'template';setup_template(template,lfc_home/'remotion-template',tpl,deps);runtime_watch=InputWatch([tpl/p.relative_to(template) for p in deps]);watch.unchanged()
 ident=spec.get('batch_id')
 if not isinstance(ident,str) or not re.fullmatch(r'[A-Za-z0-9_-]+',ident):raise ValueError('Invalid batch id')
 outdir=edl_dir/'inspection-batch'/ident
 if outdir.exists():
  index=2
  while (edl_dir/'inspection-batch'/(ident+'-attempt-'+str(index))).exists():index+=1
  outdir=edl_dir/'inspection-batch'/(ident+'-attempt-'+str(index))
 outdir.mkdir(parents=True,exist_ok=False);completed=[];frames={};common={'kind':'inspection_sample_batch_entry','complete_video':False,'input_sha256':result['input_sha256'],'sample_spec_sha256':digest(spec_path),**observed,'fps':timing['fps'],'actual_visual_qa_passed':False}
 def stable():watch.unchanged();runtime_watch.unchanged()
 def command(cmd):stable();subprocess.run(cmd,cwd=tpl,check=True);stable()
 for c in clips:
  first,last=c['frames_inclusive'];out=outdir/(c['id']+'.mp4');video=outdir/(c['id']+'.video.mp4')
  command(['npx','remotion','render','src/index.ts','Main',str(video),f'--props={props}',f'--public-dir={public}','--muted',f'--concurrency={a.concurrency}','--codec=h264','--crf=18','--log=error',f'--frames={first}-{last}'])
  command([ffmpeg,'-hide_banner','-loglevel','error','-y','-i',str(video),'-ss',str(first/timing['fps']),'-i',str(mix),'-map','0:v','-map','1:a','-c:v','copy','-c:a','aac','-b:a','192k','-shortest',str(out)])
  info=probe(out);stable()
  if info['nb_frames']!=last-first+1 or info['fps']!=timing['fps'] or [info['width'],info['height']]!=production['canvas']:raise ValueError('Actual clip frames/fps/canvas differ from requested sample')
  targets=sorted(c.get('extract_absolute_frames',[]));extracted=[]
  if targets:
   tmp=outdir/(c['id']+'-frames');tmp.mkdir(exist_ok=True);sel='+'.join('eq(n\\,'+str(x-first)+')' for x in targets)
   command([ffmpeg,'-hide_banner','-loglevel','error','-y','-i',str(out),'-vf','select='+sel,'-fps_mode','passthrough',str(tmp/'%06d.png')]);pngs=sorted(tmp.glob('*.png'))
   if len(pngs)!=len(targets):raise ValueError('Clip observation extraction count differs')
   for frame,png in zip(targets,pngs):
    with Image.open(png) as image:
     if list(image.size)!=production['canvas']:raise ValueError('Extracted frame canvas differs')
    rec={'file':str(png),'sha256':digest(png),'absolute_frame':frame,'clip_local_frame':frame-first,'clip_id':c['id']};frames[frame]=rec;extracted.append(rec)
  record={**common,'id':c['id'],'start_frame':first,'end_frame_inclusive':last,'audio_seek_s':first/timing['fps'],'file':str(out),'render_sha256':digest(out),'reviewed_request':c,'measured_output':{'nb_frames':info['nb_frames'],'fps':info['fps'],'canvas':[info['width'],info['height']]},'extracted_observation_frames':extracted};write(out.with_suffix('.json'),record);completed.append(record);print(json.dumps({'batch_completed':c['id'],'native_frames':[first,last]},ensure_ascii=False),flush=True)
 for s in stills:
  f=s['frame'];out=outdir/('still-'+str(f)+'.png');command(['npx','remotion','still','src/index.ts','Main',str(out),f'--frame={f}',f'--props={props}',f'--public-dir={public}','--log=error'])
  with Image.open(out) as image:
   if list(image.size)!=production['canvas']:raise ValueError('Actual still canvas differs')
  record={**common,'absolute_frame':f,'file':str(out),'render_sha256':digest(out),'reviewed_request':s};write(out.with_suffix('.json'),record);frames[f]={'file':str(out),'sha256':record['render_sha256'],'absolute_frame':f,'kind':'standalone_still'};completed.append(record);print(json.dumps({'batch_completed_still':f},ensure_ascii=False),flush=True)
 stable();observations=[{**x,'actual_render_source':frames[x['frame']],'observation_status':'rendered_not_observed'} for x in spec['all_observation_frames']]
 report={**common,'batch_id':ident,'clip_count':len(clips),'standalone_still_count':len(stills),'completed':completed,'all_observation_frames':observations,'caption_state_map':spec['caption_state_map'],'actual_assets_check_passed':True,'input_stat_policy':'guard+assets real SHA once; all registered inputs and runtime template inode/ctime/mtime/size+symlink identity unchanged before/after every subprocess','actual_visual_or_listening_review_passed':False}
 write(outdir/'batch-report.json',report);print('done inspection batch -> '+str(outdir/'batch-report.json'),flush=True)
