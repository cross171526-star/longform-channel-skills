"""Official Gemini CLI, Google login, direct media attachment, no paid fallback."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
from media_transport import save, digest, stop, TransportError

CLI = Path.home() / '.local/share/node/bin/gemini'

def ask(media, prompt, schema, folder, model='gemini-3.1-pro-preview', timeout=240):
    media, folder = Path(media).resolve(), Path(folder).resolve()
    folder.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    for name in ('GEMINI_API_KEY', 'GOOGLE_API_KEY', 'GOOGLE_APPLICATION_CREDENTIALS',
                 'GOOGLE_GENAI_USE_VERTEXAI', 'GOOGLE_GENAI_USE_ENTERPRISE'):
        env.pop(name, None)
    env['NO_BROWSER'] = 'true'
    with tempfile.TemporaryDirectory(prefix='lfc-direct-') as tmp:
        root = Path(tmp)
        shutil.copyfile(media, root / 'input.mp4')
        settings = {}
        original = Path(env.get('GEMINI_CLI_SYSTEM_SETTINGS_PATH', '/Library/Application Support/GeminiCli/settings.json'))
        if original.exists():
            settings = json.loads(original.read_text())
        settings.setdefault('billing', {})['overageStrategy'] = 'never'
        settings.setdefault('security', {}).setdefault('auth', {})['selectedType'] = 'oauth-personal'
        settings['security']['auth']['enforcedType'] = 'oauth-personal'
        settings.setdefault('general', {})['maxAttempts'] = 2
        settings.setdefault('context', {})['fileName'] = []
        save(root / 'settings.json', settings)
        env['GEMINI_CLI_SYSTEM_SETTINGS_PATH'] = str(root / 'settings.json')
        (root / 'deny.toml').write_text('[[rule]]\ntoolName = "*"\ndecision = "deny"\npriority = 999\n')
        text = ('@input.mp4\nThe attached media is the only evidence. Do not use tools. '
                'If pixels or audio are unavailable, report that without inferring from text.\n'
                + prompt + '\nReturn only JSON conforming to this schema:\n' + json.dumps(schema))
        save(folder / 'request.json', {'transport': 'gemini-cli-direct', 'auth': 'oauth-personal',
                                      'overage': 'never', 'model': model, 'media_sha256': digest(media),
                                      'prompt': prompt, 'schema': schema})
        cmd = [str(CLI), '-p', text, '-m', model, '-o', 'stream-json',
               '--policy', str(root / 'deny.toml'), '-e', 'none']
        with (folder / 'events.jsonl').open('wb') as out, (folder / 'stderr.log').open('wb') as err:
            proc = subprocess.Popen(cmd, cwd=root, env=env, stdin=subprocess.DEVNULL,
                                    stdout=out, stderr=err, start_new_session=True)
            try:
                proc.wait(timeout)
            except subprocess.TimeoutExpired:
                stop(proc)
                raise TransportError('DIRECT_TIMEOUT', True)
            except BaseException:
                stop(proc)
                raise
        events = []
        for line in (folder / 'events.jsonl').read_text(errors='replace').splitlines():
            try:
                events.append(json.loads(line))
            except ValueError:
                pass
        save(folder / 'status.json', {'returncode': proc.returncode})
        if proc.returncode:
            raise TransportError('DIRECT_CLI_ERROR')
        if any(e.get('type') == 'tool_use' for e in events):
            raise TransportError('DIRECT_UNEXPECTED_TOOL')
        results = [e for e in events if e.get('type') == 'result']
        if len(results) != 1 or results[0].get('status') != 'success':
            raise TransportError('DIRECT_NO_SUCCESS')
        response = ''.join(e.get('content', '') for e in events
                           if e.get('type') == 'message' and e.get('role') == 'assistant')
        response = response.strip()
        if response.startswith('```'):
            response = response.split('\n', 1)[1].rsplit('```', 1)[0]
        try:
            answer = json.loads(response)
        except ValueError:
            raise TransportError('DIRECT_INVALID_JSON')
        save(folder / 'answer.json', answer)
        return answer
