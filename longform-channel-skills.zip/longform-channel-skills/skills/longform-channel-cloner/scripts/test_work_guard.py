import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from work_guard import execute, hashes

class WorkGuardTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.p=Path(self.tmp.name)
        self.env=patch.dict(os.environ,{'LFC_RUNTIME_HOME':str(self.p/'shared')});self.env.start();self.addCleanup(self.env.stop)
        self.source=self.p/'source';self.source.write_text('source');self.out=self.p/'out';self.out.write_text('output')
        self.report=self.p/'validation.json';self.run=self.p/'run1'
    def claim(self,resource='video:A',run=None,task='analysis',inputs=None,pool='model'):
        return execute(run or self.run,'claim',task,inputs or [self.source],resource=resource,stage='analysis',pool=pool)
    def finish(self,job):
        self.report.write_text(json.dumps({'passed':True,'output_sha256':hashes([self.out])}))
        return execute(self.run,'finish',lease=job['lease'],outputs=[self.out],validation=self.report,note='verified')
    def test_duplicate_alias_and_other_run_blocked(self):
        self.claim()
        with self.assertRaises(ValueError):self.claim(run=self.p/'run2',task='renamed')
    def test_independent_sessions_have_no_global_capacity_or_order(self):
        for i in range(6):
            for pool in ('model','local'):
                self.assertEqual(self.claim(resource=f'{pool}:{i}',run=self.p/f'{pool}{i}',pool=pool)['decision'],'run')
    def test_other_run_registration_never_waits_for_completion(self):
        a=self.claim();b=self.claim(resource='video:B')
        self.assertEqual(self.claim(resource='video:C',run=self.p/'other')['decision'],'run')
        self.assertEqual(self.claim(resource='video:D')['decision'],'run')
        self.finish(a)
    def test_three_successful_revisions_allowed(self):
        for i in range(3):
            self.source.write_text(str(i));self.finish(self.claim())
    def test_same_revision_failure_limit_and_changed_revision(self):
        for i in range(2):
            a=self.claim();execute(self.run,'fail',lease=a['lease'],note='same error')
        with self.assertRaises(ValueError):self.claim()
        self.source.write_text('corrected input');self.assertEqual(self.claim()['decision'],'run')
    def test_reuse_and_output_tampering(self):
        self.finish(self.claim());self.assertEqual(self.claim()['decision'],'reuse')
        self.out.write_text('altered');self.assertEqual(self.claim()['decision'],'run')
    def test_dependency_manifest_checks_real_file(self):
        manifest=self.p/'inputs.json';manifest.write_text(json.dumps({'schema':'lfc-inputs-v1','files':[{'path':str(self.source),'sha256':hashes([self.source])[str(self.source.resolve())]}]}))
        self.finish(self.claim(inputs=[manifest]));self.source.write_text('changed')
        with self.assertRaises(ValueError):self.claim(inputs=[manifest])
    def test_failed_or_unbound_validation_rejected(self):
        a=self.claim();self.report.write_text('{"passed":false}')
        with self.assertRaises(ValueError):execute(self.run,'finish',lease=a['lease'],outputs=[self.out],validation=self.report,note='test')
    def test_usage_dedup_and_progress_checkpoint(self):
        a=self.claim();rows=[{'response_id':str(i),'usage':{'input_tokens':10,'cached_input_tokens':8,'output_tokens':1}} for i in range(80)]
        for _ in range(2):r=execute(self.run,'usage',lease=a['lease'],records=rows)
        self.assertEqual(r['calls'],80);self.assertEqual(r['uncached_input'],160)
        self.assertEqual(execute(self.run,'check',lease=a['lease'])['decision'],'run')
        progress=self.p/'progress.json';progress.write_text('{"completed_units":["video:A:0-60"]}')
        execute(self.run,'checkpoint',lease=a['lease'],validation=progress)
        self.assertEqual(execute(self.run,'check',lease=a['lease'])['decision'],'run')
        with self.assertRaises(ValueError):execute(self.run,'checkpoint',lease=a['lease'],validation=progress)
    def test_wrong_run_cannot_finish_another_session(self):
        a=self.claim()
        with self.assertRaises(ValueError):execute(self.p/'other','fail',lease=a['lease'],note='wrong run')

    def test_same_inputs_in_different_snapshot_paths_reuse(self):
        for name in ['r1','r2']:
            d=self.p/name;d.mkdir();(d/'spec.md').write_text('identical spec')
            (d/'inputs.json').write_text(json.dumps({'schema':'lfc-inputs-v1','files':[{'path':str(d/'spec.md'),'sha256':hashes([d/'spec.md'])[str((d/'spec.md').resolve())]}]}))
        self.finish(self.claim(inputs=[self.p/'r1/inputs.json']))
        self.assertEqual(self.claim(run=self.p/'run2',inputs=[self.p/'r2/inputs.json'])['decision'],'reuse')

    def test_competing_sessions_admit_only_one_duplicate(self):
        from concurrent.futures import ThreadPoolExecutor
        execute(self.run,'status')
        def attempt(i):
            try:return self.claim(run=self.p/f'run{i}')['decision']
            except ValueError:return 'blocked'
        with ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(attempt,range(4)))
        self.assertEqual(results.count('run'),1)
        self.assertEqual(results.count('blocked'),3)

if __name__=='__main__':unittest.main()
