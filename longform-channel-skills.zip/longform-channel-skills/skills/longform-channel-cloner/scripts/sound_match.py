#!/usr/bin/env python3
"""Rank SFX / BGM candidates by how close they sound to a reference clip (CLAP embedding + envelope + tempo).

  run.sh sound_match --project P --key sfx:VID:s0003 --ref <ref.wav> [--start S --end E] [--top 5]

Reads assets/candidates/<key>/candidates.json (from fetch_assets search --kind audio), downloads each candidate
audio, and scores: CLAP cosine similarity (timbre/category), RMS-envelope correlation (attack/decay shape, SFX),
duration ratio (SFX) or tempo ratio (BGM, when the reference excerpt is > 8 s). Writes the scores back into
candidates.json and prints a ranking; then run fetch_assets pick with the chosen number.
Reference audio is only used for comparison and never placed in the output.
"""
from __future__ import annotations

import argparse
import re
import subprocess
from pathlib import Path

import numpy as np

from common import load_mono, read_json, rms_db, write_json

SR = 48000


def fetch(url: str, dest: Path) -> Path | None:
    if dest.exists() and dest.stat().st_size > 0:
        return dest
    # shared cache across keys (same library clip is often a candidate for several keys)
    from common import LFC_HOME
    import hashlib, shutil
    cache = LFC_HOME / "audio_cache" / (hashlib.sha1(url.encode()).hexdigest()[:16] + dest.suffix)
    if cache.exists() and cache.stat().st_size > 0:
        shutil.copy(cache, dest)
        return dest
    p = subprocess.run(["curl", "-fsSL", "--connect-timeout", "8", "--max-time", "25", "--speed-limit", "50000",
                        "--speed-time", "8", "-A", "longform-channel-cloner/1.0", "-o", str(dest), url])
    if p.returncode == 0 and dest.exists() and dest.stat().st_size > 0:
        cache.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy(dest, cache)
    if p.returncode != 0 or not dest.exists() or dest.stat().st_size == 0:
        print(f"  ! download failed ({p.returncode}): {url[:80]}")
        dest.unlink(missing_ok=True)
        return None
    return dest


def envelope(x, n=64):
    e = rms_db(x, SR, 0.02)
    e = np.maximum(e, e.max() - 50)
    if len(e) < 2:
        return np.zeros(n)
    return np.interp(np.linspace(0, len(e) - 1, n), np.arange(len(e)), (e - e.min()) / (np.ptp(e) + 1e-9))


def trim_silence(x, thr_db=-45):
    e = rms_db(x, SR, 0.01)
    on = np.nonzero(e > e.max() + thr_db)[0]
    if not len(on):
        return x, 0.0
    s = on[0] * int(0.01 * SR)
    t = (on[-1] + 1) * int(0.01 * SR)
    return x[s:t], s / SR


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--project", required=True)
    ap.add_argument("--key", required=True)
    ap.add_argument("--ref", required=True)
    ap.add_argument("--start", type=float)
    ap.add_argument("--end", type=float)
    ap.add_argument("--top", type=int, default=5)
    a = ap.parse_args()
    import librosa
    from audio_analysis import Clap
    kd = Path(a.project) / "assets" / "candidates" / re.sub(r"[^\w\-]+", "_", a.key)
    doc = read_json(kd / "candidates.json")
    ref = load_mono(a.ref, SR)
    if a.start is not None:
        ref = ref[int(a.start * SR): int((a.end or a.start + 10) * SR)]
    ref_t, _ = trim_silence(ref)
    is_bgm = len(ref_t) / SR > 8
    clap = Clap()
    clips = [ref_t[: 10 * SR]]
    kept = []
    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(8) as ex:
        paths = list(ex.map(lambda c: fetch(c["url"], kd / f"aud_{c['n']:02d}{Path(c['url'].split('?')[0]).suffix or '.mp3'}"),
                            doc["candidates"]))
    for c, p in zip(doc["candidates"], paths):
        if not p:
            continue
        try:
            y = load_mono(p, SR)
        except Exception:
            continue
        y_t, onset = trim_silence(y)
        if len(y_t) < SR * 0.05:
            continue
        c["onset_s"] = round(onset, 3)
        c["duration_s"] = round(len(y) / SR, 3)
        kept.append((c, y_t))
        clips.append(y_t[: 10 * SR])
    if not kept:
        raise SystemExit("no candidate audio could be loaded")
    import torch
    inp = clap.proc(audio=[x.astype(np.float32) for x in clips], sampling_rate=SR, return_tensors="pt")
    with torch.no_grad():
        emb = clap.model.get_audio_features(**inp)
    emb = emb.pooler_output if hasattr(emb, "pooler_output") else emb
    emb = (emb / emb.norm(dim=-1, keepdim=True)).numpy()
    ref_env = envelope(ref_t)
    ref_tempo = None
    if is_bgm:
        ref_tempo = float(np.atleast_1d(librosa.beat.beat_track(y=librosa.resample(ref_t, orig_sr=SR, target_sr=22050), sr=22050)[0])[0])
    for k, (c, y) in enumerate(kept, start=1):
        sim = float(emb[0] @ emb[k])
        if is_bgm:
            tempo = float(np.atleast_1d(librosa.beat.beat_track(y=librosa.resample(y[: 60 * SR], orig_sr=SR, target_sr=22050), sr=22050)[0])[0])
            ratio = min(tempo, ref_tempo) / max(tempo, ref_tempo, 1e-6)
            ratio = max(ratio, min(2 * tempo, ref_tempo) / max(2 * tempo, ref_tempo), min(tempo, 2 * ref_tempo) / max(tempo, 2 * ref_tempo))
            score = 0.75 * sim + 0.25 * ratio
            c["match"] = {"score": round(score, 4), "clap": round(sim, 4), "tempo": round(tempo, 1), "ref_tempo": round(ref_tempo, 1)}
        else:
            env_c = float(np.corrcoef(ref_env, envelope(y))[0, 1]) if np.std(envelope(y)) > 0 else 0.0
            dr = min(len(y), len(ref_t)) / max(len(y), len(ref_t))
            score = 0.6 * sim + 0.25 * max(0.0, env_c) + 0.15 * dr
            c["match"] = {"score": round(score, 4), "clap": round(sim, 4), "envelope_corr": round(env_c, 3),
                          "duration_ratio": round(dr, 3)}
    write_json(kd / "candidates.json", doc)
    ranked = sorted((c for c, _ in kept), key=lambda c: -c["match"]["score"])
    for c in ranked[: a.top]:
        print(f"#{c['n']:<3} {c['match']}  {c['provider']}  {c.get('license')}  {c.get('title') or ''}")
    print(f"then: run.sh fetch_assets pick --project {a.project} --key {a.key} --candidate {ranked[0]['n']}")


if __name__ == "__main__":
    main()
