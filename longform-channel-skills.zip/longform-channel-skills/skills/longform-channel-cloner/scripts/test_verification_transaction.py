"""Content-bound sharing must preserve the current gate's semantics."""
import contextlib
import io
import json
import os
from pathlib import Path
import tempfile
import time
import unittest
from types import SimpleNamespace
from unittest.mock import patch

import check_production as cp
import compile_timeline as ct
import runtime
from work_guard import FileSnapshot, digest, signature
import test_check_production as fixtures


class TransactionTests(unittest.TestCase):
    def setUp(self):
        self.f = fixtures.ProductionGateTest(); self.f.setUp(); self.addCleanup(self.f.doCleanups)
        self.path = self.f.root/'reference_map.json'

    def test_same_document_and_alias_parse_once_and_recheck_content_at_end(self):
        path = self.f.root/'evidence.json'; alias = self.f.root/'alias.json'; alias.symlink_to(path)
        with patch.object(cp, 'read', wraps=cp.read) as read, patch.object(cp, 'digest', wraps=cp.digest) as hashed:
            context = cp.VerificationContext()
            self.assertIs(context.document(path), context.document(alias))
            context.document(path); context.close()
            self.assertEqual(read.call_count, 1)
            self.assertEqual(hashed.call_count, 2)  # acquisition + fresh boundary

    def test_cached_pass_is_scoped_and_returned_report_cannot_mutate_cache(self):
        with patch.object(cp, '_check', wraps=cp._check) as run:
            context = cp.VerificationContext()
            first = cp.check(self.path, 'plan', context=context)
            self.assertTrue(first['passed'], first['errors'])
            first['passed'] = False
            self.assertTrue(cp.check(self.path, 'plan', context=context)['passed'])
            self.assertEqual(run.call_count, 1)
            cp.check(self.path, 'assets', self.f.probe, context)
            self.assertEqual(run.call_count, 2)
            context.close()

    def test_same_size_restored_mtime_cannot_reuse_success(self):
        context = cp.VerificationContext(); cp.check(self.path, 'plan', context=context)
        path = self.f.root/'code.js'; stat = path.stat(); path.write_bytes(b'X'*stat.st_size)
        os.utime(path, ns=(stat.st_atime_ns, stat.st_mtime_ns))
        with self.assertRaises(ValueError): cp.check(self.path, 'plan', context=context)
        with self.assertRaises(ValueError): context.close()

    def test_boundary_checks_content_even_if_stat_signature_appears_same(self):
        path = self.f.root/'code.js'; before = signature(path)
        snap = FileSnapshot(); snap.add(path); path.write_bytes(b'X'*path.stat().st_size)
        with patch('work_guard.signature', return_value=before):
            with self.assertRaisesRegex(ValueError, 'content changed'): snap.unchanged(verify_content=True)

    def test_manifest_symlink_retarget_is_not_an_untracked_alias(self):
        alias = self.f.root/'manifest-link.json'; alias.symlink_to(self.path)
        context = cp.VerificationContext(); cp.check(alias, 'plan', context=context)
        other = self.f.root/'different.json'; other.write_bytes(self.path.read_bytes())
        alias.unlink(); alias.symlink_to(other)
        with self.assertRaises(ValueError): context.close()

    def test_checker_change_invalidates_transaction(self):
        # Bind a harmless separate tool fixture in place of the code inventory.
        tool = self.f.root/'tool.py'; tool.write_text('before')
        with patch.object(Path, 'glob', return_value=[tool]):
            context = cp.VerificationContext(); cp.check(self.path, 'plan', context=context)
            tool.write_text('after')
            with self.assertRaises(ValueError): cp.check(self.path, 'plan', context=context)

    def test_closed_context_cannot_be_reused(self):
        context = cp.VerificationContext(); context.close()
        with self.assertRaisesRegex(ValueError, 'closed'): cp.check(self.path, 'plan', context=context)

    def test_failure_not_memoized_and_scope_stage_not_collapsed(self):
        self.f.m['cuts'][0]['effects'] = {}; self.f.save()
        with patch.object(cp, '_check', wraps=cp._check) as run:
            context = cp.VerificationContext()
            for _ in range(2): self.assertFalse(cp.check(self.path, 'plan', context=context)['passed'])
            self.assertEqual(run.call_count, 2); context.close()

    def test_cheap_missing_renderer_inventory_before_any_evidence_parse(self):
        self.f.m['render_inputs'] = [n for n in self.f.m['render_inputs'] if not n.endswith('package-lock.json')]
        self.f.save()
        with patch.object(cp, 'read', wraps=cp.read) as read:
            report = cp.check(self.path, 'assets')
        self.assertFalse(report['passed'])
        self.assertTrue(any('Render timing dependency missing' in e for e in report['errors']))
        self.assertNotIn(str(self.f.root/'evidence.json'), [str(c.args[0]) for c in read.call_args_list])

    def test_batch_matches_individual_results_and_compiled_payload(self):
        first = cp.check(self.path, 'plan')
        reports = cp.check_many([(self.path, 'plan'), (self.path, 'plan')])
        self.assertEqual(reports, [first, first])
        self.assertEqual(ct.compile_many([self.path, self.path]), [ct.compile_timeline(self.path)]*2)

    def test_mid_check_mutation_does_not_return_a_pass(self):
        original = cp._check
        def mutate(*a, **kw):
            report = original(*a, **kw)
            (self.f.root/'code.js').write_text('changed after judgment')
            return report
        with patch.object(cp, '_check', side_effect=mutate):
            with self.assertRaises(ValueError): cp.check_many([(self.path, 'plan')])

    def test_cli_primary_output_cannot_overwrite_additional_manifest_or_alias(self):
        other = self.f.root/'other.json'; other.write_bytes(self.path.read_bytes())
        alias = self.f.root/'alias-manifest.json'; alias.symlink_to(other)
        for out in (other, alias):
            self.f.m['compiled_timeline'] = str(out); self.f.save()
            before = {p: p.read_bytes() for p in (self.path, other)}
            with patch('sys.argv', ['compile_timeline', str(self.path), '--out', str(out), '--also-manifest', str(other)]), patch.object(ct, 'write_plan') as write, contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit) as exit: ct.main()
            self.assertEqual(exit.exception.code, 1); write.assert_not_called()
            self.assertEqual(before, {p: p.read_bytes() for p in before})

    def test_batch_output_cannot_replace_other_scope_dependency_or_hardlink(self):
        source = self.f.root/'code.js'; alias = self.f.root/'hardlink'; alias.hardlink_to(source)
        for out in (source, alias):
            with self.assertRaisesRegex(ValueError, 'cannot overwrite source inputs'):
                ct.validate_output_paths([self.path], [out], [source])
        with self.assertRaises(ValueError): ct.validate_output_paths([self.path], [source, alias])

    def test_compile_batch_checks_all_actual_dependency_paths_before_writing(self):
        with self.assertRaisesRegex(ValueError, 'cannot overwrite source inputs'):
            ct.compile_many([self.path], [self.f.root/'code.js'])


class RuntimeTimingTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        p = patch.dict(os.environ, {'LFC_RUN_DIR': str(self.root), 'LFC_RUNTIME_HOME': str(self.root/'shared')})
        p.start(); self.addCleanup(p.stop)

    def test_total_timing_includes_pre_command_post_and_has_no_overlap(self):
        def fake(name, args, timing):
            time.sleep(.01); timing['enter']('command'); time.sleep(.01)
            timing['enter']('postcheck'); time.sleep(.01); return 0
        with patch.object(runtime, '_invoke', side_effect=fake): self.assertEqual(runtime.invoke('fixture', []), 0)
        row = json.loads((self.root/'commands.jsonl').read_text())
        self.assertGreaterEqual(row['elapsed_s'], .03)
        self.assertAlmostEqual(row['elapsed_s'], sum(row['phase_elapsed_s'].values()))
        self.assertGreaterEqual(row['phase_elapsed_s']['preflight'], .01)
        self.assertGreaterEqual(row['phase_elapsed_s']['postcheck'], .01)

    def test_early_failure_recorded_without_running_child(self):
        with patch.object(runtime, 'frozen_skill', side_effect=ValueError('stale snapshot')), patch.object(runtime.subprocess, 'run') as child:
            with self.assertRaises(ValueError): runtime.invoke('fetch_channel', [])
        child.assert_not_called()
        row = json.loads((self.root/'commands.jsonl').read_text())
        self.assertEqual(row['exit_code'], 2); self.assertEqual(row['failure']['phase'], 'preflight')

    def test_busy_admission_is_recorded_as_retryable_exit_three(self):
        def busy(name, args, timing):
            timing['enter']('admission'); raise BlockingIOError('busy')
        with patch.object(runtime, '_invoke', side_effect=busy):
            with self.assertRaises(BlockingIOError): runtime.invoke('fixture', [])
        row = json.loads((self.root/'commands.jsonl').read_text())
        self.assertEqual(row['exit_code'], 3); self.assertEqual(row['failure']['phase'], 'admission')


if __name__ == '__main__': unittest.main()
