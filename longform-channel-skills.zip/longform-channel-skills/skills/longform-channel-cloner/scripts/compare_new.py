#!/usr/bin/env python3
"""Check a NEW video against the reference channel, cut by cut (the recreation check is compare.py).

  run.sh compare_new --project P --new NEW_DIR [--video NEW_DIR/output.mp4] [--out NEW_DIR/compare_new]

For every EDL cut it puts the donor's reference frame next to the new frame (pairs_###.jpg) and measures:
  - source type kept: needs.json source_type == donor source_type; registered asset method fits the type
    (ai_video->ai_video, stock_*->stock_search/library, graphics->render_graphic, external->archive/stock of the
    same kind) [any mismatch = fail, it is the "never swap the source type" rule]
  - motion: donor keyframe preset vs keyframes present in the EDL cut [missing motion on a moving donor = fail]
  - subtitle: every narration second covered by a subtitle; subtitle plate present when the reference has one
  - chrome: every style/chrome.json element (except the subtitle plate) has an own replacement in brand.json
  - pop-ups: planned text count per cut must be at least the donor pop-up count
  - credits: credit shown exactly where the donor shows one
  - length: total duration vs the reference median (style_profile videos) [> 5 % off = fail unless the new
    script.json has "length_ok_reason"]
  - audio: integrated loudness vs reference median [> 2 LU = fail]; SFX count per minute vs reference [< 50 % = warn]
Requires a rendered video; writes compare_new.json with pass/fail and per-cut rows.
Automatic PASS is a prerequisite for manual review of every pair, not a visual match verdict.
"""
from __future__ import annotations

import argparse
import statistics as st
import sys
from pathlib import Path

import cv2

from common import grab_frames, grid, label_image, lufs, extract_wav, probe, read_json, resize_w, write_json

GRAPHIC = {"motion_graphic", "text_card", "map_or_chart"}
METHOD_OK = {"ai_video": {"ai_video"}, "ai_image": {"ai_image"}, "illustration": {"ai_image"}, "stock_video": {"stock_search"},
             "stock_photo": {"stock_search"}, "archival_photo": {"stock_search", "archive_search"},
             "external_footage": {"archive_search", "screen_capture", "licensed_external"},
             "screen_recording": {"screen_capture"}, "motion_graphic": {"render_graphic"},
             "text_card": {"render_graphic"}, "map_or_chart": {"render_graphic"},
             "meme_or_reaction": {"archive_search", "licensed_external"}}


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--project", required=True)
    ap.add_argument("--new", required=True)
    ap.add_argument("--video")
    ap.add_argument("--out")
    a = ap.parse_args()
    P, N = Path(a.project), Path(a.new)
    out = Path(a.out or N / "compare_new")
    out.mkdir(parents=True, exist_ok=True)
    edl, needs = read_json(N / "edl.json"), read_json(N / "needs.json")
    script = read_json(N / "script.json") if (N / "script.json").exists() else {}
    man = (read_json(P / "assets" / "manifest.json") if (P / "assets" / "manifest.json").exists() else {"items": {}})["items"]
    prof = read_json(P / "style" / "style_profile.json") if (P / "style" / "style_profile.json").exists() else {}
    video = Path(a.video) if a.video else next((N / f for f in ("output_final.mp4", "output.mp4") if (N / f).exists()), None)
    fails, warns, rows = [], [], []
    donors_cache = {}

    def donor(ref):
        vid, cid = ref.split(":")
        if vid not in donors_cache:
            donors_cache[vid] = {c["id"]: c for c in read_json(P / "analysis" / vid / "cuts.json")["cuts"]}
        return donors_cache[vid].get(cid)

    for c in edl["cuts"]:
        n = needs.get(c["asset_key"], {})
        d = donor(c["donor"]) if c.get("donor") else None
        dann = (d or {}).get("annotation") or {}
        dtype = (dann.get("source") or {}).get("type")
        m = man.get(c["asset_key"], {})
        row = {"cut": c["id"], "donor": c.get("donor"), "donor_type": dtype, "new_type": n.get("source_type"),
               "asset_method": m.get("method"), "problems": []}
        if dtype and n.get("source_type") != dtype and not n.get("substitution_approved"):
            row["problems"].append(f"needs source type {n.get('source_type')} differs from donor {dtype}")
        if not m:
            row["problems"].append("no asset registered")
        elif dtype == "external_footage" and (m.get("provider") or "").split("/")[0] in ("pexels", "pixabay"):
            # stock libraries are generic footage; the reference shows real news/brand/person footage here
            if not n.get("substitution_approved"):
                row["problems"].append("external footage replaced by generic stock (needs the user's approval: "
                                       "set needs.json substitution_approved with their answer)")
        elif dtype and m.get("method") not in METHOD_OK.get(dtype, set()) and not n.get("substitution_approved"):
            row["problems"].append(f"source type swapped: donor {dtype}, asset method {m.get('method')}")
        if (m.get("notes") or "").lower().find("substitute") >= 0:
            row["problems"].append("asset marked as substitute")
        preset = (dann.get("keyframes") or {}).get("preset")
        if preset and preset not in ("static", "camera_motion") and not c.get("keyframes"):
            row["problems"].append(f"donor moves ({preset}) but the new cut has no keyframes")
        want_cr = bool((dann.get("source_credit") or {}).get("shown"))
        if want_cr != bool((c.get("credit") or {}).get("shown")) and dtype not in GRAPHIC:
            row["problems"].append(f"credit {'missing' if want_cr else 'added'} vs donor")
        dpops = sum(len(o.get("text_event_ids", [])) for o in dann.get("overlays", []) if o["kind"] in ("keyword_popup", "title", "number")) if dtype not in GRAPHIC else 0
        npops = sum(1 for t in edl.get("texts", []) if t.get("kind") not in ("subtitle",) and c["start_s"] <= t["start_s"] < c["end_s"] and t.get("text"))
        row["popups"] = [dpops, npops]
        if npops < dpops:
            row["problems"].append(f"{npops} pop-ups vs donor {dpops}")
        if row["problems"]:
            fails += [f"{c['id']}: {p}" for p in row["problems"]]
        rows.append(row)
    # subtitles cover narration
    nar = read_json(N / "tts" / "narration.json") if (N / "tts" / "narration.json").exists() else {"words": []}
    subs = [t for t in edl.get("texts", []) if t.get("kind") == "subtitle"]
    uncovered = [w["w"] for w in nar.get("words", []) if not any(s["start_s"] - 0.05 <= w["start"] and w["end"] <= s["end_s"] + 0.1 for s in subs)]
    if len(uncovered) > max(3, 0.02 * len(nar.get("words", []))):
        fails.append(f"{len(uncovered)} narration words without subtitle (e.g. {uncovered[:5]})")
    if subs and not any((s.get("style") or {}).get("box") for s in subs):
        ref_plate = any((z.get("plate") or {}) for v in prof.get("videos", {}) for z in
                        (read_json(P / "analysis" / v / "captions.json").get("zones", []) if (P / "analysis" / v / "captions.json").exists() else []))
        if ref_plate:
            fails.append("reference subtitles sit on a plate but the new subtitles have none")
    # chrome replacement
    cp, bp = P / "style" / "chrome.json", P / "brand.json"
    if cp.exists():
        conf = (read_json(bp).get("chrome") or {}) if bp.exists() else {}
        miss = [e["id"] for e in read_json(cp)["elements"] if e.get("kind_guess") != "subtitle_plate" and e["id"] not in conf]
        if miss:
            fails.append(f"reference chrome without own replacement: {miss} (brand.json chrome)")
    # length
    ref_durs = [v.get("duration_s") for v in prof.get("videos", {}).values() if v.get("duration_s")]
    if ref_durs:
        med = st.median(ref_durs)
        ratio = edl["duration_s"] / med
        if abs(ratio - 1) > 0.05 and not script.get("length_ok_reason"):
            fails.append(f"length {edl['duration_s']:.0f}s is {ratio:.0%} of reference median {med:.0f}s "
                         "(ask the user first; record their answer as script.json length_ok_reason)")
    # audio
    rep_audio = {}
    if video and video.exists():
        info = probe(video)
        if abs(info["duration_s"] - edl["duration_s"]) > max(0.5, 2 / info["fps"]):
            fails.append(f"rendered duration {info['duration_s']:.2f}s differs from EDL {edl['duration_s']:.2f}s")
        wav = extract_wav(video, out / "new.wav", 48000, 1)
        rep_audio["new_lufs"] = lufs(wav)
        ref_l = [v.get("levels", {}).get("mix_lufs") for v in prof.get("audio", {}).values() if v.get("levels", {}).get("mix_lufs") is not None]
        if ref_l and rep_audio["new_lufs"] is not None:
            rep_audio["ref_lufs_median"] = st.median(ref_l)
            rep_audio["diff_lu"] = round(rep_audio["new_lufs"] - rep_audio["ref_lufs_median"], 2)
            if abs(rep_audio["diff_lu"]) > 2:
                fails.append(f"loudness {rep_audio['new_lufs']} LUFS vs reference {rep_audio['ref_lufs_median']}")
        spm_ref = [v.get("sfx_per_minute_filtered") or v.get("sfx_per_minute") for v in prof.get("audio", {}).values()]
        spm_ref = [x for x in spm_ref if x]
        spm_new = len(edl.get("sfx", [])) / max(1e-6, edl["duration_s"] / 60)
        rep_audio["sfx_per_min"] = [round(spm_new, 2), round(st.median(spm_ref), 2) if spm_ref else None]
        if spm_ref and spm_new < 0.5 * st.median(spm_ref):
            warns.append(f"SFX {spm_new:.1f}/min vs reference {st.median(spm_ref):.1f}/min")
        # frame pairs donor | new
        fr_new = grab_frames(video, [int((c["start_s"] + c["end_s"]) / 2 * info["fps"]) for c in edl["cuts"]], width=480)
        tiles = []
        for c in edl["cuts"]:
            nf = fr_new.get(int((c["start_s"] + c["end_s"]) / 2 * info["fps"]))
            dfp = needs.get(c["asset_key"], {}).get("donor_frame")
            df = cv2.imread(dfp) if dfp and Path(dfp).exists() else None
            if nf is None or df is None:
                fails.append(f"{c['id']}: missing rendered or donor frame for visual review")
                continue
            tiles += [label_image(resize_w(df, 480), f"DONOR {c['donor']}", 0.4), label_image(nf.copy(), f"NEW {c['id']}", 0.4)]
        for k in range(0, len(tiles), 16):
            cv2.imwrite(str(out / f"pairs_{k // 16 + 1:03d}.jpg"), grid(tiles[k:k + 16], 4))
    else:
        fails.append("no rendered video found; cannot validate the finished video")
    rep = {"pass": not fails, "fails": fails, "warnings": warns, "audio": rep_audio, "cuts": rows,
           "duration_s": edl["duration_s"]}
    write_json(out / "compare_new.json", rep)
    print(f"{'PASS' if not fails else 'FAIL'}: {len(fails)} fails, {len(warns)} warnings -> {out / 'compare_new.json'}")
    for f in fails[:25]:
        print("  FAIL", f)
    for w in warns[:15]:
        print("  warn", w)
    print(f"pairs: {out}/pairs_*.jpg (donor left, new right) - look at every pair")
    sys.exit(0 if rep["pass"] else 1)


if __name__ == "__main__":
    main()
