"""효율화가 입력 연결·독립 검수·완료 기준을 약화시키지 않는지 검사한다."""
import contextlib
import datetime as dt
import io
import json
import os
import sqlite3
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import work_guard as guard
from runtime import collect_usage, initialize, frozen_skill
from fetch_channel import choose_references, cmd_list
from plan_duration import plan_duration
from workflow import check_handoff, impact, REQUIRED


class Fixture(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.p=Path(self.tmp.name).resolve()
        env=patch.dict(os.environ,{'LFC_RUNTIME_HOME':str(self.p/'db')});env.start();self.addCleanup(env.stop)

    def write(self,name,value):
        p=self.p/name;p.parent.mkdir(parents=True,exist_ok=True)
        p.write_text(json.dumps(value) if not isinstance(value,str) else value);return p

    def manifest(self,name,rows):
        return self.write(name,{'schema':'lfc-inputs-v1','files':[{'path':str(p),'sha256':h} for p,h in rows]})


class EfficiencyTests(Fixture):
    def test_nested_shared_dependency_hashed_once_and_conflict_rejected(self):
        media=self.write('media','payload');h=guard.digest(media)
        left=self.manifest('left.json',[(media,h)]);right=self.manifest('right.json',[(media,h)])
        root=self.manifest('root.json',[(left,guard.digest(left)),(right,guard.digest(right))])
        snap=guard.FileSnapshot()
        with patch('work_guard.digest',wraps=guard.digest) as read:
            guard.dependencies([root,left],snap);guard.revision_fingerprint([root],snap)
        self.assertEqual(read.call_count,4)
        right=self.manifest('right.json',[(media,'0'*64)])
        with self.assertRaisesRegex(ValueError,'Dependency changed'):guard.dependencies([left,right])

    def test_same_size_restored_mtime_and_symlink_mutation_detected(self):
        p=self.write('a','AAAA');q=self.write('b','BBBB');link=self.p/'alias';link.symlink_to(p)
        snap=guard.FileSnapshot();snap.add(link);st=p.stat()
        p.write_text('CCCC');os.utime(p,ns=(st.st_atime_ns,st.st_mtime_ns))
        with self.assertRaises(ValueError):snap.unchanged()
        snap=guard.FileSnapshot();snap.add(link);link.unlink();link.symlink_to(q)
        with self.assertRaises(ValueError):snap.unchanged()

    def test_role_swap_changes_revision_even_with_same_content_set(self):
        a=self.write('a','a');b=self.write('b','b')
        p=self.write('inputs.json',{'schema':'lfc-inputs-v1','files':[
            {'path':'a','sha256':guard.digest(a),'role':'visual'},
            {'path':'b','sha256':guard.digest(b),'role':'script'}]})
        first=guard.revision_fingerprint([p]);doc=json.loads(p.read_text())
        doc['files'][0]['role'],doc['files'][1]['role']='script','visual';self.write('inputs.json',doc)
        self.assertNotEqual(first,guard.revision_fingerprint([p]))

    def test_hashing_allows_another_db_writer(self):
        root=self.p/'run';guard.execute(root,'status');p=self.write('input','x');original=guard.digest
        def read(path):
            db=sqlite3.connect(self.p/'db/work.sqlite',timeout=.05)
            try:db.execute('BEGIN IMMEDIATE');db.rollback()
            finally:db.close()
            return original(path)
        with patch('work_guard.digest',side_effect=read):
            self.assertEqual(guard.execute(root,'claim','analysis',[p],resource='A',stage='analysis')['decision'],'run')

    def test_status_can_read_while_other_writer_holds_transaction(self):
        root=self.p/'run';guard.execute(root,'status')
        db=sqlite3.connect(self.p/'db/work.sqlite');db.execute('BEGIN IMMEDIATE')
        try:self.assertEqual(guard.execute(root,'status')['jobs'],[])
        finally:db.rollback();db.close()

    def test_usage_partial_append_and_replacement_do_not_double_count(self):
        root=self.p/'run';root.mkdir();source=self.write('source','x')
        job=guard.execute(root,'claim','analysis',[source],resource='A',stage='analysis')
        def event(rid):
            return json.dumps({'type':'token_usage_record','timestamp':dt.datetime.now(dt.timezone.utc).isoformat(),
              'payload':{'thread_id':'actual','response_id':rid,'usage':{'input_tokens':10,'cached_input_tokens':8,'output_tokens':2}}})+'\n'
        header=json.dumps({'type':'session_meta','payload':{'id':'actual'}})+'\n'
        second=event('r2');log=self.write('rollout.jsonl',header+event('r1')+second[:20])
        self.assertEqual(collect_usage(root,job['lease'],log)['calls'],1)
        with log.open('a') as f:f.write(second[20:])
        self.assertEqual(collect_usage(root,job['lease'],log)['calls'],2)
        replacement=self.write('replacement',header+event('r1')+event('r2'));replacement.replace(log)
        self.assertEqual(collect_usage(root,job['lease'],log)['calls'],2)

    def test_snapshot_contains_stages_no_deadline_and_rejects_added_code(self):
        run=initialize(Path(__file__).resolve().parent.parent,self.p,'run')
        config=json.loads((Path(run['run_dir'])/'run.json').read_text())
        self.assertTrue(all(v is None for v in config['limits'].values()))
        self.assertTrue(all(v==['gpt-6.1-sol','high'] for v in config['models'].values()))
        self.assertEqual(config['reference_policy'],{'mode':'latest-one-v1','count':1,'max_duration_s':1800})
        self.assertEqual(config['duration_policy']['full_tolerance_s'],30)
        for stage in ('analysis','planning','production','review'):
            self.assertTrue((Path(run['skill'])/'stages'/('longform-channel-'+stage)/'SKILL.md').is_file())
        (Path(run['skill'])/'scripts/injected.py').write_text('pass')
        with self.assertRaisesRegex(ValueError,'inventory'):frozen_skill(run['run_dir'])

    def test_latest_one_same_day_keep_channel_order_without_view_counts(self):
        rows=[{'id':vid,'upload_date':'20261001','duration':600,'view_count':None} for vid in ('Z','A','B')]
        result=choose_references(rows,dt.date(2026,10,2))
        self.assertEqual(result['recent'],['Z']);self.assertEqual(result['unresolved_ids'],[])

    def test_latest_one_metadata_stops_after_one_confirmed_candidate(self):
        entries=[{'id':str(i),'duration':600} for i in range(20)]
        args=SimpleNamespace(project=str(self.p/'channel'),channel_url='https://www.youtube.com/@test',as_of='2026-10-02',
            min_duration=0,max_duration=1800,top=0,recent=1,scan=0,cookies_from_browser=None,metadata_jobs=3)
        def meta(vid,*args):return {'id':vid,'duration':600,'upload_date':'20261001','view_count':None}
        with patch('fetch_channel.ytdlp',return_value=SimpleNamespace(returncode=0,stdout=json.dumps({'entries':entries}))),patch('fetch_channel.cached_meta',side_effect=meta) as fetch,contextlib.redirect_stdout(io.StringIO()):
            cmd_list(args)
        self.assertEqual(fetch.call_count,1)
        self.assertTrue(json.loads((self.p/'channel/channel.json').read_text())['selection_complete'])

    def test_two_reference_mean(self):
        result=plan_duration({'reference_count':2,'references':[{'id':'A','duration_s':600},{'id':'B','duration_s':900}]},'input')
        self.assertEqual(result['reference_count'],2)
        self.assertIn(750,result.values())

    def test_impact_includes_all_instances_and_neighbors(self):
        cuts=[{'id':str(i),'renderer_layers':[{'kind':'text' if i in (1,4) else 'rect'}]} for i in range(6)]
        result=impact({'cuts':cuts},['scene:text'])
        self.assertEqual(result['affected_cut_ids'],['1','4'])
        self.assertEqual(result['review_cut_ids_with_neighbors'],[str(i) for i in range(6)])
        with self.assertRaises(ValueError):impact({'cuts':cuts},['unknown'])


class HandoffTests(Fixture):
    def packet(self,stage,previous=None):
        rows=[]
        def row(role,name,value,vid=None):
            path=self.write(name,value)
            item={'role':role,'path':str(path),'sha256':guard.digest(path)}
            if vid:item['video_id']=vid
            rows.append(item);return path
        basis=self.write('criterion','fixed')
        doc={'schema':'lfc-stage-handoff-v1','stage':stage,'model':'gpt-6.1-sol','reasoning_effort':'high','session_id':stage,
             'user_instructions':[],'unresolved_items':[],'completed_scope':['complete'],'basis_sha256':{str(basis):guard.digest(basis)},
             'files':rows,'reference_ids':['A'],'input_sha256':'actual-input','implementation_session_ids':['production']}
        if previous:
            doc['previous_handoff']={'path':str(previous),'sha256':guard.digest(previous)}
        if stage=='analysis':
            row('selected_references','selected.json',{'reference_count':1,'selection_complete':True,'references':[{'id':v,'duration_s':10} for v in doc['reference_ids']]})
            row('style','style.json',{'styles':['observed']})
            for vid in doc['reference_ids']:
                source=row('source',vid+'/source','video',vid)
                visual=row('visual_analysis',vid+'/visual.json',{'analysis_provenance':{'video_id':vid,'source_sha256':guard.digest(source),
                    'model':'gpt-6.1-sol','reasoning_effort':'high','session_id':'analysis'},'full_video_analyzed':True,'coverage':{'missing_ranges':[],'duration_s':10}},vid)
                script=row('script_analysis',vid+'/script.json',{'video_id':vid},vid)
                speech=row('speech_rate',vid+'/speech.json',{'status':'measured'},vid)
                row('evidence',vid+'/frame','observed',vid)
                row('analysis_validation',vid+'/validation.json',{'passed':True,'source_sha256':guard.digest(source),'output_sha256':guard.hashes([visual,script,speech])},vid)
            doc['states']={'observed':True,'production_ready':True,'render_verified':False}
        else:
            old={r['role']:r for r in json.loads(previous.read_text())['files']}
            for role in sorted(REQUIRED[stage]):
                if role.endswith('validation'):continue
                if role in old:rows.append(old[role].copy())
                else:row(role,stage+'/'+role+'.json',{'artifact':role})
            if stage in ('production','review'):
                role='numeric_validation' if stage=='production' else 'final_validation'
                outputs={'render'} if stage=='production' else {'render','conformance','visual_review','script_review'}
                report={'passed':True,'input_sha256':'actual-input','output_sha256':{r['path']:r['sha256'] for r in rows if r['role'] in outputs},
                        'dependencies_sha256':{r['path']:r['sha256'] for r in rows if r['role'] in ('baseline','reference_map','render_inputs')}}
                row(role,stage+'/validation.json',report)
        return self.write(stage+'-handoff.json',doc)

    def chain(self):
        previous=None
        for stage in ('analysis','planning','production','review'):previous=self.packet(stage,previous)
        return previous

    def test_valid_chain_and_stale_predecessor(self):
        final=self.chain();result=check_handoff(final)
        self.assertTrue(result['passed'],result['errors'])
        self.write('A/frame','changed')
        self.assertFalse(check_handoff(final)['passed'])

    def test_new_handoff_rejects_extra_reference_or_incomplete_selection(self):
        packet=self.packet('analysis');original=json.loads(packet.read_text())
        for ids in ([],['A','B']):
            self.write(packet.name,dict(original,reference_ids=ids))
            self.assertFalse(check_handoff(packet)['passed'])
        self.write(packet.name,original)
        selected=self.p/'selected.json';selection=json.loads(selected.read_text())
        for count,complete in ((2,True),(True,True),(1,False)):
            self.write(selected.name,dict(selection,reference_count=count,selection_complete=complete))
            doc=json.loads(packet.read_text())
            next(r for r in doc['files'] if r['role']=='selected_references')['sha256']=guard.digest(selected)
            self.write(packet.name,doc)
            self.assertFalse(check_handoff(packet)['passed'])

    def test_unrelated_validation_cannot_approve_production_or_review(self):
        final=self.chain()
        for stage in ('production','review'):
            packet=self.p/(stage+'-handoff.json');doc=json.loads(packet.read_text())
            validation=next(r for r in doc['files'] if r['role'].endswith('validation'))
            original=Path(validation['path']).read_text();old_hash=validation['sha256']
            unrelated=self.write('unrelated','x')
            Path(validation['path']).write_text(json.dumps({'passed':True,'input_sha256':'actual-input','output_sha256':guard.hashes([unrelated])}))
            validation['sha256']=guard.digest(validation['path']);self.write(packet.name,doc)
            self.assertFalse(check_handoff(packet)['passed'])
            Path(validation['path']).write_text(original);validation['sha256']=old_hash;self.write(packet.name,doc)

    def test_reference_id_mismatch_and_missing_chain_rejected(self):
        final=self.chain();doc=json.loads(final.read_text());doc.pop('previous_handoff');self.write(final.name,doc)
        self.assertFalse(check_handoff(final)['passed'])
        analysis=self.p/'analysis-handoff.json';doc=json.loads(analysis.read_text());doc['reference_ids']=['A','C'];self.write(analysis.name,doc)
        self.assertFalse(check_handoff(analysis)['passed'])


class ReviewIndependenceTests(unittest.TestCase):
    def test_actual_source_session_cannot_be_hidden_in_baseline(self):
        from test_check_production import ProductionGateTest
        fixture=ProductionGateTest();fixture.setUp();self.addCleanup(fixture.doCleanups)
        data=json.loads((fixture.root/'evidence.json').read_text());data['analysis_provenance']['session_id']='independent'
        fixture.write('evidence.json',data);fixture.reviews()
        result=fixture.run_gate('final');self.assertFalse(result['passed'])
        self.assertTrue(any('actual analysis' in e for e in result['errors']),result)

    def test_actual_implementation_session_cannot_be_hidden(self):
        from test_check_production import ProductionGateTest
        fixture=ProductionGateTest();fixture.setUp();self.addCleanup(fixture.doCleanups)
        fixture.write('implementation.json',{'session_ids':['independent']});fixture.reviews()
        result=fixture.run_gate('final');self.assertFalse(result['passed'])
        self.assertTrue(any('implementation provenance' in e for e in result['errors']),result)


if __name__=='__main__':unittest.main()
