import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from check_duration_feasibility import inspect_structure

class DurationEarlyTest(unittest.TestCase):
    def test_single_reference_tolerance_intersection_and_cli_exit(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)
            (root/'source.json').write_text(json.dumps({'analysis_provenance':{'video_id':'v1'},'background_segments':[{'id':'bg1','start_s':0,'end_s':300}]}))
            (root/'structure.json').write_text(json.dumps({'structure_id':'S1','cuts':[{'id':'c1','reference_video_id':'v1','reference_cut_id':'bg1','duration_s':300,'visual_evidence':{'file':'source.json','pointer':'/background_segments/0'}}]}))
            for target,expected in ((210,True),(209.99,False),(390,True),(390.01,False)):
                with self.subTest(target=target):
                    (root/'selected.json').write_text(json.dumps({'reference_count':1,'references':[{'id':'v1','duration_s':target}]}))
                    report=inspect_structure(root/'structure.json',root/'selected.json')
                    self.assertFalse(report['mean_feasible'])
                    self.assertEqual(report['target_range_feasible'],expected)
                    result=subprocess.run([sys.executable,'-B',str(Path(__file__).with_name('check_duration_feasibility.py')),str(root/'structure.json'),'--references',str(root/'selected.json'),'--out',str(root/'report.json')],capture_output=True,text=True)
                    self.assertEqual(result.returncode,0 if expected else 1,result.stderr)

    def test_without_script_tts_or_narration_windows(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)
            (root/'source.json').write_text(json.dumps({'analysis_provenance':{'video_id':'v1'},'background_segments':[{'id':'bg1','start_s':0,'end_s':10}]}))
            (root/'structure.json').write_text(json.dumps({'structure_id':'S1','cuts':[{'id':'c1','reference_video_id':'v1','reference_cut_id':'bg1','duration_s':10,'visual_evidence':{'file':'source.json','pointer':'/background_segments/0'}}]}))
            selected={'references':[{'id':f'v{i}','duration_s':20} for i in range(6)]}
            (root/'selected.json').write_text(json.dumps(selected))
            report=inspect_structure(root/'structure.json',root/'selected.json')
            self.assertFalse(report['mean_feasible'])
            self.assertEqual(report['maximum_duration_s'],12)
            self.assertEqual(report['nearest_feasible_duration_s'],12)
            result=subprocess.run([sys.executable,str(Path(__file__).with_name('check_duration_feasibility.py')),str(root/'structure.json'),'--selected6',str(root/'selected.json'),'--out',str(root/'report.json')],capture_output=True,text=True)
            self.assertEqual(result.returncode,1)
            self.assertFalse(json.loads((root/'report.json').read_text())['mean_feasible'])
            selected['references'][0]['duration_s']=10
            for row in selected['references']:row['duration_s']=10
            (root/'selected.json').write_text(json.dumps(selected))
            self.assertTrue(inspect_structure(root/'structure.json',root/'selected.json')['mean_feasible'])

class DuplicateSourceTest(unittest.TestCase):
    def test_same_source_with_new_cut_id_cannot_inflate_duration(self):
        from timing_contract import duration_preflight, validate_reference_clips
        rows=[{'cut_id':name,'reference_video_id':'v1','reference_cut_id':'bg1','original_duration_s':10} for name in ('c1','c2')]
        with self.assertRaisesRegex(ValueError,'Duplicate source background'):
            validate_reference_clips(rows)
        with self.assertRaisesRegex(ValueError,'Duplicate source background'):
            duration_preflight({'duration_link':{}},{},rows,20,20,'','',lambda _:None)

if __name__=='__main__':unittest.main()
