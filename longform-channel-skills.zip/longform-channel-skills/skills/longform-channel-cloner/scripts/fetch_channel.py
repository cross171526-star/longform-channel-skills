#!/usr/bin/env python3
"""Pick and download reference videos from a YouTube channel.

  run.sh fetch_channel list <channel_url> --project DIR [--recent 1] [--top 0] [--max-duration 1800] [--as-of YYYY-MM-DD] [--scan 0]
  run.sh fetch_channel download --project DIR [--ids ID ...] [--max-height 1080] [--jobs 3] [--cookies-from-browser BROWSER]

list: checks eligible /videos metadata before ranking. Selects the current cumulative-view top uploads
published in the last calendar year (inclusive) and newest remaining uploads, all at most 30 minutes.
Unknown metadata and limited scans are recorded as incomplete, never an authoritative full ranking.
download: fetches each selected video (<=1080p, H.264 preferred for frame-accurate decoding), info json,
thumbnail and subtitles into DIR/videos/<id>/, then writes meta.json. --jobs videos download at once and each
uses 4 fragment connections. Subtitles are fetched only in the channel's language (ko.* by default): extra
languages hit YouTube's 429 rate limit and add minutes of retries.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import math
import os
import time
import tempfile
from concurrent.futures import ThreadPoolExecutor
from zoneinfo import ZoneInfo
import re
import subprocess
import sys
from pathlib import Path

from common import FFMPEG, probe, read_json, write_json

LIVE_STATES = {"is_live", "was_live", "post_live", "is_upcoming"}


def ytdlp(args: list[str], cookies: str | None = None, timeout_s: float | None = None) -> subprocess.CompletedProcess:
    cmd = [sys.executable, "-m", "yt_dlp", "--js-runtimes", "node",
           "--ffmpeg-location", str(Path(FFMPEG).parent), "--no-warnings"]
    if cookies:
        cmd += ["--cookies-from-browser", cookies]
    try:
        return subprocess.run(cmd + ['--socket-timeout','20','--extractor-retries','2'] + args,
                              capture_output=True, text=True, timeout=timeout_s if timeout_s is not None else (1800 if '--merge-output-format' in args else 300))
    except subprocess.TimeoutExpired:
        return subprocess.CompletedProcess(cmd, 124, stdout='', stderr='Metadata/download command timed out; resume cached completed work')


def normalize_channel(url: str) -> str:
    url = url.strip()
    if url.startswith("@"):
        url = "https://www.youtube.com/" + url
    elif not url.startswith("http"):
        url = "https://www.youtube.com/" + url.lstrip("/")
    url = re.sub(r"[?#].*$", "", url).rstrip("/")
    url = re.sub(r"/(videos|shorts|streams|featured|playlists|community|about|podcasts|releases)$", "", url)
    return url + "/videos"


def video_meta(vid: str, cookies: str | None) -> dict | None:
    p = ytdlp(["-J", "--skip-download", "--no-playlist", f"https://www.youtube.com/watch?v={vid}"], cookies)
    if p.returncode != 0:
        print(f"  ! metadata failed for {vid}: {p.stderr.strip()[-300:]}", file=sys.stderr)
        return None
    try: return json.loads(p.stdout)
    except ValueError: return None


def cached_meta(vid, cookies, cache, flat_duration=None):
    cache=Path(cache);cache.mkdir(parents=True,exist_ok=True);path=cache/(vid+'.json')
    try:
        record=json.loads(path.read_text());meta=record['meta']
        if time.time()-record['checked_at']<21600 and (flat_duration is None or meta.get('duration')==flat_duration):
            return meta
    except (OSError,ValueError,KeyError):pass
    meta=video_meta(vid,cookies)
    if meta:
        # Independent sessions can share completed cache entries, never partial files.
        with tempfile.NamedTemporaryFile(mode='w',dir=cache,suffix='.tmp',delete=False) as f:
            json.dump({'checked_at':time.time(),'meta':meta},f,ensure_ascii=False);temporary=f.name
        os.replace(temporary,path)
    return meta


def cmd_titles(a) -> None:
    """Inventory every retrievable title; no duration or ranking filter."""
    base = normalize_channel(a.channel_url).removesuffix('/videos')
    records, tabs = {}, {}
    quick = getattr(a, 'quick', False)
    for tab in (('videos',) if quick else ('videos', 'shorts', 'streams')):
        if quick:
            result = ytdlp(['--flat-playlist', '--playlist-end', '100', '-J', base + '/' + tab], a.cookies_from_browser, timeout_s=90)
        else:
            result = ytdlp(['--flat-playlist', '-J', base + '/' + tab], a.cookies_from_browser)
        if result.returncode:
            tabs[tab] = {'status': 'unavailable', 'reason': result.stderr.strip()[-500:]}
            continue
        try:
            data = json.loads(result.stdout)
            entries = data.get('entries')
            if not isinstance(entries, list):
                raise ValueError('No playlist entries array')
        except (ValueError, AttributeError) as exc:
            tabs[tab] = {'status': 'unavailable', 'reason': str(exc)}
            continue
        missing = 0
        for order, entry in enumerate(entries):
            if not entry or not entry.get('id') or not entry.get('title'):
                missing += 1
                continue
            vid = entry['id']
            if vid not in records:
                records[vid] = {'id': vid, 'title': entry['title'],
                    'url': 'https://www.youtube.com/watch?v=' + vid,
                    'upload_date': entry.get('upload_date'), 'timestamp': entry.get('timestamp'),
                    'view_count': entry.get('view_count'), 'duration': entry.get('duration'),
                    'appearances': []}
            records[vid]['appearances'].append({'tab': tab, 'order': order})
        tabs[tab] = {'status': 'retrieved' if missing == 0 else 'partial',
                     'entries_returned': len(entries), 'missing_titles_or_ids': missing}
    out = {'channel_url': base, 'checked_at': dt.datetime.now(dt.timezone.utc).isoformat(),
           'scope': ('First up to 100 public videos-tab titles for topic proposal; not a complete channel inventory.' if quick else 'Public titles returned by videos/shorts/streams tabs; private/deleted/unlisted content is not guaranteed.'),
           'all_tabs_retrieved': not quick and all(v['status'] == 'retrieved' for v in tabs.values()),
           'quick_topic_proposal': quick, 'title_limit': 100 if quick else None,
           'tabs': tabs, 'count': len(records), 'videos': list(records.values()),
           'note': 'Flat metadata may omit dates and round views. Tab order is not an exact upload date. Inventory is not semantic analysis.'}
    target = Path(a.project) / 'analysis' / 'channel_titles.json'
    write_json(target, out)
    print(f'Title inventory: {len(records)} unique titles -> {target}; all tabs retrieved={out["all_tabs_retrieved"]}')


def publication_day(entry):
    try:
        return dt.datetime.strptime(entry['upload_date'], '%Y%m%d').date()
    except (KeyError, ValueError, TypeError):
        return None


def year_boundary(day):
    try:
        return day.replace(year=day.year - 1)
    except ValueError:  # Feb 29 -> Feb 28 of the preceding year
        return day.replace(year=day.year - 1, day=28)


def excluded_format(entry):
    return (entry.get('live_status') in LIVE_STATES or entry.get('was_live')
            or entry.get('is_live') or entry.get('is_short')
            or '/shorts/' in str(entry.get('webpage_url') or entry.get('url') or ''))


def choose_references(entries, as_of, top=0, recent=1, min_duration=0, max_duration=1800):
    cutoff = year_boundary(as_of)
    valid, unresolved, seen = [], [], set()
    for entry in entries:
        vid = entry.get('id')
        if not vid or vid in seen:
            continue
        seen.add(vid)
        if excluded_format(entry):
            continue
        duration, views, day = entry.get('duration'), entry.get('view_count'), publication_day(entry)
        number = lambda x: isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)
        if number(duration) and (duration > max_duration or duration < min_duration):
            continue
        if not number(duration) or duration <= 0 or day is None or (top and (not number(views) or views < 0)):
            unresolved.append(vid)
            continue
        if day > as_of:
            continue
        valid.append(entry)
    # 같은 날짜는 /videos의 최신순을 유지한다. video_id는 게시순이 아니다.
    newest = sorted(valid, key=publication_day, reverse=True)
    ranked = sorted((e for e in valid if cutoff <= publication_day(e) <= as_of and number(e.get('view_count')) and e['view_count'] >= 0),
                    key=lambda x: (-x['view_count'], -publication_day(x).toordinal(), x['id']))
    top_ids = [e['id'] for e in ranked[:top]]
    recent_pool = [e['id'] for e in newest if e['id'] not in top_ids]
    return {'top_views': top_ids, 'recent': recent_pool[:recent],
            'backup_top': [e['id'] for e in ranked[top:top+3]],
            'backup_recent': recent_pool[recent:recent+3],
            'eligible': newest, 'ranked': ranked, 'unresolved_ids': unresolved,
            'cutoff': cutoff.isoformat()}


def cmd_list(a) -> None:
    project = Path(a.project)
    project.mkdir(parents=True, exist_ok=True)
    url = normalize_channel(a.channel_url)
    as_of = dt.date.fromisoformat(a.as_of) if a.as_of else dt.datetime.now(ZoneInfo('Asia/Seoul')).date()
    if not 0 <= a.min_duration < a.max_duration <= 1800 or a.top < 0 or a.recent < 0:
        sys.exit('Invalid selection limits: 0 <= min < max <= 1800 required')
    args = ['--flat-playlist', '-J']
    if a.scan:
        args += ['--playlist-end', str(a.scan)]
    print(f'listing {url} ...')
    p = ytdlp(args + [url], a.cookies_from_browser)
    if p.returncode != 0:
        sys.exit(p.stderr[-2000:])
    data = json.loads(p.stdout)
    entries = {e['id']: e for e in (data.get('entries') or []) if e and e.get('id')}
    # Do not pick all-time top candidates before applying the upload-date filter.
    # Exact metadata is needed for date eligibility and ranking; unknowns remain explicit.
    metas, failed, candidates = [], [], []
    for vid, entry in entries.items():
        if excluded_format(entry): continue
        duration=entry.get('duration')
        if isinstance(duration,(int,float)) and not isinstance(duration,bool) and math.isfinite(duration):
            if duration>a.max_duration or duration<a.min_duration:continue
        candidates.append((vid,duration))
    cache=Path(getattr(a,'metadata_cache_dir',None) or project/'.cache/youtube')
    workers=min(3,max(1,getattr(a,'metadata_jobs',3)))
    with ThreadPoolExecutor(max_workers=workers) as executor:
        def fetch(row):return row[0],cached_meta(row[0],a.cookies_from_browser,cache,row[1])
        # /videos 최신순 목록에서 필요한 후보만 상세 조회한다. 과거 전체 조회수 순위와 구분한다.
        batch_size = workers if a.top else max(1, min(workers, a.recent))
        for offset in range(0, len(candidates), batch_size):
            for vid,meta in executor.map(fetch,candidates[offset:offset+batch_size]):
                if meta and meta.get('id')==vid:metas.append(meta)
                else:failed.append(vid)
            if not a.top and len(choose_references(metas,as_of,0,a.recent,a.min_duration,a.max_duration)['recent']) >= a.recent:
                break
    selection = choose_references(metas, as_of, a.top, a.recent, a.min_duration, a.max_duration)
    top_ids, recent_ids = selection['top_views'], selection['recent']
    videos = {}
    for meta in selection['eligible']:
        vid = meta['id']
        roles = [f'top_views#{top_ids.index(vid)+1}'] if vid in top_ids else []
        if vid in recent_ids:
            roles.append(f'recent#{recent_ids.index(vid)+1}')
        videos[vid] = {'title':meta.get('title'), 'url':f'https://www.youtube.com/watch?v={vid}',
                       'duration':meta['duration'], 'view_count':meta.get('view_count'),
                       'upload_date':meta['upload_date'], 'roles':roles or ['candidate']}
    unresolved = sorted(set(failed + selection['unresolved_ids']))
    complete = not a.scan and not unresolved and len(top_ids) == a.top and len(recent_ids) == a.recent
    out = {'channel_url':url,
           'channel':{'id':data.get('channel_id') or data.get('id'), 'name':data.get('channel') or data.get('title'), 'handle':data.get('uploader_id')},
           'listed_at':dt.datetime.now(ZoneInfo('Asia/Seoul')).isoformat(timespec='seconds'),
           'metadata_cache_max_age_s':21600, 'metadata_cache_dir':str(cache.resolve()),
           'longform_listed':len(videos), 'min_duration_s':a.min_duration,'max_duration_s':a.max_duration,
           'selection_policy':{'as_of':as_of.isoformat(),'timezone':'Asia/Seoul','top_upload_start':selection['cutoff'],
                               'top_upload_end':as_of.isoformat(),'inclusive':True,'ranking':'current_cumulative_views' if a.top else 'latest_uploads',
                               'reference_count':a.top+a.recent,'metadata_scope':'all_eligible' if a.top else 'newest_candidates',
                               'listing_order':'YouTube /videos newest-first; unresolved earlier candidates block completion',
                               'recent_upload_window':None,'max_duration_s':a.max_duration},
           'selection_complete':complete,'unresolved_ids':unresolved,'limited_scan':bool(a.scan),
           'selection':{'pilot':(top_ids+recent_ids)[0] if top_ids+recent_ids else None, **{k:selection[k] for k in ('top_views','recent','backup_top','backup_recent')}},
           'videos':videos}
    write_json(project/'channel.json',out)
    write_json(project/'style/topic_references.json', {'note':'Verified <=30-minute candidates; popularity window uses upload date, not one-year view gains.',
               'selection_complete':complete,'last_year_top':[{'rank':i+1,**videos[e['id']],'id':e['id']} for i,e in enumerate(selection['ranked'][:20])]})
    print(f"selected top={top_ids}, recent={recent_ids}; complete={complete}")
    if not complete:
        print('WARN: insufficient eligible references or unresolved/list-limited metadata; do not widen limits or claim final ranking.',file=sys.stderr)


def cmd_download(a) -> None:
    project = Path(a.project)
    ch = read_json(project / "channel.json")
    if not a.ids and ch.get("selection_complete") is False:
        sys.exit("Selection is incomplete; resolve metadata/selection before automatic download")
    sel = ch["selection"]
    ids = a.ids or (sel["top_views"] + sel["recent"])
    fmt = (f"bv*[height<={a.max_height}][vcodec^=avc1]+ba[ext=m4a]/bv*[height<={a.max_height}]+ba"
           f"/b[height<={a.max_height}]/b")
    failed = []

    def one(vid):
        vdir = project / "videos" / vid
        vdir.mkdir(parents=True, exist_ok=True)
        url = f"https://www.youtube.com/watch?v={vid}"
        src = vdir / "source.mp4"
        log = []
        if not src.exists():
            print(f"downloading {vid} ...", flush=True)
            p = ytdlp(["-f", fmt, "--merge-output-format", "mp4", "-o", str(vdir / "source.%(ext)s"),
                       "--write-info-json", "--write-thumbnail", "--convert-thumbnails", "jpg",
                       "--no-playlist", "--retries", "5", "--concurrent-fragments", "4", url], a.cookies_from_browser)
            if p.returncode != 0 or not src.exists():
                print(f"  ! download failed: {p.stderr.strip()[-500:]}", file=sys.stderr)
                return vid
        if not list(vdir.glob("source.*.vtt")):
            p = ytdlp(["--skip-download", "--write-subs", "--write-auto-subs", "--sub-langs", a.sub_langs,
                       "--sub-format", "vtt/best", "--sleep-subtitles", "2", "--no-playlist",
                       "-o", str(vdir / "source.%(ext)s"), url], a.cookies_from_browser)
            if p.returncode != 0:
                log.append(f"  (subtitles unavailable: {p.stderr.strip()[-200:]})")
        info = read_json(vdir / "source.info.json") if (vdir / "source.info.json").exists() else {}
        manual = set((info.get("subtitles") or {}).keys())
        subs = []
        for f in sorted(vdir.glob("source.*.vtt")):
            lang = f.name[len("source."):-len(".vtt")]
            subs.append({"file": f.name, "lang": lang, "kind": "manual" if lang in manual else "auto"})
        meta = {
            "id": vid, "title": info.get("title"), "upload_date": info.get("upload_date"),
            "view_count": info.get("view_count"), "like_count": info.get("like_count"),
            "comment_count": info.get("comment_count"), "duration": info.get("duration"),
            "language": info.get("language"), "chapters": info.get("chapters"),
            "description": info.get("description"), "tags": info.get("tags"), "categories": info.get("categories"),
            "channel": info.get("channel"), "roles": ch["videos"].get(vid, {}).get("roles", []),
            "file": "source.mp4", "probe": probe(src), "subtitles": subs,
        }
        write_json(vdir / "meta.json", meta)
        pr = meta["probe"]
        print("\n".join(log + [f"  ok {vid}: {pr.get('width')}x{pr.get('height')} @ {pr.get('fps', 0):.3f}fps "
                                f"{pr['duration_s']:.1f}s subs={[s['lang'] + ':' + s['kind'] for s in subs]}"]), flush=True)
        return None

    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(max_workers=max(1, a.jobs)) as ex:
        failed = [v for v in ex.map(one, ids) if v]
    if failed:
        sys.exit(f"failed: {failed}. Use a backup id from channel.json selection with --ids.")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    titles = sub.add_parser("titles", help="collect all available public titles before channel analysis")
    titles.add_argument("channel_url")
    titles.add_argument("--project", required=True)
    titles.add_argument("--quick", action="store_true", help="videos tab only, up to 100 titles, 90s metadata timeout; no video download")
    titles.add_argument("--cookies-from-browser")
    l = sub.add_parser("list")
    l.add_argument("channel_url")
    l.add_argument("--project", required=True)
    l.add_argument("--recent", type=int, default=1)
    l.add_argument("--top", type=int, default=0)
    l.add_argument("--min-duration", type=int, default=0, help="optional seconds floor; Shorts are excluded separately")
    l.add_argument("--max-duration", type=int, default=1800, help="inclusive seconds ceiling, at most 1800")
    l.add_argument("--as-of", help="selection day YYYY-MM-DD; default today in Asia/Seoul")
    l.add_argument("--scan", type=int, default=0, help="max videos to list (0 = all)")
    l.add_argument("--cookies-from-browser")
    l.add_argument("--metadata-cache-dir")
    l.add_argument("--metadata-jobs",type=int,default=3)
    d = sub.add_parser("download")
    d.add_argument("--project", required=True)
    d.add_argument("--ids", nargs="*")
    d.add_argument("--max-height", type=int, default=1080)
    d.add_argument("--sub-langs", default="ko.*")
    d.add_argument("--jobs", type=int, default=3, help="videos downloaded at once")
    d.add_argument("--cookies-from-browser")
    a = ap.parse_args()
    {"titles": cmd_titles, "list": cmd_list, "download": cmd_download}[a.cmd](a)


if __name__ == "__main__":
    main()
