import json,os,subprocess,tempfile,time,unittest
from pathlib import Path
from unittest.mock import patch
from concurrent.futures import ThreadPoolExecutor
from work_guard import execute,connection,digest
from scheduler import provenance
from revision_graph import generate,validate,reuse
from quality_contract import validate as quality,guard_tool
from production_preflight import clock_check,inspect_file

class Contracts(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.p=Path(self.tmp.name)
  self.patch=patch.dict(os.environ,{'LFC_RUNTIME_HOME':str(self.p/'shared')});self.patch.start();self.addCleanup(self.patch.stop)
  self.input=self.p/'input';self.input.write_text('frozen')
 def write(self,name,doc):
  p=self.p/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(doc));return p
 def claim(self,i,run=None,**kw):return execute(run or self.p/f'r{i}','claim',str(i),[self.input],resource=f'video:{i}',stage='analysis',**kw)
 def rollout(self,event=None,model='gpt-6.1-sol',effort='high'):
  p=self.p/'rollout.jsonl';rows=[{'type':'session_meta','payload':{'id':'actual-session'}},{'type':'turn_context','payload':{'model':model,'effort':effort}}]
  if event:rows.append({'type':'event_msg','payload':{'type':event}})
  p.write_text(''.join(json.dumps(r)+'\n' for r in rows));return p
 def modern(self):
  root=self.p/'modern';root.mkdir(exist_ok=True);self.write('modern/run.json',{'scheduler_version':2});return root
 def test_old_scheduling_actions_create_no_requests_or_reservations(self):
  root=self.p/'sleep'
  self.assertEqual(execute(root,'enqueue',resource='video:sleep',stage='analysis')['decision'],'ready')
  with connection() as db:
   self.assertEqual(db.execute('SELECT COUNT(*) FROM waiting').fetchone()[0],0)
   names={r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
   self.assertFalse({'durable_waiting','queue_meta'} & names)
  for i in range(6):self.assertEqual(self.claim(i)['decision'],'run')
 def test_old_waiting_rows_never_block_independent_tasks(self):
  with connection() as db:
   db.execute('INSERT INTO waiting VALUES (?,?,?,?,?,?)',('old','old','analysis','model',0,0))
  for i in range(6):self.assertEqual(self.claim(i)['decision'],'run')
  with connection() as db:self.assertEqual(db.execute('SELECT COUNT(*) FROM waiting').fetchone()[0],1)
 def test_wait_claim_is_single_immediate_compatibility_call(self):
  from work_guard import wait_claim
  with patch('work_guard.time.sleep',side_effect=AssertionError('No waiting')):
   for i in range(6):self.assertEqual(wait_claim(self.p/f'w{i}',str(i),[self.input],f'video:{i}','analysis',wait_seconds=3600)['decision'],'run')
 def test_modern_terminal_or_wrong_model_worker_cannot_claim(self):
  root=self.modern()
  for event in ('turn_aborted','task_complete'):
   with self.assertRaises(ValueError):self.claim(1,root,worker_rollout=self.rollout(event))
  with self.assertRaises(ValueError):self.claim(1,root,worker_rollout=self.rollout(model='gpt-6-astra'))
  self.assertEqual(self.claim(1,root,worker_rollout=self.rollout())['decision'],'run')
 def test_compatibility_ack_and_heartbeat_never_update_timers(self):
  root=self.modern();log=self.rollout();job=self.claim(1,root,worker_rollout=log)
  for action in ('ack','heartbeat'):execute(root,action,lease=job['lease'],worker_rollout=log)
  execute(root,'check',lease=job['lease'])
  with connection() as db:
   row=db.execute('SELECT acked,heartbeat FROM owners WHERE lease=?',(job['lease'],)).fetchone()
   self.assertIsNone(row['acked']);self.assertIsNone(row['heartbeat'])
   self.assertEqual(db.execute("SELECT COUNT(*) FROM events WHERE lease=? AND kind='acked'",(job['lease'],)).fetchone()[0],0)
 def test_owner_ack_and_confirmed_orphan_recovery_only(self):
  root=self.modern();log=self.rollout();job=self.claim(1,root,worker_rollout=log)
  execute(root,'ack',lease=job['lease'],worker_rollout=log)
  d=execute(root,'diagnose',lease=job['lease']);self.assertFalse(d['safe_to_recover'])
  self.rollout('turn_aborted');d=execute(root,'diagnose',lease=job['lease']);self.assertTrue(d['safe_to_recover'])
  proof=self.write('proof.json',d);r=execute(root,'recover',lease=job['lease'],validation=proof,note='confirmed aborted owner preserved')
  self.assertTrue(r['outputs_preserved']);self.assertFalse(r['processes_terminated'])
 def test_legacy_schema_insert_and_unknown_owner_never_autorecovered(self):
  with connection() as db:
   db.execute('INSERT INTO jobs VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)',('old',str((self.p/'old-run').resolve()),'old','video:old','review','model','fingerprint','{}',None,'running',None,time.time()-86400,None,None))
  d=execute(self.p/'old-run','diagnose',lease='old');self.assertEqual(d['classification'],'unknown_owner');self.assertFalse(d['safe_to_recover'])
  self.assertEqual(self.claim(1)['decision'],'run');self.assertEqual(self.claim(2)['decision'],'run')
 def test_cli_fresh_db_race_capacity(self):
  def call(i):
   cmd=[os.sys.executable,str(Path(__file__).parent/'work_guard.py'),'claim','--run-dir',str(self.p/f'r{i}'),'--task',str(i),'--resource',f'video:{i}','--stage','analysis','--inputs',str(self.input)]
   r=subprocess.run(cmd,capture_output=True,text=True);return r.returncode,json.loads(r.stdout)['decision']
  with ThreadPoolExecutor(max_workers=4) as e:r=list(e.map(call,range(4)))
  self.assertEqual(sum(x[1]=='run' for x in r),4);self.assertEqual(sum(x[1]=='wait' for x in r),0)
 def test_command_resource_guard_only_during_execution_and_releases_on_error(self):
  from runtime import command_resource_guard
  code="from runtime import command_resource_guard; import sys;\ntry:\n with command_resource_guard(sys.argv[1]): print('running')\nexcept BlockingIOError: sys.exit(3)"
  env={**os.environ,'PYTHONPATH':str(Path(__file__).parent)}
  def command(name):return subprocess.run([os.sys.executable,'-c',code,name],env=env,capture_output=True,text=True)
  with command_resource_guard('transcribe'):
   self.assertEqual(command('gen_video').returncode,3)
   self.assertEqual(command('build_timeline').returncode,0)
   for i in range(4):self.assertEqual(self.claim(i)['decision'],'run')
  self.assertEqual(command('gen_video').returncode,0)
  try:
   with command_resource_guard('transcribe'):raise RuntimeError('actual command failed')
  except RuntimeError:pass
  self.assertEqual(command('transcribe').returncode,0)
  with command_resource_guard('build_timeline'),command_resource_guard('tts'):
   self.assertEqual(command('render_graphic').returncode,3)
  self.assertEqual(command('render_graphic').returncode,0)
 def test_new_runtime_marks_unbounded_policy_preserving_snapshot(self):
  from runtime import initialize,frozen_skill
  source=Path(__file__).resolve().parent.parent
  info=initialize(source,self.p/'project','new-independent')
  config=json.loads((Path(info['run_dir'])/'run.json').read_text())
  self.assertEqual(config['scheduler_version'],3)
  self.assertEqual(frozen_skill(info['run_dir']),Path(info['skill']))
  for pool in ('model','local'):
   for i in range(4):
    kwargs={'worker_rollout':self.rollout()} if pool=='model' else {}
    self.assertEqual(execute(info['run_dir'],'claim',f'{pool}{i}',[self.input],resource=f'{pool}:{i}',stage='analysis',pool=pool,**kwargs)['decision'],'run')
 def graph(self,revision,metadata):
  props=self.write('props.json',{'content':'actual props','fps':10,'duration_s':1,'width':32,'height':18});meta=self.write(metadata,{'note':metadata})
  tts=self.write('tts.json',{'lines':[]});full=self.write('base-full.json',{'tts':{'timeline':str(tts)},'output_scope':{'kind':'full'},'render_timing':{'props':str(props)},'render_inputs':[]})
  preview=self.write('base-preview.json',{'tts':{'timeline':str(tts)},'output_scope':{'kind':'preview','full_plan':str(full)},'render_timing':{'props':str(props)},'render_inputs':[]})
  spec=self.write(revision+'-spec.json',{'schema':'lfc-revision-spec-v1','revision':revision,'artifacts':[{'id':'props','role':'props','path':str(props)},{'id':'meta','role':'review_note','path':str(meta)},{'id':'tts','role':'narration','path':str(tts)}],'scopes':[{'id':'full','template':str(full)},{'id':'preview','template':str(preview)}]})
  generate(spec,self.p/revision);return self.p/revision/'graph.json'
 def test_current_graph_and_metadata_render_reuse(self):
  a=self.graph('v1','note1.json');b=self.graph('v2','note2.json')
  g=json.loads(b.read_text());preview=json.loads(Path(g['scopes']['preview']['path']).read_text())
  self.assertEqual(preview['output_scope']['full_plan'],g['scopes']['full']['path'])
  output=self.p/'video.mp4'
  subprocess.run([str(Path.home()/'.longform-cloner/bin/ffmpeg'),'-v','error','-f','lavfi','-i','color=c=blue:s=32x18:r=10:d=1','-c:v','libx264',str(output)],check=True)
  record=self.write('render-proof.json',{'passed':True,'kind':'lfc-verified-render-v1','scope':'preview','graph_sha256':digest(a),'render_signature':json.loads(a.read_text())['render_signature'],'output_sha256':{str(output):digest(output)}})
  r=reuse(a,b,record);self.assertTrue(r['reuse_render']);self.assertFalse(r['content_review_reusable'])
  self.write('props.json',{'content':'changed pixels'})
  self.assertFalse(validate(b)['passed'])
 def test_failed_or_fake_render_record_never_reused(self):
  graph=self.graph('v1','note.json');output=self.p/'fake.mp4';output.write_text('not-a-render')
  for passed in (False,True):
   record=self.write('fake-record.json',{'passed':passed,'kind':'lfc-verified-render-v1','scope':'preview','graph_sha256':digest(graph),'render_signature':json.loads(graph.read_text())['render_signature'],'output_sha256':{str(output):digest(output)}})
   with self.assertRaises((ValueError,subprocess.SubprocessError)):reuse(graph,graph,record)
 def test_missing_actual_pilot_report_or_unresolved_cut_blocks_review(self):
  contract=self.contract();doc=json.loads(contract.read_text());doc['cuts'][-1]['unresolved_items']=['source unavailable'];contract.write_text(json.dumps(doc))
  log=self.rollout();original=doc['cuts'][0]['reference_states']['before']
  review=self.write('review.json',{'reviewer_rollout':str(log),'session_id':'actual-session','implementation_session_ids':['different-session'],'contract_sha256':digest(contract),'observed_cut_ids':['0','1','2'],'direct_observation':True,'visual_passed':True,'script_passed':True,'unresolved_items':[],'render_evidence':[original]})
  result=quality(contract,review);self.assertFalse(result['passed']);self.assertFalse(result['pilot_independent_passed']);self.assertEqual(result['unresolved_items'],['source unavailable'])
 def test_final_capabilities_cannot_convert_unsupported_to_asr_pass(self):
  from production_preflight import final_capabilities
  video=self.p/'final.mp4';subprocess.run([str(Path.home()/'.longform-cloner/bin/ffmpeg'),'-v','error','-f','lavfi','-i','color=c=blue:s=32x18:r=10:d=1','-c:v','libx264',str(video)],check=True)
  initial=self.write('preflight.json',{'passed':True,'capabilities':{'direct_listening':{'status':'unsupported'},'continuous_playback':{'status':'denied'}}})
  evidence=self.write('observation.json',{'source':'independent permitted actual observation fixture'})
  log=self.rollout();current={'preflight_sha256':digest(initial),'render_sha256':digest(video),'input_sha256':'input','reviewer_rollout':str(log),'session_id':'actual-session','capabilities':{k:{'status':'available','passed':True,'method':m,'coverage_s':[[0,1]],'evidence':[{'path':str(evidence),'sha256':digest(evidence)}],'resolution_reason':'new supported authorized route','approved_access':True} for k,m in [('direct_listening','direct_listening_observation'),('continuous_playback','continuous_playback_observation')]}}
  resolution=self.write('resolution.json',current)
  self.assertTrue(final_capabilities(initial,resolution,video,'input','actual-session')['passed'])
  current['capabilities']['direct_listening']['method']='asr';resolution.write_text(json.dumps(current))
  self.assertFalse(final_capabilities(initial,resolution,video,'input','actual-session')['passed'])
  current['capabilities']['direct_listening']['method']='direct_listening_observation';current['capabilities']['continuous_playback']['coverage_s']=[[.5,1]];resolution.write_text(json.dumps(current))
  self.assertFalse(final_capabilities(initial,resolution,video,'input','actual-session')['passed'])
 def test_no_render_signature_or_stale_scope_rejected(self):
  p=self.graph('v1','note.json');g=json.loads(p.read_text());g['render_signature']='wrong';p.write_text(json.dumps(g));self.assertFalse(validate(p)['passed'])
 def contract(self):
  evidence=self.write('evidence.json',{'observed':'reference and factual source'});e={'path':str(evidence),'sha256':digest(evidence)}
  from PIL import Image
  frame=self.p/'reference.png';Image.new('RGB',(32,18),(80,80,80)).save(frame);state={'path':str(frame),'sha256':digest(frame)}
  cuts=[{'id':str(i),'visual_role':'diagram','narrative_role':'evidence','ink_geometry':[.1,.1,.5,.5],'texture':'painted','anchors':{'subject':'center'},'before':'enter','middle':'hold','after':'exit','material_role':'actual source','visual_evidence':[e],'script_evidence':[e],'reference_states':{k:state for k in ('before','middle','after')},'claims':[],'unresolved_items':[]} for i in range(3)]
  return self.write('quality.json',{'schema':'lfc-cut-contract-v1','complete_cut_ids':['0','1','2'],'cuts':cuts,'pilot':{'samples':[{'cut_id':str(i),'risk_reason':'motion','absolute_range_s':[i*10,(i+1)*10],'line_ids':[str(i)]} for i in range(3)]}})
 def test_generic_image_cannot_prove_specific_episode_fact(self):
  p=self.contract();self.assertTrue(quality(p)['passed']);d=json.loads(p.read_text());d['cuts'][0]['claims']=[{'kind':'episode_fact','text':'This is the actual injury record','screen_is_evidence':True,'asset_relation':'generic','new_topic_evidence':d['cuts'][0]['visual_evidence']}];p.write_text(json.dumps(d));self.assertFalse(quality(p)['passed'])
 def test_episode_sponsorship_cannot_be_inherited_as_fact(self):
  p=self.contract();d=json.loads(p.read_text());d['cuts'][0]['claims']=[{'kind':'episode_fact','text':'I attended the premiere'}];p.write_text(json.dumps(d));self.assertFalse(quality(p)['passed'])
 def test_pilot_first_blocks_bulk_tts(self):
  p=self.contract();root=self.modern();(root/'work').mkdir();(root/'work/quality-contract.json').write_bytes(p.read_bytes())
  lines=self.write('lines.json',[{'id':'not-a-pilot-line','text':'bulk'}])
  with self.assertRaises(ValueError):guard_tool(root,'tts',['--lines',str(lines)])
 def test_html_disguised_as_media_and_absolute_master_clock(self):
  fake=self.p/'fake.png';fake.write_text('<!DOCTYPE html><html>error</html>')
  with self.assertRaises(ValueError):inspect_file(fake)
  clock={'fps':30,'master_duration_s':198,'composition_frames':990,'absolute_frames':[108,5550],'functional_boundary_frames':[0,5939],'reset_clock_or_rebase_props':False}
  with self.assertRaises(ValueError):clock_check(clock)
  clock['composition_frames']=5940;self.assertTrue(clock_check(clock)['passed'])

if __name__=='__main__':unittest.main()
