"""Shared helpers for longform-channel-cloner scripts.

Do not import faster_whisper / av in the same process as cv2: both bundle libavdevice on macOS.
"""
from __future__ import annotations

import json
import math
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any, Iterable

LFC_HOME = Path(os.environ.get("LFC_HOME", Path.home() / ".longform-cloner"))
CANVAS_W, CANVAS_H = 1920, 1080


def which(tool: str) -> str:
    local = LFC_HOME / "bin" / tool
    if local.exists():
        return str(local)
    found = shutil.which(tool)
    if not found:
        sys.exit(f"{tool} not found. Run scripts/setup_env.sh")
    return found


FFMPEG = which("ffmpeg")
FFPROBE = which("ffprobe")


def run(cmd: list[str], **kw) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, check=True, text=True, capture_output=True, **kw)


def read_json(path: str | Path) -> Any:
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def _json_default(o):
    try:
        import numpy as np
        if isinstance(o, np.generic):
            return o.item()
        if isinstance(o, np.ndarray):
            return o.tolist()
    except ImportError:
        pass
    if isinstance(o, Path):
        return str(o)
    raise TypeError(f"not JSON serializable: {type(o)}")


def write_json(path: str | Path, data: Any) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2, default=_json_default)
    tmp.replace(path)
    return path


def probe(path: str | Path) -> dict:
    """fps (float), fps_fraction, width, height, duration_s, nb_frames, has_audio."""
    out = run([FFPROBE, "-v", "error", "-print_format", "json", "-show_streams", "-show_format", str(path)]).stdout
    info = json.loads(out)
    v = next((s for s in info["streams"] if s["codec_type"] == "video"), None)
    a = next((s for s in info["streams"] if s["codec_type"] == "audio"), None)
    dur = float(info["format"].get("duration", 0) or 0)
    res: dict[str, Any] = {"duration_s": dur, "has_audio": a is not None}
    if v:
        num, den = (int(x) for x in v.get("avg_frame_rate", "0/1").split("/"))
        if not num or not den:
            num, den = (int(x) for x in v.get("r_frame_rate", "30/1").split("/"))
        fps = num / den if den else 30.0
        res.update({
            "fps": fps, "fps_fraction": f"{num}/{den}", "width": int(v["width"]), "height": int(v["height"]),
            "nb_frames": int(v.get("nb_frames") or round(dur * fps)), "vcodec": v.get("codec_name"),
        })
    return res


def parse_range(spec: str | None, duration: float) -> tuple[float, float]:
    """'0:30' -> (0,30); '12.5:' -> (12.5,duration); None -> (0,duration). Seconds."""
    if not spec:
        return 0.0, duration
    a, _, b = spec.partition(":")
    start = float(a) if a else 0.0
    end = float(b) if b else duration
    return max(0.0, start), min(duration, end)


def fmt_tc(seconds: float) -> str:
    m, s = divmod(max(0.0, seconds), 60)
    return f"{int(m):02d}:{s:06.3f}"


def hex_color(rgb: Iterable[float]) -> str:
    r, g, b = (int(max(0, min(255, round(c)))) for c in rgb)
    return f"#{r:02X}{g:02X}{b:02X}"


def extract_wav(video: str | Path, out: str | Path, sr: int = 44100, channels: int = 2,
                start: float | None = None, end: float | None = None) -> Path:
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    cmd = [FFMPEG, "-hide_banner", "-loglevel", "error", "-y"]
    if start is not None:
        cmd += ["-ss", f"{start:.3f}"]
    if end is not None:
        cmd += ["-to", f"{end:.3f}"]
    cmd += ["-i", str(video), "-vn", "-ac", str(channels), "-ar", str(sr), "-c:a", "pcm_s16le", str(out)]
    run(cmd)
    return out


def lufs(path: str | Path) -> float | None:
    """Integrated loudness (EBU R128) of a media file."""
    r = subprocess.run([FFMPEG, "-hide_banner", "-nostats", "-i", str(path), "-af", "ebur128", "-f", "null", "-"],
                       capture_output=True, text=True)
    m = re.findall(r"I:\s+(-?[\d.]+) LUFS", r.stderr)
    return float(m[-1]) if m else None


def load_mono(path: str | Path, sr: int = 48000):
    """Decode any media to mono float32 numpy at sr."""
    import numpy as np
    p = subprocess.run([FFMPEG, "-hide_banner", "-loglevel", "error", "-i", str(path), "-vn", "-ac", "1", "-ar", str(sr),
                        "-f", "f32le", "-"], capture_output=True, check=True)
    return np.frombuffer(p.stdout, dtype=np.float32)


def rms_db(x, sr: int, win: float = 0.1):
    import numpy as np
    hop = max(1, int(sr * win))
    n = len(x) // hop
    if n == 0:
        return np.array([-120.0])
    fr = x[: n * hop].reshape(n, hop)
    return 20 * np.log10(np.sqrt((fr ** 2).mean(1)) + 1e-9)


# ---------------------------------------------------------------- frames (cv2)

def open_capture(path: str | Path):
    import cv2
    cap = cv2.VideoCapture(str(path))
    if not cap.isOpened():
        sys.exit(f"cannot open video: {path}")
    return cap


def resize_w(img, width: int):
    import cv2
    h, w = img.shape[:2]
    if w == width:
        return img
    return cv2.resize(img, (width, round(h * width / w)), interpolation=cv2.INTER_AREA)


def iter_frames(path: str | Path, start_frame: int = 0, end_frame: int | None = None, step: int = 1,
                width: int | None = None):
    """Yield (frame_index, bgr). Seeks once, then decodes sequentially.

    With a target width the frames come from an ffmpeg pipe (decode + area-scale in native code, ~5x faster
    than cv2 decode + resize). Full-resolution reads use cv2."""
    if width:
        yield from _iter_frames_ffmpeg(path, start_frame, end_frame, step, width)
        return
    import cv2
    cap = open_capture(path)
    if start_frame > 0:
        cap.set(cv2.CAP_PROP_POS_FRAMES, start_frame)
    idx = start_frame
    try:
        while end_frame is None or idx < end_frame:
            if (idx - start_frame) % step == 0:
                ok, frame = cap.read()
                if not ok:
                    break
                yield idx, (resize_w(frame, width) if width else frame)
            elif not cap.grab():
                break
            idx += 1
    finally:
        cap.release()


_PROBE_CACHE: dict = {}


def _iter_frames_ffmpeg(path, start_frame, end_frame, step, width):
    import numpy as np
    key = str(path)
    info = _PROBE_CACHE.get(key) or probe(path)
    _PROBE_CACHE[key] = info
    fps = info["fps"]
    w = int(width) // 2 * 2
    h = int(round(info["height"] * w / info["width"] / 2)) * 2
    vf = f"scale={w}:{h}:flags=area"
    if step > 1:
        vf = f"select='not(mod(n\\,{step}))'," + vf
    cmd = [FFMPEG, "-hide_banner", "-loglevel", "error", "-nostdin"]
    if start_frame > 0:
        cmd += ["-ss", f"{start_frame / fps:.6f}"]
    cmd += ["-i", str(path), "-an", "-vf", vf, "-fps_mode", "passthrough", "-f", "rawvideo", "-pix_fmt", "bgr24"]
    if end_frame is not None:
        n = max(0, -(-(end_frame - start_frame) // step))
        cmd += ["-frames:v", str(n)]
    cmd += ["-"]
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, bufsize=w * h * 3 * 4)
    size = w * h * 3
    idx = start_frame
    try:
        while end_frame is None or idx < end_frame:
            buf = p.stdout.read(size)
            if len(buf) < size:
                break
            yield idx, np.frombuffer(buf, np.uint8).reshape(h, w, 3).copy()
            idx += step
    finally:
        p.stdout.close()
        p.kill()
        p.wait()


def grab_frames(path: str | Path, frame_indices: Iterable[int], width: int | None = None) -> dict[int, Any]:
    """Random-access frames by index (sorted; sequential decode for short gaps)."""
    import cv2
    wanted = sorted(set(int(i) for i in frame_indices if i >= 0))
    out: dict[int, Any] = {}
    if not wanted:
        return out
    cap = open_capture(path)
    pos = -1
    try:
        for fi in wanted:
            if pos < 0 or fi < pos or fi - pos > 90:
                cap.set(cv2.CAP_PROP_POS_FRAMES, fi)
                pos = fi
            while pos < fi:
                cap.grab()
                pos += 1
            ok, frame = cap.read()
            pos += 1
            if ok:
                out[fi] = resize_w(frame, width) if width else frame
    finally:
        cap.release()
    return out


def label_image(img, text: str, scale: float = 0.5):
    import cv2
    bar = int(22 * scale / 0.5)
    cv2.rectangle(img, (0, 0), (img.shape[1], bar), (0, 0, 0), -1)
    cv2.putText(img, text, (4, int(bar * 0.75)), cv2.FONT_HERSHEY_SIMPLEX, scale, (255, 255, 255), 1, cv2.LINE_AA)
    return img


def grid(images: list, cols: int, pad: int = 4, bg=(30, 30, 30)):
    import numpy as np
    if not images:
        return None
    h = max(i.shape[0] for i in images)
    w = max(i.shape[1] for i in images)
    rows = math.ceil(len(images) / cols)
    sheet = np.full((rows * (h + pad) + pad, cols * (w + pad) + pad, 3), bg, dtype=np.uint8)
    for k, im in enumerate(images):
        r, c = divmod(k, cols)
        y, x = pad + r * (h + pad), pad + c * (w + pad)
        sheet[y:y + im.shape[0], x:x + im.shape[1]] = im
    return sheet


# ---------------------------------------------------------------- OCR (Apple Vision)

def vision_ocr(bgr, languages=("ko-KR", "en-US"), min_len: int = 1) -> list[dict]:
    """Apple Vision accurate OCR -> [{text, conf, bbox:[x,y,w,h]}], normalized, origin top-left.

    Feed ~640-800 px wide frames. Korean accuracy is unstable at some larger input sizes.
    """
    import cv2
    import objc
    import Vision
    from Foundation import NSData

    # BMP: no compression (PNG encode was ~6 ms of ~48 ms per frame); Vision reads it directly, same results
    ok, buf = cv2.imencode(".bmp", bgr)
    data = NSData.dataWithBytes_length_(buf.tobytes(), len(buf))
    results = []
    with objc.autorelease_pool():
        req = Vision.VNRecognizeTextRequest.alloc().init()
        req.setRecognitionLevel_(Vision.VNRequestTextRecognitionLevelAccurate)
        req.setRecognitionLanguages_(list(languages))
        req.setUsesLanguageCorrection_(False)
        handler = Vision.VNImageRequestHandler.alloc().initWithData_options_(data, None)
        handler.performRequests_error_([req], None)
        for obs in req.results() or []:
            cand = obs.topCandidates_(1)
            if not cand:
                continue
            c = cand[0]
            text = str(c.string()).strip()
            if len(text) < min_len:
                continue
            bb = obs.boundingBox()
            x, y, w, h = bb.origin.x, bb.origin.y, bb.size.width, bb.size.height
            results.append({"text": text, "conf": round(float(c.confidence()), 3),
                            "bbox": [round(x, 4), round(1 - y - h, 4), round(w, 4), round(h, 4)]})
    return results


def bbox_iou(a, b) -> float:
    ax2, ay2, bx2, by2 = a[0] + a[2], a[1] + a[3], b[0] + b[2], b[1] + b[3]
    iw = max(0.0, min(ax2, bx2) - max(a[0], b[0]))
    ih = max(0.0, min(ay2, by2) - max(a[1], b[1]))
    inter = iw * ih
    union = a[2] * a[3] + b[2] * b[3] - inter
    return inter / union if union > 0 else 0.0


def text_similarity(a: str, b: str) -> float:
    from difflib import SequenceMatcher
    na, nb = re.sub(r"\s+", "", a), re.sub(r"\s+", "", b)
    if not na or not nb:
        return 0.0
    return SequenceMatcher(None, na, nb).ratio()


def write_gen_jobs(out_dir, needs: dict, project, seed0: int = 7) -> int:
    """Write <out_dir>/gen_jobs.json for gen_video --batch from the ai_video entries of needs.json.

    Start frames go to <out_dir>/start_frames/<id>.png, clips to <out_dir>/clips/<id>.mp4. seconds = the unique
    footage the reference shows (gen_seconds / cadence retime at 24 fps, else the cut length). The prompt is the
    reference cut's AI prompt; the agent rewrites it for new content (keep camera move + style words) before
    queueing. Existing entries keep their edits (prompt, seed) so re-running the planner is safe."""
    out_dir = Path(out_dir)
    path = out_dir / "gen_jobs.json"
    old = {j["key"]: j for j in read_json(path)} if path.exists() else {}
    jobs = []
    for k, (key, n) in enumerate(sorted(needs.items())):
        if n.get("kind") != "clip" or n.get("source_type") != "ai_video":
            continue
        if key in old:
            jobs.append(old[key])
            continue
        cid = key.split(":")[-1]
        acq = n.get("acquire") or {}
        prompt = n.get("donor_ai_prompt") or acq.get("ai_prompt") or n.get("description") or ""
        secs = n.get("gen_seconds") or n.get("source_len_s") or n.get("duration_s")
        jobs.append({"key": key, "image": str(out_dir / "start_frames" / f"{cid}.png"), "prompt": prompt,
                     "seconds": round(float(secs), 2), "seed": seed0 + k,
                     "out": str(out_dir / "clips" / f"{cid}.mp4"),
                     "style_frame": n.get("donor_frame") or n.get("ref_frame")})
    if jobs:
        write_json(path, jobs)
    return len(jobs)

# 한국어 표시용 라벨 (JSON 값은 영어 코드 그대로 두고, 사람이 읽는 md에서만 바꿔 씀)
KO_KEY = {
    "source_type": "소스 종류", "transition": "전환 효과", "motion_preset": "키프레임 움직임",
    "animation_in": "클립 등장 애니메이션", "effect": "클립 효과", "overlay": "오버레이",
    "caption_animation_in": "자막 등장 애니메이션", "sfx_label": "효과음", "section_role": "대본 구간 역할",
    "hook_technique": "훅 기법", "script_technique": "대본 기법", "layer_fit": "화면 채우기 방식",
    "narration_sync": "컷과 내레이션 타이밍",
}
KO = {
    # source_type
    "ai_video": "AI 영상", "ai_image": "AI 이미지", "stock_video": "스톡 영상", "stock_photo": "스톡 사진",
    "external_footage": "외부에서 가져온 영상", "archival_photo": "기록 사진", "screen_recording": "화면 녹화",
    "motion_graphic": "모션 그래픽", "text_card": "텍스트 카드", "map_or_chart": "지도/차트",
    "talking_head": "인물 출연", "game_footage": "게임 화면", "illustration": "일러스트",
    "meme_or_reaction": "밈/리액션", "unknown": "미상",
    # transition
    "cut": "컷", "dissolve": "디졸브", "fade_black": "검은 화면 페이드", "fade_white": "흰 화면 페이드",
    "flash_white": "흰색 플래시", "dip_color": "색 화면 거쳐 전환", "slide_left": "왼쪽 슬라이드",
    "slide_right": "오른쪽 슬라이드", "slide_up": "위로 슬라이드", "slide_down": "아래로 슬라이드",
    "push_left": "왼쪽으로 밀기", "push_right": "오른쪽으로 밀기", "push_up": "위로 밀기", "push_down": "아래로 밀기",
    "zoom_in": "줌 인", "zoom_out": "줌 아웃", "whip_pan": "휩 팬", "wipe": "와이프", "blur": "블러",
    "glitch": "글리치", "spin": "회전", "luma_matte": "루마 매트", "shape_mask": "도형 마스크", "other": "기타",
    "start": "영상 시작",
    # motion_preset
    "static": "고정", "pan_left": "왼쪽 팬", "pan_right": "오른쪽 팬", "pan_up": "위로 팬", "pan_down": "아래로 팬",
    "ken_burns": "켄 번즈(확대+이동)", "rotate": "회전", "shake": "흔들림", "camera_motion": "소스 자체 카메라 움직임",
    "custom": "직접 지정",
    # animation_in / caption animation
    "none": "없음", "fade": "페이드", "pop_scale": "팝(커지며 등장)", "scale_down": "작아지며 등장",
    "blur_in": "블러 인", "typewriter": "타자기", "word_by_word": "단어별 등장", "bounce": "바운스",
    # effect
    "vignette": "비네트", "film_grain": "필름 그레인", "color_grade": "색보정", "black_white": "흑백", "sepia": "세피아",
    "blur_background": "흐린 배경", "glow": "글로우", "chromatic_aberration": "색수차", "light_leak": "빛샘",
    "letterbox_bars": "레터박스", "overlay_texture": "텍스처 오버레이", "vhs": "VHS", "speed_ramp": "속도 변화",
    "freeze_frame": "정지 화면", "reverse": "역재생", "split_screen": "화면 분할", "picture_in_picture": "화면 속 화면",
    "mask_reveal": "마스크 등장", "highlight_circle": "강조 원", "counter": "숫자 카운터", "progress_bar": "진행 바",
    # overlay_kind
    "caption": "자막", "title": "제목", "keyword_popup": "키워드 팝업", "lower_third": "하단 자막 바", "number": "숫자",
    "arrow": "화살표", "circle": "원", "underline": "밑줄", "map_marker": "지도 표시", "image_pip": "삽입 이미지",
    "logo": "로고", "source_credit": "출처 표시",
    # layer_fit / narration_sync
    "cover": "화면 꽉 채움", "contain": "전체 보이기", "in_pause": "말 쉬는 틈", "mid_sentence": "문장 중간",
    "on_keyword": "키워드 순간", "on_sentence_start": "문장 시작",
    # script_role
    "hook": "훅", "cold_open": "콜드 오픈", "teaser": "예고", "title_card": "타이틀 카드", "intro": "인트로",
    "context": "배경 설명", "setup": "통념 제시", "problem": "문제 제기", "story_beat": "본론 전개",
    "escalation": "긴장 고조", "reveal": "반전 공개", "twist": "반전", "explanation": "설명", "example": "예시",
    "evidence": "근거", "comparison": "비교", "list_item": "목록 항목", "recap": "요약", "lesson": "교훈",
    "cta": "구독 유도", "sponsor": "광고", "outro": "마무리", "transition": "전환(시간 점프 등)",
    # script_technique
    "open_loop": "궁금증 유발", "question": "질문", "rhetorical_question": "수사 의문문",
    "shocking_statistic": "충격적인 통계", "contrast": "대비", "direct_address": "시청자에게 말 걸기",
    "cliffhanger": "클리프행어", "foreshadow": "복선", "callback": "앞 내용 회수", "enumeration": "나열",
    "anecdote": "일화", "quote": "인용", "time_pressure": "시간 압박", "mystery": "미스터리", "stakes": "중요성 강조",
    "humor": "유머", "myth_busting": "통념 깨기", "pov_second_person": "2인칭 시점", "countdown": "카운트다운",
    # CLAP 효과음 라벨
    "whoosh swoosh transition": "휙 소리(전환)", "impact boom hit": "쾅 타격음", "cinematic riser build up": "긴장 고조 라이저",
    "bass drop": "베이스 드롭", "pop sound": "뿅 소리", "mouse click": "마우스 클릭", "ding bell notification": "딩 알림음",
    "keyboard typing": "키보드 타자", "camera shutter": "카메라 셔터", "glitch digital error": "글리치 소리",
    "cash register ka-ching": "계산대 소리", "record scratch": "레코드 스크래치", "heartbeat": "심장 박동",
    "drum hit": "드럼", "explosion": "폭발", "thunder": "천둥", "applause": "박수", "laugh track": "웃음소리",
    "wind whoosh": "바람 소리", "sword swish": "칼 휘두르는 소리", "magic sparkle chime": "반짝 효과음",
    "error buzzer": "오답 버저", "swipe paper": "종이 넘기는 소리", "footsteps": "발소리", "gunshot": "총소리",
}


def ko(value) -> str:
    return KO.get(str(value), str(value))


def ko_formula(s: str) -> str:
    """'draft: hook -> context -> story_beat -> story_beat' -> '초안: 훅 → 배경 설명 → 본론 전개 ×2'."""
    s = s or ""
    draft = s.startswith("draft:")
    body = s[len("draft:"):].strip() if draft else s
    out = []
    for p in re.split(r"\s*(?:->|→)\s*", body):
        m = re.fullmatch(r"([a-z_]+)(\(.*\))?", p.strip())
        lab = (ko(m.group(1)) + (m.group(2) or "")) if m else p.strip()
        if out and out[-1][0] == lab:
            out[-1][1] += 1
        else:
            out.append([lab, 1])
    return ("초안: " if draft else "") + " → ".join(l if c == 1 else f"{l} ×{c}" for l, c in out)
