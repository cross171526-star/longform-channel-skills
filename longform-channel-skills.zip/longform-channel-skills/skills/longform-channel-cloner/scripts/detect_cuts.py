#!/usr/bin/env python3
"""Detect clip boundaries, classify each boundary transition, and render review sheets.

  run.sh detect_cuts <video> --out <analysis_dir> [--range START:END] [--detail-range 0:30]
                     [--threshold 3.0] [--min-scene-len 0.25] [--detector adaptive|content]

One decode pass feeds PySceneDetect (adaptive/content + fade detector) and keeps 64x36 thumbnails and colour
histograms. A second pass compares histograms across a 0.2 s window to catch gradual transitions (wipes,
slides, fast dissolves) whose per-frame change is too small for the adaptive detector. Every boundary is
then measured: hard cut vs gradual, fade through black/white, dissolve, wipe (with direction), or
motion-type transition (slide/push/zoom/whip/glitch - confirm visually). Writes:
  <out>/cuts.json                 measured cuts; "annotation" is null until the agent fills it
  <out>/frames/cuts_###.jpg       3 frames per cut (start/mid/end), 16 cuts per sheet
  <out>/frames/bounds_###.jpg     9-frame filmstrips across boundaries (gradual ones + all in --detail-range)
"""
from __future__ import annotations

import argparse
from pathlib import Path

import cv2
import numpy as np

from common import fmt_tc, grab_frames, grid, iter_frames, label_image, parse_range, probe, write_json

SMALL = (64, 36)


def mad(a, b) -> float:
    return float(np.mean(np.abs(a.astype(np.int16) - b.astype(np.int16))))


def hist(frame_bgr):
    hsv = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2HSV)
    h = cv2.calcHist([hsv], [0, 1, 2], None, [16, 4, 4], [0, 180, 0, 256, 0, 256]).ravel()
    return (h / (h.sum() + 1e-9)).astype(np.float32)


def bhatt(a, b):
    """Bhattacharyya distance between histogram rows (broadcasts)."""
    return np.sqrt(np.clip(1 - np.sum(np.sqrt(a * b), axis=-1), 0, 1))


def gradual_candidates(H, fps, f0, existing, min_cross=0.35, min_ratio=2.5):
    """Frames where colour content changes across a ~0.2 s window but is stable on both sides."""
    k = max(3, int(round(0.2 * fps)))
    n = len(H)
    if n < 3 * k + 2:
        return []
    i = np.arange(k + 1, n - 2 * k)
    cross = bhatt(H[i - 1], H[i + k])
    within = np.maximum(bhatt(H[i - 1 - k], H[i - 1]), bhatt(H[i + k], H[i + 2 * k - 1]))
    ratio = cross / (within + 0.03)
    ok = (cross > min_cross) & (ratio > min_ratio)
    out, last = [], -10 ** 9
    for j in np.nonzero(ok)[0]:
        fr = int(i[j]) + f0
        if fr - last <= k:
            if ratio[j] > out[-1][1]:
                out[-1] = (fr, float(ratio[j]))
            last = fr
            continue
        out.append((fr, float(ratio[j])))
        last = fr
    ex = np.array(sorted(existing)) if existing else np.array([])
    res = []
    for fr, _ in out:
        if ex.size and np.min(np.abs(ex - fr)) <= 2 * k:
            continue
        res.append(fr + k // 2)  # centre of the change window
    return res


def scan(video, fps, f0, f1, threshold, min_len, detector):
    from scenedetect import AdaptiveDetector, ContentDetector, FrameTimecode, ThresholdDetector
    main = (ContentDetector(threshold=27.0, min_scene_len=min_len) if detector == "content"
            else AdaptiveDetector(adaptive_threshold=threshold, min_scene_len=min_len, min_content_val=15.0))
    fade = ThresholdDetector(threshold=12, min_scene_len=min_len)
    cuts: set[int] = set()
    small, luma, hists = [], [], []
    last = f0
    for idx, frame in iter_frames(video, f0, f1, width=320):
        tc = FrameTimecode(idx, fps)
        for det in (main, fade):
            for c in det.process_frame(tc, frame) or []:
                cuts.add(int(c.frame_num))
        g = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        small.append(cv2.resize(g, SMALL, interpolation=cv2.INTER_AREA))
        luma.append(float(g.mean()))
        hists.append(hist(frame))
        last = idx
    end_tc = FrameTimecode(last + 1, fps)
    for det in (main, fade):
        for c in det.post_process(end_tc) or []:
            cuts.add(int(c.frame_num))
    H = np.stack(hists)
    grad = gradual_candidates(H, fps, f0, cuts)
    cuts |= set(grad)
    return sorted(c for c in cuts if f0 < c <= last), np.stack(small), np.array(luma), last + 1, set(grad)


def wipe_check(S, left, right):
    """During a wipe each pixel shows either the outgoing or the incoming image at the same position.
    Returns (is_wipe, direction) where direction is the side the incoming image enters from."""
    n = len(S)
    a_i, b_i = max(0, left - 2), min(n - 1, right + 2)
    A, B = S[a_i].astype(np.float32), S[b_i].astype(np.float32)
    if np.mean(np.abs(A - B)) < 8:
        return False, None
    cents, comps = [], []
    for frac in (0.3, 0.5, 0.7):
        M = S[int(round(left + (right - left) * frac))].astype(np.float32)
        ea, eb = np.abs(M - A), np.abs(M - B)
        comps.append(float(np.mean(np.minimum(ea, eb) < 14)))
        mask = (eb < ea).astype(np.float32)
        fb = mask.mean()
        if 0.08 < fb < 0.92:
            ys, xs = np.nonzero(mask)
            cents.append((xs.mean() / S.shape[2], ys.mean() / S.shape[1], fb))
    if min(comps) < 0.7 or len(cents) < 2:
        return False, None
    (x0, y0, _), (x1, y1, _) = cents[0], cents[-1]
    dx, dy = x1 - x0, y1 - y0
    # incoming region grows from where it first appears: its first centroid sits on the entry side
    cx, cy = cents[0][0] - 0.5, cents[0][1] - 0.5
    if abs(cx) >= abs(cy):
        direction = "from_right" if cx > 0 else "from_left"
    else:
        direction = "from_bottom" if cy > 0 else "from_top"
    if abs(dx) > 0.02 and abs(dy) > 0.02:
        direction += "_diagonal"
    return True, direction


def classify(S, L, f0, b):
    """Measure the transition around boundary frame b using small frames S (index = frame - f0)."""
    n = len(S)
    i = b - f0
    lo, hi = max(1, i - 15), min(n - 1, i + 15)
    d = {k: mad(S[k], S[k - 1]) for k in range(lo, hi + 1)}
    near = [k for k in range(max(lo, i - 2), min(hi, i + 2) + 1)]
    kp = max(near, key=lambda k: d[k]) if near else i
    peak = d.get(kp, 0.0)
    base = float(np.percentile(list(d.values()), 25)) if d else 0.0
    thr = max(2.5, 0.3 * peak, 2.0 * base)
    left = right = kp
    while left - 1 in d and d[left - 1] > thr:
        left -= 1
    while right + 1 in d and d[right + 1] > thr:
        right += 1
    span = right - left + 1
    a_i, b_i = max(0, left - 2), min(n - 1, right + 1)
    seg_l = L[left:right + 1]
    res = {"frame": int(b), "start_frame": int(left + f0), "end_frame": int(right + f0), "frames": int(span),
           "peak_diff": round(peak, 2)}
    if span <= 2:
        res.update(auto_type="cut", confidence=0.9 if peak > 3 * max(base, 1) else 0.6)
        return res
    A, B = S[a_i].astype(np.float32), S[b_i].astype(np.float32)
    mid = S[(left + right) // 2].astype(np.float32)
    blend = min(float(np.mean(np.abs(mid - (al * A + (1 - al) * B)))) for al in np.linspace(0.1, 0.9, 9))
    ea, eb = float(np.mean(np.abs(mid - A))), float(np.mean(np.abs(mid - B)))
    lmin, lmax = float(seg_l.min()), float(seg_l.max())
    around = max(L[a_i], L[b_i])
    if lmin < 18 and min(L[a_i], L[b_i]) > lmin + 15:
        res.update(auto_type="fade_black", confidence=0.8)
    elif lmax > 225 and lmax - around > 35:
        res.update(auto_type="flash_white", confidence=0.75)
    else:
        is_wipe, direction = wipe_check(S, left, right)
        if is_wipe:
            res.update(auto_type="wipe", confidence=0.65, direction=direction)
        elif blend < 0.55 * min(ea, eb):
            res.update(auto_type="dissolve", confidence=0.7)
        else:
            res.update(auto_type="motion", confidence=0.4, note="slide/push/zoom/whip/glitch - check filmstrip")
    return res


def merge_overlapping(bounds):
    out = []
    for bd in bounds:
        if out and bd["start_frame"] <= out[-1]["end_frame"] + 1 and bd["auto_type"] != "cut":
            prev = out[-1]
            prev["end_frame"] = max(prev["end_frame"], bd["end_frame"])
            prev["frames"] = prev["end_frame"] - prev["start_frame"] + 1
            prev["frame"] = (prev["start_frame"] + prev["end_frame"]) // 2
            if prev["auto_type"] == "cut":
                prev.update(auto_type=bd["auto_type"], confidence=bd["confidence"])
            continue
        out.append(bd)
    return out


def sheets(video, cuts, out_dir: Path, fps, detail, thumb_w=256):
    out_dir.mkdir(parents=True, exist_ok=True)
    for old in list(out_dir.glob("cuts_*.jpg")) + list(out_dir.glob("bounds_*.jpg")):
        old.unlink()
    want = {}
    for c in cuts:
        s, e = c["start_frame"], c["end_frame"]
        bi = c.get("boundary_in") or {}
        s2 = max(s, bi.get("end_frame", s) + 1) if bi.get("auto_type", "cut") != "cut" else s
        s2 = min(s2 + 1, e - 1)
        want[c["id"]] = [s2, (s + e) // 2, max(s, e - 2)]
    frames = grab_frames(video, [f for v in want.values() for f in v], width=thumb_w)
    rows, n_sheet = [], 0
    for k, c in enumerate(cuts):
        ims = []
        for j, f in enumerate(want[c["id"]]):
            im = frames.get(f)
            if im is None:
                im = np.zeros((thumb_w * 9 // 16, thumb_w, 3), np.uint8)
            im = im.copy()
            tag = f"{c['id']} {fmt_tc(c['start_s'])} ({c['duration_s']:.2f}s)" if j == 0 else fmt_tc(f / fps)
            ims.append(label_image(im, tag, 0.4))
        rows.extend(ims)
        if len(rows) == 6 * 8 or k == len(cuts) - 1:
            n_sheet += 1
            cv2.imwrite(str(out_dir / f"cuts_{n_sheet:03d}.jpg"), grid(rows, 6), [cv2.IMWRITE_JPEG_QUALITY, 85])
            rows = []
    # boundary filmstrips
    targets = [c for c in cuts if c.get("boundary_in") and (c["boundary_in"]["auto_type"] != "cut"
               or detail[0] <= c["start_s"] < detail[1])]
    plan = {}
    for c in targets:
        bd = c["boundary_in"]
        if bd["auto_type"] == "cut":
            offs = [bd["frame"] + o for o in (-6, -4, -2, -1, 0, 1, 2, 4, 6)]
        else:
            a, b = bd["start_frame"] - 3, bd["end_frame"] + 3
            offs = [int(round(a + (b - a) * t / 8)) for t in range(9)]
        plan[c["id"]] = offs
    frames = grab_frames(video, [f for v in plan.values() for f in v], width=192)
    rows, n_sheet = [], 0
    for k, c in enumerate(targets):
        bd = c["boundary_in"]
        for j, f in enumerate(plan[c["id"]]):
            im = frames.get(f)
            im = np.zeros((108, 192, 3), np.uint8) if im is None else im.copy()
            tag = f"{c['id']} {bd['auto_type']} {bd['frames']}f" if j == 0 else f"{f - bd['frame']:+d}"
            rows.append(label_image(im, tag, 0.38))
        if len(rows) == 9 * 8 or k == len(targets) - 1:
            n_sheet += 1
            cv2.imwrite(str(out_dir / f"bounds_{n_sheet:03d}.jpg"), grid(rows, 9), [cv2.IMWRITE_JPEG_QUALITY, 85])
            rows = []


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("video")
    ap.add_argument("--out", required=True)
    ap.add_argument("--range", help="START:END seconds to analyze (default whole video)")
    ap.add_argument("--detail-range", default="0:30", help="boundaries here always get filmstrips")
    ap.add_argument("--threshold", type=float, default=3.0, help="AdaptiveDetector adaptive_threshold")
    ap.add_argument("--min-scene-len", type=float, default=0.25, help="seconds")
    ap.add_argument("--detector", choices=["adaptive", "content"], default="adaptive")
    ap.add_argument("--no-sheets", action="store_true")
    a = ap.parse_args()

    info = probe(a.video)
    fps = info["fps"]
    t0, t1 = parse_range(a.range, info["duration_s"])
    f0, f1 = int(round(t0 * fps)), int(round(t1 * fps))
    min_len = max(2, int(round(a.min_scene_len * fps)))
    print(f"scanning {a.video} frames {f0}-{f1} @ {fps:.3f}fps ...")
    raw, S, L, f_end, grad = scan(a.video, fps, f0, f1, a.threshold, min_len, a.detector)
    bounds = []
    for b in raw:
        bd = classify(S, L, f0, b)
        if b in grad:
            bd["found_by"] = "histogram_window"
            if bd["auto_type"] == "cut" and bd["frames"] <= 2:
                bd["confidence"] = 0.5
        bounds.append(bd)
    bounds = merge_overlapping(bounds)

    starts = [f0] + [bd["start_frame"] if bd["auto_type"] != "cut" else bd["frame"] for bd in bounds]
    ends = starts[1:] + [f_end]
    cuts = []
    for k, (s, e) in enumerate(zip(starts, ends)):
        if e <= s:
            continue
        c = {"id": f"c{len(cuts) + 1:03d}", "index": len(cuts), "start_frame": int(s), "end_frame": int(e),
             "start_s": round(s / fps, 4), "end_s": round(e / fps, 4), "duration_s": round((e - s) / fps, 4),
             "duration_frames": int(e - s), "boundary_in": bounds[k - 1] if k > 0 else None, "annotation": None}
        cuts.append(c)
    if cuts and L[0] < 18:
        cuts[0]["starts_from_black"] = True
    out = Path(a.out)
    doc = {"video": {"path": str(Path(a.video).resolve()), **info},
           "range": {"start_s": t0, "end_s": t1}, "detail_range": a.detail_range,
           "detector": {"type": a.detector, "adaptive_threshold": a.threshold, "min_scene_len_frames": min_len},
           "cuts": cuts}
    write_json(out / "cuts.json", doc)
    kinds = {}
    for c in cuts[1:]:
        kinds[c["boundary_in"]["auto_type"]] = kinds.get(c["boundary_in"]["auto_type"], 0) + 1
    durs = [c["duration_s"] for c in cuts]
    print(f"{len(cuts)} cuts, median {np.median(durs):.2f}s, boundaries {kinds}")
    if not a.no_sheets:
        sheets(a.video, cuts, out / "frames", fps, parse_range(a.detail_range, info["duration_s"]))
        print(f"sheets -> {out / 'frames'}")


if __name__ == "__main__":
    main()
