#!/usr/bin/env python3
"""Draft annotations for every cut from measurements + CLIP zero-shot image tags (for full-length videos).

  run.sh auto_annotate <analysis_dir> [--overwrite-drafts] [--range START:END]

Uses cuts.json (boundaries, motion), source_signals.json (+ frames/src/<cut>.jpg), captions.json
(render_policy, credits), audio.json (SFX on cuts), transcript.json (boundary vs words) and script.json
(section roles) when present. Every drafted annotation has "draft": true and confidence <= 0.7.
Hand-written annotations (no draft flag) are never touched. The agent reviews the contact sheets, corrects source
types/descriptions/transitions, and removes "draft" on the cuts it has confirmed. Always confirm the recreation
range and every cut used as a donor for a new video.
Writes clip_tags into source_signals.json (cached) and annotations into cuts.json.
"""
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np

from common import parse_range, read_json, write_json  # noqa: E402

LABELS = {
    "flat_illustration": "a flat 2D vector cartoon illustration",
    "painted_illustration": "a cinematic digital painting of a historical scene with people, animals or buildings",
    "ai_photoreal": "a photorealistic AI generated historical scene with soft cinematic lighting",
    "3d_render": "a 3D rendered computer graphics object on a plain background",
    "real_photo": "a candid real news photograph of modern people",
    "real_video_street": "real camera footage of a modern city street with cars and traffic",
    "aerial_footage": "aerial drone footage of a modern highway or city",
    "bw_archival": "an old black and white historical photograph",
    "infographic": "an infographic with large numbers, icons and labels on a dark background",
    "map": "a geographic map with country borders and labels",
    "globe": "a 3D globe of the earth",
    "document": "a close-up of an old manuscript, parchment page or document with text",
    "note_card": "a paper note card with handwritten quote text over an image",
    "text_card": "a plain dark background with a large title text",
    "game": "a screenshot from a modern video game with a HUD",
}
TYPE_OF = {
    "flat_illustration": ("ai_image", "ai_video"), "painted_illustration": ("ai_image", "ai_video"),
    "ai_photoreal": ("ai_image", "ai_video"),
    "3d_render": ("motion_graphic", "motion_graphic"), "real_photo": ("stock_photo", "external_footage"),
    "real_video_street": ("stock_photo", "stock_video"), "aerial_footage": ("stock_photo", "stock_video"),
    "bw_archival": ("archival_photo", "external_footage"), "infographic": ("motion_graphic", "motion_graphic"),
    "map": ("map_or_chart", "map_or_chart"), "globe": ("motion_graphic", "motion_graphic"),
    "document": ("ai_image", "ai_video"), "note_card": ("motion_graphic", "motion_graphic"),
    "text_card": ("text_card", "text_card"), "game": ("game_footage", "game_footage"),
}
METHOD = {"ai_video": "ai_video", "ai_image": "ai_image", "stock_video": "stock_search", "stock_photo": "stock_search",
          "external_footage": "archive_search", "archival_photo": "archive_search", "screen_recording": "screen_capture",
          "motion_graphic": "render_graphic", "text_card": "render_graphic", "map_or_chart": "render_graphic",
          "talking_head": "unavailable", "game_footage": "unavailable", "illustration": "ai_image",
          "meme_or_reaction": "archive_search", "unknown": "unavailable"}
TRANS = {"cut": "cut", "dissolve": "dissolve", "fade_black": "fade_black", "flash_white": "flash_white",
         "wipe": "wipe", "motion": "other"}
SYNC = {"word_start": "on_keyword", "pause": "in_pause", "mid_word": "mid_sentence"}


def clip_tags(ad: Path, sig: dict, cut_ids):
    todo = [c for c in cut_ids if c in sig["cuts"] and "clip_tags" not in sig["cuts"][c]]
    if not todo:
        return
    import torch
    from PIL import Image
    from transformers import CLIPModel, CLIPProcessor
    from common import LFC_HOME
    local = LFC_HOME / "models" / "clip-vit-base-patch32"
    name = str(local) if (local / "config.json").exists() else "openai/clip-vit-base-patch32"
    model = CLIPModel.from_pretrained(name).eval()
    proc = CLIPProcessor.from_pretrained(name)
    keys = list(LABELS)
    tin = proc(text=[LABELS[k] for k in keys], return_tensors="pt", padding=True)
    with torch.no_grad():
        te = model.get_text_features(**tin)
    te = te.pooler_output if hasattr(te, "pooler_output") else te
    te = te / te.norm(dim=-1, keepdim=True)
    for i in range(0, len(todo), 16):
        batch = todo[i:i + 16]
        ims = [Image.open(ad / sig["cuts"][c]["image"]).convert("RGB") for c in batch]
        with torch.no_grad():
            ie = model.get_image_features(**proc(images=ims, return_tensors="pt"))
        ie = ie.pooler_output if hasattr(ie, "pooler_output") else ie
        ie = ie / ie.norm(dim=-1, keepdim=True)
        probs = (100 * ie @ te.T).softmax(-1).numpy()
        for c, p in zip(batch, probs):
            order = np.argsort(-p)[:3]
            sig["cuts"][c]["clip_tags"] = [[keys[j], round(float(p[j]), 3)] for j in order]


def ai_label_times(cap, patterns=("AI 생성", "AI생성", "AI 이미지", "AI 영상", "AI generated", "AI-generated", "Made with AI")):
    """Time spans where the reference shows an on-screen 'AI generated' disclosure (many channels do)."""
    out = []
    for e in (cap or {}).get("events", []):
        t = (e.get("text_corrected") or e.get("text") or "").replace(" ", "").lower()
        if any(p.replace(" ", "").lower() in t for p in patterns) and len(t) <= 16:
            out.append((e["start_s"], e["end_s"]))
    return out


def draft(c, s, cap, cap_by_id, audio, tr_map, sections, fps, priors=None, ai_spans=()):
    """priors (channel_priors in P/channel.json or --priors JSON):
      {"exclude_types": ["game_footage"], "prefer_on_exclude": "ai_photoreal"}"""
    priors = priors or {}
    m = c.get("motion") or {}
    tags = s.get("clip_tags") or [["unknown", 0.0]]
    top, p = tags[0]
    excluded = set(priors.get("exclude_types", []))
    # a tag whose source type this channel never uses: fall through to the next tag unless CLIP is very sure
    # (CLIP often files stylized renders under "game")
    def banned(tag):
        return bool(set(TYPE_OF.get(tag, ("unknown", "unknown"))) & excluded)
    k = 0
    while excluded and banned(top) and p < 0.9 and k + 1 < len(tags):
        k += 1
        top, p = tags[k][0], max(tags[k][1], 0.35)
    ai_labelled = any(a0 < c["end_s"] - 0.05 and a1 > c["start_s"] + 0.05 for a0, a1 in ai_spans)
    moving = (m.get("residual_first_to_last") or 0) >= 8 or (m.get("median_inlier") or 1) < 0.35
    stype = TYPE_OF.get(top, ("unknown", "unknown"))[1 if moving else 0]
    ev = [f"CLIP: {top} ({p:.2f})" + (f", 2nd {tags[1][0]} ({tags[1][1]:.2f})" if len(tags) > 1 else "")]
    if ai_labelled:
        stype = "ai_video" if moving else "ai_image"
        ev.insert(0, "reference shows an 'AI generated' label during this cut")
        p = max(p, 0.9)
    if m:
        ev.append(f"in-frame motion residual {m.get('residual_first_to_last')} (first->last), inlier {m.get('median_inlier')}")
        cd = m.get("cadence") or {}
        if cd.get("holds_ratio", 0) > 0.15:
            ev.append(f"frame holds {cd['holds_ratio']:.0%}, {cd['unique_per_s']} unique fps (retimed source)")
    if s.get("corner_text"):
        ev.append(f"corner text {s['corner_text'][:3]}")
    if s.get("saturation_mean", 99) < 12:
        ev.append("monochrome")
    if s.get("blur_pillarbox"):
        ev.append("blurred pillarbox (vertical source)")
    conf = round(min(0.85 if ai_labelled else 0.7, 0.35 + 0.4 * p), 2)
    fx = []
    if s.get("saturation_mean", 99) < 12:
        fx.append("black_white")
    b = s.get("bars") or {}
    if b.get("top", 0) > 0.08 and b.get("bottom", 0) > 0.08:
        fx.append("letterbox_bars")
    op = ((m.get("components") or {}).get("opacity") or {}).get("keyframes") or []
    a_in, a_in_s = "none", None
    if op and op[0]["v"] < 0.35 and len(op) > 1:
        a_in, a_in_s = "fade", op[1]["t"]
    bi = c.get("boundary_in") or {}
    t_type = TRANS.get(bi.get("auto_type", "cut"), "other") if c["index"] > 0 else "cut"
    t_frames = 0 if t_type == "cut" else int(bi.get("frames", 0))
    sfx_ids = [e["id"] for e in audio.get("sfx_events", []) if e.get("likely_sfx") and not e.get("rejected")
               and abs(e["t"] - c["start_s"]) <= 0.12]
    in_cut = [e for e in cap.get("events", []) if e["start_s"] < c["end_s"] and e["end_s"] > c["start_s"]]
    pol = cap.get("render_policy") or {}
    sub_z = set(pol.get("subtitle_zones") or pol.get("zones") or [])
    brand_z = set(pol.get("brand_zones") or [])
    excl = set(pol.get("exclude_ids") or [])
    credits = [e for e in in_cut if e.get("credit_like") and e["id"] not in excl]
    overlays = []
    pops = [e["id"] for e in in_cut if e.get("zone") not in sub_z | brand_z and e["id"] not in excl and not e.get("credit_like")]
    if pops:
        overlays.append({"kind": "keyword_popup", "text_event_ids": pops, "notes": "draft: check kind"})
    role = "explanation"
    for sec in sections:
        if sec["start_s"] <= (c["start_s"] + c["end_s"]) / 2 < sec["end_s"]:
            role = sec["role"]
            break
    preset = m.get("preset_guess") or "static"
    return {
        "draft": True,
        "source": {"type": stype, "subtype": f"draft from CLIP '{top}'",
                   "description": f"draft: {LABELS.get(top, top)}" + ("; content moves" if moving else "; still"),
                   "evidence": ev, "confidence": conf, "media": "video" if moving else "image",
                   "orientation": "portrait" if s.get("blur_pillarbox") else "landscape",
                   "acquire": {"method": METHOD.get(stype, "unavailable")}},
        "source_credit": ({"shown": True, "text": credits[0]["text"], "text_event_ids": [e["id"] for e in credits]}
                          if credits else {"shown": False}),
        "layer": {"fit": "blur_background" if s.get("blur_pillarbox") else "cover", "initial_scale": 1.0},
        "keyframes": {"preset": preset, "confirmed": False},
        "animation": {"in": a_in, **({"in_s": a_in_s} if a_in_s else {}), "effects": fx},
        "transition_in": {"type": t_type, "frames": t_frames, **({"sfx_ids": sfx_ids} if sfx_ids else {}),
                          **({"notes": f"wipe {bi.get('direction')}"} if bi.get("direction") else {})},
        "script_role": role,
        "overlays": overlays,
        "sfx_ids": sfx_ids,
        "narration_sync": SYNC.get(tr_map.get(c["id"]), "independent"),
    }


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("analysis_dir")
    ap.add_argument("--overwrite-drafts", action="store_true")
    ap.add_argument("--range")
    ap.add_argument("--priors", help='JSON, e.g. {"exclude_types": ["game_footage"]}; default: channel_priors in P/channel.json')
    a = ap.parse_args()
    ad = Path(a.analysis_dir)
    doc = read_json(ad / "cuts.json")
    sig = read_json(ad / "source_signals.json")
    cap = read_json(ad / "captions.json") if (ad / "captions.json").exists() else {"events": []}
    audio = read_json(ad / "audio.json") if (ad / "audio.json").exists() else {}
    tr = read_json(ad / "transcript.json") if (ad / "transcript.json").exists() else {}
    tr_map = {x["cut_id"]: x.get("boundary_vs_word") for x in tr.get("cut_text", [])}
    sections = read_json(ad / "script.json")["sections"] if (ad / "script.json").exists() else []
    lo, hi = parse_range(a.range, doc["video"]["duration_s"]) if a.range else (0, 1e9)
    cuts = [c for c in doc["cuts"] if lo <= c["start_s"] < hi]
    import json as _json
    priors = _json.loads(a.priors) if a.priors else {}
    chp = ad.parent.parent / "channel.json"
    if not priors and chp.exists():
        priors = read_json(chp).get("channel_priors") or {}
    ai_spans = ai_label_times(cap)
    # rejected SFX (sfx_filter) must never be linked
    if audio.get("sfx_events"):
        audio = dict(audio, sfx_events=[e for e in audio["sfx_events"] if not e.get("rejected")])
    clip_tags(ad, sig, [c["id"] for c in cuts])
    write_json(ad / "source_signals.json", sig)
    n = 0
    for c in cuts:
        ann = c.get("annotation")
        if ann and not (ann.get("draft") and a.overwrite_drafts):
            continue
        s = sig["cuts"].get(c["id"], {})
        c["annotation"] = draft(c, s, cap, None, audio, tr_map, sections, doc["video"]["fps"], priors, ai_spans)
        n += 1
    write_json(ad / "cuts.json", doc)
    from collections import Counter
    types = Counter((c.get("annotation") or {}).get("source", {}).get("type") for c in cuts)
    print(f"drafted {n} cuts; source types in range: {dict(types)}")


if __name__ == "__main__":
    main()
