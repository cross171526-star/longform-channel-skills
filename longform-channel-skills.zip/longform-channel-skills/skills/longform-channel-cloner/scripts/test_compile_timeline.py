import json
import unittest
from compile_timeline import compile_timeline
import test_check_production as fixtures


class CompileTimelineTests(unittest.TestCase):
    def setUp(self):
        self.fixture = fixtures.ProductionGateTest()
        self.fixture.setUp()
        self.addCleanup(self.fixture.doCleanups)
        self.path = self.fixture.root / 'reference_map.json'

    def test_keeps_components_and_connects_times(self):
        f = self.fixture
        f.add_cut('c2')
        f.m['cuts'][1]['duration_s'] = 12
        f.set_duration(22)
        f.save()
        result = compile_timeline(self.path)
        self.assertEqual([(c['id'],c['start_s'],c['end_s']) for c in result['cuts']], [('c1',0,10),('c2',10,22)])
        self.assertEqual(result['cuts'][1]['effects'], f.m['cuts'][1]['effects'])
        self.assertEqual(result['cuts'][1]['visual_evidence'], f.m['cuts'][1]['visual_evidence'])

    def test_missing_effect_is_not_invented(self):
        self.fixture.m['cuts'][0]['effects'] = {}
        self.fixture.save()
        with self.assertRaisesRegex(ValueError, 'missing grain'):
            compile_timeline(self.path)


if __name__ == '__main__':
    unittest.main()
