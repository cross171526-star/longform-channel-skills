#!/usr/bin/env python3
"""Transcribe narration with word timestamps and map spoken text onto cuts.

  run.sh transcribe <video_or_audio> --out <analysis_dir> [--lang ko] [--model large-v3-turbo]
                    [--subs <source.ko.vtt>] [--cuts <cuts.json>] [--range START:END]

Uses faster-whisper (CPU int8) with word timestamps and VAD. If a manual subtitle file is given, its text is
kept alongside for correcting recognition errors (timing still comes from whisper words).
Writes <out>/transcript.json: timed segments and words; optional cut_text.
Speech-rate measurement is handled by speech_rate.py. No narrator or pause-pattern analysis.
"""
from __future__ import annotations

import argparse
import re
from pathlib import Path

from common import LFC_HOME, extract_wav, parse_range, probe, read_json, write_json


def parse_vtt(path: Path) -> list[dict]:
    cues, cur = [], None
    ts = re.compile(r"(\d+):(\d+):(\d+)\.(\d+)\s+-->\s+(\d+):(\d+):(\d+)\.(\d+)")
    for line in path.read_text(encoding="utf-8").splitlines():
        m = ts.search(line)
        if m:
            g = [int(x) for x in m.groups()]
            cur = {"start": g[0] * 3600 + g[1] * 60 + g[2] + g[3] / 1000,
                   "end": g[4] * 3600 + g[5] * 60 + g[6] + g[7] / 1000, "text": ""}
            cues.append(cur)
        elif cur is not None and line.strip() and not line.startswith(("WEBVTT", "Kind:", "Language:")):
            clean = re.sub(r"<[^>]+>", "", line).strip()
            if clean and clean not in cur["text"]:
                cur["text"] = (cur["text"] + " " + clean).strip()
    out = []
    for c in cues:  # auto-subs repeat rolling lines; drop exact repeats
        if c["text"] and (not out or c["text"] != out[-1]["text"]):
            out.append(c)
    return out


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("media")
    ap.add_argument("--out", required=True)
    ap.add_argument("--lang", default=None, help="ko, en, ... (default auto)")
    ap.add_argument("--model", default="large-v3-turbo")
    ap.add_argument("--subs")
    ap.add_argument("--cuts")
    ap.add_argument("--range")
    ap.add_argument("--threads", type=int, default=8)
    ap.add_argument("--backend", choices=["auto", "mlx", "faster-whisper"], default="auto")
    ap.add_argument("--verbose", action="store_true")
    ap.add_argument("--transcript-only", action="store_true", help="Compatibility alias: timed text and words only")
    a = ap.parse_args()
    out = Path(a.out)
    info = probe(a.media)
    t0, t1 = parse_range(a.range, info["duration_s"])
    vocals = out / "stems" / "vocals.wav"
    wav = out / "audio_16k.wav"
    src = a.media  # Do not silently reuse unverified stems from another source.
    extract_wav(src, wav, sr=16000, channels=1, start=t0 if a.range else None, end=t1 if a.range else None)
    segments, words = [], []
    mlx_dir = LFC_HOME / "models" / "whisper-large-v3-turbo-mlx"
    backend = a.backend
    if backend == "auto":
        backend = "mlx" if (mlx_dir / "weights.safetensors").exists() else "faster-whisper"
    if backend == "mlx":
        # Apple GPU: ~10x faster than faster-whisper CPU int8 on the same audio
        import mlx_whisper
        res = mlx_whisper.transcribe(str(wav), path_or_hf_repo=str(mlx_dir), language=a.lang, word_timestamps=True,
                                     condition_on_previous_text=False, verbose=None)
        lang = res.get("language", a.lang)
        raw = [(s["start"], s["end"], s["text"], [(w["word"], w["start"], w["end"], w.get("probability", 1.0))
                                                   for w in s.get("words", [])]) for s in res["segments"]]
    else:
        from faster_whisper import WhisperModel
        model = WhisperModel(a.model, device="cpu", compute_type="int8", cpu_threads=a.threads)
        segs, meta = model.transcribe(str(wav), language=a.lang, word_timestamps=True, vad_filter=True,
                                      vad_parameters={"min_silence_duration_ms": 250}, beam_size=5,
                                      condition_on_previous_text=False)
        lang = meta.language
        raw = [(s.start, s.end, s.text, [(w.word, w.start, w.end, w.probability) for w in (s.words or [])]) for s in segs]
    for st, en, tx, ws in raw:
        if not tx.strip():
            continue
        seg = {"id": len(segments), "start": round(st + t0, 3), "end": round(en + t0, 3), "text": tx.strip()}
        segments.append(seg)
        for w, ws_, we, pr in ws:
            words.append({"w": w.strip(), "start": round(ws_ + t0, 3), "end": round(we + t0, 3),
                          "p": round(float(pr), 3), "seg": seg["id"]})
        if a.verbose:
            print(f"[{seg['start']:7.2f}-{seg['end']:7.2f}] {seg['text']}")
    doc = {"media": str(Path(a.media).resolve()), "language": lang,
           "model": a.model if backend != "mlx" else "whisper-large-v3-turbo (mlx)",
           "range": [t0,t1], "segments":segments, "words":words}
    if a.subs:
        doc["subtitle_reference"] = {"file": str(a.subs), "cues": parse_vtt(Path(a.subs))}
    if a.cuts:
        cuts = read_json(a.cuts)["cuts"]
        cut_text = []
        for c in cuts:
            ws = [w for w in words if c["start_s"] <= (w["start"] + w["end"]) / 2 < c["end_s"]]
            cut_text.append({"cut_id": c["id"], "start_s": c["start_s"], "end_s": c["end_s"],
                             "text": " ".join(w["w"] for w in ws),
                             "boundary_vs_word": _boundary_relation(c["start_s"], words)})
        doc["cut_text"] = cut_text
    write_json(out / "transcript.json", doc)
    print(f"{len(words)} timed words -> {out / 'transcript.json'}")


def _boundary_relation(t, words):
    """Where a cut falls relative to speech: in a pause, at a word start, or mid-word."""
    for w in words:
        if w["start"] - 0.06 <= t <= w["start"] + 0.06:
            return "word_start"
        if w["start"] < t < w["end"]:
            return "mid_word"
    return "pause"


if __name__ == "__main__":
    main()
