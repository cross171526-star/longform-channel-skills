#!/usr/bin/env python3
"""Clean SFX candidates in audio.json: drop BGM beats, voice leakage and weak/unsure detections.

  run.sh sfx_filter <analysis_dir> [--keep-labels ...] [--dry-run]

audio_analysis finds onsets on the music stem, which also contains the BGM's own drums, and Demucs leaves some
plosives in it. On real channels this produced 80-95 % false SFX (measured 956 -> 162 after manual review on
3 videos). Rules (each one is logged per event in "filter"):
  1. beat grid: onsets that fall on the local BGM beat (librosa beat track of the surrounding 8 s of music stem,
     |offset| < 45 ms) and whose CLAP top label is a percussive/music label are BGM, not SFX
  2. label: top label in BEATLIKE (thunder, footsteps, heartbeat, drum hit, bass drop) or NON_SFX, or top-label
     probability < 0.5 -> rejected unless the onset is also on a cut (<= 120 ms) and strong
  3. isolation: a real SFX sticks out of the music bed: onset strength z >= 6 on the music stem
Accepted events keep likely_sfx=true; rejected ones get rejected=true + rejected_reason. The original file is kept
as audio.raw.json. Always listen to a sample of kept sfx/*.wav and fix labels (label_corrected) before use.
"""
from __future__ import annotations

import argparse
import shutil
from pathlib import Path

import numpy as np
import soundfile as sf

from common import read_json, write_json

BEATLIKE = {"thunder", "footsteps", "heartbeat", "drum hit", "bass drop", "explosion", "gunshot"}
NON_SFX = {"background music", "piano music", "orchestral music", "electronic beat music", "silence", "speech"}


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("analysis_dir")
    ap.add_argument("--keep-labels", nargs="*", default=[], help="labels to keep even if beat-like (channel uses them)")
    ap.add_argument("--min-z", type=float, default=6.0)
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args()
    import librosa
    ad = Path(a.analysis_dir)
    raw = ad / "audio.raw.json"
    if not raw.exists():
        shutil.copy2(ad / "audio.json", raw)
    doc = read_json(raw)
    mus, sr = sf.read(str(ad / doc["stems"]["music"]), dtype="float32")
    mus = mus.mean(1) if mus.ndim > 1 else mus
    y = librosa.resample(mus, orig_sr=sr, target_sr=22050)
    keep_l = set(a.keep_labels)
    t_off = (doc.get("range") or [0, 0])[0]
    beat_cache = {}

    def beats_near(t):
        k = int(t // 8)
        if k not in beat_cache:
            s, e = max(0, int((k * 8 - 2) * 22050)), int((k * 8 + 10) * 22050)
            seg = y[s:e]
            if len(seg) < 22050 * 3 or float(np.sqrt(np.mean(seg ** 2))) < 1e-3:
                beat_cache[k] = np.array([])
            else:
                _, bt = librosa.beat.beat_track(y=seg, sr=22050, units="time")
                beat_cache[k] = np.asarray(bt) + s / 22050
        return beat_cache[k]

    kept = rej = 0
    stats = {}
    for ev in doc.get("sfx_events", []):
        if not ev.get("likely_sfx"):
            continue
        lab, p = (ev.get("labels") or [["?", 0.0]])[0]
        t = ev["t"] - t_off
        on_cut = bool(ev.get("on_cut"))
        b = beats_near(t)
        on_beat = bool(b.size) and float(np.min(np.abs(b - t))) < 0.045
        reason = None
        if lab in keep_l:
            pass
        elif lab in NON_SFX:
            reason = f"label '{lab}' is not an effect"
        elif on_beat and lab in BEATLIKE:
            reason = "on BGM beat grid with a percussive label (BGM drum)"
        elif lab in BEATLIKE and not on_cut:
            reason = f"beat-like label '{lab}' off-cut (usually BGM or voice leakage)"
        elif p < 0.5 and not (on_cut and ev.get("strength_z", 0) >= 2 * a.min_z):
            reason = f"unsure label ({lab} {p:.2f})"
        elif ev.get("strength_z", 0) < a.min_z and not on_cut:
            reason = f"weak onset z={ev.get('strength_z')}"
        ev["filter"] = {"on_beat": on_beat, "on_cut": on_cut}
        if reason:
            ev["rejected"] = True
            ev["rejected_reason"] = reason
            rej += 1
            stats[reason.split(" (")[0].split(" '")[0]] = stats.get(reason.split(" (")[0].split(" '")[0], 0) + 1
        else:
            ev.pop("rejected", None)
            kept += 1
    doc["sfx_filter"] = {"kept": kept, "rejected": rej, "reasons": stats}
    good = [e for e in doc.get("sfx_events", []) if e.get("likely_sfx") and not e.get("rejected")]
    dur = max(1e-6, ((doc.get("range") or [0, 0])[1] - t_off) / 60)
    doc["sfx_per_minute_filtered"] = round(len(good) / dur, 2)
    if not a.dry_run:
        write_json(ad / "audio.json", doc)
    from collections import Counter
    print(f"{ad.name}: kept {kept}, rejected {rej} {stats}; kept labels {Counter(e['labels'][0][0] for e in good).most_common(8)}")


if __name__ == "__main__":
    main()

