"""stdlib CLI의 길이 계산, 입력 검증, 실패 시 출력 보존을 확인한다."""

import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from plan_duration import write_plan


SCRIPT = Path(__file__).with_name("plan_duration.py")


def six_references(durations=(100, 200, 300, 400, 500, 600)):
    return [{"id": f"ref-{i}", "duration_s": value}
            for i, value in enumerate(durations)]


class DurationPlanningTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.addCleanup(self.folder.cleanup)
        self.input_path = Path(self.folder.name) / "references.json"
        self.output_path = Path(self.folder.name) / "plan.json"

    def run_cli(self, document=None, raw=None):
        if raw is None:
            raw = json.dumps(document, ensure_ascii=False).encode("utf-8")
        self.input_path.write_bytes(raw)
        return subprocess.run(
            [sys.executable, "-B", str(SCRIPT), str(self.input_path),
             "--out", str(self.output_path)],
            capture_output=True, text=True, check=False,
        )

    def successful_plan(self, durations, excluded=None):
        references = six_references(durations)
        document = {"references": references}
        if excluded is not None:
            document["excluded_references"] = excluded
        result = self.run_cli(document)
        self.assertEqual(result.returncode, 0, result.stderr)
        plan = json.loads(self.output_path.read_text(encoding="utf-8"))
        self.assertEqual(plan["references"], references)
        self.assertEqual(plan["excluded_references"], excluded or [])
        self.assertEqual(plan["preview_start_s"], 0)
        self.assertEqual(plan["preview_min_duration_s"], min(170, plan["target_duration_s"]))
        self.assertEqual(plan["preview_max_duration_s"], min(210, plan["target_duration_s"]))
        self.assertIs(plan["preview_selection_required"], True)
        self.assertEqual(plan["source_input_sha256"],
                         hashlib.sha256(self.input_path.read_bytes()).hexdigest())
        self.assertEqual(plan["formula"],
                         "sum(reference.duration_s for reference in references) / 6")
        return plan

    def test_twenty_minute_mean(self):
        plan = self.successful_plan([600, 900, 1100, 1300, 1500, 1800])
        self.assertEqual(plan["target_duration_s"], 1200)
        self.assertEqual(plan["preview_end_s"], 180)
        self.assertEqual(plan["preview_duration_s"], 180)

    def test_mean_uses_exactly_six_selected_references(self):
        excluded = [{"id": "excluded", "duration_s": 9999, "reason": "사용자 제외"}]
        plan = self.successful_plan([100, 200, 300, 400, 500, 600], excluded)
        self.assertEqual(plan["target_duration_s"], 350)
        self.assertEqual(plan["preview_end_s"], 180)
        self.assertEqual(plan["preview_duration_s"], 180)

    def test_short_mean_caps_preview_at_full_length(self):
        plan = self.successful_plan([30, 30, 90, 90, 120, 120])
        self.assertEqual(plan["target_duration_s"], 80)
        self.assertEqual(plan["preview_end_s"], 80)
        self.assertEqual(plan["preview_duration_s"], 80)

    def test_fractional_mean_is_not_rounded(self):
        plan = self.successful_plan([1, 2, 2, 2, 2, 2])
        self.assertEqual(plan["target_duration_s"], 11 / 6)
        self.assertEqual(plan["preview_duration_s"], 11 / 6)

    def test_preview_boundary(self):
        for target in (169, 170, 175, 180, 195, 210, 211):
            with self.subTest(target=target):
                plan = self.successful_plan([target] * 6)
                self.assertEqual(plan["target_duration_s"], target)
                self.assertEqual(plan["preview_end_s"], min(180, target))
                self.assertEqual(plan["preview_duration_s"], min(180, target))

    def test_large_finite_values_do_not_overflow_sum(self):
        plan = self.successful_plan([1e308] * 6)
        self.assertEqual(plan["target_duration_s"], 1e308)
        self.assertEqual(plan["preview_duration_s"], 180)

    def test_success_replaces_existing_output(self):
        self.output_path.write_bytes(b"previous output")
        plan = self.successful_plan([240, 360] * 3)
        self.assertEqual(plan["target_duration_s"], 300)

    def assert_invalid(self, document=None, raw=None):
        for existing in (False, True):
            with self.subTest(existing_output=existing):
                if existing:
                    self.output_path.write_bytes(b"previous output\x00")
                else:
                    self.output_path.unlink(missing_ok=True)
                result = self.run_cli(document, raw)
                self.assertEqual(result.returncode, 1, result.stderr)
                self.assertTrue(result.stderr)
                if existing:
                    self.assertEqual(self.output_path.read_bytes(), b"previous output\x00")
                else:
                    self.assertFalse(self.output_path.exists())

    def test_empty_or_invalid_structure(self):
        for document in (None, [], {}, {"references": []}, {"references": None},
                         {"references": {}}, {"references": [None]},
                         {"references": [{}]}, {"references": ["ref"]}):
            with self.subTest(document=document):
                self.assert_invalid(document)

    def test_invalid_ids(self):
        for reference_id in (None, "", "  \t", 0, True, [], {}):
            with self.subTest(reference_id=reference_id):
                references = six_references()
                references[2]["id"] = reference_id
                self.assert_invalid({"references": references})

    def test_duplicate_ids(self):
        for duplicate in ("ref-0", " ref-0 "):
            with self.subTest(duplicate=duplicate):
                references = six_references()
                references[-1]["id"] = duplicate
                self.assert_invalid({"references": references})

    def test_invalid_counts_have_no_shortage_exception(self):
        for count in (0, 3, 4, 5, 7, 8, 12):
            with self.subTest(count=count):
                self.assert_invalid({
                    "references": six_references([120] * count),
                    "excluded_references": [{"id": "extra", "duration_s": 120}],
                    "allow_shortage": True,
                })

    def test_latest_one_uses_source_duration_and_thirty_second_range(self):
        for duration in (20, 169, 180, 600.125):
            with self.subTest(duration=duration):
                result = self.run_cli({'reference_count': 1, 'references': [{'id': 'latest', 'duration_s': duration}]})
                self.assertEqual(result.returncode, 0, result.stderr)
                plan = json.loads(self.output_path.read_text())
                self.assertEqual(plan['target_duration_s'], duration)
                self.assertEqual(plan['reference_policy'], 'latest-one-v1')
                self.assertEqual(plan['full_duration_tolerance_s'], 30)
                self.assertEqual(plan['full_min_duration_s'], max(0, duration - 30))
                self.assertEqual(plan['full_max_duration_s'], duration + 30)
                self.assertEqual(plan['preview_max_duration_s'], min(210, duration))

    def test_explicit_one_does_not_accept_second_reference_or_boolean_count(self):
        self.assert_invalid({'reference_count': 1, 'references': six_references([300, 300])})
        self.assert_invalid({'reference_count': True, 'references': six_references([300])})

    def test_legacy_two_and_six_do_not_inherit_new_tolerance(self):
        for count in (2, 6):
            result = self.run_cli({'references': six_references([300] * count)})
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertNotIn('full_duration_tolerance_s', json.loads(self.output_path.read_text()))

    def test_structure_discovery_references_do_not_change_mean(self):
        result = self.run_cli({
            "references": six_references(),
            "structure_discovery_references": [{"id": "extra", "duration_s": 99999}],
        })
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(self.output_path.read_text())["target_duration_s"], 350)

    def test_invalid_durations(self):
        for duration in (None, True, False, "120", 0, -1, [], {},
                         float("nan"), float("inf"), float("-inf"), 10 ** 400):
            with self.subTest(duration=duration):
                references = six_references()
                references[2]["duration_s"] = duration
                self.assert_invalid({"references": references})
        references = six_references()
        del references[2]["duration_s"]
        self.assert_invalid({"references": references})

    def test_invalid_reference_entry_with_valid_count(self):
        for entry in (None, {}, "ref", []):
            with self.subTest(entry=entry):
                references = six_references()
                references[2] = entry
                self.assert_invalid({"references": references})

    def test_invalid_excluded_array(self):
        for excluded in (None, {}, "ref", True):
            with self.subTest(excluded=excluded):
                self.assert_invalid({"references": six_references(),
                                     "excluded_references": excluded})

    def test_malformed_or_empty_source(self):
        for raw in (b"", b"{", b"not JSON", b"\xff"):
            with self.subTest(raw=raw):
                self.assert_invalid(raw=raw)

    def test_hash_uses_original_bytes(self):
        raw = json.dumps({"references": six_references([220] * 6)}, indent=4).encode() + b"\n"
        result = self.run_cli(raw=raw)
        self.assertEqual(result.returncode, 0, result.stderr)
        plan = json.loads(self.output_path.read_text())
        self.assertEqual(plan["source_input_sha256"], hashlib.sha256(raw).hexdigest())

    def test_missing_source_preserves_output(self):
        self.output_path.write_bytes(b"previous output")
        result = subprocess.run(
            [sys.executable, "-B", str(SCRIPT), str(self.input_path),
             "--out", str(self.output_path)], capture_output=True, text=True,
        )
        self.assertEqual(result.returncode, 1)
        self.assertEqual(self.output_path.read_bytes(), b"previous output")

    def test_failed_replace_preserves_output_and_removes_temporary_file(self):
        self.output_path.write_bytes(b"previous output")
        with patch("plan_duration.os.replace", side_effect=OSError("쓰기 실패")):
            with self.assertRaises(OSError):
                write_plan(self.output_path, {"target_duration_s": 120})
        self.assertEqual(self.output_path.read_bytes(), b"previous output")
        self.assertEqual(list(Path(self.folder.name).iterdir()), [self.output_path])

    def test_serialization_failure_preserves_output(self):
        self.output_path.write_bytes(b"previous output")
        with self.assertRaises(ValueError):
            write_plan(self.output_path, {"duration_s": float("nan")})
        self.assertEqual(self.output_path.read_bytes(), b"previous output")
        self.assertEqual(list(Path(self.folder.name).iterdir()), [self.output_path])

    def test_creates_output_parent(self):
        self.output_path = Path(self.folder.name) / 'new' / 'video' / 'duration_plan.json'
        result = self.run_cli(document={'references': six_references([1200] * 6)})
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(self.output_path.read_text())['preview_duration_s'], 180)


if __name__ == "__main__":
    unittest.main()
