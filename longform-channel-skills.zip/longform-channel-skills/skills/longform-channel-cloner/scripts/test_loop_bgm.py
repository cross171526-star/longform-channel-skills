#!/usr/bin/env python3
"""실제 ffmpeg PCM 반복과 해시·기간·덮어쓰기 거부를 검증한다."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import struct
import subprocess
import sys
import tempfile
import unittest
import wave

sys.path.insert(0, str(Path(__file__).resolve().parent))
import loop_bgm
from common import FFMPEG, probe


class LoopBGMTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.source = self.root / "prepared.wav"
        self.config = self.root / "config.json"
        self.output = self.root / "output.wav"
        self.frames = 6000
        # 매 샘플이 0이 아닌 비주기적 스테레오 패턴으로 속도·위상 변화도 검출한다.
        pcm = b"".join(struct.pack("<hh", 1 + (i * 137 % 30000),
                                  -(1 + (i * 251 % 30000))) for i in range(self.frames))
        subprocess.run([FFMPEG, "-hide_banner", "-loglevel", "error", "-nostdin",
                        "-f", "s16le", "-ar", "48000", "-ac", "2", "-i", "pipe:0",
                        "-c:a", "pcm_s16le", str(self.source)],
                       input=pcm, check=True, capture_output=True)
        self.source_bytes = self.source.read_bytes()
        self.source_hash = hashlib.sha256(self.source_bytes).hexdigest()
        self.write_config()

    def write_config(self, **overrides):
        playback = {"local_path": self.source.name, "sha256": self.source_hash}
        playback.update(overrides)
        self.config.write_text(json.dumps({"playback": playback}), encoding="utf-8")

    def cli(self, duration="0.4375", output=None):
        return subprocess.run([sys.executable, "-B", str(Path(loop_bgm.__file__)),
                               str(self.config), f"--duration={duration}",
                               "--out", str(output or self.output)],
                              capture_output=True, text=True)

    def assert_rejected(self, result, message):
        self.assertEqual(result.returncode, 2, result.stderr)
        self.assertIn(message, result.stderr)
        self.assertEqual(self.source.read_bytes(), self.source_bytes)
        self.assertFalse(self.output.exists())
        self.assertFalse(self.output.with_suffix(".wav.json").exists())

    def test_actual_cli_repeats_exact_pcm_without_silence_or_speed_change(self):
        config_bytes = self.config.read_bytes()
        result = self.cli()
        self.assertEqual(result.returncode, 0, result.stderr)
        with wave.open(str(self.source), "rb") as source:
            original_pcm = source.readframes(source.getnframes())
        with wave.open(str(self.output), "rb") as output:
            self.assertEqual(output.getframerate(), 48000)
            self.assertEqual(output.getsampwidth(), 2)
            self.assertEqual(output.getnchannels(), 2)
            self.assertEqual(output.getnframes(), 21000)
            actual_pcm = output.readframes(output.getnframes())
        self.assertGreater(probe(self.output)["duration_s"], 2 * probe(self.source)["duration_s"])
        expected_pcm = (original_pcm * 4)[:21000 * 4]
        self.assertEqual(actual_pcm, expected_pcm)
        for boundary in (6000, 12000, 18000):
            with self.subTest(boundary=boundary):
                start, end = (boundary - 32) * 4, (boundary + 32) * 4
                self.assertEqual(actual_pcm[start:end], expected_pcm[start:end])
                samples = struct.unpack("<128h", actual_pcm[start:end])
                self.assertTrue(all(sample != 0 for sample in samples))
        metadata = json.loads(self.output.with_suffix(".wav.json").read_text())
        self.assertEqual(metadata, {
            "source_sha256": self.source_hash, "source_path": str(self.source.resolve()),
            "duration_s": 0.4375, "loop": True, "playback_rate": 1.0,
        })
        self.assertEqual(self.source.read_bytes(), self.source_bytes)
        self.assertEqual(self.config.read_bytes(), config_bytes)

    def test_flat_config_and_absolute_source(self):
        self.config.write_text(json.dumps({"local_path": str(self.source),
                                          "sha256": self.source_hash}), encoding="utf-8")
        result = self.cli(duration="0.0625")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(probe(self.output)["duration_s"], 0.0625)

    def test_wrong_hash_rejected(self):
        self.write_config(sha256="0" * 64)
        config_bytes = self.config.read_bytes()
        self.assert_rejected(self.cli(), "SHA-256 mismatch")
        self.assertEqual(self.config.read_bytes(), config_bytes)

    def test_nonfinite_and_nonpositive_duration_rejected(self):
        for duration in ("nan", "inf", "-inf", "1e999", "0", "-1"):
            with self.subTest(duration=duration):
                self.assert_rejected(self.cli(duration=duration), "finite and positive")

    def test_input_and_config_overwrite_rejected_including_aliases(self):
        # WAV 확장자를 가진 설정 파일도 덮어쓰지 않는다.
        wav_config = self.root / "config.wav"
        wav_config.write_bytes(self.config.read_bytes())
        self.config = wav_config
        config_bytes = self.config.read_bytes()
        for protected in (self.source, self.config):
            for alias_type in ("direct", "symlink", "hardlink"):
                with self.subTest(protected=protected.name, alias_type=alias_type):
                    target = protected
                    if alias_type != "direct":
                        target = self.root / f"{protected.stem}-{alias_type}.wav"
                        if alias_type == "symlink":
                            target.symlink_to(protected)
                        else:
                            os.link(protected, target)
                    self.assert_rejected(self.cli(output=target), "must not overwrite input/config")
                    self.assertEqual(self.config.read_bytes(), config_bytes)

    def test_metadata_cannot_overwrite_config_or_input(self):
        sidecar = self.output.with_suffix(".wav.json")
        for protected in (self.source, self.config):
            with self.subTest(protected=protected.name):
                sidecar.symlink_to(protected)
                try:
                    result = self.cli()
                    self.assertEqual(result.returncode, 2, result.stderr)
                    self.assertIn("must not overwrite input/config", result.stderr)
                    self.assertFalse(self.output.exists())
                    self.assertEqual(self.source.read_bytes(), self.source_bytes)
                finally:
                    sidecar.unlink()


if __name__ == "__main__":
    unittest.main()
