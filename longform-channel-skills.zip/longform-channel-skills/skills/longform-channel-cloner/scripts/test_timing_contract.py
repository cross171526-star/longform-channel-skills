"""원본 배경 시간 근거·평균 실행 가능성·구체적 사용자 결정의 회귀 검증."""
import copy
import json
import subprocess
import unittest
from unittest import mock

from compile_timeline import compile_timeline
from timing_contract import reference_background, duration_preflight
import test_check_production as fixtures


class TimingContractTests(unittest.TestCase):
    def setUp(self):
        self.docs = {'visual.json': {'analysis_provenance': {'video_id': 'v1'},
                                     'background_segments': [{'id': 'bg1', 'start_s': 2, 'end_s': 12}],
                                     'cuts': [{'id': 'event1', 'start_s': 2, 'end_s': 2.01}]}}
        self.cut = {'id': 'c1', 'reference_video_id': 'v1', 'reference_cut_id': 'bg1',
                    'duration_s': 10, 'visual_evidence': {'file': 'visual.json', 'pointer': '/background_segments/0'}}
        self.baseline = {'structure_id': 'S1', 'cuts': [self.cut]}
        self.manifest = {'duration_link': {}}

    def load(self, name):
        return self.docs[name]

    def preflight(self, mean=10, planned=10):
        return duration_preflight(self.manifest, self.baseline,
                                  [reference_background(self.cut, self.load)], mean, planned,
                                  'selected6-hash', 'baseline-hash', self.load)

    def decision(self, chosen=10):
        self.manifest['duration_link']['decision'] = {'file': 'decision.json', 'pointer': '/decision'}
        decision = {'authorized_by': 'user', 'instruction': '이 구조의 본편을 10초로 제작한다.',
                    'source': '사용자 대화', 'recorded_at': '2026-10-01',
                    'planned_duration_s': chosen,
                    'scope': {'structure_id': 'S1', 'cut_ids': ['c1'],
                              'selected6_sha256': 'selected6-hash', 'baseline_sha256': 'baseline-hash'}}
        self.docs['decision.json'] = {'decision': decision}
        return decision

    def test_derive_duration_from_start_end_not_other_observation(self):
        self.docs['visual.json']['background_segments'][0]['duration_s'] = 10
        reference = reference_background(self.cut, self.load)
        self.assertEqual(reference['original_duration_s'], 10)
        self.assertEqual((reference['minimum_duration_s'], reference['maximum_duration_s']), (8, 12))

    def test_optional_source_duration_must_match_actual_interval(self):
        for wrong in (5, True, None, float('nan'), float('inf')):
            with self.subTest(wrong=wrong):
                self.docs['visual.json']['background_segments'][0]['duration_s'] = wrong
                with self.assertRaisesRegex(ValueError, 'reference background duration_s differs'):
                    reference_background(self.cut, self.load)

    def test_video_identity_required_even_when_background_id_matches(self):
        for provenance in ({'video_id': 'other'}, {}, None, {'video_id': True}):
            with self.subTest(provenance=provenance):
                self.docs['visual.json']['analysis_provenance'] = provenance
                with self.assertRaisesRegex(ValueError, 'analysis_provenance.video_id'):
                    reference_background(self.cut, self.load)
        self.docs['visual.json'].pop('analysis_provenance')
        self.docs['visual.json']['video_id'] = 'v1'
        with self.assertRaisesRegex(ValueError, 'analysis_provenance.video_id'):
            reference_background(self.cut, self.load)

    def test_false_baseline_five_cannot_redefine_actual_ten(self):
        self.cut['duration_s'] = 5
        with self.assertRaisesRegex(ValueError, 'baseline duration differs'):
            reference_background(self.cut, self.load)

    def test_wrong_reference_id_fails(self):
        self.cut['reference_cut_id'] = 'other'
        with self.assertRaisesRegex(ValueError, 'reference_cut_id differs'):
            reference_background(self.cut, self.load)

    def test_invalid_reference_times(self):
        for start, end in ((-1, 10), (0, 0), (10, 5), (True, 10), (0, True),
                           (None, 10), (0, '10'), (float('nan'), 10),
                           (0, float('inf')), (0, float('-inf'))):
            with self.subTest(start=start, end=end):
                self.docs['visual.json']['background_segments'][0].update(start_s=start, end_s=end)
                with self.assertRaisesRegex(ValueError, 'invalid reference background'):
                    reference_background(self.cut, self.load)

    def test_missing_times_and_observed_only_evidence_rejected(self):
        original = copy.deepcopy(self.docs['visual.json']['background_segments'][0])
        for missing in ('start_s', 'end_s', 'id'):
            changed = dict(original)
            changed.pop(missing)
            self.docs['visual.json']['background_segments'][0] = changed
            with self.assertRaises(ValueError):
                reference_background(self.cut, self.load)
        self.docs['visual.json']['background_segments'][0] = original
        for pointer in ('/cuts/0', '/observed', '/background_segments/0/start_s', '/background_segments/-1'):
            self.cut['visual_evidence']['pointer'] = pointer
            with self.assertRaisesRegex(ValueError, 'background_segments object'):
                reference_background(self.cut, self.load)

    def test_preflight_range_edges_inclusive(self):
        for mean, passed in ((8, True), (12, True), (7.99, False), (12.01, False)):
            with self.subTest(mean=mean):
                result = self.preflight(mean)
                self.assertEqual(result['passed'], passed)
                self.assertEqual((result['original_total_s'], result['minimum_duration_s'],
                                  result['maximum_duration_s']), (10, 8, 12))

    def test_impossible_mean_requires_scoped_user_decision(self):
        result = self.preflight(500)
        self.assertFalse(result['passed'])
        self.assertFalse(result['mean_feasible'])
        self.assertEqual(result['effective_target_duration_s'], 500)
        self.assertIn('scoped user duration decision required', result['errors'][0])
        self.decision()
        result = self.preflight(500)
        self.assertTrue(result['passed'], result)
        self.assertFalse(result['mean_feasible'])
        self.assertEqual(result['effective_target_duration_s'], 10)

    def test_decision_scope_cannot_expand_or_be_stale(self):
        decision = self.decision()
        original = copy.deepcopy(decision['scope'])
        for key, wrong in (('structure_id', 'S2'), ('cut_ids', ['c1', 'c2']),
                           ('selected6_sha256', 'other'), ('baseline_sha256', 'old')):
            with self.subTest(key=key):
                decision['scope'] = dict(original, **{key: wrong})
                self.assertFalse(self.preflight(500)['passed'])
        decision['scope'] = {'structure_id': 'S1'}
        self.assertFalse(self.preflight(500)['passed'])

    def test_decision_must_be_user_with_concrete_instruction_provenance(self):
        for key, wrong in (('authorized_by', 'astra'), ('instruction', ''),
                           ('source', ''), ('recorded_at', None), ('scope', None)):
            with self.subTest(key=key):
                decision = self.decision()
                decision[key] = wrong
                self.assertFalse(self.preflight(500)['passed'])
        self.manifest['duration_link']['decision'] = {'file': 'decision.json', 'pointer': '/missing'}
        self.assertFalse(self.preflight(500)['passed'])

    def test_chosen_length_must_be_feasible_and_match_actual_plan(self):
        for chosen in (7.99, 12.01, None, True, float('nan'), float('inf'), 11):
            with self.subTest(chosen=chosen):
                self.decision(chosen)
                self.assertFalse(self.preflight(500)['passed'])
        for edge in (8, 12):
            self.decision(edge)
            self.assertTrue(self.preflight(500, edge)['passed'])


class TimingGateIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.f = fixtures.ProductionGateTest()
        self.f.setUp()
        self.addCleanup(self.f.doCleanups)

    def doc(self, name):
        return json.loads((self.f.root / name).read_text())

    def test_gate_rejects_false_baseline_even_if_production_matches_five(self):
        f = self.f
        base = self.doc('baseline.json')
        base['cuts'][0]['duration_s'] = 5
        base['narration_windows'] = [base['narration_windows'][0]]
        f.write('baseline.json', base)
        f.m['cuts'][0]['duration_s'] = 5
        f.set_duration(5)
        f.assert_gate_error('baseline duration differs', 'plan')

    def test_gate_rejects_forged_reference_id_and_loose_evidence(self):
        f = self.f
        original = self.doc('baseline.json')
        base = copy.deepcopy(original)
        base['cuts'][0]['reference_cut_id'] = f.m['cuts'][0]['reference_cut_id'] = 'wrong'
        f.write('baseline.json', base)
        f.assert_gate_error('reference_cut_id differs', 'plan')
        f.m['cuts'][0]['reference_cut_id'] = original['cuts'][0]['reference_cut_id']
        original['cuts'][0]['visual_evidence'] = f.m['cuts'][0]['visual_evidence'] = {
            'file': 'evidence.json', 'pointer': '/item'}
        f.write('baseline.json', original)
        f.assert_gate_error('background_segments object', 'plan')

    def test_gate_rejects_wrong_video_with_same_background_id(self):
        f = self.f
        evidence = self.doc('evidence.json')
        evidence['analysis_provenance']['video_id'] = 'different-video'
        f.write('evidence.json', evidence)
        f.assert_gate_error('analysis_provenance.video_id', 'plan')

    def test_scoped_decision_preserves_original_mean_and_tracks_evidence_hash(self):
        f = self.f
        f.set_duration(500)
        f.authorize_duration()
        result = f.run_gate('plan')
        self.assertTrue(result['passed'], result)
        self.assertEqual(result['duration_link']['target_duration_s'], 500)
        self.assertEqual(result['duration_link']['delta_s'], -490)
        self.assertEqual(result['duration_link']['preflight']['effective_target_duration_s'], 10)
        before = result['input_sha256']
        decision = self.doc('duration_decision.json')
        decision['decision']['instruction'] += ' 사용자 확인'
        f.write('duration_decision.json', decision)
        result = f.run_gate('plan')
        self.assertTrue(result['passed'], result)
        self.assertNotEqual(before, result['input_sha256'])

    def test_stale_scope_rejected_after_baseline_or_selection_changes(self):
        f = self.f
        f.set_duration(500)
        f.authorize_duration()
        self.assertTrue(f.run_gate('plan')['passed'])
        base = self.doc('baseline.json')
        base['revision'] = 2
        f.write('baseline.json', base)
        f.assert_gate_error('Duration decision scope differs', 'plan')
        f.authorize_duration()
        f.set_duration(600)
        f.assert_gate_error('Duration decision scope differs', 'plan')

    def test_event_observations_preserved_without_event_interval_tolerance(self):
        f = self.f
        events = [{'id': 'event1', 'parent_background_id': 'r1', 'start_s': 1, 'end_s': 1.01},
                  {'id': 'event2', 'parent_background_id': 'r1', 'start_s': 4, 'end_s': 9}]
        f.m['event_observations'] = events
        self.assertTrue(f.run_gate('plan')['passed'])
        compiled = compile_timeline(f.root / 'reference_map.json')
        self.assertEqual(compiled['event_observations'], events)
        self.assertEqual(len(compiled['cuts']), 1)
        self.assertEqual(compiled['cuts'][0]['duration_s'], 10)

    def test_assets_and_final_require_real_renderer_contract(self):
        f = self.f
        f.reviews()
        f.m.pop('render_timing')
        self.assertTrue(f.run_gate('plan')['passed'])
        for stage in ('assets', 'final'):
            f.assert_gate_error('Missing/unsupported render_timing.kind', stage)

    def test_valid_actual_props_timing_is_reported(self):
        result = self.f.run_gate('assets')
        self.assertTrue(result['passed'], result)
        timing = result['render_timing_check']
        self.assertTrue(timing['passed'])
        self.assertFalse(timing['visual_accuracy_verified'])
        self.assertTrue(timing['props_sha256'])
        self.assertTrue(timing['compiled_sha256'])
        self.assertTrue(timing['template_sha256'])

    def test_props_drift_rejected_even_after_recompiling_input_hash(self):
        f = self.f
        self.assertTrue(f.run_gate('assets')['passed'])
        props = self.doc('props.json')
        props['cuts'][0]['start_s'] = 1
        f.write('props.json', props)
        f.write('compiled.json', compile_timeline(f.root / 'reference_map.json'))
        result = f.run_gate('assets', refresh_compile=False)
        self.assertFalse(result['passed'])
        self.assertTrue(any('actual renderer frames differ' in e for e in result['errors']), result)
        self.assertFalse(any('Stale/different compiled_timeline' in e for e in result['errors']), result)

    def test_node_timeout_is_structured_gate_failure(self):
        with mock.patch('check_render_timing.validate_render_timing',
                        side_effect=subprocess.TimeoutExpired('node', 30)):
            result = self.f.run_gate('assets')
        self.assertFalse(result['passed'])
        self.assertIsNone(result['render_timing_check'])
        self.assertTrue(any('timed out' in e for e in result['errors']), result)


if __name__ == '__main__':
    unittest.main()
