import copy
import json
import tempfile
import unittest
from pathlib import Path
from check_production import check, digest
from compile_timeline import compile_timeline
from plan_duration import plan_duration


class ProductionGateTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.write('evidence.json', {'item': {'observed': True}, 'analysis_provenance': {'video_id': 'v1', 'session_id': 'analysis'}, 'background_segments': [
            {'id': 'r1', 'start_s': 0, 'end_s': 10}]})
        ref = {'file': 'evidence.json', 'pointer': '/item'}
        visual_ref = {'file': 'evidence.json', 'pointer': '/background_segments/0'}
        cut = dict(id='c1', reference_video_id='v1', reference_cut_id='r1', duration_s=10,
                   media_kind='video', source_kind='documentary_footage', visual_evidence=visual_ref,
                   script_evidence=ref)
        self.write('implementation.json', {'session_ids': ['implementation']})
        self.write('baseline.json', dict(structure_id='S1', analysis_session_ids=['analysis'], implementation_session_ids=['implementation'], implementation_provenance='implementation.json',
                   rule_evidence=[ref], cuts=[dict(cut, required_layers=['base'], required_effects=['grain'])]))
        self.m = dict(baseline='baseline.json', structure_id='S1', canvas=[320, 180],
                      render='render.mp4', conformance='conformance.json',
                      render_inputs=['code.js', 'narration.json', 'timeline.json'],
                      tts=dict(provider='typecast', voice_name='진우', voice_id='tc_632293f759d649937b97f323',
                               uniform_speed=1.2, speed_method='provider', playback_rate=1.0,
                               narration_metadata='narration.json', timeline='timeline.json'),
                      cuts=[dict(cut, new_script=ref, layers={'base': {'z': 0}}, effects={'grain': {'opacity': .2}},
                                 assets=[dict(path='asset.mp4', media_kind='video', source_kind='documentary_footage', primary=True)])])
        for name in ('code.js', 'asset.mp4', 'render.mp4'):
            (self.root / name).write_text(name)
        self.narration = dict(provider='typecast', voice=self.m['tts']['voice_id'], fit=False,
                              uniform_speed=1.2, speed_method='provider', lines=[
                                  dict(id='l1', provider_tempo=1.2, atempo=1.0, placed_start_s=0, placed_end_s=3),
                                  dict(id='l2', provider_tempo=1.2, atempo=1.0, placed_start_s=4, placed_end_s=8)])
        self.timeline = dict(segments=[
            dict(line_id='l1', cut_ids=['c1'], allowed_start_s=0, allowed_end_s=4,
                 start_s=0, end_s=3, playback_rate=1.0),
            dict(line_id='l2', cut_ids=['c1'], allowed_start_s=4, allowed_end_s=10,
                 start_s=4, end_s=8, playback_rate=1.0)])
        self.save_narration()
        self.m.update(compiled_timeline='compiled.json', visual_acceptance='visual_acceptance.json',
                      duration_link={'selected6': 'selected6.json', 'input': 'duration_input.json', 'plan': 'duration_plan.json'})
        self.m['render_inputs'] += ['compiled.json', 'visual_acceptance.json']
        self.write('visual_acceptance.json', {'tolerance_status': 'provisional', 'rules': [
            {'id': 'grain', 'cut_ids': ['c1'], 'evidence': ref, 'metrics': [
                {'id': 'opacity', 'target': .2, 'tolerance': .02, 'unit': 'ratio'}]}]})
        baseline = json.loads((self.root / 'baseline.json').read_text())
        baseline.update(required_visual_rule_ids=['grain'], narration_windows=[
            {k: s[k] for k in ('line_id', 'cut_ids', 'allowed_start_s', 'allowed_end_s')}
            for s in self.timeline['segments']])
        self.write('baseline.json', baseline)
        self.set_duration(10)
        from check_render_timing import renderer_dependencies
        self.m['render_timing'] = {'kind': 'remotion-template', 'props': 'props.json'}
        (self.root/'public/media').mkdir(parents=True)
        (self.root/'public/media/asset.mp4').write_bytes((self.root/'asset.mp4').read_bytes())
        self.m['render_inputs'] += ['asset.mp4','public/media/asset.mp4']
        self.m['render_inputs'] += ['props.json'] + [str(p) for p in renderer_dependencies()]
        self.save_render_props()
        self.save()

    def write(self, name, value):
        (self.root / name).write_text(json.dumps(value))

    def save(self):
        self.write('reference_map.json', self.m)

    def save_narration(self):
        self.write('narration.json', self.narration)
        self.write('timeline.json', self.timeline)

    def set_duration(self, duration):
        refs = {'references': [{'id': 'v' + str(i), 'duration_s': duration} for i in range(1, 7)]}
        self.write('selected6.json', refs)
        self.write('duration_input.json', refs)
        self.write('duration_plan.json', plan_duration(refs, digest(self.root / 'duration_input.json')))

    def set_backgrounds(self, durations):
        baseline = json.loads((self.root / 'baseline.json').read_text())
        evidence = json.loads((self.root / 'evidence.json').read_text())
        backgrounds, cursor = [], 0
        for index, (target, actual, duration) in enumerate(zip(baseline['cuts'], self.m['cuts'], durations)):
            ref = {'file': 'evidence.json', 'pointer': '/background_segments/' + str(index)}
            background_id = 'r' + str(index + 1)
            backgrounds.append({'id': background_id, 'start_s': cursor, 'end_s': cursor + duration})
            cursor += duration
            target.update(reference_cut_id=background_id, duration_s=duration, visual_evidence=ref)
            actual.update(reference_cut_id=background_id, visual_evidence=ref)
        evidence['background_segments'] = backgrounds
        self.write('evidence.json', evidence)
        self.write('baseline.json', baseline)

    def authorize_duration(self):
        baseline = json.loads((self.root / 'baseline.json').read_text())
        self.write('duration_decision.json', {'decision': {
            'authorized_by': 'user', 'instruction': '이 구조의 본편을 아래 길이로 제작한다.',
            'source': '테스트 사용자 지시', 'recorded_at': '2026-10-01T00:00:00+09:00',
            'planned_duration_s': sum(c['duration_s'] for c in self.m['cuts']),
            'scope': {'structure_id': baseline['structure_id'], 'cut_ids': [c['id'] for c in baseline['cuts']],
                      'selected6_sha256': digest(self.root / 'selected6.json'),
                      'baseline_sha256': digest(self.root / 'baseline.json')}}})
        self.m['duration_link']['decision'] = {'file': 'duration_decision.json', 'pointer': '/decision'}

    def save_render_props(self):
        (self.root/'public/media/asset.mp4').write_bytes((self.root/'asset.mp4').read_bytes())
        end = self.m.get('output_scope', {}).get('end_s', sum(c['duration_s'] for c in self.m['cuts']))
        cursor, cuts = 0, []
        for cut in self.m['cuts']:
            start, cursor = cursor, cursor + cut['duration_s']
            if start < end:
                cuts.append({'id': cut['id'], 'start_s': start, 'end_s': cursor,
                             'transition_in': {'frames': 0},'asset':{'file':'media/asset.mp4','source_path':str(self.root/'asset.mp4'),'sha256':digest(self.root/'asset.mp4')}})
        self.write('props.json', {'fps': 30, 'width': 320, 'height': 180, 'duration_s': end, 'cuts': cuts})

    def accept_windows(self):
        baseline = json.loads((self.root / 'baseline.json').read_text())
        baseline['narration_windows'] = [{k: s[k] for k in
            ('line_id', 'cut_ids', 'allowed_start_s', 'allowed_end_s')} for s in self.timeline['segments']]
        self.write('baseline.json', baseline)

    def assert_gate_error(self, message, stage='assets'):
        result = self.run_gate(stage)
        self.assertFalse(result['passed'], result)
        self.assertTrue(any(message in e for e in result['errors']), result['errors'])

    @staticmethod
    def probe(path):
        return {'streams': [{'codec_type': 'video', 'width': 320, 'height': 180}, {'codec_type': 'audio'}],
                'format': {'format_name': 'mov,mp4', 'duration': '10'}}

    def run_gate(self, stage='plan', refresh_compile=True):
        self.save()
        if stage in ('assets', 'final') and refresh_compile:
            self.save_render_props()
            try:
                self.write('compiled.json', compile_timeline(self.root / 'reference_map.json'))
            except (OSError, ValueError, KeyError, TypeError, IndexError):
                pass
        return check(self.root / 'reference_map.json', stage, self.probe)

    def reviews(self):
        result = self.run_gate('assets')
        review = dict(status='pass', model='gpt-6.1-sol', reasoning_effort='high', input_sha256=result['input_sha256'],
                      render_sha256=digest(self.root / 'render.mp4'), session_id='independent',
                      report={'file': 'evidence.json', 'pointer': '/item'})
        self.c = dict(visual_review=dict(review, reviewer='sol'), script_review=dict(review, reviewer='sol'),
                      unresolved_items=[], user_authorized_changes=[],
                      visual_measurements=dict(status='pass', input_sha256=result['input_sha256'],
                          render_sha256=review['render_sha256'], visual_acceptance_sha256=result['visual_acceptance_sha256'],
                          rules=[dict(rule_id='grain', status='pass', evidence=review['report'],
                                      metrics=[dict(id='opacity', value=.2)])]))
        self.write('conformance.json', self.c)

    def test_boundaries(self):
        for seconds, expected in [(8, True), (12, True), (7.99, False), (12.01, False), (0, False)]:
            with self.subTest(seconds=seconds):
                self.m['cuts'][0]['duration_s'] = seconds
                self.set_duration(seconds if seconds > 0 else 10)
                baseline = json.loads((self.root / 'baseline.json').read_text())
                baseline['narration_windows'][1]['allowed_end_s'] = min(10, seconds)
                self.write('baseline.json', baseline)
                self.assertEqual(self.run_gate()['passed'], expected)

    def test_plan_needs_no_synthesis(self):
        for key in ('narration_metadata', 'timeline'):
            del self.m['tts'][key]
        self.m['render_inputs'] = [n for n in self.m['render_inputs'] if n not in ('narration.json', 'timeline.json')]
        (self.root / 'narration.json').unlink()
        (self.root / 'timeline.json').unlink()
        self.assertTrue(self.run_gate('plan')['passed'])

    def test_mandatory_manifest_speed_all_stages(self):
        self.reviews()
        original = copy.deepcopy(self.m['tts'])
        for stage in ('plan', 'assets', 'final'):
            for key, wrong in (('uniform_speed', 1.0), ('speed_method', 'atempo'), ('playback_rate', 1.2)):
                for missing in (False, True):
                    with self.subTest(stage=stage, key=key, missing=missing):
                        self.m['tts'] = copy.deepcopy(original)
                        if missing:
                            del self.m['tts'][key]
                        else:
                            self.m['tts'][key] = wrong
                        self.assert_gate_error('tts.' + key, stage)

    def test_mandatory_narration_paths_and_inventory(self):
        self.reviews()
        for stage in ('assets', 'final'):
            for key in ('narration_metadata', 'timeline'):
                with self.subTest(stage=stage, key=key):
                    name = self.m['tts'].pop(key)
                    self.assert_gate_error('Missing tts.' + key, stage)
                    self.m['tts'][key] = name
                    self.m['render_inputs'].remove(name)
                    self.assert_gate_error('missing from render_inputs', stage)
                    self.m['render_inputs'].append(name)

    def test_missing_actual_narration_files(self):
        for name in ('narration.json', 'timeline.json'):
            with self.subTest(name=name):
                content = (self.root / name).read_text()
                (self.root / name).unlink()
                self.assertFalse(self.run_gate('assets')['passed'])
                (self.root / name).write_text(content)

    def test_inventory_uses_resolved_paths(self):
        self.m['render_inputs'] = [str(self.root / n) if n == 'narration.json'
                                  else './' + n if n in ('timeline.json', 'compiled.json') else n
                                  for n in self.m['render_inputs']]
        self.assertTrue(self.run_gate('assets')['passed'])

    def test_metadata_policy_and_identity(self):
        original = copy.deepcopy(self.narration)
        for key, wrong in (('provider', 'other'), ('voice', 'other'), ('fit', True),
                           ('uniform_speed', 1.0), ('speed_method', 'atempo')):
            for missing in (False, True):
                with self.subTest(key=key, missing=missing):
                    self.narration = copy.deepcopy(original)
                    if missing:
                        del self.narration[key]
                    else:
                        self.narration[key] = wrong
                    self.save_narration()
                    self.assert_gate_error('Narration')

    def test_speed_values_are_exact_and_numeric(self):
        for location, key, invalid in (
                ('metadata', 'uniform_speed', 1.205), ('metadata', 'fit', 0),
                ('line', 'provider_tempo', 1.205), ('line', 'atempo', 1.005),
                ('line', 'atempo', True), ('segment', 'playback_rate', True),
                ('segment', 'playback_rate', 1.005), ('line', 'provider_tempo', '1.2'),
                ('metadata', 'uniform_speed', float('nan')), ('line', 'atempo', float('inf'))):
            with self.subTest(location=location, key=key, invalid=invalid):
                n, t = copy.deepcopy(self.narration), copy.deepcopy(self.timeline)
                target = (self.narration if location == 'metadata' else self.narration['lines'][0]
                          if location == 'line' else self.timeline['segments'][0])
                target[key] = invalid
                self.save_narration()
                self.assertFalse(self.run_gate('assets')['passed'])
                self.narration, self.timeline = n, t

    def test_each_line_speed_is_mandatory(self):
        for key in ('provider_tempo', 'atempo'):
            for value in (None, 1.4):
                with self.subTest(key=key, value=value):
                    line = self.narration['lines'][1]
                    old = line.pop(key)
                    if value is not None:
                        line[key] = value
                    self.save_narration()
                    self.assert_gate_error(key)
                    line[key] = old

    def test_duplicate_or_missing_lines(self):
        n, t = copy.deepcopy(self.narration), copy.deepcopy(self.timeline)
        cases = ('duplicate_metadata', 'duplicate_segment', 'missing_segment', 'unknown_segment', 'missing_metadata')
        for case in cases:
            with self.subTest(case=case):
                self.narration, self.timeline = copy.deepcopy(n), copy.deepcopy(t)
                if case == 'duplicate_metadata':
                    self.narration['lines'][1]['id'] = 'l1'
                elif case == 'duplicate_segment':
                    self.timeline['segments'].append(copy.deepcopy(t['segments'][0]))
                elif case == 'missing_segment':
                    self.timeline['segments'].pop()
                elif case == 'unknown_segment':
                    self.timeline['segments'][1]['line_id'] = 'unknown'
                else:
                    self.narration['lines'].pop()
                self.save_narration()
                self.assertFalse(self.run_gate('assets')['passed'])

    def test_invalid_ids(self):
        for record, key in ((self.narration['lines'][0], 'id'), (self.timeline['segments'][0], 'line_id')):
            old = record[key]
            for value in (None, '', ' ', 1, [], {}):
                with self.subTest(key=key, value=value):
                    record[key] = value
                    self.save_narration()
                    self.assert_gate_error('non-empty string')
            record[key] = old

    def test_invalid_placed_and_timeline_intervals(self):
        for record, start_key, end_key in ((self.narration['lines'][0], 'placed_start_s', 'placed_end_s'),
                                          (self.timeline['segments'][0], 'start_s', 'end_s'),
                                          (self.timeline['segments'][0], 'allowed_start_s', 'allowed_end_s')):
            original = copy.deepcopy(record)
            for start, end in ((-1, 3), (0, 0), (4, 3), (float('nan'), 3), (0, float('inf')),
                               (True, 3), (0, '3'), (0, None)):
                with self.subTest(start_key=start_key, start=start, end=end):
                    record[start_key], record[end_key] = start, end
                    self.save_narration()
                    self.assert_gate_error('invalid ' + start_key)
            record.clear()
            record.update(original)

    def test_required_interval_fields(self):
        for record, keys in ((self.narration['lines'][0], ('placed_start_s', 'placed_end_s')),
                              (self.timeline['segments'][0], ('start_s', 'end_s', 'allowed_start_s', 'allowed_end_s',
                                                              'playback_rate', 'cut_ids'))):
            for key in keys:
                with self.subTest(key=key):
                    value = record.pop(key)
                    self.save_narration()
                    self.assertFalse(self.run_gate('assets')['passed'])
                    record[key] = value

    def test_overflow_window_and_cut_bounds(self):
        self.timeline['segments'][1]['allowed_end_s'] = 7
        self.save_narration()
        self.assert_gate_error('placement outside allowed window')
        self.timeline['segments'][1]['allowed_end_s'] = 10.02
        self.save_narration()
        self.assert_gate_error('allowed window outside referenced cuts')
        self.timeline['segments'][1].update(end_s=10.02, allowed_end_s=10)
        self.narration['lines'][1]['placed_end_s'] = 10.02
        self.save_narration()
        self.assert_gate_error('placement outside referenced cuts')

    def test_timing_mismatch_and_tolerance(self):
        for delta, passed in ((.01, True), (.0101, False)):
            with self.subTest(delta=delta):
                self.timeline['segments'][1]['start_s'] = 4 + delta
                self.timeline['segments'][1]['end_s'] = 8 + delta
                self.save_narration()
                self.assertEqual(self.run_gate('assets')['passed'], passed)

    def test_window_tolerance(self):
        for delta, passed in ((.01, True), (.0101, False)):
            with self.subTest(delta=delta):
                self.narration['lines'][1]['placed_end_s'] = 10 + delta
                self.timeline['segments'][1]['end_s'] = 10 + delta
                self.save_narration()
                self.assertEqual(self.run_gate('assets')['passed'], passed)

    def test_tolerances_do_not_compound_for_actual_placement(self):
        self.narration['lines'][1]['placed_end_s'] = 10.018
        self.timeline['segments'][1]['end_s'] = 10.009
        self.save_narration()
        self.assert_gate_error('narration placement outside allowed window')
        self.assert_gate_error('narration placement outside referenced cuts')

    def test_baseline_window_has_no_tolerance_for_redeclaration(self):
        for delta, passed in ((.01, True), (.0101, False)):
            with self.subTest(delta=delta):
                self.timeline['segments'][1]['allowed_end_s'] = 10 + delta
                self.save_narration()
                self.assertFalse(self.run_gate('assets')['passed'])

    def test_invalid_narration_path_values(self):
        for key in ('narration_metadata', 'timeline'):
            old = self.m['tts'][key]
            for value in (None, '', ' ', [], {}):
                with self.subTest(key=key, value=value):
                    self.m['tts'][key] = value
                    self.assert_gate_error('Missing tts.' + key)
            self.m['tts'][key] = old

    def test_invalid_json_documents(self):
        for name in ('narration.json', 'timeline.json'):
            with self.subTest(name=name):
                self.save_narration()
                (self.root / name).write_text('{invalid json')
                self.assert_gate_error('Invalid tts.')

    def test_overlapping_intervals(self):
        self.narration['lines'][1]['placed_start_s'] = 2.9
        self.timeline['segments'][1].update(start_s=2.9, allowed_start_s=0)
        self.save_narration()
        self.assert_gate_error('Narration: overlapping intervals')
        self.assert_gate_error('Timeline: overlapping intervals')

    def test_unknown_empty_or_duplicate_cut_ids(self):
        for cut_ids in (['unknown'], [], ['c1', 'c1'], 'c1', [None]):
            with self.subTest(cut_ids=cut_ids):
                self.timeline['segments'][0]['cut_ids'] = cut_ids
                self.save_narration()
                self.assertFalse(self.run_gate('assets')['passed'])

    def add_cut(self, cut_id):
        baseline = json.loads((self.root / 'baseline.json').read_text())
        evidence = json.loads((self.root / 'evidence.json').read_text())
        backgrounds = evidence['background_segments']
        index = len(backgrounds)
        reference_id = 'r' + str(index + 1)
        start = backgrounds[-1]['end_s']
        backgrounds.append({'id': reference_id, 'start_s': start, 'end_s': start + baseline['cuts'][0]['duration_s']})
        self.write('evidence.json', evidence)
        ref = {'file': 'evidence.json', 'pointer': '/background_segments/' + str(index)}
        baseline['cuts'].append(dict(baseline['cuts'][0], id=cut_id, reference_cut_id=reference_id, visual_evidence=ref))
        self.write('baseline.json', baseline)
        self.m['cuts'].append(dict(self.m['cuts'][0], id=cut_id, reference_cut_id=reference_id, visual_evidence=ref))
        self.set_duration(sum(c['duration_s'] for c in self.m['cuts']))

    def test_cumulative_cut_bounds_and_cross_cut_window(self):
        self.add_cut('c2')
        self.narration['lines'][1].update(placed_start_s=10, placed_end_s=15)
        segment = self.timeline['segments'][1]
        segment.update(cut_ids=['c2'], allowed_start_s=10, allowed_end_s=20, start_s=10, end_s=15)
        self.accept_windows()
        self.save_narration()
        self.assertTrue(self.run_gate('assets')['passed'])
        segment['cut_ids'] = ['c1']
        self.save_narration()
        self.assert_gate_error('allowed window outside referenced cuts')
        segment.update(cut_ids=['c1', 'c2'], allowed_start_s=8, allowed_end_s=20, start_s=9)
        self.narration['lines'][1]['placed_start_s'] = 9
        self.accept_windows()
        self.save_narration()
        self.assertTrue(self.run_gate('assets')['passed'])

    def test_window_cannot_bridge_unreferenced_cut(self):
        self.add_cut('c2')
        self.add_cut('c3')
        self.timeline['segments'][1].update(cut_ids=['c1', 'c3'], allowed_start_s=4, allowed_end_s=25)
        self.save_narration()
        self.assert_gate_error('allowed window outside referenced cuts')

    def test_narration_documents_must_have_records(self):
        for name, data in (('narration.json', {}), ('narration.json', {'lines': []}),
                           ('narration.json', {'lines': [None]}), ('narration.json', []),
                           ('timeline.json', {}), ('timeline.json', {'segments': []}),
                           ('timeline.json', {'segments': [None]}), ('timeline.json', [])):
            with self.subTest(name=name, data=data):
                self.save_narration()
                self.write(name, data)
                self.assertFalse(self.run_gate('assets')['passed'])

    def test_changed_metadata_invalidates_hash_and_review(self):
        self.reviews()
        before = self.run_gate('assets')['input_sha256']
        self.narration['lines'][0]['text'] = '변경된 문장'
        self.save_narration()
        result = self.run_gate('assets')
        self.assertTrue(result['passed'])
        self.assertNotEqual(before, result['input_sha256'])
        self.assert_gate_error('Stale review', 'final')

    def test_changed_timeline_invalidates_hash_and_review(self):
        self.reviews()
        before = self.run_gate('assets')['input_sha256']
        self.timeline['segments'][0]['allowed_end_s'] = 3.5
        self.save_narration()
        result = self.run_gate('assets')
        self.assertFalse(result['passed'])
        self.assertNotEqual(before, result['input_sha256'])
        self.assert_gate_error('Stale review', 'final')

    def test_cut_omission(self):
        self.m['cuts'] = []
        self.assertFalse(self.run_gate()['passed'])

    def test_missing_effect(self):
        self.m['cuts'][0]['effects'] = {}
        self.assertFalse(self.run_gate()['passed'])

    def test_type_mismatch(self):
        self.m['cuts'][0]['assets'][0]['media_kind'] = 'image'
        self.assertFalse(self.run_gate('assets')['passed'])

    def test_valid_final_and_stale_asset(self):
        self.reviews()
        self.assertTrue(self.run_gate('final')['passed'])
        (self.root / 'asset.mp4').write_text('changed')
        self.assertFalse(self.run_gate('final')['passed'])

    def test_stale_render(self):
        self.reviews()
        (self.root / 'render.mp4').write_text('changed render')
        self.assertFalse(self.run_gate('final')['passed'])

    def test_same_session(self):
        self.reviews()
        self.c['visual_review']['session_id'] = 'analysis'
        self.write('conformance.json', self.c)
        self.assertFalse(self.run_gate('final')['passed'])

    def test_missing_evidence(self):
        (self.root / 'evidence.json').unlink()
        with self.assertRaises(ValueError):
            self.run_gate()

    def test_reordered_cuts(self):
        b = json.loads((self.root / 'baseline.json').read_text())
        b['cuts'].append(dict(b['cuts'][0], id='c2'))
        self.write('baseline.json', b)
        self.m['cuts'].append(dict(self.m['cuts'][0], id='c2'))
        self.m['cuts'].reverse()
        self.assertFalse(self.run_gate()['passed'])

    def setup_override(self):
        b = json.loads((self.root / 'baseline.json').read_text())
        self.override = dict(cut_id='c1', reviewer='codex',
                             authorization={'file': 'authorization.json', 'pointer': '/instruction'})
        self.write('authorization.json', {'instruction': {'text': 'c1 visual review by Codex', 'scope': ['c1']}})
        b['visual_review_overrides'] = [self.override]
        self.write('baseline.json', b)
        self.reviews()
        part = dict(self.c['visual_review'], reviewer='codex', cut_ids=['c1'])
        self.c['visual_review'] = {k: part[k] for k in ('status', 'input_sha256', 'render_sha256')}
        self.c['visual_review']['parts'] = [part]
        self.c['user_authorized_changes'] = [self.override]
        self.write('conformance.json', self.c)

    def test_authorized_reviewer_override(self):
        self.setup_override()
        self.assertTrue(self.run_gate('final')['passed'])

    def test_override_cannot_expand_scope(self):
        self.setup_override()
        self.c['visual_review']['parts'][0]['cut_ids'].append('c2')
        self.write('conformance.json', self.c)
        self.assertFalse(self.run_gate('final')['passed'])

    def test_override_needs_authorization_record(self):
        self.setup_override()
        self.c['user_authorized_changes'] = []
        self.write('conformance.json', self.c)
        self.assertFalse(self.run_gate('final')['passed'])

    def test_changed_authorization_invalidates_review(self):
        self.setup_override()
        self.write('authorization.json', {'instruction': {'text': 'changed', 'scope': ['c1']}})
        self.assertFalse(self.run_gate('final')['passed'])

    def test_unauthorized_reviewer_rejected(self):
        self.reviews()
        self.c['visual_review']['reviewer'] = 'codex'
        self.write('conformance.json', self.c)
        self.assertFalse(self.run_gate('final')['passed'])

    def test_gemini_review_rejected(self):
        self.reviews()
        self.c['visual_review']['reviewer'] = 'gemini'
        self.write('conformance.json', self.c)
        self.assertFalse(self.run_gate('final')['passed'])

    def test_gemini_override_rejected(self):
        self.setup_override()
        b = json.loads((self.root / 'baseline.json').read_text())
        b['visual_review_overrides'][0]['reviewer'] = 'gemini'
        self.write('baseline.json', b)
        self.assertFalse(self.run_gate('plan')['passed'])


if __name__ == '__main__':
    unittest.main()
