"""환경·단계 인계·수정 영향 범위의 결정적 검사. 의미 판단/완료 승인은 모델이 수행한다."""
import argparse
import importlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
from work_guard import FileSnapshot, digest, hashes
from plan_duration import write_plan

REQUIRED={
 'analysis':{'source','visual_analysis','script_analysis','speech_rate','evidence','selected_references','style'},
 'planning':{'full_script','baseline','reference_map','asset_requirements','renderer_readiness'},
 'production':{'baseline','reference_map','render','render_inputs','numeric_validation'},
 'review':{'conformance','visual_review','script_review','final_validation','render','baseline','reference_map','render_inputs'},
}


def check_handoff(packet_path, _ancestors=()):
    packet_path=Path(packet_path).resolve();snap=FileSnapshot();doc=snap.document(packet_path)
    if str(packet_path) in _ancestors:raise ValueError('Cyclic handoff chain')
    errors=[];checked={};roles=set();refs={}
    def require(ok,message):
        if not ok:errors.append(message)
    require(doc.get('schema')=='lfc-stage-handoff-v1','Unsupported handoff schema')
    if doc.get('revision_graph'):
        from revision_graph import validate as graph_validate
        graph=doc['revision_graph'];graph_path=(packet_path.parent/graph['path']).resolve()
        require(digest(graph_path)==graph['sha256'],'Changed central revision graph')
        require(graph_validate(graph_path)['passed'],'Revision graph preflight failed')
    stage=doc.get('stage');require(stage in REQUIRED,'Unknown source stage')
    require(doc.get('model')=='gpt-6.1-sol' and doc.get('reasoning_effort')=='high','Missing actual Sol High provenance')
    require(bool(doc.get('session_id')),'Missing actual source session')
    if doc.get('contract_version',1)>=2:
        from scheduler import provenance
        actual=provenance(doc['source_rollout'])
        require(actual['session']==doc.get('session_id'),'Actual source rollout differs from handoff session')
    require(isinstance(doc.get('user_instructions'),list),'Missing scoped user instructions/provenance')
    require(isinstance(doc.get('unresolved_items'),list),'Missing explicit unresolved_items')
    require(isinstance(doc.get('completed_scope'),list) and bool(doc['completed_scope']),'Missing actual completed scope')
    basis=doc.get('basis_sha256',{})
    require(isinstance(basis,dict) and bool(basis),'Missing frozen criteria hashes')
    for name,expected in basis.items():
        canonical,actual=snap.add(packet_path.parent/name)
        checked[canonical]=actual;require(actual==expected,'Changed basis: '+name)
    rows=doc.get('files',[]);require(isinstance(rows,list) and bool(rows),'No handoff artifacts')
    for row in rows:
        role=row.get('role');roles.add(role)
        require(role not in ('cache','log','telemetry'),'Disposable files must not be handoff inputs')
        canonical,actual=snap.add(packet_path.parent/row['path'])
        require(actual==row.get('sha256'),'Changed artifact: '+row['path']);checked[canonical]=actual
        if row.get('video_id'):refs.setdefault(row['video_id'],set()).add(role)
        if role.endswith('validation'):
            report=snap.document(canonical)
            require(report.get('passed') is True,'Unpassed artifact validation: '+canonical)
            linked=report.get('output_sha256',{})
            require(isinstance(linked,dict) and bool(linked),'Validation not bound to output hashes: '+canonical)
            for depmap in (linked,report.get('dependencies_sha256',{})):
                for name,wanted in depmap.items():
                    target,actual=snap.add(Path(canonical).parent/name)
                    checked[target]=actual;require(actual==wanted,'Validation artifact changed: '+name)
    require(REQUIRED.get(stage,set())<=roles,'Required handoff artifacts missing: '+','.join(sorted(REQUIRED.get(stage,set())-roles)))
    if stage in ('planning','production','review'):
        previous=doc.get('previous_handoff',{})
        require(bool(previous.get('path')) and bool(previous.get('sha256')),'Missing previous handoff binding')
        if previous.get('path') and previous.get('sha256'):
            prev_path,prev_hash=snap.add(packet_path.parent/previous['path'])
            checked[prev_path]=prev_hash
            require(prev_hash==previous['sha256'],'Changed previous handoff')
            prev=snap.document(prev_path)
            require(prev.get('stage')=={'planning':'analysis','production':'planning','review':'production'}[stage],'Wrong predecessor stage')
            if prev.get('stage')=={'planning':'analysis','production':'planning','review':'production'}[stage]:
                prev_report=check_handoff(prev_path,(*_ancestors,str(packet_path)))
                require(prev_report['passed'],'Previous handoff did not pass')
                for name,wanted in prev_report['dependencies_sha256'].items():
                    target,actual=snap.add(name);checked[target]=actual
                    require(actual==wanted,'Previous handoff dependency changed: '+name)
            require(doc.get('reference_ids')==prev.get('reference_ids'),'Reference selection changed between stages')
            old_rows={(r.get('role'),r.get('video_id')):r for r in prev.get('files',[])}
            for row in rows:
                old=old_rows.get((row.get('role'),row.get('video_id')))
                if old and old['sha256']!=row['sha256']:
                    require(any(c.get('role')==row['role'] and c.get('previous_sha256')==old['sha256'] and
                                c.get('sha256')==row['sha256'] and bool(c.get('reason')) and bool(c.get('affected_scope'))
                                for c in doc.get('artifact_changes',[])), 'Artifact changed without scoped handoff revision: '+row['role'])
            if stage=='review':
                require(doc.get('input_sha256')==prev.get('input_sha256'),'Review input differs from production handoff')
    if stage in ('production','review'):
        require(bool(doc.get('input_sha256')),'Missing actual production input fingerprint')
        validation_role='numeric_validation' if stage=='production' else 'final_validation'
        validations=[r for r in rows if r.get('role')==validation_role]
        require(len(validations)==1,'Expected one '+validation_role)
        if len(validations)==1:
            validation_path=(packet_path.parent/validations[0]['path']).resolve()
            validation=snap.document(validation_path)
            require(validation.get('input_sha256')==doc.get('input_sha256'),'Validation input fingerprint differs from handoff')
            output={str((validation_path.parent/p).resolve()):h for p,h in validation.get('output_sha256',{}).items()}
            linked={**{str((validation_path.parent/p).resolve()):h for p,h in validation.get('dependencies_sha256',{}).items()},**output}
            output_roles={'render'} if stage=='production' else {'render','conformance','visual_review','script_review'}
            for row in rows:
                if row.get('role') in output_roles | {'baseline','reference_map','render_inputs'}:
                    mapping=output if row['role'] in output_roles else linked
                    require(mapping.get(str((packet_path.parent/row['path']).resolve()))==row['sha256'],
                            'Validation not bound to '+row['role'])
    if stage=='analysis':
        ids=doc.get('reference_ids')
        require(isinstance(ids,list) and len(ids)==1 and isinstance(ids[0],str) and bool(ids[0].strip()),'Analysis needs exactly one reference ID')
        for vid in ids or []:
            require({'source','visual_analysis','script_analysis','speech_rate','evidence','analysis_validation'}<=refs.get(vid,set()),'Incomplete video handoff: '+vid)
        def one(role,video_id=None):
            matches=[r for r in rows if r.get('role')==role and (video_id is None or r.get('video_id')==video_id)]
            require(len(matches)==1,'Expected one '+role+' artifact for '+str(video_id))
            return matches[0] if len(matches)==1 else None
        selected_row=one('selected_references')
        if selected_row:
            selected=snap.document(packet_path.parent/selected_row['path'])
            require(type(selected.get('reference_count')) is int and selected['reference_count']==1 and selected.get('selection_complete') is True,'Selection must be verified latest one')
            chosen=selected.get('references',[])
            require(isinstance(chosen,list) and len(chosen)==1 and {r.get('id') for r in chosen}==set(ids or []),'Selected references differ from handoff IDs')
        for vid in ids or []:
            entries={role:one(role,vid) for role in ('source','visual_analysis','script_analysis','speech_rate','analysis_validation')}
            if any(v is None for v in entries.values()):continue
            paths={role:(packet_path.parent/r['path']).resolve() for role,r in entries.items()}
            visual=snap.document(paths['visual_analysis']);script=snap.document(paths['script_analysis']);report=snap.document(paths['analysis_validation'])
            provenance=visual.get('analysis_provenance',{})
            require(provenance.get('video_id')==vid and script.get('video_id')==vid,'Analysis identity differs: '+vid)
            source_hash=snap.add(paths['source'])[1]
            require(provenance.get('source_sha256')==source_hash and report.get('source_sha256')==source_hash,'Analysis source binding differs: '+vid)
            reuse=entries['visual_analysis'].get('reuse') is True
            if not reuse:
                require(provenance.get('model')=='gpt-6.1-sol' and provenance.get('reasoning_effort')=='high' and bool(provenance.get('session_id')),'Fresh analysis model/session differs: '+vid)
            else:
                require(bool(entries['visual_analysis'].get('reuse_scope')) and bool(entries['visual_analysis'].get('original_basis_sha256')),'Reuse requires original scope/criteria: '+vid)
                for name,wanted in entries['visual_analysis'].get('original_basis_sha256',{}).items():
                    target,actual=snap.add(packet_path.parent/name);checked[target]=actual
                    require(actual==wanted,'Reused analysis criteria changed: '+vid)
            expected={str(paths[role]):snap.add(paths[role])[1] for role in ('visual_analysis','script_analysis','speech_rate')}
            require(report.get('output_sha256')==expected,'Analysis validation is not bound to this video bundle: '+vid)
            require(visual.get('full_video_analyzed') is True and visual.get('coverage',{}).get('missing_ranges')==[],'Original observation is incomplete: '+vid)
            if selected_row:
                matching=[r for r in chosen if r.get('id')==vid]
                require(len(matching)==1 and matching[0].get('duration_s')==visual.get('coverage',{}).get('duration_s'),'Selected duration differs from observed source: '+vid)
        states=doc.get('states',{})
        require(states.get('observed') is True,'Observation incomplete')
        # production_ready/render_verified are independent state declarations, never inferred from observation.
        require(all(type(states.get(k)) is bool for k in ('observed','production_ready','render_verified')),'Missing independent completion states')
    if stage=='planning':
        import os
        from quality_contract import topic_required,validate_topic
        run=os.environ.get('LFC_RUN_DIR')
        if (not _ancestors and run and topic_required(run)) or doc.get('topic_materials'):
            links=doc.get('topic_materials',{})
            require(bool(links.get('request')) and bool(links.get('assessment')),'Planning requires inspected essential topic materials')
            if links.get('request') and links.get('assessment'):
                for name in ('request','assessment'):
                    p,h=snap.add(packet_path.parent/links[name]['path']);checked[p]=h
                    require(h==links[name]['sha256'],'Changed topic '+name)
                independent=not _ancestors and bool(run) and json.loads((Path(run)/'run.json').read_text()).get('topic_materials_version',0)>=2
                review=links.get('independent_review')
                if review:
                    p,h=snap.add(packet_path.parent/review['path']);checked[p]=h
                    require(h==review['sha256'],'Changed independent topic review')
                topic=validate_topic(packet_path.parent/links['assessment']['path'],packet_path.parent/links['request']['path'],
                                     packet_path.parent/review['path'] if review else None,require_independent=independent)
                require(topic['passed'],'Essential topic materials not ready: '+'; '.join(topic['errors']))
                checked.update(topic['dependencies_sha256'])
    if stage=='production':
        require(bool(doc.get('implementation_session_ids')),'Missing implementation session provenance')
    if stage=='review' and not _ancestors:
        import os
        from scheduler import modern_run
        modern=bool(os.environ.get('LFC_RUN_DIR')) and modern_run(os.environ['LFC_RUN_DIR'])
        if modern or doc.get('contract_version',1)>=2:
            from production_preflight import final_capabilities
            links=doc.get('capability_evidence',{})
            require(bool(links.get('preflight')) and bool(links.get('resolution')),'Final review requires current capability evidence binding')
            renders=[r for r in rows if r.get('role')=='render']
            if links.get('preflight') and links.get('resolution') and len(renders)==1:
                for key in ('preflight','resolution'):
                    target,h=snap.add(packet_path.parent/links[key]['path']);checked[target]=h
                    require(h==links[key]['sha256'],'Changed '+key+' capability evidence')
                cap=final_capabilities(packet_path.parent/links['preflight']['path'],packet_path.parent/links['resolution']['path'],packet_path.parent/renders[0]['path'],doc.get('input_sha256'),doc.get('session_id'))
                require(cap['passed'],'Required actual listening/playback incomplete: '+'; '.join(cap['errors']))
                checked.update(cap['dependencies_sha256'])

        run=os.environ.get('LFC_RUN_DIR')
        front=bool(run) and json.loads((Path(run)/'run.json').read_text()).get('front_review_version',0)>=1
        if front or doc.get('review_evidence'):
            links=doc.get('review_evidence',{});require(bool(links.get('record')),'Current scoped review evidence record required')
            if links.get('record') and len([r for r in rows if r.get('role')=='render'])==1:
                from review_evidence import validate_current
                link=links['record'];record_path,h=snap.add(packet_path.parent/link['path']);checked[record_path]=h
                require(h==link['sha256'],'Changed review evidence record')
                rendered=next(r for r in rows if r.get('role')=='render')
                review=validate_current(record_path,packet_path.parent/rendered['path'])
                require(review['reviewer_session']==doc.get('session_id'),'Final reviewer differs from current integration judgment')
                checked.update(review['dependencies_sha256'])

    snap.unchanged()
    return {'passed':not errors,'errors':errors,'stage':stage,'dependencies_sha256':checked,
            'output_sha256':hashes([packet_path],snap),'unresolved_items':doc.get('unresolved_items',[]),
            'content_accuracy_verified':False,'handoff_is_final_approval':False}


def review_draft(packet_path,preflight_path):
    """실제 출력의 검토본 전달. 완료승인과 분리해 미검증 상태를 유지한다."""
    packet_path,preflight_path=map(lambda p:Path(p).resolve(),(packet_path,preflight_path))
    doc=json.loads(packet_path.read_text());report=check_handoff(packet_path)
    if doc.get('stage')!='production' or not report['passed']:
        raise ValueError('Review draft needs valid current production handoff: '+'; '.join(report['errors']))
    initial=json.loads(preflight_path.read_text())
    if initial.get('passed') is not True:raise ValueError('Production preflight failed; preserve failure before review draft')
    for name,wanted in initial.get('dependencies_sha256',{}).items():
        if digest(name)!=wanted:raise ValueError('Review draft preflight dependency changed: '+name)
    from production_preflight import capability_state
    state=capability_state(initial)
    renders=[r for r in doc['files'] if r.get('role')=='render']
    if len(renders)!=1:raise ValueError('One actual review-draft render required')
    render=(packet_path.parent/renders[0]['path']).resolve()
    if digest(render)!=renders[0]['sha256']:raise ValueError('Review draft render changed')
    from production_preflight import inspect_file
    if inspect_file(render)['kind']!='media':raise ValueError('Review draft must bind actual decodable media')
    return {'schema':'lfc-review-draft-v1','passed':True,'delivery_kind':'review_draft',
            'completion_passed':False,'content_completion_eligible':False,'handoff_is_final_approval':False,
            'render':{'path':str(render),'sha256':digest(render)},'input_sha256':doc['input_sha256'],
            'production_handoff':{'path':str(packet_path),'sha256':digest(packet_path)},
            'preflight':{'path':str(preflight_path),'sha256':digest(preflight_path)},
            'capability_state':state,'unresolved_items':list(dict.fromkeys([*doc['unresolved_items'],*state['unverified_final_requirements'],'independent_final_content_review'])),
            'next_action':state['next_action'],
            'dependencies_sha256':{**report['dependencies_sha256'],str(preflight_path):digest(preflight_path)},
            'output_sha256':{str(render):digest(render)}}


def impact(manifest, components=(), cuts=(), global_change=False):
    rows=manifest.get('cuts',[])
    if not rows or len({r['id'] for r in rows})!=len(rows):raise ValueError('Unique manifest cuts required')
    known={r['id'] for r in rows}
    if not set(cuts)<=known:raise ValueError('Unknown requested cut')
    def labels(cut):
        result=set()
        def walk(value):
            if isinstance(value,dict):
                if value.get('kind') in ('group','image','video','rect','path','text','texture_sequence'):
                    result.add('scene:'+value['kind'])
                if isinstance(value.get('component_id'),str):result.add(value['component_id'])
                for key,val in value.items():
                    if key=='font_file' and isinstance(val,str):result.add('font:'+val)
                    if key=='effects' and isinstance(val,list):result.update('effect:'+x for x in val if isinstance(x,str))
                    walk(val)
            elif isinstance(value,list):
                for v in value:walk(v)
        walk(cut);return result
    used={r['id']:labels(r) for r in rows}
    for component in components:
        if not any(component in v for v in used.values()):raise ValueError('Unmapped component; use global scope if impact is not narrower: '+component)
    affected=known if global_change else set(cuts)|{k for k,v in used.items() if set(components)&v}
    if not affected:raise ValueError('Specify component/cut/global change; empty impact is not proof of no effect')
    with_edges=set(affected)
    for i,r in enumerate(rows):
        if r['id'] in affected:
            with_edges.update(rows[j]['id'] for j in (i-1,i+1) if 0<=j<len(rows))
    return {'affected_cut_ids':[r['id'] for r in rows if r['id'] in affected],
            'review_cut_ids_with_neighbors':[r['id'] for r in rows if r['id'] in with_edges],
            'global_change':global_change,'visual_review_passed':False,
            'note':'기계적으로 연결된 사용처와 인접 컷. 실제 의존성/전역 규칙을 추가 대조해야 한다.'}


def doctor():
    checks={};checks['managed_python']=sys.version_info>=(3,12) and Path(sys.executable).resolve()==(Path.home()/'.longform-cloner/venv/bin/python').resolve()
    versions={'python':sys.version.split()[0]}
    for name in ('PIL','numpy','soundfile','requests','jsonschema'):
        try:importlib.import_module(name);checks[name]=True
        except ImportError:checks[name]=False
    for name,args in [('node',['--version']),('npm',['--version']),('ffmpeg',['-version']),('ffprobe',['-version'])]:
        binary=shutil.which(name) or str(Path.home()/'.longform-cloner/bin'/name)
        try:
            r=subprocess.run([binary,*args],capture_output=True,text=True,timeout=20)
            checks[name]=r.returncode==0;versions[name]=(r.stdout or r.stderr).splitlines()[0] if r.stdout or r.stderr else 'unknown'
        except (OSError,subprocess.SubprocessError):checks[name]=False
    return {'passed':all(checks.values()),'checks':checks,'versions':versions,'external_service_access_tested':False}


def main():
    p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='command',required=True)
    q=sub.add_parser('topic');q.add_argument('materials',type=Path);q.add_argument('--request',required=True,type=Path);q.add_argument('--review',type=Path);q.add_argument('--out',required=True,type=Path)
    q=sub.add_parser('review-draft');q.add_argument('packet',type=Path);q.add_argument('--preflight',required=True,type=Path);q.add_argument('--out',required=True,type=Path)
    q=sub.add_parser('review-plan');q.add_argument('--contract',required=True,type=Path);q.add_argument('--pilot-review',required=True,type=Path);q.add_argument('--graph',required=True,type=Path);q.add_argument('--scope',default='preview');q.add_argument('--previous',type=Path);q.add_argument('--out',required=True,type=Path)
    q=sub.add_parser('review-record');q.add_argument('--plan',required=True,type=Path);q.add_argument('--render',required=True,type=Path);q.add_argument('--judgment',required=True,type=Path);q.add_argument('--out',required=True,type=Path)
    q=sub.add_parser('quality');q.add_argument('contract',type=Path);q.add_argument('--review',type=Path);q.add_argument('--out',required=True,type=Path)
    q=sub.add_parser('preflight');q.add_argument('spec',type=Path);q.add_argument('--out',required=True,type=Path)
    q=sub.add_parser('revision');q.add_argument('spec',type=Path);q.add_argument('--out-dir',required=True,type=Path)
    q=sub.add_parser('graph');q.add_argument('graph',type=Path);q.add_argument('--out',required=True,type=Path)
    q=sub.add_parser('reuse');q.add_argument('previous',type=Path);q.add_argument('current',type=Path);q.add_argument('--record',required=True,type=Path);q.add_argument('--out',required=True,type=Path)
    q=sub.add_parser('render-record');q.add_argument('graph',type=Path);q.add_argument('--scope',required=True);q.add_argument('--render',required=True,type=Path);q.add_argument('--out',required=True,type=Path)
    q=sub.add_parser('graph-handoff');q.add_argument('graph',type=Path);q.add_argument('--template',required=True,type=Path);q.add_argument('--out',required=True,type=Path)
    d=sub.add_parser('doctor');d.add_argument('--out',required=True,type=Path)
    h=sub.add_parser('handoff');h.add_argument('packet',type=Path);h.add_argument('--out',required=True,type=Path)
    i=sub.add_parser('impact');i.add_argument('manifest',type=Path);i.add_argument('--component',action='append',default=[]);i.add_argument('--cut',action='append',default=[]);i.add_argument('--global-change',action='store_true');i.add_argument('--out',required=True,type=Path)
    a=p.parse_args()
    try:
        if a.command=='topic':
            from quality_contract import validate_topic
            import os
            root=os.environ.get('LFC_RUN_DIR')
            independent=bool(root) and json.loads((Path(root)/'run.json').read_text()).get('topic_materials_version',0)>=2
            result=validate_topic(a.materials,a.request,a.review,require_independent=independent)
        elif a.command=='review-draft':result=review_draft(a.packet,a.preflight)
        elif a.command=='review-plan':
            from review_evidence import plan
            result=plan(a.contract,a.pilot_review,a.graph,a.scope,a.previous)
        elif a.command=='review-record':
            from review_evidence import record
            result=record(a.plan,a.render,a.judgment,a.out);print(json.dumps({'passed':True,'out':str(a.out)}));return 0
        elif a.command=='quality':
            from quality_contract import validate
            import os
            run=os.environ.get('LFC_RUN_DIR');front=bool(run) and json.loads((Path(run)/'run.json').read_text()).get('front_review_version',0)>=1
            result=validate(a.contract,a.review,require_front=front)
        elif a.command=='preflight':
            from production_preflight import run
            result=run(a.spec)
        elif a.command=='revision':
            from revision_graph import generate
            result=generate(a.spec,a.out_dir);print(json.dumps(result,ensure_ascii=False));return 0
        elif a.command=='graph':
            from revision_graph import validate
            result=validate(a.graph)
        elif a.command=='reuse':
            from revision_graph import reuse
            result=reuse(a.previous,a.current,a.record)
        elif a.command=='render-record':
            from revision_graph import render_record
            result=render_record(a.graph,a.scope,a.render,a.out);print(json.dumps(result,ensure_ascii=False));return 0
        elif a.command=='graph-handoff':
            from revision_graph import handoff
            result=handoff(a.graph,a.template,a.out);print(json.dumps(result,ensure_ascii=False));return 0
        elif a.command=='doctor':result=doctor()
        elif a.command=='handoff':result=check_handoff(a.packet)
        else:result=impact(json.loads(a.manifest.read_text()),a.component,a.cut,a.global_change)
        write_plan(a.out,result);print(json.dumps({'passed':result.get('passed'),'out':str(a.out)},ensure_ascii=False))
        return 1 if result.get('passed') is False else 0
    except (OSError,ValueError,KeyError,TypeError,AttributeError,subprocess.SubprocessError) as e:
        print(json.dumps({'passed':False,'error':str(e)},ensure_ascii=False));return 1


if __name__=='__main__':sys.exit(main())
