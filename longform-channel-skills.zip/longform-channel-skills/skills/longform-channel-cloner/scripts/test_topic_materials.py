import copy,json,os,subprocess,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from PIL import Image
from quality_contract import validate_topic,guard_tool
from work_guard import digest,execute
from workflow import check_handoff

class TopicMaterials(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.p=Path(self.tmp.name).resolve();self.run=self.p/'run';(self.run/'work').mkdir(parents=True)
  self.env=patch.dict(os.environ,{'LFC_RUNTIME_HOME':str(self.p/'isolated'),'LFC_RUN_DIR':str(self.run)});self.env.start();self.addCleanup(self.env.stop)
  (self.run/'run.json').write_text('{"scheduler_version":3,"topic_materials_version":1}')
  self.req=self.write('work/topic-request.json',{'schema':'lfc-topic-request-v1','user_fixed_topic':False,'topic':'','user_instruction':'choose supported topic','instruction_source':'fixture explicit request'})
  self.log=self.p/'actual.jsonl';self.log.write_text(json.dumps({'type':'session_meta','payload':{'id':'researcher'}})+'\n'+json.dumps({'type':'turn_context','payload':{'model':'gpt-6.1-sol','effort':'high'}})+'\n')
  self.source=self.run/'work/article.html';self.source.write_text('<html><body><article>Actual substantive article content for structural test.</article></body></html>')
  self.observed=self.run/'work/observation.md';self.observed.write_text('Technical fixture judgment: inspected content/legibility, not actual topic approval.')
  self.usage=self.run/'work/usage.md';self.usage.write_text('Technical fixture usage basis; not legal authorization.')
  self.value={'schema':'lfc-topic-materials-v1','topic':'supported candidate','request_sha256':digest(self.req),'reviewer_rollout':str(self.log),'session_id':'researcher','core_claims':[{'id':'C','text':'core claim'}],'essential_scenes':[{'id':'S','description':'essential explanation','claim_ids':['C'],'role':'explanation','material_kind':'document','sources':[{'access_status':'inspected','source_type':'source_content','origin':'fixture article origin','role':'factual_source','file':self.bind(self.source),'inspection':{'content_matches':True,'content_note':'actual content inspected','usable_quality':True,'quality_note':'readable document','evidence':[self.bind(self.observed)]},'usage':{'status':'confirmed','basis':[self.bind(self.usage)]}}]}],'story_supported':True,'supported_scope':'scope supported by actual representative article'}
  self.doc=self.write('work/topic-materials.json',self.value)
 def write(self,name,obj):
  p=self.run/name;p.write_text(json.dumps(obj));return p
 def bind(self,p):return {'path':str(p),'sha256':digest(p)}
 def assess(self,value=None):
  if value is not None:self.doc.write_text(json.dumps(value))
  return validate_topic(self.doc,self.req)
 def claim(self,stage):return execute(self.run,'claim',stage,[self.req],resource='topic:'+stage,stage=stage,worker_rollout=self.log)
 def test_actual_article_valid_and_no_truth_or_rights_auto_certification(self):
  r=self.assess();self.assertTrue(r['passed'],r['errors']);self.assertEqual(r['checked_samples'][0]['kind'],'document');self.assertFalse(r['content_truth_or_rights_automatically_verified']);self.assertFalse(r['all_cuts_precollected'])
 def test_prepare_official_cli_available_but_full_script_blocked(self):
  self.doc.unlink();script=Path(__file__).with_name('run.sh')
  from runtime import initialize
  initialized=initialize(script.parent.parent,self.p/'project','candidate-fixture');actual=Path(initialized['run_dir'])
  result=subprocess.run(['bash',str(script),'work_guard','claim','--run-dir',str(actual),'--task','candidate-research','--resource','topic:research','--stage','prepare','--pool','model','--inputs',str(self.req),'--worker-rollout',str(self.log)],capture_output=True,text=True,env={**os.environ,'LFC_RUN_DIR':str(actual)})
  self.assertEqual(result.returncode,0,result.stdout+result.stderr);self.assertEqual(json.loads(result.stdout)['decision'],'run')
  with self.assertRaisesRegex(ValueError,'prepare/research'):self.claim('planning')
  self.write('work/topic-materials.json',self.value);self.assertEqual(self.claim('planning')['decision'],'run')
 def test_planning_freezes_all_material_and_judgment_dependencies(self):
  job=self.claim('planning');self.assertEqual(execute(self.run,'check',lease=job['lease'])['decision'],'run');self.observed.write_text('changed actual judgment')
  with self.assertRaises(ValueError):execute(self.run,'check',lease=job['lease'])
  self.assertFalse(self.assess()['passed'])
 def test_access_failed_not_found_insufficient_are_distinct_not_absence(self):
  for state in ('access_failed','not_found','insufficient'):
   v=copy.deepcopy(self.value);v['essential_scenes'][0]['sources']=[{'access_status':state,'reason':'explicit unsuccessful attempt'}];r=self.assess(v);self.assertFalse(r['passed']);self.assertEqual(r['access_attempts'][0]['access_status'],state);self.assertTrue(r['not_found_is_not_proof_of_absence'])
  v=copy.deepcopy(self.value);v['essential_scenes'][0]['sources'].insert(0,{'access_status':'access_failed','reason':'alternate site inaccessible'});self.assertTrue(self.assess(v)['passed'])
 def test_search_link_and_false_sample_no_physical_content_block(self):
  for mutation in ({'source_type':'search_result'},{'file':{'path':str(self.run/'missing.jpg'),'sha256':'unknown'}}):
   v=copy.deepcopy(self.value);v['essential_scenes'][0]['sources'][0].update(mutation);self.assertFalse(self.assess(v)['passed'])
  v=copy.deepcopy(self.value);fake=self.run/'work/false.png';fake.write_text('<html>wrong file response</html>');v['essential_scenes'][0]['sources'][0]['file']=self.bind(fake);self.assertFalse(self.assess(v)['passed'])
 def test_actual_record_cannot_use_illustration_and_image_is_allowed(self):
  v=copy.deepcopy(self.value);scene=v['essential_scenes'][0];scene['role']='actual_record';scene['sources'][0]['role']='illustration';self.assertFalse(self.assess(v)['passed'])
  image=self.run/'work/record.png';Image.new('RGB',(30,20),'blue').save(image);scene['material_kind']='image';scene['sources'][0].update(role='actual_record',file=self.bind(image));self.assertTrue(self.assess(v)['passed'])
 def test_usage_quality_observation_and_model_required(self):
  for field in ('content_matches','usable_quality','evidence'):
   v=copy.deepcopy(self.value);v['essential_scenes'][0]['sources'][0]['inspection'][field]=False if field!='evidence' else [];self.assertFalse(self.assess(v)['passed'])
  v=copy.deepcopy(self.value);v['essential_scenes'][0]['sources'][0]['usage']['status']='unverified';self.assertFalse(self.assess(v)['passed'])
  self.log.write_text(self.log.read_text().replace('"high"','"low"'));self.assertFalse(self.assess(self.value)['passed'])
 def test_fixed_topic_no_silent_change_and_legacy_compatible(self):
  req=json.loads(self.req.read_text());req.update(user_fixed_topic=True,topic='user fixed topic');self.req.write_text(json.dumps(req));v=copy.deepcopy(self.value);v['request_sha256']=digest(self.req);self.assertFalse(self.assess(v)['passed']);v['topic']='user fixed topic';self.assertTrue(self.assess(v)['passed'])
  self.doc.unlink();(self.run/'run.json').write_text('{"scheduler_version":3}');self.assertEqual(self.claim('planning')['decision'],'run')
 def test_bulk_production_and_planning_handoff_require_topic_binding(self):
  self.doc.unlink()
  with self.assertRaisesRegex(ValueError,'prepare/research'):guard_tool(self.run,'tts',['--help'])
  self.write('work/topic-materials.json',self.value)
  packet=self.write('work/handoff.json',{'schema':'lfc-stage-handoff-v1','stage':'planning','model':'gpt-6.1-sol','reasoning_effort':'high','session_id':'researcher','user_instructions':[],'completed_scope':['fixture'],'unresolved_items':[],'basis_sha256':{str(self.req):digest(self.req)},'files':[]})
  missing=check_handoff(packet);self.assertTrue(any('inspected essential' in e for e in missing['errors']))
  value=json.loads(packet.read_text());value['topic_materials']={'request':self.bind(self.req),'assessment':self.bind(self.doc)};packet.write_text(json.dumps(value));r=check_handoff(packet);self.assertFalse(any('topic' in e.lower() for e in r['errors']));self.assertIn(str(self.source),r['dependencies_sha256'])

if __name__=='__main__':unittest.main()
