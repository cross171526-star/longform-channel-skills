"""확정 컷 명세를 검증하고 동일 ID·구성요소를 절대 시간 타임라인으로 연결한다."""
import argparse
import json
from pathlib import Path
from check_production import check, VerificationContext
from production_gate_links import build_expected_timeline
from plan_duration import write_plan
from work_guard import validate_output_paths


def compile_timeline(manifest_path, context=None):
    owner = context is None
    context = context or VerificationContext()
    try: return _compile_timeline(manifest_path, context)
    finally:
        if owner: context.close()


def _compile_timeline(manifest_path, context):
    source = Path(context.snapshot.add(manifest_path)[0])
    result = check(source, 'plan', context=context)
    if not result['passed']:
        raise ValueError('; '.join(result['errors']))
    manifest = context.document(source)
    baseline = context.document(source.parent / manifest['baseline'])
    timeline = None
    if isinstance(manifest['tts'].get('timeline'), str):
        timeline_path = (source.parent / manifest['tts']['timeline']).resolve()
        if context.snapshot.optional_file(source.parent / manifest['tts']['timeline']):
            timeline = context.document(timeline_path)
    return build_expected_timeline(source, manifest, baseline, result['input_sha256'],
                                   context.digest(source), result['output_bounds'], timeline)


def compile_many(manifests, outputs=None):
    context = VerificationContext()
    try:
        if outputs is not None: validate_output_paths(manifests, outputs)
        results = [compile_timeline(path, context) for path in manifests]
        if outputs is not None:
            validate_output_paths(manifests, outputs, context.snapshot.signatures)
            if len(outputs) != len(manifests): raise ValueError('Compiled output count differs from manifest count')
            for path, output in zip(manifests, outputs):
                current = context.document(path)
                declared = (Path(path).resolve().parent / current['compiled_timeline']).resolve()
                if Path(output).resolve() != declared:
                    raise ValueError('Compiled output declaration changed before verification')
        return results
    finally: context.close()


def argument_parser():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('manifest', type=Path)
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--also-manifest', type=Path, action='append', default=[],
                   help='Compile linked scopes in one transaction; additional outputs use their declared compiled_timeline')
    return p


def parse_arguments(args=None):
    return argument_parser().parse_args(args)


def main():
    p = argument_parser()
    args = p.parse_args()
    try:
        manifest = json.loads(args.manifest.read_text())
        declared = (args.manifest.resolve().parent / manifest['compiled_timeline']).resolve()
        if args.out.resolve() != declared:
            raise ValueError('--out must match manifest.compiled_timeline')
        if args.out.resolve() == args.manifest.resolve():
            raise ValueError('출력으로 원본 명세를 덮어쓸 수 없습니다.')
        paths = [args.manifest, *args.also_manifest]
        outputs = [args.out]
        for path in args.also_manifest:
            declared = (path.resolve().parent / json.loads(path.read_text())['compiled_timeline']).resolve()
            outputs.append(declared)
        results = compile_many(paths, outputs)
        for out, timeline in zip(outputs, results): write_plan(out, timeline)
    except (OSError, ValueError, KeyError, TypeError, IndexError) as error:
        p.exit(1, str(error) + '\n')


if __name__ == '__main__':
    main()
