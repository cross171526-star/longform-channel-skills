#!/usr/bin/env python3
"""Merge the analyses of all reference videos into one channel style profile.

  run.sh aggregate <project>

Reads analysis/<id>/{cuts,captions,transcript,audio,script}.json for every selected video and writes
style/style_profile.json (machine-readable weights used by plan_video / build_timeline) and style/style_guide.md
(human summary, generated - edit the JSON, not the md). Every distribution keeps raw counts and per-video
presence so "always" features (present in all videos) can be separated from occasional ones.
"""
from __future__ import annotations

import argparse
import statistics as st
from collections import Counter, defaultdict
from pathlib import Path

from common import KO_KEY, ko, ko_formula, read_json, write_json


def dist(counter: Counter) -> dict:
    tot = sum(counter.values()) or 1
    return {k: {"count": v, "p": round(v / tot, 4)} for k, v in counter.most_common()}


def q(vals, p):
    vals = sorted(v for v in vals if v is not None)
    if not vals:
        return None
    k = (len(vals) - 1) * p
    lo, hi = int(k), min(int(k) + 1, len(vals) - 1)
    return round(vals[lo] + (vals[hi] - vals[lo]) * (k - lo), 4)


def summ(vals):
    vals = [v for v in vals if v is not None]
    if not vals:
        return None
    return {"n": len(vals), "median": q(vals, 0.5), "p10": q(vals, 0.1), "p90": q(vals, 0.9),
            "mean": round(st.mean(vals), 4)}


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("project")
    a = ap.parse_args()
    project = Path(a.project)
    ch = read_json(project / "channel.json")
    sel = ch["selection"]
    vids = [v for v in dict.fromkeys(sel["top_views"] + sel["recent"])
            if (project / "analysis" / v / "cuts.json").exists()
            and any(c.get("annotation") for c in read_json(project / "analysis" / v / "cuts.json")["cuts"])]
    if not vids:
        raise SystemExit("no analyzed videos")
    P = {"channel": ch["channel"], "videos": {}, "global": {}, "by_role": {}, "captions": {}, "audio": {}, "script": {}}
    g = defaultdict(Counter)
    presence = defaultdict(set)
    role_cut = defaultdict(list)
    role_pool = defaultdict(lambda: defaultdict(Counter))
    motion_rates = defaultdict(lambda: defaultdict(list))
    trans_frames = defaultdict(list)
    cut_durs, first30 = [], []
    for vid in vids:
        ad = project / "analysis" / vid
        cuts = read_json(ad / "cuts.json")
        meta = read_json(project / "videos" / vid / "meta.json") if (project / "videos" / vid / "meta.json").exists() else {}
        cl = cuts["cuts"]
        durs = [c["duration_s"] for c in cl]
        cut_durs += durs
        first30 += [c["duration_s"] for c in cl if c["start_s"] < 30]
        P["videos"][vid] = {"title": meta.get("title"), "views": meta.get("view_count"), "roles": meta.get("roles"),
                            "duration_s": cuts["video"]["duration_s"], "cuts": len(cl),
                            "median_cut_s": q(durs, 0.5), "cuts_per_min": round(len(cl) / cuts["video"]["duration_s"] * 60, 2),
                            "resolution": [cuts["video"].get("width"), cuts["video"].get("height")], "fps": cuts["video"]["fps"]}
        for c in cl:
            ann = c.get("annotation") or {}
            if not ann or ann.get("draft"):
                continue
            role = ann.get("script_role", "unknown")
            src = ann["source"]["type"]
            tr = ann["transition_in"]["type"] if c["index"] > 0 else "start"
            mp = ann["keyframes"].get("preset") or (c.get("motion") or {}).get("preset_guess", "static")
            anim = ann["animation"].get("in", "none")
            for key, val in (("source_type", src), ("transition", tr), ("motion_preset", mp), ("animation_in", anim),
                             ("layer_fit", ann.get("layer", {}).get("fit", "cover")),
                             ("narration_sync", ann.get("narration_sync", "independent"))):
                g[key][val] += 1
                presence[f"{key}:{val}"].add(vid)
                role_pool[role][key][val] += 1
            for fx in ann["animation"].get("effects", []):
                g["effect"][fx] += 1
                presence[f"effect:{fx}"].add(vid)
                role_pool[role]["effect"][fx] += 1
            role_cut[role].append(c["duration_s"])
            if tr not in ("cut", "start"):
                trans_frames[tr].append(ann["transition_in"].get("frames"))
            m = c.get("motion") or {}
            if m and m.get("preset_guess") not in (None, "camera_motion"):
                comp = m["components"]
                motion_rates[mp]["scale_start"].append(comp["scale"]["start"])
                motion_rates[mp]["scale_rate_per_s"].append(m["scale_rate_per_s"])
                motion_rates[mp]["x_rate_per_s"].append(m["x_rate_per_s"])
                motion_rates[mp]["y_rate_per_s"].append(m["y_rate_per_s"])
                for seg in comp["scale"]["segments"] + comp["x"]["segments"]:
                    g["motion_easing"][seg["easing"]] += 1
            ov = ann.get("overlays", [])
            for o in ov:
                g["overlay"][o["kind"]] += 1
                role_pool[role]["overlay"][o["kind"]] += 1
        # captions
        if (ad / "captions.json").exists():
            cap = read_json(ad / "captions.json")
            P["captions"][vid] = {"zones": cap["zones"][:6],
                                  "fonts": [(e["id"], e.get("zone"), (e.get("font_candidates") or [{}])[0].get("font"))
                                            for e in cap["events"] if e.get("font_candidates")][:12],
                                  "animation_in": dict(Counter(e["animation"]["in"] for e in cap["events"]))}
            for e in cap["events"]:
                if e["animation"]["in"] != "unknown":
                    g["caption_animation_in"][e["animation"]["in"]] += 1
        if (ad / "audio.json").exists():
            au = read_json(ad / "audio.json")
            labels = Counter(e["labels"][0][0] for e in au["sfx_events"] if e.get("confirmed") and not e.get("rejected") and e.get("labels"))
            P["audio"][vid] = {"levels": au["levels"], "sfx_per_minute": au["sfx_per_minute"],
                               "sfx_on_cut_ratio": au.get("sfx_on_cut_ratio"), "sfx_labels": dict(labels),
                               "bgm_segments": len(au["bgm_segments"]),
                               "bgm_moods": [s.get("mood_tags", [[None]])[0][0] for s in au["bgm_segments"] if s.get("mood_tags")],
                               "bgm_tempos": [s.get("tempo_bpm") for s in au["bgm_segments"] if s.get("tempo_bpm")]}
            g["sfx_label"].update(labels)
        if (ad / "transcript.json").exists():
            tr_ = read_json(ad / "transcript.json")
            P["videos"][vid]["speech_rate"] = tr_["rate"]
            P["videos"][vid]["first_word_s"] = tr_.get("first_word_s")
        if (ad / "script.json").exists():
            sc = read_json(ad / "script.json")
            P["script"][vid] = {"formula": sc["formula"], "hook": sc["hook"], "title_pattern": sc.get("title_pattern"),
                                "sections": [{"role": s["role"], "start_s": s["start_s"], "end_s": s["end_s"],
                                              "share": round((s["end_s"] - s["start_s"]) / sc["duration_s"], 4),
                                              "purpose": s["purpose"], "techniques": s.get("techniques", [])}
                                             for s in sc["sections"]],
                                "sentence_style": sc.get("sentence_style"), "cta": sc.get("cta"),
                                "retention_devices": sc.get("retention_devices")}
            for s in sc["sections"]:
                g["section_role"][s["role"]] += 1
                for t in s.get("techniques", []):
                    g["script_technique"][t] += 1
            for t in sc["hook"].get("technique", []):
                g["hook_technique"][t] += 1
    n = len(vids)
    P["global"] = {k: dist(v) for k, v in g.items()}
    for key, d in P["global"].items():
        for val in d:
            d[val]["videos"] = len(presence.get(f"{key}:{val}", set())) or None
    P["global"]["cut_duration_s"] = summ(cut_durs)
    P["global"]["cut_duration_first30_s"] = summ(first30)
    P["global"]["transition_frames"] = {k: summ(v) for k, v in trans_frames.items()}
    P["global"]["motion_rates"] = {k: {m: summ(v) for m, v in d.items()} for k, d in motion_rates.items()}
    P["always"] = sorted(k for k, s in presence.items() if len(s) == n)
    P["by_role"] = {r: {"cut_duration_s": summ(role_cut[r]), **{k: dist(v) for k, v in pool.items()}}
                    for r, pool in role_pool.items()}
    P["n_videos"] = n
    out = project / "style"
    write_json(out / "style_profile.json", P)
    md = [f"# 스타일 가이드: {ch['channel'].get('name')}", "",
          "컷 길이는 자동 검출 결과이며 소스·전환·효과 분포는 사람이 확정한 컷만 집계했습니다. 확정된 컷은 대표 표본이므로 전체 영상의 비율로 해석하지 마세요.", "",
          f"분석한 영상: {n}개", ""]
    md.append("| 영상 | 조회수 | 길이 | 분당 컷 수 | 컷 길이 중앙값 |")
    md.append("|---|---:|---:|---:|---:|")
    for vid, v in P["videos"].items():
        title = (v['title'] or '').replace('|', '\\|')
        md.append(f"| {title} | {v['views'] or 0:,} | {v['duration_s'] / 60:.1f}분 | {v['cuts_per_min']} | {v['median_cut_s']}초 |")

    def feat(k):
        key, _, val = k.partition(":")
        return f"{KO_KEY.get(key, key)}: {ko(val)}"
    md += ["", "모든 영상에 공통으로 있는 특징:", ""] + [f"- {feat(k)}" for k in P["always"]] + [""]
    for key in ("source_type", "transition", "motion_preset", "animation_in", "effect", "overlay", "caption_animation_in",
                "sfx_label", "section_role", "hook_technique", "script_technique"):
        d = P["global"].get(key)
        if not d:
            continue
        md.append(f"## {KO_KEY.get(key, key)}")
        md.append("")
        md += [f"- {ko(k)}: {v['p'] * 100:.1f}% ({v['count']}회, 영상 {v.get('videos') or '?'}/{n}개에서 등장)"
               for k, v in list(d.items())[:14]]
        md.append("")
    md.append("## 대본 공식")
    md.append("")
    md += [f"- {vid}: {ko_formula(s['formula'])}" for vid, s in P["script"].items()]
    md += ["", "\"초안\"은 자동 분석으로 만든 구조입니다. 사람이 확인하기 전까지는 참고용입니다."]
    (out / "style_guide.md").write_text("\n".join(md) + "\n", encoding="utf-8")
    print(f"profile from {n} videos -> {out / 'style_profile.json'}, {out / 'style_guide.md'}")


if __name__ == "__main__":
    main()
