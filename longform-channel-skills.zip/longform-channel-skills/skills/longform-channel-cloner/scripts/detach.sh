#!/usr/bin/env bash
# Run a long job detached from the agent's shell (exec cells kill their background children).
#   scripts/detach.sh <label> <logfile> <command> [args...]
# Uses a one-shot launchd agent whose plist lives in ~/.longform-cloner/jobs (outside ~/Library/LaunchAgents, so it
# never restarts at login). Poll the log; "scripts/detach.sh --stop <label>" ends it early.
set -euo pipefail
LFC_HOME="${LFC_HOME:-$HOME/.longform-cloner}"
JOBS="$LFC_HOME/jobs"; mkdir -p "$JOBS"
if [ "${1:-}" = "--stop" ]; then
  launchctl bootout "gui/$(id -u)/com.lfc.${2:?label}" 2>/dev/null || true
  exit 0
fi
label="com.lfc.${1:?label}"; log="${2:?logfile}"; shift 2
[ $# -gt 0 ] || { echo "command required" >&2; exit 2; }
mkdir -p "$(dirname "$log")"
plist="$JOBS/$label.plist"
esc() { printf '%s' "$1" | sed -e 's/&/\&amp;/g' -e 's/</\&lt;/g' -e 's/>/\&gt;/g'; }
{
  echo '<?xml version="1.0" encoding="UTF-8"?>'
  echo '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">'
  echo '<plist version="1.0"><dict>'
  echo "<key>Label</key><string>$label</string>"
  echo '<key>ProgramArguments</key><array>'
  for a in "$@"; do echo "<string>$(esc "$a")</string>"; done
  echo '</array>'
  echo "<key>WorkingDirectory</key><string>$(esc "$PWD")</string>"
  echo "<key>StandardOutPath</key><string>$(esc "$log")</string><key>StandardErrorPath</key><string>$(esc "$log")</string>"
  echo "<key>EnvironmentVariables</key><dict><key>PATH</key><string>$(esc "$LFC_HOME/bin:$HOME/.local/bin:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin")</string>"
  echo "<key>HOME</key><string>$(esc "$HOME")</string><key>HF_HUB_OFFLINE</key><string>1</string></dict>"
  echo '<key>RunAtLoad</key><true/><key>KeepAlive</key><false/>'
  echo '</dict></plist>'
} > "$plist"
launchctl bootout "gui/$(id -u)/$label" 2>/dev/null || true
launchctl bootstrap "gui/$(id -u)" "$plist"
echo "started $label -> $log"
