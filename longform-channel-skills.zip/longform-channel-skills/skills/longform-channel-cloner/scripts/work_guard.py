"""공유 실행 등록부. 파일 검증은 잠금 밖에서, 등록은 짧은 트랜잭션으로 수행한다."""
import argparse
import fcntl
from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import sys
import time
import uuid


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def signature(path):
    p = Path(path)
    a, b = p.lstat(), p.stat()
    return (str(p.resolve(strict=True)), *(getattr(s, k) for s in (a, b)
            for k in ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns')))


class FileSnapshot:
    """검증 한 번 안에서만 해시를 공유한다. 호출 간 stat-only 캐시는 사용하지 않는다."""
    def __init__(self, *, hasher=None, reader=None):
        self.signatures, self.digests, self.documents = {}, {}, {}
        self.absent = {}
        self.hasher, self.reader = hasher, reader

    def hash_file(self, path):
        return self.hasher(path) if self.hasher else digest(path)

    def optional_file(self, path):
        """An allowed missing input is still part of this transaction's closure."""
        path = str(Path(path).expanduser().absolute())
        state = self.absence_state(path)
        if path in self.absent and state != self.absent[path]:
            raise ValueError('Optional input appeared/changed during verification: ' + path)
        if state[1]: return True
        self.absent[path] = state
        return False

    @staticmethod
    def absence_state(path):
        p = Path(path)
        stat = p.lstat() if os.path.lexists(p) else None
        return (str(p.resolve()), p.is_file(), None if stat is None else
                tuple(getattr(stat, k) for k in ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns')))

    def add(self, path):
        path = str(Path(path).expanduser().absolute())
        before = signature(path)
        if path in self.signatures and self.signatures[path] != before:
            raise ValueError('Input changed during verification: ' + path)
        self.signatures[path] = before
        canonical = before[0]
        canonical_before = signature(canonical)
        if canonical in self.signatures and self.signatures[canonical] != canonical_before:
            raise ValueError('Input target changed during verification: ' + canonical)
        self.signatures[canonical] = canonical_before
        if canonical not in self.digests:
            self.digests[canonical] = self.hash_file(canonical)
        if signature(path) != before or signature(canonical) != canonical_before:
            raise ValueError('Input changed while hashing: ' + path)
        return canonical, self.digests[canonical]

    def document(self, path):
        canonical, _ = self.add(path)
        if canonical not in self.documents:
            self.documents[canonical] = (self.reader(canonical) if self.reader else
                                         json.loads(Path(canonical).read_text()))
        if signature(canonical) != self.signatures[canonical]:
            raise ValueError("JSON changed during verification: " + canonical)
        return self.documents[canonical]

    def unchanged(self, *, verify_content=False):
        for path, before in self.absent.items():
            if self.absence_state(path) != before:
                raise ValueError('Optional input appeared/changed during verification: ' + path)
        for path, before in self.signatures.items():
            if signature(path) != before:
                raise ValueError('Input changed during task transition: ' + path)
        if verify_content:
            # One fresh content read at the transaction boundary, never stat-only
            # reuse across transactions. Recheck aliases after the content read.
            for path, expected in self.digests.items():
                if self.hash_file(path) != expected:
                    raise ValueError('Input content changed during verification: ' + path)
            self.unchanged()


def validate_output_paths(inputs, outputs, protected=()):
    """A report/compiled output must never replace a source or its alias."""
    sources = {Path(p).resolve() for p in [*inputs, *protected]}
    source_ids = {(p.stat().st_dev, p.stat().st_ino) for p in sources if p.is_file()}
    seen, seen_ids = set(), set()
    for name in outputs:
        path = Path(name).resolve()
        identity = (path.stat().st_dev, path.stat().st_ino) if path.is_file() else None
        if path in sources or path in seen or (identity is not None and (identity in source_ids or identity in seen_ids)):
            raise ValueError('Outputs must be distinct and cannot overwrite source inputs')
        seen.add(path)
        if identity is not None: seen_ids.add(identity)


def hashes(paths, snapshot=None):
    snap = snapshot or FileSnapshot()
    result = dict(snap.add(p) for p in paths)
    snap.unchanged()
    return result


def dependencies(paths, snapshot=None):
    """명시 입력 그래프만 순회. 모든 선언 해시를 대조하고 각 실제 파일은 한 번 해시한다."""
    snap = snapshot or FileSnapshot()
    result, visited = {}, set()
    def visit(path, expected=None):
        lexical = str(Path(path).expanduser().absolute())
        canonical, actual = snap.add(lexical)
        if expected is not None and actual != expected:
            raise ValueError('Dependency changed: ' + lexical)
        result[canonical] = actual
        # 별칭도 보존하여 다음 검증 때 symlink 대상 교체를 검사한다.
        if lexical != canonical:
            result[lexical] = actual
        if canonical in visited:
            return
        visited.add(canonical)
        if not canonical.endswith('.json'):
            return
        doc = snap.document(canonical)
        if not isinstance(doc, dict) or doc.get('schema') != 'lfc-inputs-v1':
            return
        if not isinstance(doc.get('files'), list) or not doc['files']:
            raise ValueError('Empty or invalid dependency manifest')
        for row in doc['files']:
            if not isinstance(row, dict) or not isinstance(row.get('path'), str) or not isinstance(row.get('sha256'), str):
                raise ValueError('Invalid dependency declaration')
            visit(Path(canonical).parent / row['path'], row['sha256'])
    for path in paths:
        visit(path)
    snap.unchanged()
    return result


def revision_fingerprint(inputs, snapshot=None):
    # 파일-역할 대응까지 포함한다. v1의 내용 해시 집합만으로는 A/B 역할 교환을 구분하지 못한다.
    # DB 열 계약은 유지하며 구형 키의 완료물은 원래 고정 검사기로 명시적으로 재사용한다.
    snap = snapshot or FileSnapshot()
    values = []
    for name in inputs:
        path, actual = snap.add(name)
        doc = snap.document(path) if Path(path).suffix == '.json' else None
        if isinstance(doc, dict) and doc.get('schema') == 'lfc-inputs-v1':
            rows=[]
            for row in doc['files']:
                target=(Path(path).parent/row['path']).resolve()
                try:logical=str(target.relative_to(Path(path).parent))
                except ValueError:logical=str(target)
                rows.append({**row,'path':logical})
            values.append(json.dumps({**doc,'files':rows},sort_keys=True))
        else:
            values.append(actual)
    snap.unchanged()
    return hashlib.sha256(json.dumps(['role-bound-v2',sorted(values)]).encode()).hexdigest()


@contextmanager
def connection():
    base = Path(os.environ.get('LFC_RUNTIME_HOME', str(Path.home()/'.longform-cloner/runtime')))
    base.mkdir(parents=True, exist_ok=True)
    # 초기 스키마 생성의 PRAGMA/DDL 경쟁만 파일 잠금으로 직렬화한다.
    with (base/'schema.lock').open('a') as schema_lock:
        fcntl.flock(schema_lock,fcntl.LOCK_EX)
        db = sqlite3.connect(base/'work.sqlite', timeout=10)
        db.row_factory = sqlite3.Row
        # 기존 테이블에 열을 추가하지 않는다. 구형 실행의 INSERT 계약도 그대로 유효하다.
        present = {r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if not {'jobs', 'usage', 'waiting', 'checkpoints'} <= present:
            db.execute('PRAGMA journal_mode=WAL')
            db.execute('''CREATE TABLE IF NOT EXISTS jobs (
              lease TEXT PRIMARY KEY, run TEXT, task TEXT, resource TEXT, stage TEXT, pool TEXT,
              fingerprint TEXT, inputs TEXT, outputs TEXT, state TEXT, error TEXT,
              started REAL, ended REAL, validation TEXT)''')
            db.execute('''CREATE TABLE IF NOT EXISTS usage (
              response_id TEXT PRIMARY KEY, lease TEXT, input INTEGER, cached INTEGER,
              output INTEGER, recorded REAL)''')
            db.execute('CREATE INDEX IF NOT EXISTS job_resource ON jobs(resource,stage,state)')
            db.execute('CREATE TABLE IF NOT EXISTS waiting (run TEXT, resource TEXT, stage TEXT, pool TEXT, created REAL, seen REAL, PRIMARY KEY(run,resource,stage))')
            db.execute('CREATE TABLE IF NOT EXISTS checkpoints (lease TEXT PRIMARY KEY, calls INTEGER, progress TEXT)')
            db.commit()
        # 보조 테이블만 추가한다. 구형 jobs/waiting INSERT 열 계약은 그대로 유지한다.
        db.execute('CREATE TABLE IF NOT EXISTS owners (lease TEXT PRIMARY KEY,rollout TEXT,session TEXT,pid INTEGER,pid_identity TEXT,heartbeat REAL,acked REAL,progress REAL)')
        db.execute('CREATE TABLE IF NOT EXISTS events (id INTEGER PRIMARY KEY AUTOINCREMENT,run TEXT,lease TEXT,kind TEXT,at REAL,payload TEXT)')
        db.commit()
    try:
        with db:
            yield db
    finally:
        db.close()


def usage_summary(db, lease):
    row = db.execute('SELECT COUNT(*) calls,COALESCE(SUM(input-cached),0) uncached_input,COALESCE(SUM(cached),0) cached_input,COALESCE(SUM(output),0) output FROM usage WHERE lease=?',(lease,)).fetchone()
    return dict(row)


def _job(db, root, lease):
    row = db.execute('SELECT * FROM jobs WHERE lease=? AND run=?',(lease,root)).fetchone()
    if not row:
        raise ValueError('Valid lease for this run required')
    return dict(row)


def execute(root, action, task=None, inputs=(), outputs=(), note='', *, resource=None,
            stage=None, pool='model', lease=None, validation=None, records=(), worker_rollout=None, ready=True):
    root = str(Path(root).expanduser().resolve())
    if action == 'status':
        with connection() as db:
            return {'jobs':[dict(r) for r in db.execute('SELECT lease,task,resource,stage,pool,state,started,ended FROM jobs WHERE run=?',(root,))]}
    if action in ('enqueue','cancel','events','metrics','heartbeat','ack','diagnose','recover'):
        from scheduler import dispatch
        return dispatch(root,action,task=task,resource=resource,stage=stage,pool=pool,
                        lease=lease,validation=validation,note=note,worker_rollout=worker_rollout)
    provenance = None
    if action == 'claim':
        from scheduler import modern_run, provenance as verify_provenance
        if modern_run(root) and pool == 'model':
            if not worker_rollout:
                raise ValueError('Actual active task rollout required')
            provenance = verify_provenance(worker_rollout)
            if provenance.get('last_event') in ('turn_aborted','task_complete'):
                raise ValueError('Inactive worker cannot start a task')
    if action=='claim' and stage=='planning':
        from quality_contract import topic_required,ready_topic
        if topic_required(root):
            # Research uses collection/prepare; this registration starts complete script planning.
            topic=ready_topic(root)
            inputs=tuple(dict.fromkeys([*map(str,inputs),*topic['dependencies_sha256']]))
    snap = FileSnapshot()
    reuse = None
    if action == 'claim':
        if not task or not resource or stage not in ('collection','prepare','analysis','planning','implementation','review') or pool not in ('model','local'):
            raise ValueError('task, canonical resource, stage and model/local pool required')
        if not inputs:
            raise ValueError('Frozen specification/input files required')
        inp = dependencies(inputs, snap)
        fingerprint = revision_fingerprint(inputs, snap)
        with connection() as db:
            old_jobs = [dict(r) for r in db.execute("SELECT * FROM jobs WHERE resource=? AND stage=? AND fingerprint=? AND state='done' ORDER BY ended DESC",(resource,stage,fingerprint))]
        for old in old_jobs:
            candidate = FileSnapshot()
            try:
                saved = json.loads(old['outputs'])
                if saved and hashes(saved, candidate) == saved and dependencies(json.loads(old['inputs']), candidate) == json.loads(old['inputs']):
                    reuse = (old, saved, candidate)
                    break
            except (OSError, ValueError):
                continue
    else:
        with connection() as db:
            job = _job(db, root, lease)
        if action != 'usage' and job['state'] != 'running':
            raise ValueError('Lease no longer running')
        if action in ('check', 'finish'):
            if dependencies(json.loads(job['inputs']), snap) != json.loads(job['inputs']):
                raise ValueError('Inputs changed during task')
        output_hashes = {}
        if action == 'finish':
            if not outputs or not validation:
                raise ValueError('Outputs and bound validation report required')
            output_hashes = hashes(outputs, snap)
            report = snap.document(validation)
            if report.get('passed') is not True or report.get('output_sha256') != output_hashes:
                raise ValueError('Validation failed or outputs differ from validation report')
            dep = report.get('dependencies_sha256', {})
            if dep and hashes(dep, snap) != dep:
                raise ValueError('Validation dependencies changed')
            output_hashes.update(dep)
            output_hashes.update(hashes([validation], snap))
        if action == 'checkpoint':
            if not validation:
                raise ValueError('Progress file required')
            progress = snap.document(validation).get('completed_units')
            if not isinstance(progress, list) or not progress or any(not isinstance(v,str) or not v for v in progress):
                raise ValueError('completed_units must identify actually completed video ranges/cuts')
        if action in ('finish','fail') and not note.strip():
            raise ValueError('Outcome reason required')
    with connection() as db:
        if action != 'check':
            db.execute('BEGIN IMMEDIATE')
        snap.unchanged()
        if action == 'claim':
            if db.execute("SELECT 1 FROM jobs WHERE resource=? AND stage=? AND state='running'",(resource,stage)).fetchone():
                raise ValueError('Same resource/stage already running on this host')
            if reuse:
                old, saved, candidate = reuse
                current = db.execute('SELECT * FROM jobs WHERE lease=?',(old['lease'],)).fetchone()
                if current and dict(current) == old:
                    candidate.unchanged()
                    return {'decision':'reuse','lease':old['lease'],'outputs':list(saved)}
            failures = db.execute("SELECT COUNT(*) FROM jobs WHERE resource=? AND stage=? AND fingerprint=? AND state='failed'",(resource,stage,fingerprint)).fetchone()[0]
            if failures >= 2:
                raise ValueError('Same revision failed twice; diagnose before changing inputs')
            lease = uuid.uuid4().hex
            db.execute('INSERT INTO jobs VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)', (lease,root,task,resource,stage,pool,fingerprint,json.dumps(inp),None,'running',None,time.time(),None,None))
            from scheduler import register_owner, emit
            register_owner(db,lease,provenance,worker_rollout)
            emit(db,root,lease,'claimed',{'resource':resource,'stage':stage,'pool':pool,'claimed_at':time.time()})
            snap.unchanged()
            return {'decision':'run','lease':lease,'resource':resource,'stage':stage,'failure_attempt':failures+1}
        if _job(db, root, lease) != job:
            raise ValueError('Job state changed during verification; reread before retrying')
        if action == 'usage':
            for row in records:
                rid = row.get('response_id'); u = row.get('usage', {})
                vals = [u.get(k) for k in ('input_tokens','cached_input_tokens','output_tokens')]
                if not rid or any(type(v) is not int or v < 0 for v in vals) or vals[1] > vals[0]:
                    raise ValueError('Invalid measured usage record')
                existing = db.execute('SELECT lease,input,cached,output FROM usage WHERE response_id=?',(rid,)).fetchone()
                if existing and tuple(existing) != (lease,*vals):
                    raise ValueError('Response already assigned or recorded with different usage')
                db.execute('INSERT OR IGNORE INTO usage VALUES (?,?,?,?,?,?)',(rid,lease,*vals,time.time()))
            return {'decision':'recorded',**usage_summary(db,lease)}
        if action == 'checkpoint':
            old = db.execute('SELECT progress FROM checkpoints WHERE lease=?',(lease,)).fetchone()
            if old and not set(json.loads(old[0])) < set(progress):
                raise ValueError('No new completed scope; preserve the previous progress record')
            calls = usage_summary(db,lease)['calls']
            db.execute('INSERT OR REPLACE INTO checkpoints VALUES (?,?,?)',(lease,calls,json.dumps(progress)))
            from scheduler import emit
            db.execute('UPDATE owners SET progress=? WHERE lease=?',(time.time(),lease))
            emit(db,root,lease,'checkpoint',{'completed_units':progress})
            snap.unchanged()
            return {'decision':'continue','calls':calls,'completed_units':len(set(progress))}
        if action == 'check':
            # 사용량은 계측만 한다. 응답 수나 시간 때문에 제작을 중단하지 않는다.
            return {'decision':'run','resource':job['resource'],'stage':job['stage'],**usage_summary(db,lease)}
        if action not in ('finish','fail'):
            raise ValueError('Unknown action')
        db.execute('UPDATE jobs SET state=?,outputs=?,error=?,ended=?,validation=? WHERE lease=?', ('done' if action=='finish' else 'failed',json.dumps(output_hashes),note,time.time(),str(validation or ''),lease))
        from scheduler import emit
        emit(db,root,lease,'completed' if action=='finish' else 'failed',{'note':note})
        snap.unchanged()
        return {'decision':'done' if action=='finish' else 'failed' ,'lease':lease,**usage_summary(db,lease)}


def wait_claim(root, task, inputs, resource, stage, pool='model', wait_seconds=55, worker_rollout=None):
    """구형 인자 호환. 한 번 즉시 등록하며 폴링/대기를 하지 않는다."""
    return execute(root,'claim',task,inputs,resource=resource,stage=stage,pool=pool,worker_rollout=worker_rollout)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('action',choices=['claim','wait-claim','finish','fail','check','status','usage','checkpoint','enqueue','cancel','events','metrics','heartbeat','ack','diagnose','recover'])
    p.add_argument('--run-dir',required=True); p.add_argument('--task'); p.add_argument('--resource'); p.add_argument('--stage')
    p.add_argument('--pool',choices=['model','local'],default='model'); p.add_argument('--lease')
    p.add_argument('--inputs',nargs='+',default=[]); p.add_argument('--outputs',nargs='+',default=[])
    p.add_argument('--note',default=''); p.add_argument('--validation'); p.add_argument('--records'); p.add_argument('--wait-seconds',type=float,default=55)
    p.add_argument('--worker-rollout');
    a = p.parse_args()
    try:
        records = json.loads(Path(a.records).read_text()) if a.records else []
        if a.action == 'wait-claim':
            result = wait_claim(a.run_dir,a.task,a.inputs,a.resource,a.stage,a.pool,a.wait_seconds,a.worker_rollout)
        else:
            result = execute(a.run_dir,a.action,a.task,a.inputs,a.outputs,a.note,resource=a.resource,stage=a.stage,pool=a.pool,lease=a.lease,validation=a.validation,records=records,worker_rollout=a.worker_rollout)
        print(json.dumps(result,ensure_ascii=False))
        return 3 if result.get('decision')=='wait' else 0
    except (OSError,ValueError,KeyError,TypeError,sqlite3.Error) as exc:
        print(json.dumps({'decision':'blocked','reason':str(exc)},ensure_ascii=False)); return 2


if __name__ == '__main__':
    sys.exit(main())
