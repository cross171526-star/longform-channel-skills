"""Check a candidate structure before writing its full script or synthesizing speech.

run.sh check_duration_feasibility STRUCTURE_JSON --references REFERENCES_JSON --out REPORT_JSON
STRUCTURE_JSON needs structure_id and source-linked background cuts only.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path
from plan_duration import plan_duration, write_plan
from timing_contract import reference_background, validate_reference_clips


def inspect_structure(structure_path, selected_path):
    structure_path, selected_path = Path(structure_path).resolve(), Path(selected_path).resolve()
    baseline = json.loads(structure_path.read_text())
    source = selected_path.read_bytes()
    plan = plan_duration(json.loads(source), hashlib.sha256(source).hexdigest())
    mean = plan['target_duration_s']
    hashes = {}
    def load(name):
        path = (structure_path.parent / name).resolve()
        content = path.read_bytes()
        hashes[str(path)] = hashlib.sha256(content).hexdigest()
        return json.loads(content)
    rows = [reference_background(cut, load) for cut in baseline['cuts']]
    if not rows or len({c['cut_id'] for c in rows}) != len(rows):
        raise ValueError('Structure needs unique source-linked background clips')
    validate_reference_clips(rows)
    total = math.fsum(c['original_duration_s'] for c in rows)
    low, high = .8 * total, 1.2 * total
    if not math.isfinite(high):
        raise ValueError('Invalid structure duration range')
    report = {'structure_id': baseline['structure_id'], 'target_duration_s':mean,
            'original_total_s':total,'minimum_duration_s':low,'maximum_duration_s':high,
            'mean_feasible':low-1e-9 <= mean <= high+1e-9,
            'nearest_feasible_duration_s':max(low,min(mean,high)),
            'reference_clips':rows,'analysis_hashes':hashes,
            'structure_sha256':hashlib.sha256(structure_path.read_bytes()).hexdigest(),
            'selected6_sha256':hashlib.sha256(source).hexdigest()}
    tolerance = plan.get('full_duration_tolerance_s', 0)
    allowed_min, allowed_max = max(low, mean - tolerance), min(high, mean + tolerance)
    report.update(full_duration_tolerance_s=tolerance,
                  allowed_min_duration_s=allowed_min, allowed_max_duration_s=allowed_max,
                  target_range_feasible=allowed_min <= allowed_max + 1e-9)
    return report


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('structure',type=Path)
    p.add_argument('--references','--selected6',dest='selected6',required=True,type=Path)
    p.add_argument('--out',required=True,type=Path)
    a=p.parse_args()
    try:
        report=inspect_structure(a.structure,a.selected6)
        write_plan(a.out,report)
        if not report['target_range_feasible']:
            p.exit(1,'Target range does not intersect structure range; obtain a scoped duration decision.\n')
    except (OSError,ValueError,KeyError,TypeError,IndexError) as exc:
        p.exit(1,str(exc)+'\n')

if __name__=='__main__':main()
