#!/usr/bin/env python3
"""Request full audiovisual analysis from Gemini through the signed-in Antigravity CLI."""

import argparse
import json
import math
import shutil
import subprocess
import sys
import csv
from pathlib import Path

from common import FFMPEG, FFPROBE


def prepare_media(video):
    """Losslessly split oversized media; leave audiovisual interpretation to Gemini."""
    result = subprocess.run([FFPROBE, '-v', 'error', '-show_format', '-show_streams',
                             '-of', 'json', str(video)], capture_output=True, text=True, check=True)
    info = json.loads(result.stdout)
    duration = float(info['format']['duration'])
    streams = [{k: s.get(k) for k in ('codec_type', 'codec_name', 'width', 'height',
                                      'avg_frame_rate', 'sample_rate', 'channels')}
               for s in info['streams']]
    if video.stat().st_size < 95_000_000:
        return {'duration_s': duration, 'streams': streams,
                'parts': [{'path': str(video), 'start_s': 0, 'end_s': duration}]}
    folder = video.parent / 'gemini_media'
    folder.mkdir(exist_ok=True)
    index = folder / 'segments.csv'
    # Conservative size target handles variable bitrate; validate the actual output.
    segment_time = max(10, min(180, duration * 45_000_000 / video.stat().st_size))
    subprocess.run([FFMPEG, '-hide_banner', '-loglevel', 'error', '-y', '-i', str(video),
                    '-map', '0:v:0', '-map', '0:a?', '-c', 'copy', '-f', 'segment',
                    '-segment_time', str(segment_time), '-reset_timestamps', '1',
                    '-segment_list', str(index), '-segment_list_type', 'csv',
                    str(folder / 'part_%03d.mp4')], capture_output=True, text=True, check=True)
    parts = []
    with index.open(newline='') as handle:
        for name, start, end in csv.reader(handle):
            path = folder / Path(name).name
            if path.stat().st_size >= 95_000_000:
                raise ValueError('A lossless segment exceeds the media size limit: ' + str(path))
            parts.append({'path': str(path), 'start_s': float(start),
                          'end_s': min(float(end), duration)})
    manifest = {'duration_s': duration, 'streams': streams, 'lossless_stream_copy': True,
                'timestamp_note': 'Map local clip times to original times using start_s.', 'parts': parts}
    (folder / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    return manifest


ARRAY_FIELDS = ('cuts', 'captions', 'chrome', 'animations', 'film_overlays', 'layers', 'production_rules', 'uncertainties')
SCHEMA = {
    'type': 'object',
    'properties': {
        'video_read': {'type': 'boolean'},
        'audio_read': {'type': 'boolean'},
        'full_video_analyzed': {'type': 'boolean'},
        'method': {'type': 'string'},
        'coverage': {
            'type': 'object',
            'properties': {
                'duration_s': {'type': 'number'},
                'reviewed_ranges': {'type': 'array', 'items': {'type': 'object'}},
                'missing_ranges': {'type': 'array', 'items': {'type': 'object'}},
            },
            'required': ['duration_s', 'reviewed_ranges', 'missing_ranges'],
        },
        'audio': {'type': 'object'},
        **{key: {'type': 'array', 'items': {'type': 'object'}} for key in ARRAY_FIELDS},
    },
}
RANGE = {'type': 'object', 'properties': {'start_s': {'type': 'number'}, 'end_s': {'type': 'number'}}, 'required': ['start_s', 'end_s']}
SCHEMA['properties']['coverage']['properties']['reviewed_ranges']['items'] = RANGE
SCHEMA['properties']['cuts']['items'] = {
    'type': 'object', 'properties': {**RANGE['properties'], 'id': {'type': 'string'}},
    'required': ['id', 'start_s', 'end_s'],
}
for field in ('animations', 'film_overlays'):
    SCHEMA['properties'][field]['items'] = {
        'type': 'object',
        'properties': {'cut_id': {'type': 'string'},
                       'presence': {'type': 'string', 'enum': ['present', 'absent', 'unknown']},
                       'events': {'type': 'array', 'items': {'type': 'object'}}},
        'required': ['cut_id', 'presence', 'events'],
    }
SCHEMA['properties']['audio'] = {
    'type': 'object', 'properties': {k: {'type': 'array', 'items': {'type': 'object'}} for k in ('bgm', 'sfx')},
    'required': ['bgm', 'sfx'],
}
SCHEMA['properties']['layers']['items'] = {
    'type': 'object',
    'properties': {
        'cut_id': {'type': 'string'},
        'status': {'type': 'string', 'enum': ['observed', 'inferred', 'unknown']},
        'stack': {'type': 'array', 'items': {'type': 'object', 'properties': {
            'layer_id': {'type': 'string'}, 'role': {'type': 'string'},
            'evidence': {'type': 'string'}, 'confidence': {'type': 'number', 'minimum': 0, 'maximum': 1}},
            'required': ['layer_id', 'role', 'evidence', 'confidence']}},
        'reconstruction': {'type': 'string'}, 'uncertainty': {'type': 'string'},
    },
    'required': ['cut_id', 'status', 'stack', 'reconstruction', 'uncertainty'],
}
SCHEMA['required'] = list(SCHEMA['properties'])


def covers(ranges, duration):
    """Structural coverage only; does not independently interpret the video."""
    if not isinstance(ranges, list) or not ranges:
        return False
    spans = []
    for r in ranges:
        if not isinstance(r, dict):
            return False
        start, end = r.get('start_s'), r.get('end_s')
        if any(type(v) not in (int, float) or not math.isfinite(v) for v in (start, end)):
            return False
        if not 0 <= start < end <= duration + 0.001:
            return False
        spans.append((start, end))
    cursor = 0
    for start, end in sorted(spans):
        if start > cursor + 0.001:
            return False
        cursor = max(cursor, end)
    return cursor >= duration - 0.001


def complete(data):
    """Check structural completeness; Gemini owns visual/audio interpretation."""
    if not isinstance(data, dict) or any(k not in data for k in SCHEMA['required']):
        return False
    if any(data.get(k) is not True for k in ('video_read', 'audio_read', 'full_video_analyzed')):
        return False
    coverage = data.get('coverage')
    if not isinstance(coverage, dict):
        return False
    duration = coverage.get('duration_s')
    if type(duration) not in (int, float) or not math.isfinite(duration) or duration <= 0:
        return False
    if coverage.get('missing_ranges') != [] or not covers(coverage.get('reviewed_ranges'), duration):
        return False
    if any(not isinstance(data.get(k), list) for k in ARRAY_FIELDS):
        return False
    if not covers(data['cuts'], duration):
        return False
    ids = [cut.get('id') for cut in data['cuts']]
    if any(not isinstance(i, str) or not i for i in ids) or len(set(ids)) != len(ids):
        return False
    for field in ('animations', 'film_overlays'):
        entries = data[field]
        if len(entries) != len(ids) or any(not isinstance(e, dict) for e in entries):
            return False
        linked = [e.get('cut_id') for e in entries]
        if any(not isinstance(i, str) for i in linked) or set(linked) != set(ids):
            return False
        for e in entries:
            if e.get('presence') not in ('present', 'absent', 'unknown') or not isinstance(e.get('events'), list):
                return False
            if e['presence'] == 'present' and not e['events']:
                return False
            if e['presence'] == 'absent' and e['events']:
                return False
    layers = data['layers']
    if len(layers) != len(ids) or any(not isinstance(e, dict) for e in layers):
        return False
    links = [e.get('cut_id') for e in layers]
    if any(not isinstance(i, str) for i in links) or set(links) != set(ids):
        return False
    for e in layers:
        if e.get('status') not in ('observed', 'inferred', 'unknown') or not isinstance(e.get('stack'), list):
            return False
        if not isinstance(e.get('reconstruction'), str) or not isinstance(e.get('uncertainty'), str):
            return False
        if e['status'] == 'unknown' and not e['uncertainty'].strip():
            return False
        if e['status'] != 'unknown' and (not e['stack'] or not e['reconstruction'].strip()):
            return False
        seen = set()
        for layer in e['stack']:
            if not isinstance(layer, dict):
                return False
            if any(not isinstance(layer.get(k), str) or not layer[k].strip() for k in ('layer_id', 'role', 'evidence')):
                return False
            confidence = layer.get('confidence')
            if type(confidence) not in (int, float) or not 0 <= confidence <= 1:
                return False
            if layer['layer_id'] in seen:
                return False
            seen.add(layer['layer_id'])
    audio = data.get('audio')
    return (isinstance(audio, dict) and all(isinstance(audio.get(k), list) for k in ('bgm', 'sfx'))
            and bool(data['production_rules']))



def main():
    print('Retired: this skill now requires Astra analysis. Gemini dispatch is disabled.', file=sys.stderr)
    return 1


if __name__ == '__main__':
    raise SystemExit(main())
