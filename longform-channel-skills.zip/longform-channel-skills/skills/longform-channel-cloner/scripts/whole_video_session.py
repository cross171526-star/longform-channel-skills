#!/usr/bin/env python3
"""One whole video per persisted AGY conversation. Never split/upload short clips."""
import argparse
import fcntl
import json
from pathlib import Path
import time
import uuid
from media_transport import ask, digest, identity, save, TransportError
from common import probe

ACCESS_SCHEMA = {'type': 'object', 'properties': {
    'pixels_available': {'type': 'boolean'}, 'audio_available': {'type': 'boolean'},
    'full_video_accessible': {'type': 'boolean'},
    'observations': {'type': 'array', 'items': {'type': 'object', 'properties': {
        'start_s': {'type': 'number'}, 'end_s': {'type': 'number'},
        **{k: {'type': 'string'} for k in ('visual', 'exact_visible_text', 'movement', 'bgm', 'sfx')}},
        'required': ['start_s', 'end_s', 'visual', 'exact_visible_text', 'movement', 'bgm', 'sfx']}},
    'limitations': {'type': 'array', 'items': {'type': 'string'}}},
    'required': ['pixels_available', 'audio_available', 'full_video_accessible', 'observations', 'limitations']}

def access_ok(data, duration):
    if not isinstance(data, dict) or not all(data.get(k) is True for k in
        ('pixels_available', 'audio_available', 'full_video_accessible')):
        return False
    rows = data.get('observations', [])
    if data.get('limitations') or len(rows) < 3:
        return False
    for center in (min(5, duration / 10), duration / 2, max(0, duration - 8)):
        if not any(isinstance(r, dict) and type(r.get('start_s')) in (int, float)
                   and type(r.get('end_s')) in (int, float)
                   and 0 <= r['start_s'] <= center <= r['end_s'] <= duration + .1
                   and all(isinstance(r.get(k), str) and r[k].strip()
                           for k in ('visual', 'exact_visible_text', 'movement', 'bgm', 'sfx')) for r in rows):
            return False
    return True

def run(video, folder, model, timeout, question=None, schema=None):
    video, folder = video.resolve(), folder.resolve()
    folder.mkdir(parents=True, exist_ok=True)
    with (folder / 'lock').open('w') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise TransportError('SESSION_BUSY')
        ident = identity(model)
        signature = digest(video)
        path = folder / 'session.json'
        state = json.loads(path.read_text()) if path.exists() else {}
        if state and (state.get('media_sha256') != signature or state.get('identity') != ident):
            raise TransportError('INPUT_CHANGED_USE_NEW_SESSION_DIRECTORY')
        if video.stat().st_size > 100_000_000:
            raise TransportError('WHOLE_FILE_EXCEEDS_100MB_NO_SPLITTING_ALLOWED')
        info = probe(video)
        duration = info['duration_s']
        if not info['has_audio']:
            raise TransportError('NO_AUDIO_STREAM')
        call = folder / ('call-' + uuid.uuid4().hex)
        if not state.get('conversation_id'):
            prompt = (f'Read this WHOLE {duration:.3f}-second video ONCE. No splitting or file creation. '
                      f'Observe actual video and audio near 0-10, {duration/2-5:.2f}-{duration/2+5:.2f}, '
                      f'and {duration-15:.2f}-{duration-1:.2f} seconds. '
                      'Provide exact visible text, scenes, movement, actual BGM and SFX (explicitly absent if absent). '
                      'Do not infer audio from images or transcript. No narrator characteristics. '
                      'This tests WHOLE media access, not completion of editorial analysis. '
                      'Report limitations honestly.')
            data = ask(video, prompt, ACCESS_SCHEMA, call, model, timeout)
            result = json.loads((call / 'result.json').read_text())
            state = {'media': str(video), 'media_sha256': signature, 'identity': ident,
                     'duration_s': duration, 'conversation_id': result['conversation_id'],
                     'access_call': str(call), 'access_verified': access_ok(data, duration),
                     'analysis_complete': False, 'calls': [], 'created_at': time.time()}
            save(path, state)
        if not state.get('access_verified'):
            raise TransportError('WHOLE_VIDEO_ACCESS_UNVERIFIED')
        if question:
            if not isinstance(schema, dict):
                raise TransportError('RESPONSE_SCHEMA_REQUIRED')
            # Reuse native conversation context; no additional file read/upload permitted.
            data = ask(video, question, schema, call, model, timeout, state['conversation_id'])
            state['calls'].append({'path': str(call), 'saved_at': time.time()})
            save(path, state)
        return state

if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('video', type=Path)
    ap.add_argument('--session', type=Path, required=True)
    ap.add_argument('--model', default='gemini-3.8-flash-high')
    ap.add_argument('--timeout', type=int, default=240)
    ap.add_argument('--question-file', type=Path)
    ap.add_argument('--schema-file', type=Path)
    a = ap.parse_args()
    try:
        state = run(a.video, a.session, a.model, a.timeout,
                    a.question_file.read_text() if a.question_file else None,
                    json.loads(a.schema_file.read_text()) if a.schema_file else None)
        print(json.dumps({'session': str(a.session), 'access_verified': state['access_verified'],
                          'analysis_complete': state['analysis_complete']}))
    except TransportError as e:
        print(json.dumps({'status': 'blocked', 'reason': e.code}))
        raise SystemExit(2)
