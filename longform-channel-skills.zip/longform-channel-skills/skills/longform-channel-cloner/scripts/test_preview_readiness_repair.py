"""첫 출력 범위·후반 미확보·독립 주제판정·검토본 전달의 실제 경계 회귀."""
import copy,json,os,subprocess,unittest
from pathlib import Path
from unittest.mock import patch
from work_guard import digest
from quality_contract import validate,validate_topic,ready_topic,guard_tool
from workflow import check_handoff,review_draft

class PreviewReadinessRepair(unittest.TestCase):
 def early(self):
  from test_review_evidence import EarlyReview
  h=EarlyReview();h.setUp();self.addCleanup(h.doCleanups)
  c=json.loads(h.contract.read_text())
  manifest=h.write('planned-preview.json',{'cuts':[{'id':str(i),'duration_s':50} for i in range(5)],'output_scope':{'kind':'preview','start_s':0,'end_s':180}})
  c.update(readiness_version=2,output_scope={'kind':'preview','range_s':[0,180],'cut_ids':['0','1','2','3'],'manifest':h.bind(manifest)})
  for i,s in enumerate(c['pilot']['samples']):s.update(cut_id=str(i),absolute_range_s=[i*50,i*50+10])
  c['cuts'][4].update(material_readiness='deferred',unresolved_items=['actual source pending'])
  c['cuts'][4]['claims']=[{'kind':'episode_fact','text':'verified fact, future scene pending','new_topic_evidence':[h.bind(h.evidence)],'screen_is_evidence':True,'asset_relation':'actual_record','asset_evidence':[]}]
  h.contract.write_text(json.dumps(c));r=json.loads(h.pilot.read_text());r['contract_sha256']=digest(h.contract);r['observed_cut_ids']=['0','1','2']
  producer=Path(r['pilot_render_report']['path']);d=json.loads(producer.read_text());d['contract_sha256']=digest(h.contract)
  for i,s in enumerate(d['samples']):s.update(cut_id=str(i),absolute_frames_inclusive=[i*50,i*50+9])
  producer.write_text(json.dumps(d));r['pilot_render_report']=h.bind(producer)
  r['front_review'].update(plan_cut_ids=['0','1','2','3','4'],plan_semantics_passed=True,material_cut_ids=['0','1','2','3'],deferred_material_cut_ids=['4'])
  h.pilot.write_text(json.dumps(r));return h,manifest
 def test_pending_later_actual_record_does_not_block_preview_or_pass_later(self):
  h,m=self.early();r=validate(h.contract,h.pilot,True);self.assertTrue(r['passed'],r['errors']);self.assertEqual(r['deferred_cut_ids'],['4']);self.assertEqual(r['deferred_unresolved_items'],['actual source pending'])
 def test_current_source_unresolved_or_subset_scope_blocks(self):
  for change in ('unresolved','omit','whole_plan_not_reviewed'):
   h,m=self.early();c=json.loads(h.contract.read_text());r=json.loads(h.pilot.read_text())
   if change=='unresolved':c['cuts'][3]['unresolved_items']=['current source absent']
   elif change=='omit':c['output_scope']['cut_ids']=['0','1','2'];r['front_review']['material_cut_ids']=['0','1','2']
   else:r['front_review']['plan_cut_ids']=['0','1','2','3']
   h.contract.write_text(json.dumps(c));r['contract_sha256']=digest(h.contract);h.pilot.write_text(json.dumps(r))
   self.assertFalse(validate(h.contract,h.pilot,True)['passed'])
 def test_pending_later_source_blocks_full_output(self):
  h,m=self.early();c=json.loads(h.contract.read_text());value=json.loads(m.read_text());value['output_scope']={'kind':'full'};m.write_text(json.dumps(value))
  c['output_scope']={'kind':'full','range_s':[0,250],'cut_ids':['0','1','2','3','4'],'manifest':h.bind(m)};h.contract.write_text(json.dumps(c))
  r=json.loads(h.pilot.read_text());r['contract_sha256']=digest(h.contract);r['front_review'].update(material_cut_ids=['0','1','2','3','4'],deferred_material_cut_ids=[]);h.pilot.write_text(json.dumps(r))
  report=validate(h.contract,h.pilot,True);self.assertFalse(report['passed']);self.assertIn('actual source pending',report['unresolved_items'])
 def test_render_cannot_expand_approved_preview_scope(self):
  h,m=self.early();run=h.p/'run';(run/'work').mkdir(parents=True);(run/'run.json').write_text('{"scheduler_version":3,"front_review_version":2}')
  (run/'work/quality-contract.json').write_bytes(h.contract.read_bytes());(run/'work/pilot-review.json').write_bytes(h.pilot.read_bytes())
  guard_tool(run,'build_timeline',['--production-manifest',str(m)])
  value=json.loads(m.read_text());value['output_scope']={'kind':'full'};full=h.write('unapproved-full.json',value)
  with self.assertRaisesRegex(ValueError,'scope differs'):guard_tool(run,'build_timeline',['--production-manifest',str(full)])
  with self.assertRaisesRegex(ValueError,'manifest required'):guard_tool(run,'build_timeline',[])
 def topic(self):
  from test_topic_materials import TopicMaterials
  h=TopicMaterials();h.setUp();self.addCleanup(h.doCleanups)
  doc=copy.deepcopy(h.value);doc.update(semantic_review_version=2,difficult_scene_ids=['S'],reference_semantics={'analysis':h.bind(h.observed),'roles':[{'reference_role':'survival and rescue','candidate_role':'survival and rescue','matches':True,'evidence':[h.bind(h.source)]}]})
  h.doc.write_text(json.dumps(doc));log=h.p/'independent.jsonl';log.write_text(h.log.read_text().replace('researcher','independent'))
  review=h.write('work/topic-review.json',{'schema':'lfc-topic-semantic-review-v1','assessment_sha256':digest(h.doc),'request_sha256':digest(h.req),'reviewer_rollout':str(log),'session_id':'independent','reference_roles_reviewed':True,'story_fit_passed':True,'difficult_scenes_passed':True,'reviewed_scene_ids':['S'],'unresolved_items':[],'evidence':[h.bind(h.observed)]})
  return h,review
 def test_independent_semantics_required_and_rejects_self_or_wrong_story(self):
  h,r=self.topic();self.assertTrue(validate_topic(h.doc,h.req,r,True)['passed']);self.assertFalse(validate_topic(h.doc,h.req,None,True)['passed'])
  v=json.loads(r.read_text());v.update(reviewer_rollout=str(h.log),session_id='researcher');r.write_text(json.dumps(v));self.assertFalse(validate_topic(h.doc,h.req,r,True)['passed'])
  v['story_fit_passed']=False;r.write_text(json.dumps(v));self.assertFalse(validate_topic(h.doc,h.req,r,True)['passed'])
 def test_new_planning_freezes_independent_semantic_judgment(self):
  h,r=self.topic();(h.run/'run.json').write_text('{"scheduler_version":3,"topic_materials_version":2}')
  ready=ready_topic(h.run);self.assertTrue(ready['passed']);self.assertIn(str(r),ready['dependencies_sha256']);r.unlink()
  with self.assertRaises(ValueError):ready_topic(h.run)
 def handoffs(self):
  from test_efficiency_contracts import HandoffTests
  h=HandoffTests();h.setUp();self.addCleanup(h.doCleanups)
  a=h.packet('analysis');p=h.packet('planning',a);q=h.packet('production',p);return h,p,q
 def test_legacy_handoff_recursion_does_not_apply_new_run_topic_gate(self):
  h,p,q=self.handoffs();run=h.p/'new-run';run.mkdir();(run/'run.json').write_text('{"scheduler_version":3,"topic_materials_version":2}')
  with patch.dict(os.environ,{'LFC_RUN_DIR':str(run)}):
   self.assertTrue(check_handoff(q)['passed']);self.assertFalse(check_handoff(p)['passed'])
 def test_review_draft_real_media_technical_binding_and_false_completion(self):
  h,p,q=self.handoffs();doc=json.loads(q.read_text());row=next(x for x in doc['files'] if x['role']=='render');video=h.p/'actual.mp4'
  subprocess.run([str(Path.home()/'.longform-cloner/bin/ffmpeg'),'-v','error','-f','lavfi','-i','color=c=blue:s=32x18:r=1:d=1','-c:v','libx264',str(video)],check=True)
  old=row['path'];row.update(path=str(video),sha256=digest(video));validation=next(x for x in doc['files'] if x['role']=='numeric_validation');vp=Path(validation['path']);v=json.loads(vp.read_text());v['output_sha256']={str(video):digest(video)};vp.write_text(json.dumps(v));validation['sha256']=digest(vp);q.write_text(json.dumps(doc))
  preflight=h.write('preflight.json',{'passed':True,'capabilities':{'direct_listening':{'status':'unsupported'},'continuous_playback':{'status':'unsupported'}}})
  result=review_draft(q,preflight);self.assertTrue(result['passed']);self.assertFalse(result['completion_passed']);self.assertFalse(result['content_completion_eligible']);self.assertIn('direct_listening',result['unresolved_items']);self.assertEqual(result['render']['sha256'],digest(video))
  video.write_bytes(b'corrupt media')
  with self.assertRaises(ValueError):review_draft(q,preflight)

if __name__=='__main__':unittest.main()
