"""Check actual Remotion props with the scheduler used by Main, before rendering.

run.sh check_render_timing reference_map.json --out render_timing_check.json
This verifies frame timing, not visual faithfulness or uninstrumented renderers.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path
import shutil
import subprocess

TEMPLATE = Path(__file__).resolve().parent.parent / 'assets/remotion-template'


def renderer_dependencies():
    return sorted([p.resolve() for p in (TEMPLATE / 'src').rglob('*') if p.is_file()] +
                  [(TEMPLATE / n).resolve() for n in ('package.json', 'package-lock.json', 'remotion.config.ts', 'tsconfig.json') if (TEMPLATE / n).is_file()])


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def frame(seconds, fps):
    return math.floor(seconds * fps + .5)  # JS Math.round for non-negative timestamps


def validate_render_timing(manifest_path, context=None):
    read_file = context.document if context else read
    hash_file = context.digest if context else digest
    path = Path(manifest_path).resolve()
    manifest = read_file(path)
    config = manifest.get('render_timing')
    if not isinstance(config, dict) or config.get('kind') != 'remotion-template':
        raise ValueError('Missing/unsupported render_timing.kind; a real renderer adapter is required')
    if not isinstance(config.get('props'), str) or not config['props']:
        raise ValueError('Missing render_timing.props')
    props_path = (path.parent / config['props']).resolve()
    compiled_path = (path.parent / manifest['compiled_timeline']).resolve()
    inputs = {(path.parent / n).resolve() for n in manifest['render_inputs']}
    dependencies = renderer_dependencies()
    for required in [props_path, *dependencies]:
        if required not in inputs:
            raise ValueError('Render timing dependency missing from render_inputs: ' + str(required))
    compiled, props = read_file(compiled_path), read_file(props_path)
    if compiled.get('source_manifest_sha256') != hash_file(path):
        raise ValueError('Render timing requires freshly compiled manifest')
    node = shutil.which('node')
    if not node:
        raise ValueError('Node.js is required to inspect the actual Remotion scheduler')
    script = "const t=require(process.argv[1]);const p=JSON.parse(require('fs').readFileSync(process.argv[2],'utf8'));const s=require(process.argv[3]);for(const c of p.cuts){if(c.diagnostic_only)throw Error('Diagnostic fixture cannot enter production');s.validateScenes(c.renderer_layers??[],c.end_s-c.start_s);}process.stdout.write(JSON.stringify({cuts:t.cutSchedule(p),frames:t.compositionFrames(p),scenes:p.cuts.map(c=>({authored:s.authoredScene(c.renderer_layers??[]),media:s.sceneMedia(c.renderer_layers??[]),fonts:s.sceneFonts(c.renderer_layers??[])}))}));"
    result = subprocess.run([node, '-e', script, str(TEMPLATE / 'src/cutTiming.cjs'), str(props_path), str(TEMPLATE / 'src/sceneContract.cjs')],
                            capture_output=True, text=True, timeout=30)
    if result.returncode:
        raise ValueError('Remotion schedule failed: ' + result.stderr[-1500:])
    scheduled = json.loads(result.stdout)
    fps = props['fps']
    if [props.get('width'), props.get('height')] != manifest['canvas']:
        raise ValueError('Render props canvas differs from plan')
    scope = compiled['output_bounds']
    if scope['start_s'] != 0:
        raise ValueError('Only start-at-zero output is supported')
    if scheduled['frames'] != frame(scope['end_s'], fps):
        raise ValueError('Render composition frame count differs from output scope')
    expected = [c for c in compiled['cuts'] if c['output_clip'] is not None]
    if [c['id'] for c in expected] != [c['id'] for c in scheduled['cuts']]:
        raise ValueError('Render cut count/order differs from visible planned clips')
    checked = []
    for i, (cut, actual) in enumerate(zip(expected, scheduled['cuts'])):
        authored = (cut.get('layers') or {}).get('renderer_layers', [])
        scene = scheduled['scenes'][i]
        if scene['authored'] != authored:
            raise ValueError(cut['id'] + ': independent renderer layers differ from compiled plan')
        planned_assets = {(path.parent / a['path']).resolve(): a for a in cut.get('assets', [])}
        for asset in scene['media']:
            source = Path(asset['source_path']).resolve()
            copied = (props_path.parent / 'public' / asset.get('file', '')).resolve()
            if source not in planned_assets or planned_assets[source]['media_kind'] != asset['kind']:
                raise ValueError(cut['id'] + ': overlay source/kind missing from planned assets')
            if source not in inputs or copied not in inputs or hash_file(source) != asset['sha256'] or hash_file(copied) != asset['sha256']:
                raise ValueError(cut['id'] + ': independent layer source/copy/hash mismatch')
        for font in scene['fonts']:
            source = Path(font['source_path']).resolve()
            matches = [f for f in props.get('fonts', []) if f['family'] == font['family']]
            if len(matches) != 1:
                raise ValueError(cut['id'] + ': independent layer font not loaded exactly once')
            copied = (props_path.parent / 'public' / matches[0]['file']).resolve()
            if source not in inputs or copied not in inputs or hash_file(source) != font['sha256'] or hash_file(copied) != font['sha256']:
                raise ValueError(cut['id'] + ': independent layer font hash mismatch')
        # Require media identity in production manifests; timing-only fixtures can omit assets.
        if cut.get('assets'):
            asset = props['cuts'][i].get('asset', {})
            source = Path(asset.get('source_path', '')).resolve()
            actual_file = (props_path.parent / 'public' / asset.get('file', '')).resolve()
            planned = {(path.parent / a['path']).resolve() for a in cut['assets'] if a.get('primary')}
            if not planned or source not in planned:
                raise ValueError(cut['id'] + ': renderer source differs from primary asset')
            if source not in inputs or actual_file not in inputs:
                raise ValueError(cut['id'] + ': source/copy missing from render_inputs')
            if not asset.get('sha256') or hash_file(source) != asset['sha256'] or hash_file(actual_file) != asset['sha256']:
                raise ValueError(cut['id'] + ': renderer media hash mismatch')
        start, end = frame(cut['start_s'], fps), frame(cut['end_s'], fps)
        if actual['from'] != start or actual['end'] != end:
            raise ValueError(cut['id'] + ': actual renderer frames differ from planned clip')
        if i and actual['from'] != scheduled['cuts'][i-1]['end']:
            raise ValueError('Gap/overlap in render clip occupancy')
        planned_transition = {'type': 'cut', 'frames': 0, **cut.get('transition_in', {})}
        observed_transition = {'type': 'cut', 'frames': 0, **props['cuts'][i].get('transition_in', {})}
        if planned_transition != observed_transition:
            raise ValueError(cut['id'] + ': renderer transition differs from confirmed transition_in')
        transition_frames = observed_transition.get('frames', 0)
        if not isinstance(transition_frames, int) or isinstance(transition_frames, bool) or not 0 <= transition_frames <= end-start:
            raise ValueError(cut['id'] + ': invalid transition duration')
        if i == 0 and actual['from'] != 0:
            raise ValueError('Render starts with an unplanned gap')
        checked.append({**actual, 'output_end_frame': min(end, scheduled['frames']),
                        'planned_duration_s': cut['duration_s'],
                        'frame_quantization_delta_s': (end-start)/fps-cut['duration_s']})
    if not checked:
        raise ValueError('No visible render clips')
    template_hash = hashlib.sha256(''.join(str(p.relative_to(TEMPLATE)) + ':' + hash_file(p) for p in dependencies).encode()).hexdigest()
    return {'passed': True, 'kind': 'remotion-template', 'props_sha256': hash_file(props_path),
            'compiled_sha256': hash_file(compiled_path), 'template_sha256': template_hash,
            'fps': fps, 'output_frames': scheduled['frames'], 'cuts': checked,
            'visual_accuracy_verified': False,
            'quantization': 'Endpoints rounded to nearest frame; no additional duration percentage allowed'}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('manifest', type=Path)
    p.add_argument('--out', required=True, type=Path)
    a = p.parse_args()
    try:
        report = validate_render_timing(a.manifest)
        a.out.parent.mkdir(parents=True, exist_ok=True)
        a.out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError) as exc:
        p.exit(1, str(exc) + '\n')


if __name__ == '__main__':
    main()
