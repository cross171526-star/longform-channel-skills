#!/usr/bin/env python3
"""Compare measurable parts of a recreation against the reference segment.

  run.sh compare --reference <source.mp4> --range 0:30 --recreation <output.mp4> --edl <edl.json> --out DIR

Produces DIR/compare.json and DIR/side_by_side.mp4 (reference left, recreation right, with timecode), and
DIR/pairs_###.jpg frame pairs at every cut midpoint. Checks (fail thresholds in brackets):
  - cut boundaries: detected cuts in the recreation vs EDL/ref cut times [> 1 frame off]
  - rendered duration vs reference range [> 2 frames off]
  - text: OCR boxes of the recreation vs reference caption boxes
  - credits: text present in recreation where reference has none, or missing where reference has one
  - audio: integrated loudness difference [> 2 LU]
Motion, visual effects, music identity and SFX timing require manual side-by-side review.
The automatic PASS is only a prerequisite, not a completion verdict.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import cv2
import numpy as np

from common import (FFMPEG, bbox_iou, extract_wav, grab_frames, grid, iter_frames, label_image, lufs, parse_range,
                    probe, read_json, resize_w, run, vision_ocr, write_json)


def cut_times(video, t0, t1):
    from scenedetect import AdaptiveDetector, FrameTimecode
    info = probe(video)
    fps = info["fps"]
    det = AdaptiveDetector(adaptive_threshold=3.0, min_scene_len=max(2, int(0.25 * fps)))
    f0, f1 = int(t0 * fps), int(t1 * fps)
    last = f0
    cuts = []
    for i, fr in iter_frames(video, f0, f1, width=320):
        cuts += [c.frame_num for c in det.process_frame(FrameTimecode(i, fps), fr) or []]
        last = i
    cuts += [c.frame_num for c in det.post_process(FrameTimecode(last + 1, fps)) or []]
    return sorted((c - f0) / fps for c in cuts if f0 < c <= last), fps


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--reference", required=True)
    ap.add_argument("--range", default="0:30")
    ap.add_argument("--recreation", required=True)
    ap.add_argument("--edl", required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    edl = read_json(a.edl)
    ref_info = probe(a.reference)
    t0, t1 = parse_range(a.range, ref_info["duration_s"])
    rep = {"range": [t0, t1]}
    # 1. cut timing
    rec_cuts, rfps = cut_times(a.recreation, 0, t1 - t0)
    want = [c["start_s"] for c in edl["cuts"][1:] if c["transition_in"]["type"] == "cut"]
    fr = 1 / edl["fps"]
    diffs = []
    for w in want:
        near = min(rec_cuts, key=lambda x: abs(x - w)) if rec_cuts else None
        diffs.append({"expected_s": w, "found_s": near, "off_frames": None if near is None else round((near - w) / fr, 2)})
    bad = [d for d in diffs if d["off_frames"] is None or abs(d["off_frames"]) > 1]
    rep["cuts"] = {"expected": len(want), "detected": len(rec_cuts), "bad": bad, "all": diffs}
    # 2. text layout at each text midpoint
    fps_ref = ref_info["fps"]
    rec_info = probe(a.recreation)
    rep["duration_off_s"] = round(rec_info["duration_s"] - (t1 - t0), 3)
    texts = edl.get("texts", [])
    mids = [(t["start_s"] + t["end_s"]) / 2 for t in texts]
    ref_frames = grab_frames(a.reference, [int((t0 + m) * fps_ref) for m in mids])
    rec_frames = grab_frames(a.recreation, [int(m * rec_info["fps"]) for m in mids])
    tres = []
    for t, m in zip(texts, mids):
        rf = rec_frames.get(int(m * rec_info["fps"]))
        if rf is None:
            continue
        ocr = vision_ocr(resize_w(rf, 800))
        want_box = t["style"]["bbox"]
        # OCR may split one rendered line into fragments: merge all boxes on the expected line
        cy = want_box[1] + want_box[3] / 2
        line = [o for o in ocr if abs((o["bbox"][1] + o["bbox"][3] / 2) - cy) < want_box[3] * 0.6]
        if line:
            x0 = min(o["bbox"][0] for o in line)
            y0 = min(o["bbox"][1] for o in line)
            x1 = max(o["bbox"][0] + o["bbox"][2] for o in line)
            y1 = max(o["bbox"][1] + o["bbox"][3] for o in line)
            best = {"bbox": [x0, y0, x1 - x0, y1 - y0], "text": " ".join(o["text"] for o in sorted(line, key=lambda o: o["bbox"][0]))}
        else:
            best = max(ocr, key=lambda o: bbox_iou(o["bbox"], want_box), default=None)
        iou = bbox_iou(best["bbox"], want_box) if best else 0.0
        hr = best["bbox"][3] / want_box[3] if best and want_box[3] else None
        dy = ((best["bbox"][1] + best["bbox"][3] / 2) - (want_box[1] + want_box[3] / 2)) * 1080 if best else None
        dx = ((best["bbox"][0] + best["bbox"][2] / 2) - (want_box[0] + want_box[2] / 2)) * 1920 if best else None
        tres.append({"id": t["id"], "iou": round(iou, 3), "height_ratio": round(hr, 3) if hr else None,
                     "center_dx_px": round(dx, 1) if dx is not None else None,
                     "center_dy_px": round(dy, 1) if dy is not None else None,
                     "ocr": best["text"] if best else None, "expected": t["text"]})
    # a different font changes glyph width and OCR box height a little (font may differ by design); position
    # and size must still match: centre within 8 px, OCR height within 15 %
    rep["texts"] = {"checked": len(tres), "bad": [x for x in tres if x["iou"] < 0.55 or x["center_dy_px"] is None
                                                   or abs(x["center_dy_px"]) > 8 or abs(x["center_dx_px"]) > 12
                                                   or (x["height_ratio"] and abs(x["height_ratio"] - 1) > 0.15)],
                    "all": tres}
    # 3. credits: any small corner text in recreation where the EDL shows no credit
    cred_issues = []
    for c in edl["cuts"]:
        m = (c["start_s"] + c["end_s"]) / 2
        rf = grab_frames(a.recreation, [int(m * rec_info["fps"])]).get(int(m * rec_info["fps"]))
        if rf is None:
            continue
        small = [o["text"] for o in vision_ocr(resize_w(rf, 800)) if o["bbox"][3] < 0.035 and o["conf"] > 0.5]
        if small and not c["credit"]["shown"]:
            cred_issues.append({"cut": c["id"], "issue": "small text present but reference shows no credit (source footage text?)", "text": small})
        if c["credit"]["shown"] and not small:
            cred_issues.append({"cut": c["id"], "issue": "reference shows a credit but none detected"})
    rep["credits"] = cred_issues
    # 4. audio
    ref_wav = extract_wav(a.reference, out / "ref.wav", 48000, 1, t0, t1)
    rec_wav = extract_wav(a.recreation, out / "rec.wav", 48000, 1)
    rep["audio"] = {"ref_lufs": lufs(ref_wav), "rec_lufs": lufs(rec_wav)}
    if rep["audio"]["ref_lufs"] is not None and rep["audio"]["rec_lufs"] is not None:
        rep["audio"]["diff_lu"] = round(rep["audio"]["rec_lufs"] - rep["audio"]["ref_lufs"], 2)
    # 5. visual pairs + side by side
    ref_mid = grab_frames(a.reference, [int((t0 + (c["start_s"] + c["end_s"]) / 2) * fps_ref) for c in edl["cuts"]], width=480)
    rec_mid = grab_frames(a.recreation, [int((c["start_s"] + c["end_s"]) / 2 * rec_info["fps"]) for c in edl["cuts"]], width=480)
    tiles = []
    for c in edl["cuts"]:
        r1 = ref_mid.get(int((t0 + (c["start_s"] + c["end_s"]) / 2) * fps_ref))
        r2 = rec_mid.get(int((c["start_s"] + c["end_s"]) / 2 * rec_info["fps"]))
        if r1 is None or r2 is None:
            continue
        tiles += [label_image(r1.copy(), f"REF {c['id']}", 0.45), label_image(r2.copy(), f"NEW {c['id']}", 0.45)]
    for k in range(0, len(tiles), 16):
        cv2.imwrite(str(out / f"pairs_{k // 16 + 1:03d}.jpg"), grid(tiles[k:k + 16], 4))
    run([FFMPEG, "-hide_banner", "-loglevel", "error", "-y", "-ss", f"{t0}", "-to", f"{t1}", "-i", a.reference,
         "-i", a.recreation, "-filter_complex",
         "[0:v]scale=960:540,setsar=1[a];[1:v]scale=960:540,setsar=1[b];[a][b]hstack=inputs=2,"
         "drawtext=text='%{pts\\:hms}':x=10:y=10:fontsize=28:fontcolor=white:box=1:boxcolor=black@0.5[v]",
         "-map", "[v]", "-map", "0:a?", "-c:v", "libx264", "-crf", "23", "-preset", "fast", "-shortest",
         str(out / "side_by_side.mp4")])
    ok = (not rep["cuts"]["bad"] and not rep["texts"]["bad"] and not rep["credits"]
          and abs(rep["audio"].get("diff_lu") or 0) <= 2 and abs(rep["duration_off_s"]) <= max(0.1, 2 / rec_info["fps"]))
    rep["pass"] = ok
    write_json(out / "compare.json", rep)
    print(f"cuts bad {len(rep['cuts']['bad'])}/{len(want)}, texts bad {len(rep['texts']['bad'])}/{len(tres)}, "
          f"credit issues {len(cred_issues)}, loudness diff {rep['audio'].get('diff_lu')} LU -> pass={ok}")
    print(f"report {out / 'compare.json'}, video {out / 'side_by_side.mp4'}, pairs {out}/pairs_*.jpg")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
