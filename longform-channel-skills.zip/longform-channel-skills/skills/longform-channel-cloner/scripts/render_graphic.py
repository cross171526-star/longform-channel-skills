#!/usr/bin/env python3
"""Rebuild a generated-graphic cut (table, chart, number card, quote card, title card) in the donor's layout.

  run.sh render_graphic --spec <spec.json> --out <clip.mp4> --seconds S [--preview preview.png]
  run.sh render_graphic --needs NEW/needs.json --key new:n012 --out NEW/clips/n012.mp4   (spec from needs.json)

Spec = needs.json["<key>"]["graphic_spec"] (written by plan_video) with "new_text" filled per element:
  {"donor_frame": "...jpg", "elements": [{"ref_text", "new_text", "bbox":[x,y,w,h] (0-1), "font_px", "color",
   "outline", "box", "align", "appear_s", "anim_in", "font"}], "background": {...optional overrides}}
Background: by default the donor frame with every donor text element inpainted away (keeps the donor's plate,
colours, texture, table grid and shapes). That background is measurement-derived from the reference, so it may
only be used when the cut is a plain generated graphic (no photos/footage/logos of the reference inside) - check
the preview. Otherwise set "background": {"mode": "flat", "color": "#hex"} or {"mode": "image", "path": ...}
(e.g. a stock/AI plate) and describe the shapes in "shapes": [{"type": "rect"|"line"|"ellipse", "box":[...],
"color": "#hex", "width": px, "radius": px, "appear_s": s, "grow": "right"|"up"|"none"}].
Elements with new_text null are dropped (not copied from the reference). Entrance animation per element:
none | fade | pop_scale | slide_up | typewriter | wipe (measured anim_in from captions).
"""
from __future__ import annotations

import argparse
import json
import subprocess
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

from common import FFMPEG, LFC_HOME, read_json

W, H, FPS = 1920, 1080, 30000 / 1001
DEFAULT_FONT = LFC_HOME / "fonts" / "Pretendard-Bold.otf"


def font(path, size):
    p = Path(path) if path and Path(path).exists() else DEFAULT_FONT
    return ImageFont.truetype(str(p), max(8, int(size)))


def ease(t):
    t = min(1.0, max(0.0, t))
    return 1 - (1 - t) ** 3


def background(spec):
    bg = spec.get("background") if isinstance(spec.get("background"), dict) else {"mode": "donor"}
    mode = bg.get("mode", "donor")
    if mode == "flat":
        return Image.new("RGB", (W, H), bg.get("color", "#111111"))
    if mode == "image":
        im = Image.open(bg["path"]).convert("RGB")
        s = max(W / im.width, H / im.height)
        im = im.resize((int(im.width * s + 1), int(im.height * s + 1)), Image.LANCZOS)
        l, t = (im.width - W) // 2, (im.height - H) // 2
        return im.crop((l, t, l + W, t + H))
    fr = cv2.imread(spec["donor_frame"])
    fr = cv2.resize(fr, (W, H), interpolation=cv2.INTER_CUBIC)
    out = fr.copy()
    rects = []
    dirty = []  # every text box seen so far (donor elements, erase list, residual OCR)

    def add(box, font_px=None):
        x, y, w, h = box
        lh = max(h * H, (font_px or 0) * 1.15)
        cy = (y + h / 2) * H
        padx, pady = int(0.3 * lh) + 4, int(0.22 * lh) + 3
        rects.append((max(0, int(x * W) - padx), max(0, int(cy - lh / 2) - pady),
                      min(W, int((x + w) * W) + padx), min(H, int(cy + lh / 2) + pady)))

    def find_patch(hh, pw, ring):
        """Clean patch anywhere in the frame (outside all text boxes) with the ring's brightness and texture."""
        if hh >= H or pw >= W:
            return None
        m, sd = ring.mean(0), float(ring.std())
        best, score = None, 1e9
        for sy in range(0, H - hh, max(8, hh // 2)):
            for sx in range(0, W - pw, max(16, pw // 3)):
                if overlaps((sx, sy, sx + pw, sy + hh), dirty):
                    continue
                c = out[sy:sy + hh, sx:sx + pw].astype(np.float32)
                g = c.mean(-1)
                # reject patches containing straight lines (table rules, borders): strong row/col mean steps
                if float(np.abs(np.diff(g.mean(1))).max(initial=0)) > 6 or float(np.abs(np.diff(g.mean(0))).max(initial=0)) > 6:
                    continue
                d = float(np.abs(c.reshape(-1, 3).mean(0) - m).mean()) + abs(float(c.std()) - sd)
                if d < score:
                    best, score = c, d
        return best.astype(np.uint8) if best is not None and score < 20 else None

    def tile_fill(tile, ww):
        th, tw = tile.shape[:2]
        if tw >= ww:
            return tile[:, :ww]
        f = min(24, tw // 4)
        res = tile.astype(np.float32)
        while res.shape[1] < ww:
            a = np.linspace(1, 0, f)[None, :, None]
            seam = res[:, -f:] * a + tile[:, :f].astype(np.float32) * (1 - a)
            res = np.concatenate([res[:, :-f], seam, tile[:, f:].astype(np.float32)], 1)
        return res[:, :ww].astype(np.uint8)

    def overlaps(r, rs):
        return any(not (r[2] <= q[0] or q[2] <= r[0] or r[3] <= q[1] or q[3] <= r[1]) for q in rs)

    def clear(rs):
        """Fill each text box from its surroundings:
        truly flat border (std < 3: solid table cells, cards, plates) -> exact colour;
        textured border (paper, noise, vignette) -> tiled clean patch from elsewhere in the frame, brightness
        matched to the border and feathered; nothing suitable -> Telea inpaint."""
        tele = np.zeros((H, W), np.uint8)
        for x0, y0, x1, y1 in rs:
            if x1 - x0 < 2 or y1 - y0 < 2:
                continue
            parts = [out[max(0, y0 - 3):y0, x0:x1], out[y1:min(H, y1 + 3), x0:x1],
                     out[y0:y1, max(0, x0 - 3):x0], out[y0:y1, x1:min(W, x1 + 3)]]
            ring = np.concatenate([p_.reshape(-1, 3) for p_ in parts if p_.size]).astype(np.float32)
            if not ring.size:
                tele[y0:y1, x0:x1] = 255
                continue
            if float(ring.std(0).max()) < 3:
                out[y0:y1, x0:x1] = np.median(ring, 0).astype(np.uint8)
                continue
            hh, ww = y1 - y0, x1 - x0
            tile = find_patch(hh, min(ww, 400), ring)
            if tile is None:
                tele[y0:y1, x0:x1] = 255
                continue
            fill = tile_fill(tile, ww).astype(np.float32)
            fill += ring.mean(0) - fill.reshape(-1, 3).mean(0)  # match brightness/colour of the border
            f = max(1, min(6, hh // 4, ww // 4))
            a = np.ones((hh, ww, 1), np.float32)
            ramp = np.linspace(0, 1, f + 1)[1:]
            a[:f] *= ramp[:, None, None]; a[-f:] *= ramp[::-1][:, None, None]
            a[:, :f] *= ramp[None, :, None]; a[:, -f:] *= ramp[::-1][None, :, None]
            cur = out[y0:y1, x0:x1].astype(np.float32)
            base = np.broadcast_to(np.median(ring, 0), cur.shape)
            out[y0:y1, x0:x1] = np.clip(fill * a + base * (1 - a), 0, 255).astype(np.uint8)
        if tele.any():
            out[:] = cv2.inpaint(out, tele, 5, cv2.INPAINT_TELEA)

    for e in spec.get("elements", []):
        add(e["bbox"], e.get("font_px"))
    for r in bg.get("erase", []):
        add(r)
    try:
        from common import vision_ocr
        for o in vision_ocr(fr):
            if o.get("conf", 1) >= 0.3:
                add(o["bbox"])
    except Exception:
        pass
    dirty.extend(rects)
    clear(rects)
    # residual text (OCR misses, different-colour words): OCR the result and clear what is left
    try:
        from common import vision_ocr
        for _ in range(2):
            left = [o for o in vision_ocr(out) if o.get("conf", 1) >= 0.3]
            if not left:
                break
            rects = []
            for o in left:
                add(o["bbox"])
            dirty.extend(rects)
            clear(rects)
    except Exception as ex:
        print(f"note: residual OCR skipped ({ex})")
    return Image.fromarray(cv2.cvtColor(out, cv2.COLOR_BGR2RGB))


def draw_shapes(img, spec, t):
    d = ImageDraw.Draw(img, "RGBA")
    for sh in spec.get("shapes", []):
        a0 = sh.get("appear_s", 0.0)
        if t < a0:
            continue
        p = ease((t - a0) / max(0.01, sh.get("grow_s", 0.8))) if sh.get("grow", "none") != "none" else 1.0
        x, y, w, h = [v * (W if i % 2 == 0 else H) for i, v in enumerate(sh["box"])]
        if sh.get("grow") == "right":
            w *= p
        elif sh.get("grow") == "up":
            y, h = y + h * (1 - p), h * p
        col = sh.get("color", "#ffffff")
        if sh["type"] == "rect":
            d.rounded_rectangle((x, y, x + max(1, w), y + max(1, h)), radius=sh.get("radius", 0), fill=col)
        elif sh["type"] == "line":
            d.line((x, y, x + w, y + h), fill=col, width=int(sh.get("width", 3)))
        elif sh["type"] == "ellipse":
            d.ellipse((x, y, x + w, y + h), outline=col, width=int(sh.get("width", 4)))


def draw_text(img, e, t):
    txt = e.get("new_text")
    if not txt:
        return
    a0 = e.get("appear_s", 0.0)
    if t < a0:
        return
    an = e.get("anim_in") or "none"
    p = ease((t - a0) / 0.3)
    x, y, w, h = e["bbox"]
    size = e.get("font_px") or h * H / 1.15
    f = font(e.get("font"), size)
    # shrink to the donor box width (new text may be longer)
    tw = f.getlength(txt)
    if tw > w * W * 1.15 and tw > 0:
        f = font(e.get("font"), size * w * W * 1.15 / tw)
    lay = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    dl = ImageDraw.Draw(lay)
    al = e.get("align", "center")
    ax = {"left": x * W, "right": (x + w) * W}.get(al, (x + w / 2) * W)
    ay = (y + h / 2) * H
    anchor = {"left": "lm", "right": "rm"}.get(al, "mm")
    shown = txt
    if an == "typewriter":
        shown = txt[:max(0, int(len(txt) * min(1, (t - a0) / max(0.3, 0.05 * len(txt)))))]
    dy = (1 - p) * 0.6 * size if an == "slide_up" else 0
    col = e.get("color") or "#FFFFFF"
    box = e.get("box")
    if box and box.get("rect") and not box.get("translucent"):
        bx, by, bw, bh = box["rect"]
        dl.rectangle((ax - (ax - bx * W) if al == "left" else bx * W, by * H, (bx + bw) * W, (by + bh) * H), fill=box["color"])
    kw = {"stroke_width": 3, "stroke_fill": e["outline"]} if e.get("outline") else {}
    dl.text((ax, ay + dy), shown, font=f, fill=col, anchor=anchor, **kw)
    alpha = p if an in ("fade", "slide_up", "pop_scale", "wipe") else 1.0
    if an == "pop_scale" and p < 1:
        sc = 0.7 + 0.3 * p
        lay = lay.resize((int(W * sc), int(H * sc)))
        full = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        full.paste(lay, (int(ax - ax * sc), int(ay - ay * sc)))
        lay = full
    if an == "wipe" and p < 1:
        arr = np.array(lay)
        arr[:, int(x * W + w * W * p):, 3] = 0
        lay = Image.fromarray(arr)
    if alpha < 1:
        arr = np.array(lay).astype(np.float32)
        arr[..., 3] *= alpha
        lay = Image.fromarray(arr.astype(np.uint8))
    img.alpha_composite(lay)


def render(spec, out, seconds, preview=None):
    bg = background(spec).convert("RGBA")
    n = int(round(seconds * FPS)) + 2
    out.parent.mkdir(parents=True, exist_ok=True)
    p = subprocess.Popen([FFMPEG, "-loglevel", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}",
                          "-r", "30000/1001", "-i", "-", "-frames:v", str(n), "-c:v", "libx264", "-crf", "16",
                          "-pix_fmt", "yuv420p", str(out)], stdin=subprocess.PIPE)
    last = None
    for i in range(n):
        t = i / FPS
        img = bg.copy()
        draw_shapes(img, spec, t)
        for e in spec.get("elements", []):
            draw_text(img, e, t)
        last = img
        p.stdin.write(np.asarray(img.convert("RGB")).tobytes())
    p.stdin.close()
    p.wait()
    if preview and last is not None:
        last.convert("RGB").save(preview)
    return n


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--spec")
    ap.add_argument("--needs")
    ap.add_argument("--key")
    ap.add_argument("--out", required=True)
    ap.add_argument("--seconds", type=float)
    ap.add_argument("--preview")
    a = ap.parse_args()
    if a.spec:
        spec = read_json(a.spec)
        secs = a.seconds or spec.get("seconds")
    else:
        need = read_json(a.needs)[a.key]
        spec = need["graphic_spec"]
        secs = a.seconds or need["duration_s"]
    todo = [e for e in spec.get("elements", []) if e.get("new_text") is None]
    if todo and not spec.get("allow_dropped"):
        print(f"note: {len(todo)} elements have no new_text and are dropped: {[e['ref_text'][:16] for e in todo][:8]}")
    n = render(spec, Path(a.out), float(secs), a.preview)
    print(f"{n} frames -> {a.out}" + (f", preview {a.preview}" if a.preview else ""))


if __name__ == "__main__":
    main()

