"""기존 pilot/개정 근거에서 재검토 범위를 계산한다. 기록된 관찰의 진실성은 자동 인증하지 않는다."""
import json
from pathlib import Path
from work_guard import FileSnapshot,digest
from revision_graph import canonical,validate as graph_validate,render_record
from quality_contract import validate as quality_validate
from scheduler import provenance


def bound(snap,base,row):
    if not isinstance(row,dict) or not row.get('path') or not row.get('sha256'):raise ValueError('Bound review evidence required')
    p,h=snap.add(base/row['path'])
    if h!=row['sha256']:raise ValueError('Changed review evidence: '+p)
    return p


def checked_record(path,expected_render=None,_ancestors=()):
    path=Path(path).resolve()
    if str(path) in _ancestors:raise ValueError('Cyclic reused review chain')
    snap=FileSnapshot();r=snap.document(path)
    if r.get('kind')!='lfc-reviewed-output-v1' or r.get('passed') is not True:raise ValueError('Successful independent review record required')
    pp=bound(snap,path.parent,r['plan']);plan=snap.document(pp)
    rp=bound(snap,path.parent,r['judgment']);judge=snap.document(rp)
    video=bound(snap,path.parent,r['render'])
    if expected_render and Path(video)!=Path(expected_render).resolve():raise ValueError('Review record is for a different final output')
    from production_preflight import inspect_file
    if inspect_file(video)['kind']!='media':raise ValueError('Actual reviewed video required')
    actual=provenance(judge['reviewer_rollout'])
    if actual['session']!=judge.get('session_id') or not judge.get('implementation_session_ids') or actual['session'] in judge['implementation_session_ids']:
        raise ValueError('Recorded judgment must be from independent actual Sol High session')
    if judge.get('plan_sha256')!=digest(pp) or judge.get('render_sha256')!=digest(video):raise ValueError('Judgment basis/output differs')
    if judge.get('direct_observation') is not True or judge.get('full_integration_passed') is not True or judge.get('unresolved_items')!=[]:
        raise ValueError('Actual complete integration review remains incomplete')
    if judge.get('observed_cut_ids')!=plan['required_cut_ids'] or judge.get('reused_cut_ids')!=plan['reusable_cut_ids']:
        raise ValueError('Observed/reused cut coverage differs from review plan')
    if r.get('cut_signatures')!=plan['cut_signatures'] or r.get('global_signature')!=plan['global_signature']:
        raise ValueError('Review basis signatures differ from recorded plan')
    evidence=judge.get('cut_evidence',{})
    if set(evidence)!=set(plan['required_cut_ids']):raise ValueError('Per-cut judgment evidence coverage missing')
    for entries in [judge.get('integration_evidence',[]),*evidence.values()]:
        if not entries:raise ValueError('Recorded actual observation evidence missing')
        for row in entries:bound(snap,Path(rp).parent,row)
    media=bound(snap,path.parent,r['media_validation']);proof=snap.document(media)
    if proof.get('passed') is not True or proof.get('kind')!='lfc-verified-render-v1' or proof.get('output_sha256')!={video:digest(video)} or proof.get('graph_sha256')!=plan['graph']['sha256'] or proof.get('scope')!=plan['scope']:
        raise ValueError('Successful actual media verification differs')
    if plan.get('kind')!='lfc-review-plan-v1' or plan.get('passed') is not True or plan.get('content_approved') is not False:
        raise ValueError('Valid coverage plan required')
    if plan.get('previous'):
        previous=bound(snap,Path(pp).parent,plan['previous']);old=checked_record(previous,_ancestors=(*_ancestors,str(path)))
        if any(old['cut_signatures'].get(k)!=plan['cut_signatures'].get(k) for k in plan['reusable_cut_ids']) or old['global_signature']!=plan['global_signature'] and plan['reusable_cut_ids']:
            raise ValueError('Prior review basis cannot support reused cuts')
    elif plan['reusable_cut_ids']:raise ValueError('First output cannot reuse unobserved cut visual approval')
    snap.unchanged();return r


def plan(contract,pilot_review,graph,scope='preview',previous=None):
    contract=Path(contract).resolve();pilot_review=Path(pilot_review).resolve();graph=Path(graph).resolve()
    front=quality_validate(contract,pilot_review,require_front=True)
    if not front['passed'] or not front['front_independent_passed']:raise ValueError('Complete front script/material and actual pilot review required')
    report=graph_validate(graph)
    if not report['passed']:raise ValueError('; '.join(report['errors']))
    snap=FileSnapshot();g=snap.document(graph);c=snap.document(contract)
    if scope not in g['scopes']:raise ValueError('Current render scope required')
    manifest=snap.document(g['scopes'][scope]['path']);props=Path(g['scopes'][scope]['path']).parent/manifest['render_timing']['props'];props=props.resolve();data=snap.document(props)
    cuts=data.get('cuts',[]);ids=[x['id'] for x in cuts]
    if not ids or len(set(ids))!=len(ids):raise ValueError('Unique actual rendered cut IDs required')
    if c.get('readiness_version',1)>=2:
        if scope!=c['output_scope']['kind'] or ids!=front['readiness_cut_ids']:
            raise ValueError('Actual rendered scope must match independently approved material-readiness cuts')
    contract_cuts={x['id']:x for x in c['cuts']}
    if not set(ids)<=set(contract_cuts):raise ValueError('Rendered cuts differ from complete front contract')
    percut={};cut_assets=set();public=props.parent/'public'
    for cut in cuts:
        assets={}
        def collect(v,key=''):
            if isinstance(v,dict):
                for k,x in v.items():collect(x,k)
            elif isinstance(v,list):
                for x in v:collect(x,key)
            elif isinstance(v,str) and key in ('file','image'):
                p,h=snap.add(public/v);assets[v]=h;cut_assets.add(p)
        collect(cut)
        percut[cut['id']]=canonical({'actual_props':cut,'contract':contract_cuts[cut['id']],'assets':assets})
    header={k:v for k,v in data.items() if k!='cuts'}
    global_rows=[(r['id'],r['role'],r['sha256']) for r in g['artifacts'] if scope in r.get('scopes',['full','preview']) and r['role']!='review_note' and r['path']!=str(props) and not (r['role']=='contract' and r['path']==str(contract)) and not (r['role'] in ('public','media') and r['path'] in cut_assets)]
    timing=[{k:cut.get(k) for k in ('id','start_s','end_s','duration_s','trim_start_s','speed')} for cut in cuts]
    global_sig=canonical({'props_header':header,'other_dependencies':global_rows,'cut_order':ids,'actual_cut_timing':timing})
    affected=set(ids);old=None
    if previous:
        old=checked_record(previous)
        if old['global_signature']==global_sig:affected={k for k in ids if old['cut_signatures'].get(k)!=percut[k]}
    neighbors=set(affected)
    for i,k in enumerate(ids):
        if k in affected:neighbors.update(ids[j] for j in (i-1,i+1) if 0<=j<len(ids))
    result={'kind':'lfc-review-plan-v1','passed':True,'content_approved':False,'graph':{'path':str(graph),'sha256':digest(graph)},'scope':scope,
            'contract':{'path':str(contract),'sha256':digest(contract)},'pilot_review':{'path':str(pilot_review),'sha256':digest(pilot_review)},
            'cut_signatures':percut,'global_signature':global_sig,'affected_cut_ids':[k for k in ids if k in affected],
            'required_cut_ids':[k for k in ids if k in neighbors],'reusable_cut_ids':[k for k in ids if k not in neighbors],
            'front_script_material_review_reusable':True,'pilot_is_individual_cut_approval':False,
            'requires_current_full_integration':True,'requires_current_listening_playback_sync_transitions_flow':True,
            'dependencies_sha256':{**report['dependencies_sha256'],**front['dependencies_sha256'],str(contract):digest(contract),str(pilot_review):digest(pilot_review)}}
    if previous:result['previous']={'path':str(Path(previous).resolve()),'sha256':digest(previous)}
    snap.unchanged();return result


def record(plan_path,render,judgment,out):
    plan_path=Path(plan_path).resolve();out=Path(out).resolve()
    if out.exists():raise ValueError('Preserve prior review record; use a new output path')
    p=json.loads(plan_path.read_text())
    current=plan(p['contract']['path'],p['pilot_review']['path'],p['graph']['path'],p['scope'],p.get('previous',{}).get('path'))
    if current!=p:raise ValueError('Review plan is stale; recompute current affected scope')
    render=Path(render).resolve();judgment=Path(judgment).resolve()
    media=out.with_suffix('.media-validation.json')
    render_record(p['graph']['path'],p['scope'],render,media)
    r={'kind':'lfc-reviewed-output-v1','passed':True,'plan':{'path':str(plan_path),'sha256':digest(plan_path)},'judgment':{'path':str(judgment),'sha256':digest(judgment)},
       'render':{'path':str(render),'sha256':digest(render)},'media_validation':{'path':str(media),'sha256':digest(media)},
       'cut_signatures':p['cut_signatures'],'global_signature':p['global_signature'],'recorded_independent_judgment_not_truth_certificate':True}
    # Do not publish a successful record until all coverage/provenance/evidence checks pass.
    temporary=out.with_name(out.name+'.checking');temporary.write_text(json.dumps(r,ensure_ascii=False,indent=2))
    try:checked_record(temporary,render)
    except Exception:temporary.unlink();raise
    temporary.replace(out);return r


def validate_current(record_path,render):
    record_path=Path(record_path).resolve();r=checked_record(record_path,render)
    pp=Path(r['plan']['path']);p=json.loads(pp.read_text())
    fresh=plan(p['contract']['path'],p['pilot_review']['path'],p['graph']['path'],p['scope'],p.get('previous',{}).get('path'))
    if fresh!=p:raise ValueError('Final review evidence is stale or its affected scope changed')
    return {'passed':True,'reviewer_session':json.loads(Path(r['judgment']['path']).read_text())['session_id'],
            'dependencies_sha256':{**p['dependencies_sha256'],str(record_path):digest(record_path),str(pp):digest(pp),r['judgment']['path']:r['judgment']['sha256']},
            'content_accuracy_verified':False}
