"""TTS 우선 초안의 비율 계산과 단일 기술 검사. 콘텐츠 승인을 요구하지 않는다."""
import argparse
import json
import math
import os
import re
from pathlib import Path

PROFILE = 'tts-first-v1'


def active(root=None):
    root = root or os.environ.get('LFC_RUN_DIR')
    return bool(root and json.loads((Path(root) / 'run.json').read_text()).get('workflow_profile') == PROFILE)


def units(text):
    return sum(ch.isalnum() for ch in text)


def sentence_plan(reference_text, reference_cut_durations, new_text, tts_duration_s):
    """문장 길이 대비 컷 밀도를 이식하고 최종 음성 길이에 정규화한다.

    입력은 완결된 문장/연결 문장 묶음. 문장 경계를 넘는 컷은 묶어서 한 번만 센다.
    """
    old, new = units(reference_text), units(new_text)
    values = reference_cut_durations
    if not old or not new or not values or any(type(x) not in (int, float) or not math.isfinite(x) or x <= 0 for x in values):
        raise ValueError('문장과 양수 원본 컷 길이가 필요합니다')
    if type(tts_duration_s) not in (int, float) or not math.isfinite(tts_duration_s) or tts_duration_s <= 0:
        raise ValueError('묵음 제거 후 실제 TTS 길이가 필요합니다')
    count = max(1, math.floor(len(values) * new / old + .5))
    # 원본 누적 상대 시간 곡선을 새 컷 수에 맞춰 보간한다.
    cumulative = [0.0]
    for x in values: cumulative.append(cumulative[-1] + x)
    def at(fraction):
        pos = fraction * len(values); i = min(len(values) - 1, int(pos))
        return (cumulative[i] + (pos - i) * values[i]) / cumulative[-1]
    boundaries = [tts_duration_s * at(i / count) for i in range(count + 1)]
    return {'reference_units': old, 'new_units': new, 'reference_cut_count': len(values),
            'cuts_per_unit': len(values) / old, 'reference_seconds_per_unit': sum(values) / old,
            'new_cut_count': count, 'duration_s': tts_duration_s,
            'cuts': [{'start_s': a, 'end_s': b} for a, b in zip(boundaries, boundaries[1:])],
            'note': '배치 초안: 서사 역할·문장 경계에 맞춘 최종 배치 근거를 기록한다'}


def basic_check(manifest_path):
    """현재 props·미디어·음성·자막의 기술 오류만 확인; 독립 승인/파일럿 없음."""
    from common import probe
    from work_guard import digest
    from check_render_timing import renderer_dependencies
    p = Path(manifest_path).resolve(); doc = json.loads(p.read_text()); errors = []; inputs = {}
    def read(name):
        path = (p.parent / name).resolve()
        inputs[str(path)] = digest(path)
        return json.loads(path.read_text())
    def require(value, message):
        if not value: errors.append(message)
    require(doc.get('schema') == 'lfc-draft-delivery-v1', '초안 전달 명세 형식 오류')
    props = read(doc['render_timing']['props'])
    fps, duration = props['fps'], props['duration_s']
    require(type(fps) in (int, float) and math.isfinite(fps) and fps > 0, '잘못된 fps')
    require(type(duration) in (int, float) and math.isfinite(duration) and duration > 0, '잘못된 출력 길이')
    if errors: return {'passed': False, 'errors': errors}
    require(170 <= duration <= 210 or (doc.get('short_reference_duration_s') == duration and 0 < duration < 170), '초안은 170~210초여야 합니다')
    require(doc['canvas'] == [props['width'], props['height']], '캔버스 불일치')
    narration = read(doc['narration'])
    require(narration.get('silence_policy') == 'compact', 'TTS 묵음 정리 누락')
    require(narration.get('provider') == 'typecast' and narration.get('uniform_speed') == 1.2, 'Typecast 1.2배속 필요')
    lines = narration['lines']; require(bool(lines), '음성 문장 누락')
    for previous, line in zip(lines, lines[1:]):
        require(abs(line['placed_start_s'] - previous['placed_end_s']) <= .003, '문장 사이 불필요한 묵음/겹침')
    require(not lines or lines[-1]['placed_end_s'] <= duration + 1 / fps, '출력 끝에서 발음 잘림')
    tts_wav = (p.parent / doc['narration']).resolve().parent / 'narration.wav'
    inputs[str(tts_wav)] = digest(tts_wav)
    voice_info = probe(tts_wav)
    require(abs(voice_info['duration_s'] - narration['duration_s']) < .02, '음성 시각/파일 길이 불일치')
    mix = p.parent / 'mix.wav'; inputs[str(mix.resolve())] = digest(mix)
    require(abs(probe(mix)['duration_s'] - duration) < .05, '믹스 길이 불일치')
    public = (p.parent / doc['render_timing']['props']).resolve().parent / 'public'
    def media_files(value):
        if isinstance(value, dict):
            if isinstance(value.get('file'), str):
                source = (public / value['file']).resolve()
                inputs[str(source)] = digest(source)
                if value.get('sha256'): require(inputs[str(source)] == value['sha256'], '소스 해시 불일치')
            for child in value.values(): media_files(child)
        elif isinstance(value, list):
            for child in value: media_files(child)
    media_files(props)
    cursor = 0.; ids = set()
    for cut in props['cuts']:
        require(cut['id'] not in ids, '중복 컷 ID'); ids.add(cut['id'])
        a, b = cut['start_s'], cut['end_s']
        require(math.isfinite(a) and math.isfinite(b) and b > a, '잘못된 컷 시간')
        require(abs(a - cursor) <= 1 / fps, '배경 컷 공백/겹침')
        cursor = b
        asset = cut['asset']; info_path = public / asset['file']
        if asset['kind'] == 'video':
            actual = probe(info_path)
            speed = cut.get('speed', 1); trim = cut.get('trim_start_s', 0)
            require(speed > 0 and trim >= 0 and trim + (min(b, duration) - a) * speed <= actual['duration_s'] + .05, '영상 소스 길이 부족')
        else:
            from PIL import Image
            with Image.open(info_path) as image: image.verify()
    require(bool(ids) and abs(cursor - duration) <= 1 / fps, '전체 배경 컷 누락/길이 불일치')
    for item in props.get('texts', []):
        require(0 <= item['start_s'] < item['end_s'] <= duration + 1 / fps, '자막 시간 오류')
        require('\n' not in item['text'], '한 줄 자막 위반')
        require(not re.search(r'(?<!\d)\.(?:\s+|(?=[가-힣]))\S', item['text']), '온점 뒤 다음 문장을 같은 자막에 연결함')
    require(bool(props.get('texts')), '자막 누락')
    inputs[str(p)] = digest(p)
    template = {str(x): digest(x) for x in renderer_dependencies()}
    return {'passed': not errors, 'errors': errors, 'kind': 'draft_basic_technical_check',
            'content_approved': False, 'user_review_pending': True, 'input_sha256': inputs,
            'render_timing_check': {'fps': fps, 'output_frames': max(1, math.floor(duration * fps + .5)), 'template_sha256': template}}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('request', type=Path); parser.add_argument('--out', type=Path, required=True)
    a = parser.parse_args(); doc = json.loads(a.request.read_text())
    result = sentence_plan(doc['reference_text'], doc['reference_cut_durations'], doc['new_text'], doc['tts_duration_s'])
    a.out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')


if __name__ == '__main__': main()
