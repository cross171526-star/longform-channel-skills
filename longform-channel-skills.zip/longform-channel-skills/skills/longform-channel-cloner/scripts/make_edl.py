#!/usr/bin/env python3
"""Turn a validated reference analysis into an edit decision list (EDL) for an exact recreation.

  run.sh make_edl --project DIR --video ID [--range 0:30] [--out DIR/recreate/<ID>_0-30]

Writes to --out:
  edl.json    cut-by-cut edit: timing, asset key, layer/keyframes (measured curves), effects, transition,
              credit (mirrors the reference: only where the reference shows one), text overlays with measured
              style, SFX placements, BGM segments, loudness targets
  lines.json  narration lines with reference timing (input for: run.sh tts --lines lines.json --tempo 1.2; reference times do not retime narration)
  needs.json  every asset key the EDL needs + how to acquire it (source type, description, queries, AI prompt,
              whether a no-attribution license is required because the reference shows no credit there)
Asset keys: "<ID>:<cut_id>" for clips, "sfx:<ID>:<sfx_id>", "bgm:<ID>:<n>".
Fails if any cut in range is unannotated or captions.json has no render_policy.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np

from common import parse_range, read_json, write_gen_jobs, write_json


def smooth(v, k=5):
    v = np.asarray(v, float)
    if len(v) < k:
        return v
    pad = k // 2
    vp = np.pad(v, pad, mode="edge")
    return np.convolve(vp, np.ones(k) / k, mode="valid")


def motion_keyframes(ad: Path, cut, ann, fps):
    kf = ann.get("keyframes", {})
    if kf.get("override"):
        return {k: [{"t": p["t"], "v": p["v"], "easing": p.get("easing", "linear")} for p in pts]
                for k, pts in kf["override"].items()}
    m = cut.get("motion") or {}
    if not m or kf.get("preset") in ("camera_motion", "static") or (m.get("median_inlier") or 1) < 0.35 \
            or m.get("motion_origin") == "in_source":
        return {}
    path = ad / "motion" / f"{cut['id']}.json"
    if not path.exists():
        return {}
    rows = read_json(path)["frames"]
    ts = [(r["f"] - cut["start_frame"]) / fps for r in rows]
    out = {}
    for name, key in (("scale", "scale"), ("x", "x"), ("y", "y"), ("rotation_deg", "rot")):
        v = smooth([r[key] for r in rows])
        if np.ptp(v) < (0.004 if name != "rotation_deg" else 0.3):
            continue
        step = max(1, len(v) // 90)  # <= ~90 keyframes per property
        idx = list(range(0, len(v), step))
        if idx[-1] != len(v) - 1:
            idx.append(len(v) - 1)
        out[name] = [{"t": round(ts[i], 4), "v": round(float(v[i]), 5), "easing": "linear"} for i in idx]
    return out


def zone_geometry(cap_doc):
    """Per-zone median ink box and background-box geometry, from events whose measurements agree."""
    import statistics as st_
    out = {}
    for z in cap_doc.get("zones", []):
        evs = [e for e in cap_doc["events"] if e.get("zone") == z["id"] and e.get("ink_bbox")]
        if not evs:
            continue
        hs = [e["ink_bbox"][3] for e in evs]
        mh = st_.median(hs)
        good = [e for e in evs if abs(e["ink_bbox"][3] - mh) <= 0.2 * mh]
        if not good:  # all ink heights disagree (e.g. two events, very different sizes): keep the median-closest one
            good = [min(evs, key=lambda e: abs(e["ink_bbox"][3] - mh))]
        g = {"ink_y": st_.median(e["ink_bbox"][1] for e in good), "ink_h": st_.median(e["ink_bbox"][3] for e in good)}
        boxes = [e for e in good if (e.get("style") or {}).get("box")]
        g["box_ratio"] = len(boxes) / len(good)
        if boxes and g["box_ratio"] >= 0.3:
            rs = [e["style"]["box"]["rect"] for e in boxes]
            g["box"] = {"color": boxes[0]["style"]["box"]["color"], "y": st_.median(r[1] for r in rs),
                        "h": st_.median(r[3] for r in rs),
                        "pad_x": st_.median(e["ink_bbox"][0] - e["style"]["box"]["rect"][0] for e in boxes)}
        # a real outline has one consistent colour across the zone; varying "outlines" are background pixels
        outs = [(e.get("style") or {}).get("outline") for e in good]
        outs = [o for o in outs if o]
        if len(good) >= 3 and outs and len(outs) >= 0.6 * len(good):
            ref = st_.median(_lum(o) for o in outs)
            if sum(abs(_lum(o) - ref) < 40 for o in outs) >= 0.8 * len(outs):
                g["outline"] = min(outs, key=lambda o: abs(_lum(o) - ref))
        out[z["id"]] = g
    return out


def _lum(h):
    r, g, b = (int(h[i:i + 2], 16) for i in (1, 3, 5))
    return 0.299 * r + 0.587 * g + 0.114 * b


def text_style(ev, cap_doc):
    st = ev.get("style") or {}
    zone = next((z for z in cap_doc.get("zones", []) if z["id"] == ev.get("zone")), None)
    fc = [zone["font"]] if zone and zone.get("font") else (ev.get("font_candidates") or [])
    if not fc:  # borrow from a zone sibling that was matched
        for e in cap_doc["events"]:
            if e.get("zone") == ev.get("zone") and e.get("font_candidates") and (e.get("style") or {}).get("fill") == st.get("fill"):
                fc = e["font_candidates"]
                break
    if not fc:
        for e in cap_doc["events"]:
            if e.get("zone") == ev.get("zone") and e.get("font_candidates"):
                fc = e["font_candidates"]
                break
    font = fc[0] if fc else {}
    geo = zone_geometry(cap_doc).get(ev.get("zone"), {})
    ink = list(ev.get("ink_bbox") or ev["bbox"])
    if geo and (not ev.get("ink_bbox") or abs(ink[3] - geo["ink_h"]) > 0.2 * geo["ink_h"]):
        # unreliable ink measurement (e.g. outline pixels picked up): keep the event's horizontal extent from OCR,
        # take vertical placement and glyph height from the zone
        ink = [ev["bbox"][0], geo["ink_y"], ev["bbox"][2], geo["ink_h"]]
    elif geo:
        ink = [ink[0], geo["ink_y"], ink[2], geo["ink_h"]]
    box = None
    inferred = not st.get("box")
    if geo.get("box"):
        gb = geo["box"]
        box = {"color": gb["color"], "rect": [ink[0] - gb["pad_x"], gb["y"], ink[2] + 2 * gb["pad_x"], gb["h"]]}
    elif st.get("box") and not geo:
        box = st["box"]
    fill = st.get("fill", "#FFFFFF")
    if box:
        outline = None  # text on a solid box: any "outline" cluster is box / fill mixing, not a stroke
        if _close(fill, box["color"]) and st.get("outline"):  # fill/outline swapped by k-means
            fill = st["outline"]
    else:
        outline = geo.get("outline") if geo else st.get("outline")
    return {"font_file": font.get("file"), "font_name": font.get("font"), "font_score": font.get("score"),
            "font_size_px": ev.get("font_size_px_1080p_est"), "color": fill,
            "stroke": {"color": outline, "width_px": st.get("outline_px_1080p") or 3} if outline else None,
            "box": ({"color": box["color"], "rect": box["rect"], "inferred": inferred} if box else None),
            "align": ev.get("align", "center"), "bbox": ev["bbox"], "ink_bbox": ink,
            "shadow": st.get("shadow"), "weight": st.get("weight")}


def _close(h1, h2, tol=40):
    a = [int(h1[i:i + 2], 16) for i in (1, 3, 5)]
    b = [int(h2[i:i + 2], 16) for i in (1, 3, 5)]
    return max(abs(x - y) for x, y in zip(a, b)) < tol


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--project", required=True)
    ap.add_argument("--video", required=True)
    ap.add_argument("--range", default="0:30")
    ap.add_argument("--out")
    a = ap.parse_args()
    project = Path(a.project)
    ad = project / "analysis" / a.video
    cuts_doc = read_json(ad / "cuts.json")
    cap = read_json(ad / "captions.json")
    audio = read_json(ad / "audio.json")
    tr = read_json(ad / "transcript.json")
    fps = cuts_doc["video"]["fps"]
    t0, t1 = parse_range(a.range, cuts_doc["video"]["duration_s"])
    out = Path(a.out or project / "recreate" / f"{a.video}_{int(t0)}-{int(t1)}")
    cuts = [c for c in cuts_doc["cuts"] if c["end_s"] > t0 and c["start_s"] < t1]
    missing = [c["id"] for c in cuts if not c.get("annotation") or c["annotation"].get("draft")]
    if missing:
        sys.exit(f"unconfirmed cuts in range: {missing}")
    if cap.get("render_policy") is None:
        sys.exit("captions.json render_policy is not set (decide which text is edit overlay vs baked into footage)")
    pol = cap["render_policy"]
    credit_ids = set(cap.get("credit_events", []))
    edl_cuts, needs = [], {}
    for c in cuts:
        ann = c["annotation"]
        key = f"{a.video}:{c['id']}"
        s, e = max(c["start_s"], t0) - t0, min(c["end_s"], t1) - t0
        cred = ann.get("source_credit", {"shown": False})
        if cred.get("shown"):
            credit_ids.update(cred.get("text_event_ids", []))
        style_ref = None
        cred_t = None
        if cred.get("shown") and cred.get("text_event_ids"):
            ev = next((x for x in cap["events"] if x["id"] == cred["text_event_ids"][0]), None)
            style_ref = text_style(ev, cap) if ev else None
            if ev:
                cred_t = [round(max(ev["start_s"], t0) - t0, 3), round(min(ev["end_s"], t1) - t0, 3)]
        edl_cuts.append({
            "id": c["id"], "start_s": round(s, 4), "end_s": round(e, 4), "asset_key": key,
            "source_type": ann["source"]["type"], "media": ann["source"].get("media"),
            "layer": ann.get("layer", {"fit": "cover"}),
            "keyframes": motion_keyframes(ad, c, ann, fps),
            "keyframe_preset": ann["keyframes"].get("preset"),
            "trim_start_s": 0.0, "speed": ann["animation"].get("speed", 1.0),
            "retime": ("fit_to_cut" if (c.get("motion") or {}).get("motion_origin") == "in_source"
                       and (c.get("motion") or {}).get("cadence", {}).get("retime") else None),
            "reference_cadence": (c.get("motion") or {}).get("cadence"),
            # full reference cut (the range may clip it): retiming must use the whole cut, then trim into it
            "ref_cut": {"offset_s": round(max(c["start_s"], t0) - c["start_s"], 4), "duration_s": c["duration_s"]},
            "effects": ann["animation"].get("effects", []), "effect_params": ann["animation"].get("effect_params", {}),
            "animation": {k: ann["animation"].get(k) for k in ("in", "in_s", "out", "out_s")},
            "transition_in": ann["transition_in"] if c["start_s"] >= t0 and c["index"] > 0 else {"type": "cut", "frames": 0},
            "overlays": [o for o in ann.get("overlays", []) if o["kind"] not in ("caption", "title", "keyword_popup", "lower_third", "source_credit")],
            "credit": {"shown": bool(cred.get("shown")), "format": cred.get("format"), "reference_text": cred.get("text"),
                       "style": style_ref, "time": cred_t},
        })
        src = ann["source"]
        rt = (((c.get("motion") or {}).get("cadence") or {}).get("retime") or {}).get("24fps") or {}
        src_len = rt.get("source_len_s")
        covers = round(max(c["start_s"], t0) - c["start_s"] + (e - s), 4)  # part of the cut up to the range end
        if src_len and rt.get("speed") and covers < c["duration_s"] - 1e-3:
            # the range cuts this cut off: generate only the footage that is on screen, same playback speed
            src_len = max(1.0, round(covers * rt["speed"] + 0.1, 2))
            edl_cuts[-1]["ref_cut"].update(covers_s=covers, ref_speed=rt["speed"])
        needs[key] = {"kind": "clip", "source_type": src["type"], "media": src.get("media"),
                      "description": src["description"], "duration_s": round(e - s, 3),
                      "acquire": src.get("acquire"), "orientation": src.get("orientation", "landscape"),
                      "no_attribution_required": not cred.get("shown"),
                      "same_source_group": src.get("same_source_group"),
                      "keyframe_preset": ann["keyframes"].get("preset"),
                      # unique footage the reference shows (generate this much; build_timeline retimes it)
                      "source_len_s": src_len,
                      "ref_frame": str(ad / "frames" / "src" / f"{c['id']}.jpg")}
    texts = []
    zones = set(pol.get("zones", []))
    brand_zones = set(pol.get("brand_zones", []))
    inc, exc = set(pol.get("include_ids", [])), set(pol.get("exclude_ids", []))
    brand = []
    for z in brand_zones:
        evs = [e for e in cap["events"] if e.get("zone") == z and e["end_s"] > t0 and e["start_s"] < t1]
        if not evs:
            continue
        rep = max(evs, key=lambda e: (e["end_s"] - e["start_s"], e.get("conf", 0)))
        brand.append({"zone": z, "reference_text": rep["text"], "start_s": round(max(min(e["start_s"] for e in evs), t0) - t0, 3),
                      "end_s": round(min(max(e["end_s"] for e in evs), t1) - t0, 3), "style": text_style(rep, cap)})
    for ev in cap["events"]:
        if ev["end_s"] <= t0 or ev["start_s"] >= t1 or ev["id"] in credit_ids or ev["id"] in exc:
            continue
        if ev.get("zone") not in zones and ev["id"] not in inc:
            continue
        texts.append({"id": ev["id"], "text": ev.get("text_corrected") or ev["text"],
                      "start_s": round(max(ev["start_s"], t0) - t0, 3), "end_s": round(min(ev["end_s"], t1) - t0, 3),
                      "zone": ev.get("zone"), "style": text_style(ev, cap),
                      "animation": {"in": ev["animation"].get("in"), "in_s": ev["animation"].get("in_s_est"),
                                    "growth": ev["animation"].get("growth")}})
    sfx = []
    for ev in audio.get("sfx_events", []):
        if ev.get("likely_sfx") and t0 <= ev["t"] < t1 and not ev.get("rejected"):
            k = f"sfx:{a.video}:{ev['id']}"
            sfx.append({"id": ev["id"], "t": round(ev["t"] - t0, 3), "asset_key": k, "ref_clip": str(ad / ev["clip"]),
                        "label": (ev.get("label_corrected") or (ev["labels"][0][0] if ev.get("labels") else None))})
            needs[k] = {"kind": "sfx", "label": sfx[-1]["label"], "ref_clip": sfx[-1]["ref_clip"],
                        "no_attribution_required": True}
    bgm = []
    for n, sg in enumerate(audio.get("bgm_segments", [])):
        if sg["music_present_ratio"] < 0.3 or sg["end_s"] <= t0 or sg["start_s"] >= t1:
            continue
        k = f"bgm:{a.video}:{n}"
        bgm.append({"asset_key": k, "start_s": round(max(sg["start_s"], t0) - t0, 3), "end_s": round(min(sg["end_s"], t1) - t0, 3),
                    "offset_s": 0.0, "tempo_bpm": sg.get("tempo_bpm"), "mood": (sg.get("mood_tags") or [[None]])[0][0],
                    "music_db_median": sg.get("music_db_median")})
        needs[k] = {"kind": "bgm", "mood": bgm[-1]["mood"], "tempo_bpm": sg.get("tempo_bpm"), "key": sg.get("key_guess"),
                    "duration_s": round(bgm[-1]["end_s"] - bgm[-1]["start_s"], 2), "no_attribution_required": True,
                    "ref_excerpt": {"file": str(ad / "stems" / "music.wav"), "start_s": sg["start_s"], "end_s": sg["end_s"]}}
    lines = []
    for sgm in tr["segments"]:
        if sgm["end"] <= t0 or sgm["start"] >= t1:
            continue
        # keep the full reference timing of a line that runs past the range end: it is cut at the range end
        # exactly like the reference segment is
        lines.append({"id": f"l{len(lines) + 1:03d}", "text": sgm.get("text_corrected") or sgm["text"],
                      "start_s": round(max(sgm["start"], t0) - t0, 3), "end_s": round(sgm["end"] - t0, 3)})
    lv = audio.get("levels", {})
    edl = {"mode": "recreate", "reference": {"video": a.video, "range": [t0, t1]},
           "fps": fps, "width": 1920, "height": 1080, "duration_s": round(t1 - t0, 4),
           "narration": {"lines_file": "lines.json", "tts_dir": "tts"},
           "cuts": edl_cuts, "texts": texts, "brand": brand, "sfx": sfx, "bgm": bgm,
           "levels": {"voice_lufs": lv.get("voice_lufs"), "music_lufs": lv.get("music_lufs"), "mix_lufs": lv.get("mix_lufs"),
                      "ducking_db": (lv.get("ducking") or {}).get("ducking_db")}}
    write_json(out / "edl.json", edl)
    write_json(out / "lines.json", lines)
    write_json(out / "needs.json", needs)
    nj = write_gen_jobs(out, needs, project)
    nc = sum(1 for n in needs.values() if n["kind"] == "clip")
    print(f"EDL {len(edl_cuts)} cuts, {len(texts)} texts, {len(sfx)} sfx, {len(bgm)} bgm, {len(lines)} lines -> {out}")
    print(f"needs: {nc} clips, {len(sfx)} sfx, {len(bgm)} bgm. Credits shown on "
          f"{sum(1 for c in edl_cuts if c['credit']['shown'])}/{len(edl_cuts)} cuts (mirrors reference)")
    if nj:
        print(f"gen_jobs.json: {nj} ai_video jobs (start frames -> {out / 'start_frames'}, then gen_video --batch --watch)")


if __name__ == "__main__":
    main()
