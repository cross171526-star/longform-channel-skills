#!/usr/bin/env python3
"""준비된 로컬 WAV를 1.0배속으로 반복하고 출처 메타데이터를 저장한다."""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import subprocess

from common import FFMPEG, probe, read_json, run


def same_file(a: Path, b: Path) -> bool:
    return a == b or (a.exists() and b.exists() and a.samefile(b))


def loop_bgm(config_json: str | Path, duration: float, out: str | Path) -> Path:
    if not math.isfinite(duration) or duration <= 0:
        raise ValueError("duration must be finite and positive")
    config_path = Path(config_json).resolve()
    config = read_json(config_path)
    if not isinstance(config, dict):
        raise ValueError("config must be an object")
    playback = config.get("playback", config)
    if not isinstance(playback, dict):
        raise ValueError("playback must be an object")
    local_path = playback.get("local_path")
    expected_hash = playback.get("sha256")
    if not isinstance(local_path, str) or not local_path:
        raise ValueError("playback.local_path is required")
    if (not isinstance(expected_hash, str) or len(expected_hash) != 64
            or any(c not in "0123456789abcdefABCDEF" for c in expected_hash)):
        raise ValueError("playback.sha256 must be a SHA-256 hex digest")
    source = Path(local_path)
    if not source.is_absolute():
        source = config_path.parent / source
    source = source.resolve()
    output = Path(out).resolve()
    sidecar = output.with_suffix(output.suffix + ".json")
    if source.suffix.lower() != ".wav" or not source.is_file():
        raise ValueError("playback.local_path must be a local WAV file")
    if output.suffix.lower() != ".wav":
        raise ValueError("out must be a WAV path")
    for destination in (output, sidecar):
        if any(same_file(destination, protected) for protected in (source, config_path)):
            raise ValueError("output or metadata must not overwrite input/config")
    if same_file(output, sidecar):
        raise ValueError("metadata must not overwrite output")
    with source.open("rb") as handle:
        source_hash = hashlib.file_digest(handle, "sha256").hexdigest()
    if source_hash != expected_hash.lower():
        raise ValueError("source SHA-256 mismatch")
    source_info = probe(source)
    source_duration = source_info["duration_s"]
    if (not source_info["has_audio"] or not math.isfinite(source_duration)
            or source_duration <= 0):
        raise ValueError("input must contain audio with finite positive duration")

    output.parent.mkdir(parents=True, exist_ok=True)
    run([FFMPEG, "-hide_banner", "-loglevel", "error", "-nostdin", "-y",
         "-stream_loop", "-1", "-i", str(source), "-t", str(duration),
         "-ar", "48000", "-c:a", "pcm_s16le", str(output)])
    output_info = probe(output)
    actual_duration = output_info["duration_s"]
    if (not output_info["has_audio"] or not math.isfinite(actual_duration)
            or actual_duration <= 0 or abs(actual_duration - duration) > 1 / 48000 + 1e-6):
        raise ValueError("output audio duration does not match requested duration")
    sidecar.write_text(json.dumps({
        "source_sha256": source_hash,
        "source_path": str(source),
        "duration_s": actual_duration,
        "loop": True,
        "playback_rate": 1.0,
    }, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return output


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("config_json", metavar="CONFIG_JSON")
    parser.add_argument("--duration", required=True, type=float, metavar="SECONDS")
    parser.add_argument("--out", required=True, metavar="WAV")
    args = parser.parse_args(argv)
    try:
        loop_bgm(args.config_json, args.duration, args.out)
    except (OSError, ValueError, subprocess.CalledProcessError) as error:
        parser.error(str(error))


if __name__ == "__main__":
    main()
