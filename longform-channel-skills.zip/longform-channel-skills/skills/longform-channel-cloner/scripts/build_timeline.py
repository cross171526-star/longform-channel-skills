#!/usr/bin/env python3
"""Resolve an EDL against acquired assets and render it with Remotion, then mix audio.

  run.sh build_timeline --edl DIR/edl.json --project PROJECT [--preview] [--no-render] [--concurrency 6]

Needs: assets registered in PROJECT/assets/manifest.json for every EDL asset_key (fetch_assets status),
narration in DIR/tts/narration.{wav,json} (run tts first), fonts on disk.
Steps:
  1. copy assets + fonts into DIR/render/public, build Remotion props (props.json)
     - keyframes from the reference are relative to the reference layer's first frame; base_scale adds the
       cover-fit scale measured in the reference (layer.initial_scale) so framing matches
     - text anchors come from reference ink boxes; the font size is fitted so the rendered glyph height equals
       the reference ink height, and the vertical offset between CSS box and ink is measured per font
     - credits are drawn only for cuts whose credit.shown is true, formatted from the asset's metadata
  2. render video-only with Remotion (template in assets/remotion-template, npm install once)
  3. mix narration + BGM (with measured ducking) + SFX at the reference levels, mux -> DIR/output.mp4
"""
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path

import numpy as np
import soundfile as sf

from common import FFMPEG, LFC_HOME, load_mono, lufs, probe, read_json, rms_db, run, write_json

SKILL = Path(__file__).resolve().parent.parent
TEMPLATE = SKILL / "assets" / "remotion-template"
DEFAULT_FONT = LFC_HOME / "fonts" / "Pretendard-Bold.otf"
SR = 48000


def font_metrics(font_file: Path, size: int = 200):
    """Ink height of Korean/Latin sample glyphs and ink centre offset from the CSS line box centre
    (line-height 1.15), both as fractions of font-size."""
    from PIL import ImageFont
    f = ImageFont.truetype(str(font_file), size)
    asc, desc = f.getmetrics()
    sample = "가나다라마바한글ABCDEFG"
    l, t, r, b = f.getbbox(sample, anchor="ls")  # relative to baseline
    ink_h = (b - t) / size
    ink_center_from_baseline = (t + b) / 2 / size  # negative (above baseline)
    # CSS: line box height 1.15*size, content area centred; baseline sits at half-leading + ascent
    content = (asc + desc) / size
    half_leading = (1.15 - content) / 2
    baseline_from_top = half_leading + asc / size
    ink_center_from_top = baseline_from_top + ink_center_from_baseline
    dy = ink_center_from_top - 1.15 / 2  # >0: ink centre below box centre
    return ink_h, dy


def copy_public(source, folder):
    from work_guard import digest
    source=Path(source);signature=digest(source);folder.mkdir(parents=True,exist_ok=True)
    target=folder/(signature+source.suffix.lower())
    if not target.exists() or digest(target)!=signature:shutil.copy2(source,target)
    if digest(target)!=signature:raise ValueError('Source changed during copy: '+str(source))
    return target,signature


def resolve_font(style, fonts_map, public: Path):
    ff = style.get("font_file")
    path = Path(ff) if ff else DEFAULT_FONT
    if not path.exists():
        sys.exit(f"font missing: {path}. Run scripts/fetch_fonts.sh")
    fam = fonts_map.get(str(path))
    if not fam:
        fam = f"F{len(fonts_map) + 1}_{path.stem.replace(' ', '')}"
        fonts_map[str(path)] = fam
        (public / "fonts").mkdir(parents=True, exist_ok=True)
        copy_public(path, public / "fonts")
    return fam, path


def prepare_renderer_layers(nodes, duration, public, fonts_map):
    """Strict reviewed scene nodes; preserve primary source identity and every authored field."""
    from work_guard import digest
    from copy import deepcopy
    inspector = "const s=require(process.argv[1]);s.validateScenes(JSON.parse(process.argv[2]),Number(process.argv[3]));"
    subprocess.run(['node', '-e', inspector, str(TEMPLATE / 'src/sceneContract.cjs'),
                    json.dumps(nodes, allow_nan=False), str(duration)], check=True, capture_output=True, text=True)
    out = deepcopy(nodes)

    def media(record):
        source = Path(record['source_path']).resolve()
        if digest(source) != record['sha256']:
            raise ValueError('Independent layer source hash mismatch: ' + str(source))
        target, signature = copy_public(source, public / 'scene')
        record['file'] = 'scene/' + target.name
        if signature != record['sha256']:
            raise ValueError('Independent layer changed during copy')

    def visit(records):
        for node in records:
            if node.get('media'):
                media(node['media'])
            for frame in node.get('texture_frames', []):
                media(frame['media'])
            if node.get('font'):
                font = node['font']
                source = Path(font['source_path']).resolve()
                if digest(source) != font['sha256']:
                    raise ValueError('Independent layer font hash mismatch')
                existing = fonts_map.get(str(source))
                if existing and existing != font['family']:
                    raise ValueError('One font source has conflicting family declarations')
                if font['family'] in fonts_map.values() and existing != font['family']:
                    raise ValueError('Font family aliases different source files')
                fonts_map[str(source)] = font['family']
                copy_public(source, public / 'fonts')
            visit(node.get('children', []))

    visit(out)
    return out


def text_item(item_id, kind, text, start, end, style, fonts_map, public, anim=None):
    fam, path = resolve_font(style, fonts_map, public)
    ink_h, dy = font_metrics(path)
    bbox = style.get("ink_bbox") or style["bbox"]
    ink_px = bbox[3] * 1080
    if style.get("ink_bbox"):
        size = max(8, round(ink_px / ink_h))
    else:
        size = max(8, round(style.get("font_size_px") or bbox[3] * 1080 / 1.15))
    align = style.get("align", "center")
    x = {"left": bbox[0], "center": bbox[0] + bbox[2] / 2, "right": bbox[0] + bbox[2]}[align] * 1920
    y = (bbox[1] + bbox[3] / 2) * 1080
    box = None
    if style.get("box") and style["box"].get("rect"):
        r = style["box"]["rect"]
        # CSS span background = line box (1.15*size) + padding. Split the vertical padding so the glyph ink lands
        # on the reference ink centre while the plate matches the reference rectangle.
        rect_top, rect_h = r[1] * 1080, r[3] * 1080
        ink_c = (bbox[1] + bbox[3] / 2) * 1080
        line_top = ink_c - dy * size - 1.15 * size / 2
        pad_t = max(0.0, line_top - rect_top)
        pad_b = max(0.0, rect_h - 1.15 * size - pad_t)
        pad_x = max(0.0, (bbox[0] - r[0]) * 1920)
        box = {"color": style["box"]["color"], "pad_x_px": round(pad_x, 1), "pad_top_px": round(pad_t, 1),
               "pad_bottom_px": round(pad_b, 1), "radius_px": style["box"].get("radius_px", 0)}
        if style["box"].get("alpha") is not None:
            box["alpha"] = style["box"]["alpha"]
        if style["box"].get("accent_bars"):
            x0 = r[0] * 1920
            box["bars"] = [{"side": b.get("side", "left"), "w_px": b["w_px_1080p"], "color": b["color"],
                            "inset_px": round(max(0.0, (b["x_px_1080p"] - x0) if b.get("side", "left") == "left"
                                                  else (x0 + r[2] * 1920) - (b["x_px_1080p"] + b["w_px_1080p"])), 1)}
                           for b in style["box"]["accent_bars"]]
        y = rect_top + (1.15 * size + pad_t + pad_b) / 2  # span box centre
    return {"id": item_id, "kind": kind, "text": text, "start_s": start, "end_s": end, "family": fam,
            "font_size_px": size, "weight": style.get("weight"), "color": style.get("color", "#FFFFFF"),
            "stroke": style.get("stroke"), "shadow": style.get("shadow"), "box": box, "align": align,
            "anchor_px": {"x": round(x, 1), "y": round(y, 1)}, "ink_dy_px": 0.0 if box else round(-dy * size, 1),
            "animation": anim or {}}


def build_chrome(edl, project: Path, public: Path):
    """Own brand elements in the reference chrome rects (style/chrome.json + brand.json "chrome").

    brand.json: {"chrome": {"ch01": {"image": "brand/icon.png"}, "ch02": {"image": "brand/logo.png"}}}
    image paths are relative to the project. Elements without an entry are left out (never the reference crop)."""
    cp, bp = project / "style" / "chrome.json", project / "brand.json"
    if not cp.exists() or not bp.exists():
        return []
    conf = (read_json(bp).get("chrome") or {})
    out = []
    for e in read_json(cp).get("elements", []):
        c = conf.get(e["id"])
        if not c:
            continue
        item = {"id": f"chrome_{e['id']}", "start_s": 0.0, "end_s": edl["duration_s"],
                "rect_px": c.get("rect_px") or e["rect_px_1080p"], "image": None, "color": c.get("color"),
                "alpha": c.get("alpha"), "radius_px": c.get("radius_px")}
        if c.get("image"):
            src = (project / c["image"]) if not Path(c["image"]).is_absolute() else Path(c["image"])
            if not src.exists():
                sys.exit(f"brand.json chrome {e['id']}: missing image {src}")
            (public / "brand").mkdir(parents=True, exist_ok=True)
            dst, _ = copy_public(src, public / "brand")
            item["image"] = f"brand/{dst.name}"
        out.append(item)
    missing = [e["id"] for e in read_json(cp).get("elements", []) if e["id"] not in conf and e.get("kind_guess") != "subtitle_plate"]
    if missing:
        print(f"note: reference chrome without own replacement in brand.json: {missing}")
    return out


def credit_text(fmt, entry):
    vals = {"author": entry.get("author") or "", "provider": (entry.get("provider") or "").split("/")[-1],
            "title": entry.get("title") or "", "license": entry.get("license") or ""}
    try:
        return fmt.format(**vals).strip()
    except (KeyError, IndexError):
        return fmt


def mix_audio(edl, edl_dir: Path, project: Path, manifest, out_wav: Path):
    dur = edl["duration_s"]
    n = int(dur * SR) + 1
    tts = edl_dir / edl["narration"]["tts_dir"] / "narration.wav"
    voice = np.zeros(n, np.float32)
    if tts.exists():
        v = load_mono(tts, SR)[:n]
        voice[: len(v)] = v
    lv = edl.get("levels", {})

    def gain_to(x, target_lufs, ref_path=None):
        if target_lufs is None or not np.any(x):
            return x
        tmp = out_wav.parent / "_tmp_level.wav"
        sf.write(str(tmp), x, SR)
        cur = lufs(tmp)
        tmp.unlink(missing_ok=True)
        if cur is None or cur < -70:
            return x
        return x * (10 ** ((target_lufs - cur) / 20))

    voice = gain_to(voice, lv.get("voice_lufs"))
    music = np.zeros(n, np.float32)
    for b in edl.get("bgm", []):
        e = manifest.get(b["asset_key"])
        if not e:
            continue
        y = load_mono(project / e["file"], SR)
        i0, i1 = int(b["start_s"] * SR), min(n, int(b["end_s"] * SR))
        off = int(b.get("offset_s", 0) * SR)
        seg = y[off: off + (i1 - i0)]
        if len(seg) < i1 - i0 and len(y):
            seg = np.tile(y, int(np.ceil((i1 - i0) / len(y))) + 1)[: i1 - i0]
        fade = min(len(seg), int(0.03 * SR))
        if fade:
            seg = seg.copy()
            seg[:fade] *= np.linspace(0, 1, fade)
            seg[-fade:] *= np.linspace(1, 0, fade)
        music[i0:i0 + len(seg)] += seg
    music = gain_to(music, lv.get("music_lufs"))
    duck = lv.get("ducking_db")
    if duck and duck > 1 and np.any(voice):
        env = rms_db(voice, SR, 0.05)
        speaking = env > (np.percentile(env, 90) - 25)
        g = np.where(speaking, 10 ** (-duck / 20), 1.0).astype(np.float32)
        k = 6
        g = np.convolve(np.pad(g, k, mode="edge"), np.ones(2 * k + 1) / (2 * k + 1), mode="valid")
        if len(g):
            gg = np.repeat(g, int(0.05 * SR))[:n]
            if len(gg) < n:  # n is not a whole number of 50 ms windows: hold the last gain
                gg = np.pad(gg, (0, n - len(gg)), mode="edge")
            music *= gg
    sfx = np.zeros(n, np.float32)
    for s in edl.get("sfx", []):
        e = manifest.get(s["asset_key"])
        if not e:
            continue
        y = load_mono(project / e["file"], SR)
        if s.get("ref_clip") and Path(s["ref_clip"]).exists():
            ref = load_mono(s["ref_clip"], SR)
            rr = float(np.sqrt(np.mean(ref ** 2)) + 1e-9)
            yr = float(np.sqrt(np.mean(y[: len(ref)] ** 2)) + 1e-9)
            y = y * (rr / yr)
        i = int(s["t"] * SR) - int(e.get("onset_s", 0) * SR)
        i = max(0, i)
        sfx[i:i + len(y)] += y[: n - i]
    mix = voice + music + sfx
    peak = float(np.abs(mix).max()) or 1.0
    if peak > 0.98:
        mix *= 0.98 / peak
    sf.write(str(out_wav), mix, SR)
    return {"voice": bool(np.any(voice)), "music": bool(np.any(music)), "sfx": bool(np.any(sfx))}


def render_prepared(a, edl_dir, rdir, public):
    if getattr(a, 'sample_spec', None):
        from sample_batch import run_batch
        return run_batch(a, edl_dir, rdir, public, TEMPLATE, LFC_HOME, FFMPEG)
    from check_production import check
    from check_render_timing import renderer_dependencies, digest
    manifest_path = Path(a.production_manifest).resolve()
    production = read_json(manifest_path)
    actual_props = (manifest_path.parent / production['render_timing']['props']).resolve()
    if actual_props != (rdir / 'props.json').resolve():
        raise ValueError('Production manifest must point to the actual render props')
    if (manifest_path.parent / production['render']).resolve() != (edl_dir / 'output.mp4').resolve():
        raise ValueError('Production manifest render path must match actual output.mp4')
    if a.preview:
        raise ValueError('Use the planned canvas; --preview scale is not a production render')
    if not (edl_dir / 'mix.wav').is_file():
        raise ValueError('Prepare mix.wav before rendering')
    if str((edl_dir / 'mix.wav').resolve()) not in {str((manifest_path.parent / n).resolve()) for n in production['render_inputs']}:
        raise ValueError('Actual mix.wav missing from render_inputs')
    from draft_delivery import active, basic_check
    result = basic_check(manifest_path) if active() else check(manifest_path, 'assets')
    if not result['passed']:
        raise ValueError('Pre-render gate failed: ' + '; '.join(result['errors']))
    sample = None
    if getattr(a, 'sample_frames', None):
        parts = a.sample_frames.split('-')
        if len(parts) != 2 or not all(x.isdigit() for x in parts):
            raise ValueError('--sample-frames must be START-END inclusive frame indices')
        first, last = map(int, parts)
        timing = result['render_timing_check']
        if not 0 <= first <= last < timing['output_frames']:
            raise ValueError('Sample frames outside checked output scope')
        sample = (first, last, timing['fps'])
    write_json(edl_dir / 'pre_render_check.json', result)
    # Isolate renderer sources per execution; reuse only matching installed dependencies.
    tpl = rdir / 'template'
    from renderer_runtime import setup
    setup(TEMPLATE,LFC_HOME/'remotion-template',tpl,renderer_dependencies())
    sample_tag = f'sample-{sample[0]}-{sample[1]}' if sample else None
    video_only = edl_dir / (f'{sample_tag}.video.mp4' if sample else 'video_only.mp4')
    scale = ["--scale", "0.5"] if a.preview else []
    cmd = ["npx", "remotion", "render", "src/index.ts", "Main", str(video_only), f"--props={rdir / 'props.json'}",
           f"--public-dir={public}", "--muted", f"--concurrency={a.concurrency}", "--codec=h264", "--crf=18", "--log=error",
           *scale]
    if sample:
        cmd.append(f'--frames={sample[0]}-{sample[1]}')
    print("rendering sample ..." if sample else "rendering ...")
    video_record=video_only.with_suffix('.json')
    expected_video={'input_sha256':result['input_sha256'],'props_sha256':digest(actual_props),
                    'template_sha256':result['render_timing_check']['template_sha256']}
    if getattr(a,'remux_only',False):
        if sample:raise ValueError('--remux-only requires the complete planned output')
        if not video_record.is_file() or not video_only.is_file():raise ValueError('Missing original video stream/verification record')
        previous=read_json(video_record)
        if any(previous.get(k)!=v for k,v in expected_video.items()) or previous.get('video_sha256')!=digest(video_only):
            raise ValueError('Video stream is not bound to current checked render inputs')
    else:
        subprocess.run(cmd, cwd=tpl, check=True)
        write_json(video_record,{**expected_video,'video_sha256':digest(video_only)})
    out = edl_dir / (f"{sample_tag}.mp4" if sample else "output.mp4")
    audio_seek = ["-ss", str(sample[0] / sample[2])] if sample else []
    run([FFMPEG, "-hide_banner", "-loglevel", "error", "-y", "-i", str(video_only), *audio_seek, "-i", str(edl_dir / "mix.wav"),
         "-map", "0:v", "-map", "1:a", "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", *(["-shortest"] if sample else []), str(out)])
    actual_output=probe(out)
    timing=result['render_timing_check']
    expected_frames=sample[1]-sample[0]+1 if sample else timing['output_frames']
    if actual_output.get('nb_frames')!=expected_frames or actual_output.get('fps')!=timing['fps'] or [actual_output.get('width'),actual_output.get('height')]!=production['canvas']:
        raise ValueError('Mux output frame count/fps/canvas differs from checked output')
    if sample:
        write_json(edl_dir / f'{sample_tag}.json', {'kind':'inspection_sample','complete_video':False,
                   'start_frame':sample[0],'end_frame_inclusive':sample[1],'fps':sample[2],
                   'input_sha256':result['input_sha256'],'render_sha256':digest(out),'file':str(out)})
    print(f"done -> {out} ({probe(out)['duration_s']:.2f}s)")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--edl", required=True)
    ap.add_argument("--project", required=True)
    ap.add_argument("--preview", action="store_true", help="960x540 fast render")
    ap.add_argument("--no-render", action="store_true")
    ap.add_argument("--render-prepared", action="store_true", help="Render checked existing props and mix without rebuilding inputs")
    ap.add_argument("--production-manifest", help="Required before any production render")
    ap.add_argument("--sample-frames", help="Inspect only START-END inclusive frames; preserves the checked full timeline")
    ap.add_argument("--remux-only", action="store_true", help="Reuse a hash-bound video stream for final audio mux repair")
    ap.add_argument("--sample-spec", help="Registered reviewed immutable inspection batch; actual assets gate once")
    ap.add_argument("--concurrency", type=int, default=3)
    a = ap.parse_args()
    if a.remux_only and (not a.render_prepared or a.sample_frames or a.sample_spec):
        ap.error("--remux-only requires a complete --render-prepared output")
    if a.sample_frames and a.sample_spec:
        ap.error("--sample-frames and --sample-spec are mutually exclusive")
    if (a.sample_frames or a.sample_spec) and not a.render_prepared:
        ap.error("Sample frames/spec requires --render-prepared")
    if a.render_prepared and a.no_render:
        ap.error("--render-prepared and --no-render cannot be combined")
    if not a.no_render and not a.production_manifest:
        ap.error("Rendering requires --production-manifest; prepare inputs first with --no-render")
    edl_path = Path(a.edl).resolve()
    edl_dir = edl_path.parent
    if a.render_prepared:
        render_prepared(a, edl_dir, edl_dir / "render", edl_dir / "render/public")
        return
    edl = read_json(edl_path)
    project = Path(a.project)
    manifest = read_json(project / "assets" / "manifest.json")["items"] if (project / "assets" / "manifest.json").exists() else {}
    keys = [c["asset_key"] for c in edl["cuts"]]
    missing = [k for k in keys if k not in manifest]
    if missing:
        sys.exit(f"assets missing for {len(missing)} cuts: {missing[:10]} (fetch_assets search/pick/register)")
    rdir = edl_dir / "render"
    public = rdir / "public"
    (public / "media").mkdir(parents=True, exist_ok=True)
    cuts, texts, fonts_map = [], [], {}
    for c in edl["cuts"]:
        e = manifest[c["asset_key"]]
        src = project / e["file"]
        dst, signature = copy_public(src, public / "media")
        kind = "image" if e["kind"] == "image" else "video"
        base = float((c.get("layer") or {}).get("initial_scale") or 1.0)
        speed = c.get("speed", 1.0)
        adur = (e.get("probe") or {}).get("duration_s")
        trim = c.get("trim_start_s", 0.0)
        if c.get("retime") == "fit_to_cut" and kind == "video" and adur:
            # reference: a short generated clip slowed down (frame holds) to span the whole cut
            rc = c.get("ref_cut") or {"offset_s": 0.0, "duration_s": c["end_s"] - c["start_s"]}
            # finish 2 source frames early so the clip never runs out (a loop restart would look like a cut)
            usable = max(0.1, adur - 2 / 24)
            if rc.get("covers_s"):
                # only the start of the cut is in the rendered range and only that part was generated (make_edl):
                # play at the reference speed, slower only if the clip came out too short
                speed = round(min(rc.get("ref_speed") or 1.0, usable / max(1e-3, rc["covers_s"])), 5)
            else:
                speed = round(usable / max(1e-3, rc["duration_s"]), 5)
            trim = round(rc["offset_s"] * speed, 4)
        cuts.append({"id": c["id"], "start_s": c["start_s"], "end_s": c["end_s"],
                     "asset": {"file": f"media/{dst.name}", "kind": kind, "source_path": str(src.resolve()), "sha256": signature,
                               "duration_s": adur},
                     "layer": {**{"fit": "cover"}, **(c.get("layer") or {}), "base_scale": base},
                     "keyframes": c.get("keyframes") or {}, "trim_start_s": trim,
                     "speed": speed, "effects": c.get("effects", []),
                     "effect_params": c.get("effect_params", {}), "animation": c.get("animation", {}),
                     "transition_in": c.get("transition_in") or {"type": "cut", "frames": 0},
                     "overlays": c.get("overlays", []),
                     "renderer_layers": prepare_renderer_layers(c.get('renderer_layers', []),
                         c['end_s'] - c['start_s'], public, fonts_map)})
        cr = c.get("credit") or {}
        if cr.get("shown"):
            if not cr.get("style"):
                sys.exit(f"{c['id']}: credit shown in reference but no style (link source_credit.text_event_ids)")
            txt = credit_text(cr.get("format") or cr.get("reference_text") or "{provider}", e)
            ct = cr.get("time") or [c["start_s"], c["end_s"]]
            texts.append(text_item(f"credit_{c['id']}", "credit", txt, ct[0], ct[1], cr["style"], fonts_map, public))
    for t in edl.get("texts", []):
        if t.get("text") is None:
            sys.exit(f"text {t['id']} has no text (copied pop-up from donor {t.get('reference_text')!r}); fill it in edl.json")
        texts.append(text_item(t["id"], "text", t["text"], t["start_s"], t["end_s"], t["style"], fonts_map, public,
                               t.get("animation")))
    brand_cfg = project / "brand.json"
    if edl.get("brand"):
        if brand_cfg.exists():
            bc = read_json(brand_cfg)
            for b in edl["brand"]:
                txt = (bc.get("zones") or {}).get(b["zone"])
                if txt:
                    st = dict(b["style"])
                    if bc.get("font_file"):
                        st["font_file"] = bc["font_file"]
                    texts.append(text_item(f"brand_{b['zone']}", "text", txt, b["start_s"], b["end_s"], st, fonts_map, public))
        else:
            print(f"note: reference shows a channel logo ({[b['reference_text'] for b in edl['brand']]}); "
                  f"write {brand_cfg} with your own channel name per zone to place it identically")
    chrome = build_chrome(edl, project, public)
    props = {"fps": edl["fps"], "width": 1920, "height": 1080, "duration_s": edl["duration_s"],
             "background": edl.get("background", "#000000"), "cuts": cuts, "texts": texts, "chrome": chrome,
             "fonts": [{"family": fam, "file": f"fonts/{copy_public(Path(p), public / 'fonts')[0].name}"} for p, fam in fonts_map.items()], "audio": None}
    write_json(rdir / "props.json", props)
    print(f"props: {len(cuts)} cuts, {len(texts)} texts ({sum(1 for t in texts if t['kind'] == 'credit')} credits), "
          f"{len(fonts_map)} fonts -> {rdir / 'props.json'}")
    audio_info = mix_audio(edl, edl_dir, project, manifest, edl_dir / "mix.wav")
    print(f"audio mix: {audio_info} -> {edl_dir / 'mix.wav'}")
    if a.no_render:
        return
    render_prepared(a, edl_dir, rdir, public)


if __name__ == "__main__":
    main()
