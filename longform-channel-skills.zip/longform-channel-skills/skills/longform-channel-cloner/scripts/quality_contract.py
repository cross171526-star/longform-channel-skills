"""실제 컷 근거·자료 논거·대표 난컷의 구조 검사. 관찰 사실이나 의미를 자동 승인하지 않는다."""
import json
import math
from pathlib import Path
from work_guard import FileSnapshot,digest
from scheduler import provenance

FIELDS=('visual_role','narrative_role','ink_geometry','texture','anchors','before','middle','after','material_role')


def validate(path,review=None,require_front=False):
    path=Path(path).resolve();snap=FileSnapshot();doc=snap.document(path);errors=[];deps={}
    def require(ok,msg):
        if not ok:errors.append(msg)
    def bound(row,label):
        if not isinstance(row,dict) or not row.get('path') or not row.get('sha256'):
            require(False,'Unbound evidence '+label);return
        try:p,h=snap.add(path.parent/row['path']);deps[p]=h;require(h==row['sha256'],'Changed '+label)
        except OSError:require(False,'Missing '+label)
    require(doc.get('schema')=='lfc-cut-contract-v1','Unsupported cut contract')
    cuts=doc.get('cuts',[]);ids=[c.get('id') for c in cuts]
    require(bool(ids) and len(set(ids))==len(ids) and all(ids),'Unique complete cut IDs required')
    require(doc.get('complete_cut_ids')==ids,'Contract must cover complete planned cut set')
    scoped=doc.get('readiness_version',1)>=2
    output_ids=ids
    if scoped:
        scope=doc.get('output_scope',{});link=scope.get('manifest',{})
        bound(link,'current output plan manifest')
        if link.get('path') and (path.parent/link['path']).is_file():
            manifest=snap.document(path.parent/link['path']);actual_scope=manifest.get('output_scope',{'kind':'full'})
            planned=manifest.get('cuts',[]);cursor=0;expected=[];ranges=[]
            require([c.get('id') for c in planned]==ids,'Output manifest must preserve complete planned cut order')
            for c in planned:
                duration=c.get('duration_s')
                valid=type(duration) in (int,float) and math.isfinite(duration) and duration>0
                require(valid,'Actual planned cut duration required: '+str(c.get('id')))
                if valid:ranges.append((c.get('id'),cursor,cursor+duration));cursor+=duration
            interval=[0,cursor] if actual_scope.get('kind')=='full' else [actual_scope.get('start_s'),actual_scope.get('end_s')]
            valid_range=all(type(x) in (int,float) and math.isfinite(x) for x in interval) and interval[0]==0 and interval[1]>0
            require(actual_scope.get('kind') in ('preview','full'),'Actual output manifest scope required')
            if actual_scope.get('kind')=='preview':valid_range=valid_range and min(170,cursor)<=interval[1]<=min(210,cursor)
            require(valid_range,'Actual preview manifest must start at zero and preserve 170–210s/shorter-film limits')
            if valid_range:expected=[ident for ident,start,end in ranges if start<interval[1] and end>interval[0]]
            output_ids=scope.get('cut_ids',[])
            require(scope.get('kind')==actual_scope.get('kind') and scope.get('range_s')==interval,'Readiness scope differs from actual output plan')
            require(bool(output_ids) and output_ids==expected,'Readiness must cover every actual output-manifest cut in order')
        else:require(False,'Actual output plan manifest missing')
    for c in cuts:
        for key in FIELDS:require(bool(c.get(key)),c['id']+': missing '+key)
        require(bool(c.get('visual_evidence')) and bool(c.get('script_evidence')),c['id']+': dual evidence required')
        for name in ('visual_evidence','script_evidence'):
            for e in c.get(name,[]):bound(e,c['id']+':'+name)
        states=c.get('reference_states',{})
        for phase in ('before','middle','after'):
            row=states.get(phase);bound(row,c['id']+':'+phase)
            if isinstance(row,dict) and row.get('path'):
                from production_preflight import inspect_file
                try:require(inspect_file(path.parent/row['path'])['kind']=='image',c['id']+': reference state must be actual frame image')
                except (OSError,ValueError):require(False,c['id']+': invalid reference frame')
        for claim in c.get('claims',[]):
            require(claim.get('kind') in ('channel_grammar','episode_fact'),c['id']+': classify reusable grammar/episode fact')
            require(bool(claim.get('text')),c['id']+': empty claim')
            if claim.get('kind')=='episode_fact':
                require(bool(claim.get('new_topic_evidence')),c['id']+': episode fact has no new-topic evidence')
                for e in claim.get('new_topic_evidence',[]):bound(e,c['id']+':new-topic fact')
            if claim.get('screen_is_evidence') is True:
                require(claim.get('asset_relation')=='actual_record',c['id']+': generic/illustrative material cannot be actual-event evidence')
                deferred=scoped and c['id'] not in output_ids and c.get('material_readiness')=='deferred'
                if deferred:
                    require(bool(c.get('unresolved_items')),c['id']+': deferred actual-record asset must remain explicitly unresolved')
                else:require(bool(claim.get('asset_evidence')),c['id']+': actual-record link required')
                for e in claim.get('asset_evidence',[]):bound(e,c['id']+':actual-record')
        require(isinstance(c.get('unresolved_items'),list),c['id']+': explicit unresolved required')
    pilot=doc.get('pilot',{});samples=pilot.get('samples',[]);sample_ids=[x.get('cut_id') for x in samples]
    require(3<=len(samples)<=5 and len(set(sample_ids))==len(samples),'Pilot needs 3–5 distinct difficult cuts')
    require(set(sample_ids)<=set(ids),'Unknown pilot cut')
    if scoped:require(set(sample_ids)<=set(output_ids),'Pilot difficult cuts must belong to first output scope')
    total=0
    for s in samples:
        require(bool(s.get('risk_reason')),'Pilot difficulty reason required')
        a,b=s.get('absolute_range_s',[None,None])
        require(isinstance(a,(int,float)) and isinstance(b,(int,float)) and 0<=a<b,'Pilot range invalid')
        if isinstance(a,(int,float)) and isinstance(b,(int,float)):total+=b-a
        require(bool(s.get('line_ids')),'Pilot representative narration IDs required')
    require(25<=total<=35,'Pilot must total approximately 30 seconds (25–35); final 170–210s scope unchanged')
    result={'passed':not errors,'errors':errors,'dependencies_sha256':deps,'output_sha256':{str(path):digest(path)},
            'pilot_cut_ids':sample_ids,'pilot_line_ids':sorted({x for s in samples for x in s.get('line_ids',[])}),
            'content_accuracy_verified':False,'pilot_independent_passed':False,'front_independent_passed':False,
            'readiness_cut_ids':output_ids,
            'deferred_cut_ids':[x for x in ids if x not in output_ids],
            'unresolved_items':[x for c in cuts if c['id'] in output_ids for x in c.get('unresolved_items',[])],
            'deferred_unresolved_items':[x for c in cuts if c['id'] not in output_ids for x in c.get('unresolved_items',[])]}
    if review:
        rp=Path(review).resolve();r=snap.document(rp);actual=provenance(r['reviewer_rollout'])
        require(r.get('contract_sha256')==digest(path),'Pilot review contract changed')
        require(actual['session']==r.get('session_id'),'Pilot reviewer actual session differs')
        require(actual['session'] not in r.get('implementation_session_ids',[]),'Pilot reviewer must be independent')
        require(bool(r.get('implementation_session_ids')),'Implementation provenance required')
        require(r.get('observed_cut_ids')==sample_ids,'Pilot review coverage differs')
        require(r.get('direct_observation') is True and r.get('visual_passed') is True and r.get('script_passed') is True,'Pilot observed visual/script decision required')
        require(r.get('unresolved_items')==[],'Pilot unresolved items remain')
        require(result['unresolved_items']==[],'Planned cuts still have unresolved material/dual-evidence conditions')
        producer=r.get('pilot_render_report',{})
        bound(producer,'pilot actual producer report')
        require(bool(producer.get('path')),'Actual pilot-render-report binding required')
        if producer.get('path'):
            rr=snap.document(path.parent/producer['path'])
            require(rr.get('passed') is True and rr.get('kind')=='pilot_actual_output_not_content_approval','Pilot output generation did not pass')
            require(rr.get('contract_sha256')==digest(path),'Pilot actual output contract differs')
            require([x.get('cut_id') for x in rr.get('samples',[])]==sample_ids,'Pilot actual output cut coverage differs')
            actual_outputs=rr.get('output_sha256',{})
            for name,h in actual_outputs.items():bound({'path':name,'sha256':h},'actual pilot output')
            for expected,actual in zip(samples,rr.get('samples',[])):
                media=actual.get('render',{});fps=rr.get('fps');a,b=expected['absolute_range_s']
                if not isinstance(fps,(int,float)) or fps<=0:require(False,'Actual pilot fps required');continue
                wanted=[round(a*fps),round(b*fps)-1]
                require(actual.get('absolute_frames_inclusive')==wanted,'Actual pilot absolute range differs')
                require(actual_outputs.get(media.get('path'))==media.get('sha256'),'Actual pilot clip is not bound to outputs')
                if media.get('path'):
                    from common import probe
                    from production_preflight import inspect_file
                    require(inspect_file(media['path'])['kind']=='media','Actual pilot clip must decode as media')
                    actual_probe=probe(media['path'])
                    require(actual_probe.get('nb_frames')==wanted[1]-wanted[0]+1 and actual_probe.get('fps')==fps,'Actual pilot clip frame/fps mismatch')
                else:require(False,'Actual pilot clip missing')
            require(all(str((path.parent/x['path']).resolve()) in actual_outputs and actual_outputs[str((path.parent/x['path']).resolve())]==x['sha256'] for x in r.get('render_evidence',[])),'Review pixels must come from bound actual pilot output, not original frames')
        for row in r.get('render_evidence',[]):
            bound(row,'pilot-render')
            from production_preflight import inspect_file
            require(inspect_file(path.parent/row['path'])['kind'] in ('media','image'),'Pilot review must bind actual output pixels, not a success JSON')
        require(bool(r.get('render_evidence')),'Pilot actual output evidence required')
        if require_front or r.get('front_review'):
            front=r.get('front_review',{});script=doc.get('full_script',{})
            bound(script,'complete front script')
            require(front.get('full_script_sha256')==script.get('sha256') and bool(script.get('sha256')),'Front review full script binding differs')
            require(front.get('complete_script_reviewed') is True and front.get('script_passed') is True,'Full script causal/structural/factual review missing')
            if scoped:
                require(front.get('plan_cut_ids')==ids and front.get('plan_semantics_passed') is True,'Full-plan narrative/visual roles must be independently reviewed')
                require(front.get('material_cut_ids')==output_ids and front.get('materials_passed') is True,'Actual material readiness must cover current first output scope')
                require(front.get('deferred_material_cut_ids')==result['deferred_cut_ids'],'Unoutput full-film material readiness must remain explicitly deferred')
            else:
                require(front.get('material_cut_ids')==ids and front.get('materials_passed') is True,'Front material review must cover complete planned cut set')
            require(front.get('unresolved_items')==[],'Front script/material issues remain')
            require(bool(front.get('evidence')),'Front independent judgment evidence required')
            for row in front.get('evidence',[]):bound(row,'front judgment')
            result['front_independent_passed']=not errors
        result['pilot_independent_passed']=not errors
        # This binds a recorded independent judgment; it cannot prove that the model actually saw the images.
        result['judgment_source']='recorded independent direct observation, not inferred from numeric/hash checks'
    snap.unchanged();result['passed']=not errors;result['errors']=errors
    return result


def guard_tool(root,name,args):
    """신규 실행의 전체 TTS/최종 렌더 전에 실제 pilot을 요구한다. 구형 스냅샷은 변경하지 않는다."""
    from scheduler import modern_run
    if not modern_run(root):return
    if topic_required(root):ready_topic(root)
    contract=Path(root)/'work/quality-contract.json';review=Path(root)/'work/pilot-review.json'
    if not contract.is_file():raise ValueError('Create and validate work/quality-contract.json before production')
    front_version=json.loads((Path(root)/'run.json').read_text()).get('front_review_version',0)
    front_required=front_version>=1
    if front_version>=2 and json.loads(contract.read_text()).get('readiness_version',1)<2:
        raise ValueError('Current run requires explicit scoped readiness contract v2; preserve old run and create new revision')
    report=validate(contract,review if review.is_file() else None,require_front=front_required)
    if not report['passed']:raise ValueError('; '.join(report['errors']))
    if front_version>=2 and name=='build_timeline' and '--production-manifest' in args:
        requested=json.loads(Path(args[args.index('--production-manifest')+1]).read_text())
        doc=json.loads(contract.read_text());link=doc['output_scope']['manifest']
        planned=json.loads((contract.parent/link['path']).read_text())
        actual_scope=requested.get('output_scope',{'kind':'full'});basis_scope=planned.get('output_scope',{'kind':'full'})
        keys=('kind','start_s','end_s')
        if [(c['id'],c['duration_s']) for c in requested.get('cuts',[])]!=[(c['id'],c['duration_s']) for c in planned['cuts']] or any(actual_scope.get(k)!=basis_scope.get(k) for k in keys):
            raise ValueError('Render output scope differs from independently approved material-readiness scope')
    approved=report['pilot_independent_passed'] and (not front_required or report['front_independent_passed'])
    if front_version>=2 and name=='build_timeline' and approved and '--no-render' not in args and not any(x in args for x in ('--sample-spec','--sample-frames')) and '--production-manifest' not in args:
        raise ValueError('Current independently approved output manifest required for final rendering')
    if name=='tts' and not approved:
        if '--lines' not in args:raise ValueError('Explicit representative lines required before pilot review')
        rows=json.loads(Path(args[args.index('--lines')+1]).read_text())
        if not rows or not {r['id'] for r in rows}<=set(report['pilot_line_ids']):
            raise ValueError('Only pilot representative lines may be synthesized before independent pilot pass')
    if name=='build_timeline' and '--no-render' not in args and not approved:
        if '--sample-spec' not in args:raise ValueError('Render the declared pilot sample batch before final preview')
        spec=json.loads(Path(args[args.index('--sample-spec')+1]).read_text())
        expected=[[round(a*spec['fps']),round(b*spec['fps'])-1] for s in json.loads(contract.read_text())['pilot']['samples'] for a,b in [s['absolute_range_s']]]
        if [c['frames_inclusive'] for c in spec.get('clips',[])]!=expected:
            raise ValueError('Pre-pass render samples differ from declared difficult-cut pilot')


def inspect_topic_source(path):
    """문서·사진·영상의 실제 내용 접근을 확인한다. 내용 적합성/권한은 기록된 모델 판단이다."""
    path=Path(path).resolve();suffix=path.suffix.lower()
    if suffix in ('.txt','.md','.html','.htm','.json'):
        text=path.read_text(encoding='utf-8')
        if suffix=='.json':json.loads(text)
        if suffix in ('.html','.htm'):
            from html.parser import HTMLParser
            class Text(HTMLParser):
                def __init__(self):super().__init__();self.values=[];self.skip=0
                def handle_starttag(self,tag,attrs):
                    if tag in ('script','style'):self.skip+=1
                def handle_endtag(self,tag):
                    if tag in ('script','style'):self.skip=max(0,self.skip-1)
                def handle_data(self,value):
                    if not self.skip:self.values.append(value)
            parser=Text();parser.feed(text);text=' '.join(parser.values)
        if not text.strip():raise ValueError('Source document has no actual readable content')
        return 'document'
    if suffix=='.pdf':
        import fitz
        with fitz.open(path) as doc:
            if not len(doc):raise ValueError('PDF has no actual pages')
            doc[0].get_pixmap(matrix=fitz.Matrix(.2,.2))
        return 'document'
    from production_preflight import inspect_file
    kind=inspect_file(path)['kind']
    if kind not in ('image','media'):raise ValueError('Unsupported source content; supply actual readable document or usable media')
    return kind


def validate_topic(materials,request,review=None,require_independent=False):
    materials=Path(materials).resolve();request=Path(request).resolve();snap=FileSnapshot();doc=snap.document(materials);req=snap.document(request)
    errors=[];unresolved=[];deps={str(materials):digest(materials),str(request):digest(request)};checked=[];attempts=[]
    def require(ok,message):
        if not ok:errors.append(message)
    def bound(row,label):
        if not isinstance(row,dict) or not row.get('path') or not row.get('sha256'):
            require(False,'Actual bound '+label+' required');return None
        try:
            p,h=snap.add(materials.parent/row['path']);deps[p]=h;require(h==row['sha256'],'Changed '+label);return p
        except OSError:require(False,'Missing '+label);return None
    require(req.get('schema')=='lfc-topic-request-v1','Explicit topic request required')
    require(type(req.get('user_fixed_topic')) is bool and bool(req.get('user_instruction')) and bool(req.get('instruction_source')),'Scoped actual user topic instructions required')
    require(doc.get('schema')=='lfc-topic-materials-v1' and bool(doc.get('topic')),'Current topic materials assessment required')
    require(doc.get('request_sha256')==digest(request),'Topic request binding changed')
    if req.get('user_fixed_topic') is True:
        require(bool(req.get('topic')) and doc.get('topic')==req['topic'],'User fixed topic cannot be changed by material availability')
    try:
        actual=provenance(doc['reviewer_rollout']);require(actual['session']==doc.get('session_id'),'Actual topic researcher session differs')
    except (KeyError,OSError,ValueError) as exc:require(False,str(exc))
    claims=doc.get('core_claims',[]);claim_ids=[c.get('id') for c in claims]
    require(bool(claims) and all(claim_ids) and len(set(claim_ids))==len(claim_ids) and all(c.get('text') for c in claims),'Define actual core claims before full script')
    scenes=doc.get('essential_scenes',[]);scene_ids=[s.get('id') for s in scenes];covered=set()
    require(bool(scenes) and all(scene_ids) and len(set(scene_ids))==len(scene_ids),'Define essential scenes, without a fixed number')
    for scene in scenes:
        ident=scene.get('id','?');linked=scene.get('claim_ids',[]);covered.update(linked)
        require(bool(scene.get('description')) and bool(linked) and set(linked)<=set(claim_ids),ident+': scene/core claim mapping required')
        require(scene.get('role') in ('actual_record','explanation'),ident+': classify event evidence or explanation')
        require(scene.get('material_kind','any') in ('any','document','image','media'),ident+': invalid material type')
        usable=False
        for source in scene.get('sources',[]):
            state=source.get('access_status');attempts.append({'scene_id':ident,'access_status':state,'reason':source.get('reason','')})
            require(state in ('inspected','access_failed','not_found','insufficient'),ident+': explicit access outcome required')
            if state!='inspected':
                require(bool(source.get('reason')),ident+': unresolved access/search outcome needs reason');continue
            source_errors=len(errors)
            require(source.get('source_type')=='source_content',ident+': search result/link alone is not actual source content')
            require(bool(source.get('origin')),ident+': actual source origin required')
            path=bound(source.get('file'),ident+' source sample')
            kind=None
            if path:
                try:kind=inspect_topic_source(path)
                except Exception as exc:require(False,ident+': actual source cannot be read: '+str(exc))
            if scene.get('material_kind','any')!='any':require(kind==scene['material_kind'],ident+': source type does not fulfill essential scene')
            require(source.get('role') in ('actual_record','factual_source','illustration'),ident+': source narrative role required')
            if scene.get('role')=='actual_record':require(source.get('role')=='actual_record',ident+': illustration/generic source cannot substitute event evidence')
            inspection=source.get('inspection',{})
            require(inspection.get('content_matches') is True and bool(inspection.get('content_note')),ident+': recorded actual content match needed')
            require(inspection.get('usable_quality') is True and bool(inspection.get('quality_note')),ident+': recorded usable quality needed')
            require(bool(inspection.get('evidence')),ident+': actual inspection record required')
            for row in inspection.get('evidence',[]):bound(row,ident+' content/quality inspection')
            usage=source.get('usage',{})
            require(usage.get('status')=='confirmed' and bool(usage.get('basis')),ident+': usage conditions unresolved')
            for row in usage.get('basis',[]):bound(row,ident+' usage basis')
            if len(errors)==source_errors:usable=True;checked.append({'scene_id':ident,'path':path,'kind':kind,'role':source['role']})
        if not usable:unresolved.append(ident);require(False,ident+': essential material unresolved; continue preparation, not topic/full script commitment')
    require(covered==set(claim_ids),'Every core claim needs an essential scene/material mapping')
    require(doc.get('story_supported') is True and bool(doc.get('supported_scope')),'Confirm story scope from actually available sources')
    independent=require_independent or doc.get('semantic_review_version',1)>=2
    if independent:
        mapping=doc.get('reference_semantics',{})
        bound(mapping.get('analysis'),'original full analysis')
        roles=mapping.get('roles',[])
        require(bool(roles),'Reference story and required visual roles must be mapped before full script')
        for role in roles:
            require(bool(role.get('reference_role')) and bool(role.get('candidate_role')) and role.get('matches') is True,'Candidate must fulfill reference narrative/visual role')
            require(bool(role.get('evidence')),'Role fit needs inspected content evidence')
            for row in role.get('evidence',[]):bound(row,'candidate role fit')
        difficult=doc.get('difficult_scene_ids',[])
        require(bool(difficult) and set(difficult)<=set(scene_ids),'Key difficult scene feasibility must be inspected before full script')
        require(review is not None,'Independent topic semantic decision required before full script')
        if review is not None:
            rp=Path(review).resolve();r=snap.document(rp);deps[str(rp)]=digest(rp)
            try:
                observer=provenance(r['reviewer_rollout'])
                require(observer['session']==r.get('session_id') and observer['session']!=doc.get('session_id'),'Topic semantic reviewer must be actual independent Sol High session')
            except (KeyError,OSError,ValueError) as exc:require(False,str(exc))
            require(r.get('schema')=='lfc-topic-semantic-review-v1' and r.get('assessment_sha256')==digest(materials) and r.get('request_sha256')==digest(request),'Independent topic decision bound to different assessment/request')
            require(r.get('reference_roles_reviewed') is True and r.get('story_fit_passed') is True and r.get('difficult_scenes_passed') is True,'Independent topic story/essential-screen fit incomplete')
            require(r.get('reviewed_scene_ids')==scene_ids and r.get('unresolved_items')==[],'Independent topic coverage incomplete or unresolved')
            require(bool(r.get('evidence')),'Independent topic judgment evidence required')
            for row in r.get('evidence',[]):bound(row,'independent topic judgment')
    snap.unchanged()
    return {'passed':not errors,'topic_ready':not errors,'errors':errors,'unresolved_essential_scene_ids':unresolved,'access_attempts':attempts,
            'checked_samples':checked,'dependencies_sha256':deps,'output_sha256':{str(materials):digest(materials)},
            'topic':doc.get('topic'),'user_fixed_topic':req.get('user_fixed_topic'),
            'not_found_is_not_proof_of_absence':True,'all_cuts_precollected':False,'content_truth_or_rights_automatically_verified':False}


def topic_required(root):
    config=Path(root)/'run.json'
    return config.is_file() and json.loads(config.read_text()).get('topic_materials_version',0)>=1


def ready_topic(root):
    root=Path(root);materials=root/'work/topic-materials.json';request=root/'work/topic-request.json'
    if not materials.is_file() or not request.is_file():raise ValueError('Agent must inspect core topic materials before full-script planning; prepare/research remains available')
    version=json.loads((root/'run.json').read_text()).get('topic_materials_version',0)
    review=root/'work/topic-review.json'
    result=validate_topic(materials,request,review if version>=2 and review.is_file() else None,require_independent=version>=2)
    if not result['passed']:raise ValueError('; '.join(result['errors']))
    return result
