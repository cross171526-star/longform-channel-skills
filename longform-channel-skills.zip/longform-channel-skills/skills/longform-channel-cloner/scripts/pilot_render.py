"""전체 TTS 이전 3–5난컷의 약30초 실제 시각 표본. 고정 Main의 절대 시계로만 출력한다."""
import argparse
import json
from pathlib import Path
import subprocess
import sys
from common import FFMPEG,LFC_HOME,probe
from quality_contract import validate
from renderer_runtime import setup
from check_render_timing import renderer_dependencies,TEMPLATE
from work_guard import digest,FileSnapshot
from production_preflight import clock_check,inspect_file


def render(contract,props_path,public,out):
    contract,props_path,public,out=map(lambda p:Path(p).resolve(),(contract,props_path,public,out))
    valid=validate(contract)
    if not valid['passed']:raise ValueError('; '.join(valid['errors']))
    if out.exists():raise ValueError('Preserve pilot output; use a fresh directory')
    c=json.loads(contract.read_text());p=json.loads(props_path.read_text());fps=p['fps'];total=round(p['duration_s']*fps)
    if {x['id'] for x in p['cuts']}!=set(valid['pilot_cut_ids']):raise ValueError('Pilot props may contain only declared difficult cuts')
    if p.get('audio') is not None:raise ValueError('Pilot visual renderer uses representative narration separately; no fabricated listening approval')
    watch=FileSnapshot();watch.add(contract);watch.add(props_path)
    files=[]
    def consumer(value,key=''):
        if isinstance(value,dict):
            for k,v in value.items():consumer(v,k)
        elif isinstance(value,list):
            for v in value:consumer(v,key)
        elif isinstance(value,str) and key in ('file','image'):
            q=(public/value).resolve()
            if not q.is_relative_to(public):raise ValueError('Public consumer escapes isolated directory')
            watch.add(q);files.append(inspect_file(q))
    consumer(p)
    cuts={x['id']:x for x in p['cuts']}
    for row in c['pilot']['samples']:
        a,b=row['absolute_range_s'];cut=cuts[row['cut_id']]
        if not cut['start_s']<=a<b<=cut['end_s']:raise ValueError('Pilot range must remain inside its original absolute cut')
        if b>p['duration_s']:raise ValueError('Pilot composition truncates late absolute sample')
        nodes=cut.get('renderer_layers',[])
        subprocess.run(['node','-e','const s=require(process.argv[1]);s.validateScenes(JSON.parse(process.argv[2]),Number(process.argv[3]));',str(TEMPLATE/'src/sceneContract.cjs'),json.dumps(nodes),str(cut['end_s']-cut['start_s'])],capture_output=True,text=True,check=True)
    frames=[0,total-1]+[round(t*fps) for r in c['pilot']['samples'] for t in [r['absolute_range_s'][0],(sum(r['absolute_range_s'])/2),r['absolute_range_s'][1]-1/fps]]
    clock_check({'fps':fps,'master_duration_s':p['duration_s'],'composition_frames':total,'absolute_frames':frames,'functional_boundary_frames':[0,total-1],'reset_clock_or_rebase_props':False})
    out.mkdir(parents=True);tpl=out/'template';deps=renderer_dependencies();setup(TEMPLATE,LFC_HOME/'remotion-template',tpl,deps)
    for f in deps:watch.add(f)
    outputs=[];samples=[]
    for row in c['pilot']['samples']:
        a,b=row['absolute_range_s'];first,last=round(a*fps),round(b*fps)-1;mp4=out/(row['cut_id']+'.mp4')
        watch.unchanged()
        subprocess.run(['npx','remotion','render','src/index.ts','Main',str(mp4),f'--props={props_path}',f'--public-dir={public}',f'--frames={first}-{last}','--muted','--concurrency=3','--codec=h264','--log=error'],cwd=tpl,check=True,capture_output=True,text=True)
        actual=probe(mp4)
        if actual.get('nb_frames')!=last-first+1 or actual.get('fps')!=fps:raise ValueError('Pilot actual frame count/fps differ')
        outputs.append(mp4);stills=[]
        for label,absolute in [('before',first),('middle',(first+last)//2),('after',last)]:
            image=out/(row['cut_id']+'-'+label+'.png')
            subprocess.run(['npx','remotion','still','src/index.ts','Main',str(image),f'--props={props_path}',f'--public-dir={public}',f'--frame={absolute}','--log=error'],cwd=tpl,check=True,capture_output=True,text=True)
            outputs.append(image);stills.append({'phase':label,'absolute_frame':absolute,'path':str(image),'sha256':digest(image)})
        samples.append({'cut_id':row['cut_id'],'absolute_frames_inclusive':[first,last],'stills':stills,'render':{'path':str(mp4),'sha256':digest(mp4),'fps':fps,'frames':last-first+1,'canvas':[p['width'],p['height']]}})
    watch.unchanged()
    result={'passed':True,'kind':'pilot_actual_output_not_content_approval','contract_sha256':digest(contract),'props_sha256':digest(props_path),
            'dependencies_sha256':{p:watch.digests[p] for p in watch.digests},'output_sha256':{str(p):digest(p) for p in outputs},
            'samples':samples,'fps':fps,'files':files,'full_composition_frames':total,'content_accuracy_verified':False,'actual_listening_passed':False}
    (out/'pilot-render-report.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    return result


def main():
    a=argparse.ArgumentParser();a.add_argument('--contract',required=True);a.add_argument('--props',required=True);a.add_argument('--public',required=True);a.add_argument('--out',required=True);s=a.parse_args()
    try:
        r=render(s.contract,s.props,s.public,s.out);print(json.dumps({'passed':True,'report':str(Path(s.out)/'pilot-render-report.json')}));return 0
    except (OSError,ValueError,KeyError,subprocess.SubprocessError) as e:print(json.dumps({'passed':False,'error':str(e)}));return 1

if __name__=='__main__':sys.exit(main())
