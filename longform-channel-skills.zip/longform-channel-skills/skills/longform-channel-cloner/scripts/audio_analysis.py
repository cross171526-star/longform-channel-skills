#!/usr/bin/env python3
"""Separate narration / music, find BGM segments and sound effects, and measure levels.

  run.sh audio_analysis <video> --out <analysis_dir> [--cuts <cuts.json>] [--range START:END]
                        [--device mps|cpu] [--no-clap]

1. Demucs htdemucs -> stems/vocals.wav and stems/music.wav (drums+bass+other).
2. Loudness (EBU R128) of mix, voice, music; music-to-voice ratio while speaking vs in gaps (ducking).
3. BGM segments: music presence (RMS) + timbre novelty -> segments with tempo, level, mood tags (CLAP).
4. SFX events: transient onsets in the music stem that stand out from the local music bed; each labelled by
   CLAP (whoosh, impact, riser, pop, click, ding, typing, camera shutter, glitch, ...) and linked to the
   nearest cut boundary (offset ms). SFX that sit under voice are also caught because voice is removed first.
Writes <out>/audio.json plus stems. Labels are zero-shot guesses: listen to sfx clips (<out>/sfx/*.wav).
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

import numpy as np
import soundfile as sf

from common import extract_wav, lufs, parse_range, probe, read_json, rms_db, write_json

SFX_LABELS = ["whoosh swoosh transition", "impact boom hit", "cinematic riser build up", "bass drop",
              "pop sound", "mouse click", "ding bell notification", "keyboard typing", "camera shutter",
              "glitch digital error", "cash register ka-ching", "record scratch", "heartbeat", "drum hit",
              "explosion", "thunder", "applause", "laugh track", "wind whoosh", "sword swish",
              "magic sparkle chime", "error buzzer", "swipe paper", "footsteps", "gunshot"]
NON_SFX = ["background music", "piano music", "orchestral music", "electronic beat music", "silence"]
MOODS = ["suspenseful dark cinematic music", "epic orchestral music", "sad emotional piano music",
         "upbeat happy music", "lofi chill hip hop", "mysterious ambient drone", "tense documentary music",
         "corporate inspiring music", "horror creepy music", "funny quirky music", "calm peaceful acoustic music",
         "energetic electronic music", "news broadcast music", "retro synthwave music"]


def separate(wav: Path, out: Path, device: str) -> tuple[Path, Path]:
    import torch
    from demucs.apply import apply_model
    from demucs.pretrained import get_model
    voc, mus = out / "stems" / "vocals.wav", out / "stems" / "music.wav"
    if voc.exists() and mus.exists():
        return voc, mus
    model = get_model("htdemucs")
    model.eval()
    data, sr = sf.read(str(wav), dtype="float32", always_2d=True)
    x = torch.from_numpy(data.T)[None]
    ref = x.mean(1, keepdim=True)
    x = (x - ref.mean()) / (ref.std() + 1e-8)
    try:
        with torch.no_grad():
            y = apply_model(model, x, device=device, split=True, overlap=0.25, progress=True)[0]
    except Exception as e:  # MPS op gaps -> CPU
        print(f"demucs on {device} failed ({e}); retrying on cpu")
        with torch.no_grad():
            y = apply_model(model, x, device="cpu", split=True, overlap=0.25, progress=True)[0]
    y = y * (ref.std() + 1e-8) + ref.mean()
    names = model.sources
    vocals = y[names.index("vocals")].numpy().T
    music = sum(y[names.index(n)] for n in names if n != "vocals").numpy().T
    voc.parent.mkdir(parents=True, exist_ok=True)
    sf.write(str(voc), vocals, sr)
    sf.write(str(mus), music, sr)
    return voc, mus


class Clap:
    def __init__(self, device="cpu"):
        import torch
        from transformers import ClapModel, ClapProcessor
        name = "laion/larger_clap_general"
        self.torch = torch
        self.proc = ClapProcessor.from_pretrained(name)
        self.model = ClapModel.from_pretrained(name).eval()
        self.device = "cpu"
        if device != "cpu":
            try:  # MPS: ~3x faster than CPU, same top-1 labels (measured 95/95)
                self.model = self.model.to(device)
                self.device = device
            except Exception as e:  # noqa: BLE001
                print(f"CLAP on {device} unavailable ({e}); using cpu")
        self._text = {}

    def _to(self, inp):
        return {k: v.to(self.device) for k, v in inp.items()} if self.device != "cpu" else inp

    def text_emb(self, labels):
        key = tuple(labels)
        if key not in self._text:
            inp = self._to(self.proc(text=list(labels), return_tensors="pt", padding=True))
            with self.torch.no_grad():
                e = self.model.get_text_features(**inp)
            e = e.pooler_output if hasattr(e, "pooler_output") else e
            self._text[key] = e / e.norm(dim=-1, keepdim=True)
        return self._text[key]

    def classify(self, clips, labels, sr=48000):
        if not clips:
            return []
        inp = self._to(self.proc(audio=[c.astype(np.float32) for c in clips], sampling_rate=sr, return_tensors="pt"))
        with self.torch.no_grad():
            a = self.model.get_audio_features(**inp)
        a = a.pooler_output if hasattr(a, "pooler_output") else a
        a = a / a.norm(dim=-1, keepdim=True)
        t = self.text_emb(labels)
        probs = (100 * a @ t.T).softmax(-1).cpu().numpy()
        return [[(labels[j], float(p[j])) for j in np.argsort(-p)[:3]] for p in probs]


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("video")
    ap.add_argument("--out", required=True)
    ap.add_argument("--cuts")
    ap.add_argument("--range")
    ap.add_argument("--device", default="mps")
    ap.add_argument("--no-clap", action="store_true")
    ap.add_argument("--sfx-sensitivity", type=float, default=3.0, help="MADs above local onset median")
    ap.add_argument("--max-sfx", type=int, default=0,
                    help="cap on SFX candidates to classify, near-cut ones always kept (0 = all; a cap under-counts "
                         "SFX density, measured 211 -> 85 on a 17 min video)")
    a = ap.parse_args()
    import librosa
    out = Path(a.out)
    info = probe(a.video)
    t0, t1 = parse_range(a.range, info["duration_s"])
    mix = extract_wav(a.video, out / "audio_mix.wav", sr=44100, channels=2,
                      start=t0 if a.range else None, end=t1 if a.range else None)
    voc_p, mus_p = separate(mix, out, a.device)
    voc, sr = sf.read(str(voc_p), dtype="float32")
    mus, _ = sf.read(str(mus_p), dtype="float32")
    voc_m, mus_m = voc.mean(1), mus.mean(1)
    levels = {"mix_lufs": lufs(mix), "voice_lufs": lufs(voc_p), "music_lufs": lufs(mus_p)}
    vdb, mdb = rms_db(voc_m, sr), rms_db(mus_m, sr)
    n = min(len(vdb), len(mdb))
    speaking = vdb[:n] > (np.percentile(vdb[:n], 90) - 25)
    music_on = mdb[:n] > max(-55, np.percentile(mdb[:n], 95) - 30)
    duck = {}
    if speaking.any() and (~speaking & music_on).any():
        duck = {"music_db_while_speaking": round(float(np.median(mdb[:n][speaking & music_on])), 1) if (speaking & music_on).any() else None,
                "music_db_in_gaps": round(float(np.median(mdb[:n][~speaking & music_on])), 1),
                "voice_db_median": round(float(np.median(vdb[:n][speaking])), 1)}
        if duck["music_db_while_speaking"] is not None:
            duck["ducking_db"] = round(duck["music_db_in_gaps"] - duck["music_db_while_speaking"], 1)
    levels["ducking"] = duck
    # ---- BGM segments
    y22 = librosa.resample(mus_m, orig_sr=sr, target_sr=22050)
    hop = 512
    mfcc = librosa.feature.mfcc(y=y22, sr=22050, n_mfcc=20, hop_length=hop)
    chroma = librosa.feature.chroma_cqt(y=y22, sr=22050, hop_length=hop)
    feat = np.vstack([librosa.util.normalize(mfcc, axis=1), chroma])
    frames_per_s = 22050 / hop
    k = max(2, min(40, int(len(y22) / 22050 / 20)))
    try:
        bounds = librosa.segment.agglomerative(feat, k)
    except Exception:
        bounds = np.array([0])
    bt = sorted(set([0.0] + [float(b / frames_per_s) for b in bounds] + [len(y22) / 22050]))
    presence = music_on
    segments = []
    for s, e in zip(bt, bt[1:]):
        if e - s < 3:
            continue
        i0, i1 = int(s * 10), int(e * 10)
        on = float(presence[i0:i1].mean()) if i1 > i0 else 0
        seg = {"start_s": round(s + t0, 2), "end_s": round(e + t0, 2), "music_present_ratio": round(on, 2),
               "music_db_median": round(float(np.median(mdb[i0:i1])), 1) if i1 > i0 else None}
        if on > 0.3:
            ys = y22[int(s * 22050): int(e * 22050)]
            tempo, _ = librosa.beat.beat_track(y=ys, sr=22050)
            seg["tempo_bpm"] = round(float(np.atleast_1d(tempo)[0]), 1)
            ch = librosa.feature.chroma_cqt(y=ys, sr=22050).mean(1)
            seg["key_guess"] = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"][int(ch.argmax())]
        segments.append(seg)
    merged = []  # merge adjacent segments with similar timbre/level -> tracks
    for sg in segments:
        if merged and abs((sg.get("music_db_median") or -99) - (merged[-1].get("music_db_median") or -99)) < 4 \
                and abs((sg.get("tempo_bpm") or 0) - (merged[-1].get("tempo_bpm") or 0)) < 6 \
                and (sg["music_present_ratio"] > 0.3) == (merged[-1]["music_present_ratio"] > 0.3):
            merged[-1]["end_s"] = sg["end_s"]
            continue
        merged.append(dict(sg))
    # ---- SFX events
    oenv = librosa.onset.onset_strength(y=y22, sr=22050, hop_length=hop, aggregate=np.median)
    peaks = librosa.util.peak_pick(oenv, pre_max=6, post_max=6, pre_avg=40, post_avg=40, delta=0.0, wait=8)
    win = int(4 * frames_per_s)
    cand = []
    for p in peaks:
        lo, hi = max(0, p - win), min(len(oenv), p + win)
        med = np.median(oenv[lo:hi])
        mad = np.median(np.abs(oenv[lo:hi] - med)) + 1e-6
        z = (oenv[p] - med) / mad
        if z >= a.sfx_sensitivity:
            cand.append((p / frames_per_s, float(z)))
    # risers: sustained rise of broadband energy ending near a cut
    cut_times = []
    if a.cuts:
        cut_times = [c["start_s"] for c in read_json(a.cuts)["cuts"][1:]]
    y48 = librosa.resample(mus_m, orig_sr=sr, target_sr=48000)
    clips, meta = [], []
    sfx_dir = out / "sfx"
    sfx_dir.mkdir(parents=True, exist_ok=True)
    # all candidates are classified by default (CLAP on MPS: ~16 ms per clip). With --max-sfx, keep onsets near a
    # cut boundary plus the strongest others
    if a.max_sfx <= 0:
        pass
    elif cut_times:
        ct = np.array(cut_times) - t0
        near = [(t, z) for t, z in cand if np.min(np.abs(ct - t)) <= 0.25]
        rest = sorted([(t, z) for t, z in cand if np.min(np.abs(ct - t)) > 0.25], key=lambda x: -x[1])
        cand = sorted(near + rest[: max(0, a.max_sfx - len(near))])
    else:
        cand = sorted(sorted(cand, key=lambda x: -x[1])[: a.max_sfx])
    for t, z in cand:
        s = max(0, int((t - 0.15) * 48000))
        e = min(len(y48), int((t + 1.35) * 48000))
        clips.append(y48[s:e])
        meta.append((t, z))
    labels = [] if a.no_clap else None
    clap = None
    if not a.no_clap and clips:
        clap = Clap(a.device)
        labels = []
        for i in range(0, len(clips), 48):
            labels += clap.classify(clips[i:i + 48], SFX_LABELS + NON_SFX)
    events = []
    for k, (t, z) in enumerate(meta):
        top = labels[k] if labels else []
        is_sfx = (not top) or (top[0][0] not in NON_SFX)
        abs_t = t + t0
        near = min(cut_times, key=lambda c: abs(c - abs_t)) if cut_times else None
        ev = {"t": round(abs_t, 3), "strength_z": round(z, 1), "labels": [(l, round(p, 3)) for l, p in top],
              "likely_sfx": bool(is_sfx)}
        if near is not None:
            ev["nearest_cut_s"] = near
            ev["offset_to_cut_ms"] = round((abs_t - near) * 1000)
            ev["on_cut"] = abs(abs_t - near) <= 0.12
        if is_sfx or ev.get("on_cut"):
            ev["id"] = f"s{len(events) + 1:04d}"
            clip_path = sfx_dir / f"{ev['id']}.wav"
            sf.write(str(clip_path), clips[k], 48000)
            ev["clip"] = f"sfx/{ev['id']}.wav"
            events.append(ev)
    if clap:
        for sg in merged:
            if sg["music_present_ratio"] > 0.3:
                mid = (sg["start_s"] + sg["end_s"]) / 2 - t0
                s, e = int(max(0, mid - 5) * 48000), int((mid + 5) * 48000)
                sg["mood_tags"] = [(l, round(p, 3)) for l, p in clap.classify([y48[s:e]], MOODS)[0]]
    doc = {"video": str(Path(a.video).resolve()), "range": [t0, t1], "levels": levels, "bgm_segments": merged,
           "sfx_events": events, "sfx_per_minute": round(len([e for e in events if e["likely_sfx"]]) / max((t1 - t0) / 60, 1e-6), 2),
           "stems": {"vocals": "stems/vocals.wav", "music": "stems/music.wav"},
           "note": "SFX labels and moods are CLAP zero-shot guesses. Listen to sfx/*.wav and correct in annotations."}
    if cut_times:
        on_cut = [e for e in events if e.get("on_cut") and e["likely_sfx"]]
        doc["sfx_on_cut_ratio"] = round(len(on_cut) / max(1, len([c for c in cut_times if t0 <= c < t1])), 3)
    write_json(out / "audio.json", doc)
    print(f"levels {json.dumps(levels, ensure_ascii=False)}")
    print(f"{len(merged)} bgm segments, {len(events)} sfx candidates -> {out / 'audio.json'}")


if __name__ == "__main__":
    main()
