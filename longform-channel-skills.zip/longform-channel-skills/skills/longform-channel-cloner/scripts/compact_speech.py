"""불필요한 묵음을 잘라내고 같은 편집 지도로 단어 시각을 보정한다."""
import math
from pathlib import Path
import numpy as np
import soundfile as sf


def compact_samples(audio, sr, threshold_db=-50, minimum_s=.12, edge_s=.015):
    if audio.ndim != 1 or sr <= 0 or not len(audio) or not np.isfinite(audio).all():
        raise ValueError('유효한 mono 음성이 필요합니다')
    hop = max(1, round(sr * .005))
    count = math.ceil(len(audio) / hop)
    padded = np.pad(audio, (0, count * hop - len(audio)))
    rms = np.sqrt(np.mean(padded.reshape(count, hop).astype(np.float64) ** 2, axis=1))
    quiet = rms < 10 ** (threshold_db / 20)
    if quiet.all(): raise ValueError('발화 없는 TTS 결과: 해당 문장만 재합성해야 합니다')
    changes = np.diff(np.r_[False, quiet, False].astype(int))
    removed = []; pad = round(sr * edge_s)
    for start, end in zip(np.where(changes == 1)[0], np.where(changes == -1)[0]):
        a, b = start * hop, min(len(audio), end * hop)
        if a == 0: b = max(a, b - pad)
        elif b == len(audio): a = min(b, a + pad)
        elif b - a >= minimum_s * sr: a += pad; b -= pad
        else: continue
        if b > a: removed.append((a, b))
    parts = []; cursor = 0
    for a, b in removed:
        parts.append(audio[cursor:a]); cursor = b
    parts.append(audio[cursor:])
    return np.concatenate(parts), [(a / sr, b / sr) for a, b in removed]


def map_time(t, removed):
    return max(0., t - sum(max(0., min(t, b) - a) for a, b in removed))


def convert(src, dst, words, sr=48000):
    from common import FFMPEG, run
    decoded = Path(dst).with_suffix('.decoded.wav')
    run([FFMPEG, '-hide_banner', '-loglevel', 'error', '-y', '-i', str(src), '-ac', '1', '-ar', str(sr), str(decoded)])
    audio, actual_sr = sf.read(decoded, dtype='float32')
    compact, removed = compact_samples(audio, actual_sr)
    sf.write(dst, compact, actual_sr)
    decoded.unlink()
    duration = len(compact) / actual_sr
    mapped = [{**w, 'start': min(duration, map_time(w['start'], removed)),
               'end': min(duration, map_time(w['end'], removed))} for w in words]
    return duration, mapped, removed
