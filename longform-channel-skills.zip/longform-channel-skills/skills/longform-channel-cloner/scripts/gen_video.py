#!/usr/bin/env python3
"""Generate AI video clips locally (LTX-2.3 distilled via ltx-2-mlx on Apple Silicon), image-to-video.

  run.sh gen_video --prompt "..." --out clip.mp4 --image start.png [--seconds 7] [--seed 42]
  run.sh gen_video --batch jobs.json [--project P]        # resumable queue, one job after another
  run.sh gen_video --batch jobs.json --watch 900 [--project P]   # also pick up jobs appended later

jobs.json: [{"key": "VID:c001", "image": "...png", "prompt": "...", "seconds": 8.25, "seed": 7, "out": "...mp4"}, ...]
Batch mode skips jobs whose output exists, logs per-job timings to <jobs>.log.jsonl and registers each clip in
P/assets/manifest.json (method ai_video) when --project is given. Run it detached (scripts/detach.sh) and poll.
--watch N keeps the queue open: the jobs file is re-read after every clip and polled every 10 s, and the run
ends after N seconds without a pending job. Start the queue as soon as the first start frame exists and append
jobs while the other start frames are still being made, so generation never waits for image generation.

Use for cuts whose source.type is ai_video. Start frame: built-in image generation in the reference style
(prompt = acquire.ai_prompt, style target = frames/src/<cut>.jpg). --seconds = cadence.retime source_len_s
(the unique footage the reference shows); build_timeline retimes the clip to the cut.

Post-processing in one ffmpeg pass: LTX distilled tends to darken the last second of I2V clips. Frames are
brightness-normalized to the first quarter of the clip (gain capped at 1.6), frames that fell below 60 % are
dropped from the tail, then the clip is upscaled to 1920x1080 (lanczos, cover crop).
Measured on M5 Pro 24 GB, 768x448, 10 clips: t_gen = 20.6 s + 0.651 s per generated frame. The fixed part is
Gemma load 3.6 s + prompt encode 4.9 s + VAE decode ~14 s; process start-up is ~0.2 s, so a resident worker
would save only the Gemma reload and was not adopted (it also risks memory pressure on 24 GB).
"""
from __future__ import annotations

import argparse
import json
import math
import subprocess
import sys
import time
from pathlib import Path

import numpy as np

from common import FFMPEG, LFC_HOME, probe

LTX_BIN = LFC_HOME / "ltx-venv" / "bin" / "ltx-2-mlx"
MODEL = LFC_HOME / "models" / "ltx-2.3-mlx-q8"
GEMMA = LFC_HOME / "models" / "gemma-3-12b-it-4bit"
STEADY = " The lighting stays bright and constant for the whole shot, no fade, no darkening."


def frames_for(seconds: float, fps: int) -> int:
    """LTX needs 8k+1 frames."""
    n = max(9, int(round(seconds * fps)))
    return int(math.ceil((n - 1) / 8) * 8 + 1)


def postprocess(raw: Path, out: Path, fps: int, want_s: float, size=(1920, 1080)) -> dict:
    import cv2
    from common import iter_frames
    frames = [f for _, f in iter_frames(raw)]
    if not frames:
        raise SystemExit("empty LTX output")
    lum = np.array([float(cv2.cvtColor(f, cv2.COLOR_BGR2GRAY).mean()) for f in frames])
    ref = float(np.median(lum[: max(1, len(lum) // 4)])) or 1.0
    keep = len(frames)
    while keep > 1 and lum[keep - 1] < 0.6 * ref:
        keep -= 1
    want = max(1, int(round(want_s * fps)))
    keep = min(keep, want) if keep >= want else keep
    W, H = size
    enc = subprocess.Popen([FFMPEG, "-hide_banner", "-loglevel", "error", "-y", "-f", "rawvideo", "-pix_fmt", "bgr24",
                            "-s", f"{frames[0].shape[1]}x{frames[0].shape[0]}", "-r", str(fps), "-i", "-",
                            "-vf", f"scale={W}:{H}:force_original_aspect_ratio=increase:flags=lanczos,crop={W}:{H},setsar=1",
                            "-c:v", "libx264", "-crf", "16", "-preset", "fast", "-pix_fmt", "yuv420p", str(out)],
                           stdin=subprocess.PIPE)
    gains = []
    for f, l in zip(frames[:keep], lum[:keep]):
        g = 1.0 if l >= 0.97 * ref else min(1.6, ref / max(l, 1e-3))
        gains.append(g)
        if g != 1.0:
            f = np.clip(f.astype(np.float32) * g, 0, 255).astype(np.uint8)
        enc.stdin.write(f.tobytes())
    enc.stdin.close()
    enc.wait()
    return {"frames_generated": len(frames), "frames_kept": keep, "max_gain": round(max(gains), 3),
            "short": keep < want}


def generate(job: dict, mode="distilled", width=768, height=448, fps=24) -> dict:
    if not LTX_BIN.exists() or not (MODEL / "transformer-distilled.safetensors").exists():
        sys.exit("AI video toolchain missing: run scripts/setup_ai_video.sh")
    out = Path(job["out"]).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    raw = out.with_name(out.stem + "_raw.mp4")
    secs = float(job.get("seconds", 5.0))
    nf = frames_for(secs + 0.5, fps)  # tail margin for trimming
    prompt = job["prompt"].rstrip() + ("" if "constant" in job["prompt"] else STEADY)
    cmd = [str(LTX_BIN), "generate", f"--{mode}", "--prompt", prompt, "--output", str(raw), "--model", str(MODEL),
           "--gemma", str(GEMMA), "--seed", str(job.get("seed", 42)), "-H", str(height), "-W", str(width),
           "-f", str(nf), "--frame-rate", str(fps), "--low-ram", "--no-audio", "--quiet"]
    if job.get("image"):
        cmd += ["--image", str(Path(job["image"]).resolve()), "0", "1.0"]
    t0 = time.time()
    p = subprocess.run(cmd, cwd=LFC_HOME / "ltx-2-mlx", capture_output=True, text=True)
    t_gen = time.time() - t0
    if p.returncode != 0 or not raw.exists():
        return {"ok": False, "error": (p.stderr or p.stdout)[-800:], "t_gen": round(t_gen, 1)}
    t1 = time.time()
    pp = postprocess(raw, out, fps, secs)
    raw.unlink()
    info = probe(out)
    return {"ok": True, "t_gen": round(t_gen, 1), "t_post": round(time.time() - t1, 1), "frames": nf,
            "duration_s": info["duration_s"], **pp}


def register(project: str, key: str, out: str, prompt: str, notes: str):
    subprocess.run([sys.executable, str(Path(__file__).with_name("fetch_assets.py")), "register", "--project", project,
                    "--key", key, "--file", out, "--method", "ai_video", "--tool", "LTX-2.3 q8 distilled (ltx-2-mlx)",
                    "--prompt", prompt, "--notes", notes], check=True, capture_output=True)


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--prompt")
    ap.add_argument("--out")
    ap.add_argument("--image")
    ap.add_argument("--seconds", type=float, default=5.0)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--width", type=int, default=768)
    ap.add_argument("--height", type=int, default=448)
    ap.add_argument("--fps", type=int, default=24)
    ap.add_argument("--batch")
    ap.add_argument("--watch", type=float, default=0, help="batch: keep polling for appended jobs, exit after N idle s")
    ap.add_argument("--project")
    ap.add_argument("--key")
    a = ap.parse_args()
    if not a.batch:
        run_job({"key": a.key, "image": a.image, "prompt": a.prompt, "seconds": a.seconds, "seed": a.seed,
                 "out": a.out}, a, None)
        return
    log = Path(a.batch).with_suffix(".log.jsonl")
    failed: set = set()
    idle_since = time.time()
    while True:
        # re-read after every clip so jobs appended while running are picked up
        todo = [j for j in read_jobs(a.batch) if not Path(j["out"]).exists() and j["out"] not in failed]
        # a job is ready once its start frame exists; jobs whose frame is still being made wait (--watch)
        ready = [j for j in todo if not j.get("image") or Path(j["image"]).exists()]
        if ready:
            job = ready[0]
            print(f"[{len(todo)} left] {job.get('key')} {job.get('seconds')}s ...", flush=True)
            if not run_job(job, a, log):
                failed.add(job["out"])
            idle_since = time.time()
            continue
        if time.time() - idle_since >= a.watch:
            for j in todo:
                print(f"not generated (start frame missing): {j.get('key')} {j.get('image')}", flush=True)
            break
        time.sleep(10)
    if failed:
        print(f"{len(failed)} jobs failed (see {log})", flush=True)
    print("BATCH_DONE", flush=True)


def run_job(job, a, log) -> bool:
    if not job.get("image") or Path(job["image"]).exists():
        res = generate(job, width=a.width, height=a.height, fps=a.fps)
    else:
        res = {"ok": False, "error": f"start image missing: {job['image']}"}
    rec = {"key": job.get("key"), "t": time.strftime("%H:%M:%S"), **res}
    print(json.dumps(rec, ensure_ascii=False), flush=True)
    if log:
        with open(log, "a") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    if res["ok"] and a.project and job.get("key"):
        register(a.project, job["key"], str(Path(job["out"]).resolve()), job["prompt"],
                 f"seed {job.get('seed', 42)}, start image {job.get('image')}")
    return res["ok"]


def read_jobs(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


if __name__ == "__main__":
    main()
