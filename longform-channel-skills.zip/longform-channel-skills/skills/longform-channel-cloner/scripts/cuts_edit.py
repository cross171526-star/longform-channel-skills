#!/usr/bin/env python3
"""Correct detected cuts after visual review (run before motion_track / source_signals).

  run.sh cuts_edit <cuts.json> split --at FRAME [--at FRAME ...]
  run.sh cuts_edit <cuts.json> merge --ids c010 c011 [c012]
  run.sh cuts_edit <cuts.json> move --id c010 --start FRAME
  run.sh cuts_edit <cuts.json> transition --id c010 --start FRAME --end FRAME [--type dissolve]

Ids are renumbered after split/merge. Unchanged cuts keep annotation, motion/<id>.json, frames/src/<id>.jpg,
source_signals and transcript cut_text under their new id; changed cuts are cleared and listed for re-measuring.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from common import read_json, write_json


def renumber(doc):
    fps = doc["video"]["fps"]
    for i, c in enumerate(doc["cuts"]):
        c["index"] = i
        c["id"] = f"c{i + 1:03d}"
        c["start_s"] = round(c["start_frame"] / fps, 4)
        c["end_s"] = round(c["end_frame"] / fps, 4)
        c["duration_frames"] = c["end_frame"] - c["start_frame"]
        c["duration_s"] = round(c["duration_frames"] / fps, 4)
    if doc["cuts"]:
        doc["cuts"][0]["boundary_in"] = None


def remap_side_files(path: Path, before: dict, doc) -> list[str]:
    """After renumbering, rename per-cut files and keys so unchanged cuts keep their data.

    before: old_id -> (start_frame, end_frame). A new cut whose frame span equals an old one inherits that old id's
    motion/<id>.json, frames/src/<id>.jpg, source_signals entry and transcript cut_text. Changed cuts get nothing
    (rerun motion_track --ids / source_signals for them). Returns the new ids that need re-measuring."""
    import shutil
    ad = path.parent
    span_to_old = {v: k for k, v in before.items()}
    mapping, fresh = {}, []
    for c in doc["cuts"]:
        old = span_to_old.get((c["start_frame"], c["end_frame"]))
        if old:
            mapping[c["id"]] = old
        else:
            fresh.append(c["id"])
            c["motion"] = None
    for sub, ext in (("motion", ".json"), ("frames/src", ".jpg")):
        d = ad / sub
        if not d.exists():
            continue
        tmp = ad / (sub.replace("/", "_") + "_remap_tmp")
        tmp.mkdir(exist_ok=True)
        for new, old in mapping.items():
            src = d / f"{old}{ext}"
            if src.exists():
                shutil.copy2(src, tmp / f"{new}{ext}")
        backup = ad / (sub.replace("/", "_") + "_before_edit")
        if backup.exists():
            shutil.rmtree(backup)
        d.rename(backup)
        tmp.rename(d)
    sp = ad / "source_signals.json"
    if sp.exists():
        sig = read_json(sp)
        old_cuts = sig.get("cuts", {})
        new_cuts = {}
        for new, old in mapping.items():
            if old in old_cuts:
                e = dict(old_cuts[old])
                e["image"] = f"frames/src/{new}.jpg"
                new_cuts[new] = e
        sig["cuts"] = new_cuts
        write_json(sp, sig)
    tp = ad / "transcript.json"
    if tp.exists():
        tr = read_json(tp)
        inv = {old: new for new, old in mapping.items()}
        tr["cut_text"] = [dict(x, cut_id=inv[x["cut_id"]]) for x in tr.get("cut_text", []) if x.get("cut_id") in inv]
        write_json(tp, tr)
    return fresh



def find(doc, cid):
    for c in doc["cuts"]:
        if c["id"] == cid:
            return c
    sys.exit(f"no cut {cid}")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("cuts")
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("split"); s.add_argument("--at", type=int, action="append", required=True)
    m = sub.add_parser("merge"); m.add_argument("--ids", nargs="+", required=True)
    mv = sub.add_parser("move"); mv.add_argument("--id", required=True); mv.add_argument("--start", type=int, required=True)
    t = sub.add_parser("transition")
    t.add_argument("--id", required=True); t.add_argument("--start", type=int, required=True)
    t.add_argument("--end", type=int, required=True); t.add_argument("--type", default=None)
    a = ap.parse_args()
    path = Path(a.cuts)
    doc = read_json(path)
    cuts = doc["cuts"]
    before = {c["id"]: (c["start_frame"], c["end_frame"]) for c in cuts}
    import shutil
    shutil.copy2(path, path.with_name("cuts.before_edit.json"))
    if a.cmd == "split":
        for f in sorted(a.at):
            c = next((c for c in cuts if c["start_frame"] < f < c["end_frame"]), None)
            if not c:
                sys.exit(f"frame {f} is not strictly inside a cut")
            new = dict(c, start_frame=f, annotation=None,
                       boundary_in={"frame": f, "start_frame": f, "end_frame": f, "frames": 1, "auto_type": "cut",
                                    "confidence": 1.0, "peak_diff": None, "manual": True})
            c["end_frame"] = f
            c["annotation"] = None
            cuts.insert(cuts.index(c) + 1, new)
    elif a.cmd == "merge":
        group = [find(doc, i) for i in a.ids]
        idx = sorted(cuts.index(c) for c in group)
        if idx != list(range(idx[0], idx[-1] + 1)):
            sys.exit("merge ids must be consecutive")
        first, last = cuts[idx[0]], cuts[idx[-1]]
        first["end_frame"] = last["end_frame"]
        first["annotation"] = None
        del cuts[idx[0] + 1: idx[-1] + 1]
    elif a.cmd == "move":
        c = find(doc, a.id)
        i = cuts.index(c)
        if i == 0 or not (cuts[i - 1]["start_frame"] < a.start < c["end_frame"]):
            sys.exit("new start must stay between the previous cut start and this cut end")
        cuts[i - 1]["end_frame"] = a.start
        c["start_frame"] = a.start
        if c.get("boundary_in"):
            c["boundary_in"].update(frame=a.start, manual=True)
    elif a.cmd == "transition":
        c = find(doc, a.id)
        i = cuts.index(c)
        if i == 0:
            sys.exit("first cut has no incoming transition")
        bd = c.get("boundary_in") or {}
        bd.update(start_frame=a.start, end_frame=a.end, frames=a.end - a.start + 1, manual=True)
        if a.type:
            bd["auto_type"] = a.type
        c["boundary_in"] = bd
        cuts[i - 1]["end_frame"] = a.start
        c["start_frame"] = a.start
    renumber(doc)
    fresh = remap_side_files(path, before, doc)
    write_json(path, doc)
    print(f"{len(doc['cuts'])} cuts saved (backup cuts.before_edit.json). Unchanged cuts kept their annotation, motion, "
          f"frames and signals under the new ids.")
    if fresh:
        print(f"re-measure changed cuts: run.sh motion_track <video> --cuts {path} --ids {' '.join(fresh)}; "
              f"then run.sh source_signals <video> --cuts {path} --ids {' '.join(fresh)}")


if __name__ == "__main__":
    main()
