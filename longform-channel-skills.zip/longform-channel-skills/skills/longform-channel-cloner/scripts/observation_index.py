"""Reuse actual observed ranges only when evidence, source and requested precision match."""
import argparse
import fcntl
import json
from pathlib import Path
import sys
from work_guard import digest, hashes


def missing_ranges(rows,start,end):
    cursor=start;missing=[]
    for row in sorted(rows,key=lambda r:r['start_s']):
        a,b=max(start,row['start_s']),min(end,row['end_s'])
        if b<=a:continue
        if a>cursor:missing.append([cursor,a])
        cursor=max(cursor,b)
    if cursor<end:missing.append([cursor,end])
    return missing


def query(index,source,start,end,max_step,min_width,purpose):
    if not 0<=start<end or max_step<=0 or min_width<=0:raise ValueError('Invalid requested range/precision')
    signature=digest(source);rows=[]
    for row in index.get('observations',[]):
        if row['source_sha256']!=signature or row['purpose']!=purpose or row['step_s']>max_step or row['width']<min_width:continue
        try:
            if hashes(row['evidence_sha256'])!=row['evidence_sha256']:continue
        except OSError:continue
        rows.append(row)
    return {'missing_ranges':missing_ranges(rows,start,end),'evidence_files':sorted({p for r in rows if r['end_s']>start and r['start_s']<end for p in r['evidence_sha256']}),
            'note':'Observed sampling coverage, not proof of every hidden frame'}


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('action',choices=['record','query'])
    p.add_argument('--index',required=True);p.add_argument('--source',required=True)
    p.add_argument('--start',type=float,required=True);p.add_argument('--end',type=float,required=True)
    p.add_argument('--step',type=float,required=True);p.add_argument('--width',type=int,required=True);p.add_argument('--purpose',required=True)
    p.add_argument('--session-id');p.add_argument('--evidence',nargs='+');a=p.parse_args();path=Path(a.index)
    try:
        import math
        if not all(math.isfinite(n) for n in (a.start,a.end,a.step)) or not 0<=a.start<a.end or a.step<=0 or a.width<=0:raise ValueError('Invalid range/precision')
        path.parent.mkdir(parents=True,exist_ok=True)
        with path.with_suffix('.lock').open('a') as f:
            fcntl.flock(f,fcntl.LOCK_EX)
            data=json.loads(path.read_text()) if path.exists() else {'observations':[]}
            if a.action=='record':
                if not a.session_id or not a.evidence:raise ValueError('Actual observer session and evidence required')
                row={'source_sha256':digest(a.source),'start_s':a.start,'end_s':a.end,'step_s':a.step,'width':a.width,
                     'purpose':a.purpose,'session_id':a.session_id,'evidence_sha256':hashes(a.evidence)}
                if row not in data['observations']:data['observations'].append(row)
                temp=path.with_suffix('.tmp');temp.write_text(json.dumps(data,ensure_ascii=False,indent=2));temp.replace(path)
            result=query(data,a.source,a.start,a.end,a.step,a.width,a.purpose)
        print(json.dumps(result,ensure_ascii=False));return 0
    except (OSError,ValueError,KeyError) as e:print(str(e),file=sys.stderr);return 1

if __name__=='__main__':sys.exit(main())
