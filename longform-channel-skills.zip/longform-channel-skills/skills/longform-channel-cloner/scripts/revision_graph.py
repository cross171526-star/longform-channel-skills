"""단일 개정 명세에서 소비 경로·해시·인계를 생성하고 비싼 검사 전에 연결을 검사한다."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
from work_guard import FileSnapshot, digest

RENDER_ROLES={'props','mix','renderer','public','font','media','narration'}
METADATA_ROLES={'attribution','script_evidence','review_note'}


def canonical(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False,allow_nan=False).encode()).hexdigest()


def pointer_set(doc,pointer,value):
    if not isinstance(pointer,str) or not pointer.startswith('/'):
        raise ValueError('Explicit JSON pointer required')
    parts=[p.replace('~1','/').replace('~0','~') for p in pointer[1:].split('/')]
    target=doc
    for p in parts[:-1]:target=target[int(p)] if isinstance(target,list) else target[p]
    if isinstance(target,list):target[int(parts[-1])]=value
    else:target[parts[-1]]=value


def generate(spec_path,out):
    spec_path=Path(spec_path).resolve();out=Path(out).resolve();spec=json.loads(spec_path.read_text())
    if spec.get('schema')!='lfc-revision-spec-v1' or not spec.get('revision'):
        raise ValueError('Central revision specification required')
    if out.exists():raise ValueError('Preserve existing revision; use a new output directory')
    snap=FileSnapshot();rows=[];byid={};dependencies={}
    for row in spec.get('artifacts',[]):
        if not row.get('id') or row['id'] in byid:raise ValueError('Unique artifact id required')
        if row.get('role') not in RENDER_ROLES|METADATA_ROLES|{'source','analysis','baseline','acceptance','tts_metadata','contract'}:
            raise ValueError('Unknown artifact role; no implicit metadata skipping')
        path,h=snap.add(spec_path.parent/row['path'])
        if row.get('sha256') and row['sha256']!=h:raise ValueError('Stale central artifact: '+row['id'])
        item={**row,'path':path,'sha256':h};byid[row['id']]=item;rows.append(item);dependencies[path]=h
    if not rows:raise ValueError('Empty revision graph')
    # 실제 렌더러 코드와 props의 public 소비자를 중앙 graph가 직접 수집한다.
    from check_render_timing import renderer_dependencies,TEMPLATE
    for f in renderer_dependencies():
        path,h=snap.add(f);dependencies[path]=h
        item={'id':'renderer:'+str(Path(path).relative_to(TEMPLATE)),'role':'renderer','path':path,'sha256':h}
        if not any(r['path']==path and r['role']=='renderer' for r in rows):rows.append(item)
    for artifact in list(rows):
        if artifact['role']!='props':continue
        props=snap.document(artifact['path']);public=Path(artifact['path']).parent/'public'
        def public_refs(value,key=''):
            if isinstance(value,dict):
                for k,v in value.items():public_refs(v,k)
            elif isinstance(value,list):
                for v in value:public_refs(v,key)
            elif isinstance(value,str) and key in ('file','image'):
                target=(public/value).resolve()
                if not target.is_relative_to(public.resolve()):raise ValueError('Public consumer escapes isolated directory')
                path,h=snap.add(target);dependencies[path]=h
                if not any(r['path']==path and r['role'] in RENDER_ROLES for r in rows):
                    rows.append({'id':'public:'+value,'role':'public','path':path,'sha256':h,'scopes':artifact.get('scopes',['full','preview'])})
        public_refs(props)
    scopes={};names={r['id'] for r in spec.get('scopes',[])}
    if not names or not names<={'full','preview'}:raise ValueError('Explicit full/preview scopes required')
    for scope in spec['scopes']:
        ident=scope['id']
        if ident in scopes:raise ValueError('Duplicate scope')
        template,h=snap.add(spec_path.parent/scope['template']);dependencies[template]=h
        doc=deepcopy(snap.document(template));doc['revision_id']=spec['revision']
        for binding in scope.get('bindings',[]):
            item=byid.get(binding['artifact'])
            if not item:raise ValueError('Unknown binding artifact')
            pointer_set(doc,binding['pointer'],item['path'])
        if ident=='preview':
            if 'full' not in names:raise ValueError('Preview requires current full scope')
            doc['output_scope']['full_plan']=str(out/'full.json')
        compiled=(out/(ident+'-compiled.json')).resolve()
        doc['compiled_timeline']=str(compiled)
        # Inventory is derived from current artifacts and explicit semantic references, never blanket old-directory replacement.
        inventory={r['path'] for r in rows if ident in r.get('scopes',['full','preview'])}
        def refs(v,key=''):
            if isinstance(v,dict):
                for k,x in list(v.items()):
                    replacement=refs(x,k)
                    if replacement is not None:v[k]=replacement
            elif isinstance(v,list):
                for x in v:refs(x,key)
            elif isinstance(v,str) and key in {'file','source_path','font_file','baseline','visual_acceptance','timeline','narration_metadata','props','full_plan'}:
                target=(Path(template).parent/v).resolve()
                if target==out/'full.json':inventory.add(str(target));return str(target)
                if target.is_file():
                    canonical_path,actual=snap.add(target);dependencies[canonical_path]=actual;inventory.add(canonical_path);return canonical_path
                else:raise ValueError('Missing semantic consumer: '+key+' '+str(target))
        refs(doc)
        inventory.add(str(compiled));doc['render_inputs']=sorted(inventory)
        scopes[ident]=doc
    snap.unchanged();out.mkdir(parents=True)
    for ident,doc in scopes.items():(out/(ident+'.json')).write_text(json.dumps(doc,ensure_ascii=False,indent=2)+'\n')
    scope_rows={ident:{'path':str(out/(ident+'.json')),'sha256':digest(out/(ident+'.json'))} for ident in scopes}
    graph={'schema':'lfc-revision-graph-v1','revision':spec['revision'],'artifacts':rows,'scopes':scope_rows,
           'dependencies_sha256':dependencies,'render_signature':canonical([(r['id'],r['role'],r['sha256'],r.get('scopes',['full','preview']),r.get('consumers',[])) for r in rows if r['role'] in RENDER_ROLES]),
           'handoff_files':[{'role':r.get('handoff_role',r['role']),'path':r['path'],'sha256':r['sha256']} for r in rows],
           'content_accuracy_verified':False}
    (out/'graph.json').write_text(json.dumps(graph,ensure_ascii=False,indent=2)+'\n')
    result=validate(out/'graph.json')
    if not result['passed']:raise ValueError('; '.join(result['errors']))
    return {'passed':True,'graph':str(out/'graph.json'),'scopes':scope_rows,'content_accuracy_verified':False}


def validate(graph_path):
    graph_path=Path(graph_path).resolve();g=json.loads(graph_path.read_text());snap=FileSnapshot();errors=[]
    def require(ok,message):
        if not ok:errors.append(message)
    require(g.get('schema')=='lfc-revision-graph-v1','Unsupported revision graph')
    deps={}
    for name,h in g.get('dependencies_sha256',{}).items():
        try:p,a=snap.add(name);deps[p]=a;require(a==h,'Changed dependency: '+name)
        except OSError:require(False,'Missing dependency: '+name)
    expected=set(deps)|{r['path'] for r in g.get('scopes',{}).values()}
    for ident,row in g.get('scopes',{}).items():
        p,h=snap.add(row['path']);require(h==row['sha256'],'Changed scope: '+ident);doc=snap.document(p)
        require(doc.get('revision_id')==g.get('revision'),'Stale scope revision')
        compiled=str((Path(p).parent/doc['compiled_timeline']).resolve())
        inventory={str((Path(p).parent/x).resolve()) for x in doc.get('render_inputs',[])}
        require(compiled in inventory,'Missing compiled output declaration')
        require(compiled not in g.get('dependencies_sha256',{}),'Compiled output cannot be source input')
        require(inventory-{compiled}<=expected,'Undeclared/stale scope input')
        for key in ('timeline','narration_metadata'):
            if key in doc.get('tts',{}):require(str((Path(p).parent/doc['tts'][key]).resolve()) in inventory,'Missing tts.'+key+' input')
        if ident=='preview':require(str((Path(p).parent/doc['output_scope']['full_plan']).resolve())==g['scopes'].get('full',{}).get('path'),'Preview full_plan is stale')
    from check_render_timing import renderer_dependencies
    renderer_paths={r['path'] for r in g.get('artifacts',[]) if r['role']=='renderer'}
    require({str(p.resolve()) for p in renderer_dependencies()}<=renderer_paths,'Actual renderer dependency missing from graph')
    for ident,row in g.get('scopes',{}).items():
        doc=json.loads(Path(row['path']).read_text())
        props_name=doc.get('render_timing',{}).get('props')
        if props_name:
            props_path=str((Path(row['path']).parent/props_name).resolve())
            require(any(r['path']==props_path and r['role']=='props' for r in g.get('artifacts',[])),'Actual props must be render-sensitive')
    render_paths={r['path'] for r in g.get('artifacts',[]) if r['role'] in RENDER_ROLES}
    for r in g.get('artifacts',[]):
        if r['role']!='props':continue
        props=json.loads(Path(r['path']).read_text());public=Path(r['path']).parent/'public'
        def require_public(value,key=''):
            if isinstance(value,dict):
                for k,v in value.items():require_public(v,k)
            elif isinstance(value,list):
                for v in value:require_public(v,key)
            elif isinstance(value,str) and key in ('file','image'):
                target=str((public/value).resolve())
                require(target in render_paths,'Actual public consumer missing from render signature: '+target)
        require_public(props)
    render=[(r['id'],r['role'],r['sha256'],r.get('scopes',['full','preview']),r.get('consumers',[])) for r in g.get('artifacts',[]) if r['role'] in RENDER_ROLES]
    require(bool(render),'No actual render consumers; cannot prove render invariance')
    require(canonical(render)==g.get('render_signature'),'Render signature changed')
    for r in g.get('artifacts',[]):require(deps.get(r['path'])==r['sha256'],'Unbound artifact: '+r['id'])
    snap.unchanged()
    return {'passed':not errors,'errors':errors,'graph_sha256':digest(graph_path),'render_signature':g.get('render_signature'),'dependencies_sha256':deps,'content_accuracy_verified':False}


def reuse(previous,current,record):
    a=validate(previous);b=validate(current)
    if not a['passed'] or not b['passed']:raise ValueError('Both immutable graphs must pass')
    old=json.loads(Path(previous).read_text());new=json.loads(Path(current).read_text());proof=json.loads(Path(record).read_text())
    if proof.get('passed') is not True or proof.get('kind')!='lfc-verified-render-v1':
        raise ValueError('Successful actual render verification record required')
    if proof.get('graph_sha256')!=digest(previous) or proof.get('render_signature')!=a['render_signature']:
        raise ValueError('Previous output is not bound to previous render consumers')
    if not proof.get('output_sha256'):raise ValueError('No verified output')
    if proof.get('scope') not in old.get('scopes',{}):raise ValueError('Verified render scope missing')
    scope=json.loads(Path(old['scopes'][proof['scope']]['path']).read_text())
    props_artifacts=[r for r in old['artifacts'] if r['role']=='props' and proof['scope'] in r.get('scopes',['full','preview'])]
    if len(props_artifacts)!=1:raise ValueError('Exactly one actual props per verified scope required')
    props=json.loads(Path(props_artifacts[0]['path']).read_text())
    for p,h in proof['output_sha256'].items():
        if digest(p)!=h:raise ValueError('Previous output changed')
        from production_preflight import inspect_file
        from common import probe
        if inspect_file(p)['kind']!='media':raise ValueError('Render output must decode as actual media')
        actual=probe(p)
        if actual.get('nb_frames')!=round(props['duration_s']*props['fps']) or actual.get('fps')!=props['fps'] or [actual.get('width'),actual.get('height')]!=[props['width'],props['height']]:
            raise ValueError('Verified render frame/fps/canvas differs from actual props')
        import subprocess,shutil
        ffmpeg=shutil.which('ffmpeg') or str(Path.home()/'.longform-cloner/bin/ffmpeg')
        subprocess.run([ffmpeg,'-v','error','-i',p,'-f','null','-'],capture_output=True,text=True,check=True)
    old_by={r['id']:r for r in old['artifacts']};new_by={r['id']:r for r in new['artifacts']}
    changed={i for i in set(old_by)|set(new_by) if old_by.get(i)!=new_by.get(i)}
    metadata_only=all(i in old_by and i in new_by and old_by[i]['role']==new_by[i]['role'] and new_by[i]['role'] in METADATA_ROLES for i in changed)
    unchanged=a['render_signature']==b['render_signature'] and metadata_only
    affected=sorted({c for i in changed for r in [old_by.get(i,{}),new_by.get(i,{})] for c in r.get('consumers',[])})
    return {'passed':True,'reuse_render':unchanged,'changed_artifacts':sorted(changed),'affected_cut_ids':affected,
            'unknown_scope':bool(changed) and not affected,'content_review_reusable':not changed,
            'note':'렌더 재사용은 콘텐츠 승인 재사용이 아니다. 사실·근거·검토 메타데이터 변경은 별도 독립 검토한다.'}


def handoff(graph_path,template,out):
    report=validate(graph_path)
    if not report['passed']:raise ValueError('; '.join(report['errors']))
    g=json.loads(Path(graph_path).read_text());doc=json.loads(Path(template).read_text())
    existing={r['role']:r for r in doc.get('files',[])}
    for r in g['handoff_files']:existing[r['role']]=r
    doc['files']=list(existing.values());doc['revision_graph']={'path':str(Path(graph_path).resolve()),'sha256':digest(graph_path)}
    out=Path(out)
    if out.exists():raise ValueError('Preserve previous handoff; use a new file')
    out.write_text(json.dumps(doc,ensure_ascii=False,indent=2)+'\n')
    return {'passed':True,'out':str(out),'content_accuracy_verified':False}


def render_record(graph_path,scope,media,out):
    result=validate(graph_path)
    if not result['passed']:raise ValueError('; '.join(result['errors']))
    # reuse() performs the same actual decode/frame checks; a provisional record is never exported on failure.
    g=json.loads(Path(graph_path).read_text());media=Path(media).resolve();out=Path(out)
    if out.exists():raise ValueError('Preserve render verification; use a new record')
    proof={'passed':True,'kind':'lfc-verified-render-v1','scope':scope,'graph_sha256':digest(graph_path),
           'render_signature':g['render_signature'],'output_sha256':{str(media):digest(media)},'content_accuracy_verified':False}
    import tempfile
    with tempfile.TemporaryDirectory() as d:
        candidate=Path(d)/'candidate.json';candidate.write_text(json.dumps(proof))
        reuse(graph_path,graph_path,candidate)
    out.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
    return {'passed':True,'out':str(out),'content_accuracy_verified':False}
