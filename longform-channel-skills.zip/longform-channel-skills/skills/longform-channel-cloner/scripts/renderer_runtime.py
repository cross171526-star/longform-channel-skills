"""실행별 렌더러 설치. 공용 node_modules를 수정 가능한 symlink로 공유하지 않는다."""
from pathlib import Path
import json
import shutil
import subprocess
import sys
from work_guard import digest


def setup(template, cached, target, dependencies):
    template, cached, target = map(Path, (template,cached,target))
    expected={name:digest(template/name) for name in ('package.json','package-lock.json') if (template/name).is_file()}
    marker=target/'.lfc-dependencies.json'
    if (target/'node_modules').exists() and (not marker.is_file() or json.loads(marker.read_text())!=expected):
        raise ValueError('Renderer dependency identity missing/changed; preserve this directory and use a new isolated renderer directory')
    for name in ('src','package.json','package-lock.json','remotion.config.ts','tsconfig.json'):
        source=template/name
        if not source.exists():continue
        if source.is_dir():shutil.copytree(source,target/name,dirs_exist_ok=True)
        else:
            (target/name).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target/name)
    modules=target/'node_modules'
    if modules.is_symlink():
        raise ValueError('Mutable shared node_modules symlink; use a new isolated render directory')
    if not modules.exists():
        same=(cached/'package.json').is_file() and (cached/'package.json').read_bytes()==(template/'package.json').read_bytes()
        if (template/'package-lock.json').exists():
            same=same and (cached/'package-lock.json').is_file() and digest(cached/'package-lock.json')==digest(template/'package-lock.json')
        if same and (cached/'node_modules/remotion').exists():
            # APFS clone keeps separate files without eagerly duplicating their disk blocks.
            if sys.platform=='darwin':
                result=subprocess.run(['cp','-cR',str(cached/'node_modules'),str(modules)],capture_output=True,text=True)
                if result.returncode:
                    raise ValueError('Isolated dependency clone failed; preserve partial output and use a new directory: '+result.stderr[-500:])
            else:shutil.copytree(cached/'node_modules',modules,symlinks=True)
        else:
            command='ci' if (target/'package-lock.json').exists() else 'install'
            subprocess.run(['npm',command,'--no-audit','--no-fund','--loglevel=error'],cwd=target,check=True)
        marker.write_text(json.dumps(expected,sort_keys=True))
    package=json.loads((template/'package.json').read_text())
    for name,version in {**package.get('dependencies',{}),**package.get('devDependencies',{})}.items():
        actual=json.loads((modules/name/'package.json').read_text()).get('version')
        if actual!=version:raise ValueError('Installed renderer package version differs: '+name)
    for source in dependencies:
        if digest(source)!=digest(target/source.relative_to(template)):
            raise ValueError('Runtime template differs from checked source: '+str(source))
