"""Validate analysis completeness and evidence linkage, not the truth of visual interpretation."""
import argparse
import json
import math
import subprocess
from pathlib import Path
import sys
import jsonschema
from validate_event_cuts import validate
from work_guard import digest, hashes
from common import probe


def check(folder,source,video_id, *, expected_model="gpt-6.1-sol", expected_effort="high"):
    folder=Path(folder).resolve();source=Path(source).resolve();errors=[];linked={str(source)}
    names=['visual_analysis.json','script.json','speech_rate.json']
    try:
        visual,script,speech=[json.loads((folder/n).read_text()) for n in names]
        errors.extend(validate(visual))
        required=['video_read','audio_read','full_video_analyzed','method','coverage','cuts','layers','animations',
                  'captions','chrome','film_overlays','audio','production_rules','uncertainties','background_segments',
                  'counting','analysis_provenance','implementation_recommendations','state_timeline','color_adjustments']
        for field in required:
            if field not in visual:errors.append('Missing '+field)
        if visual.get('full_video_analyzed') is not True:errors.append('Full analysis incomplete')
        cov=visual.get('coverage',{});duration=cov.get('duration_s')
        if type(duration) not in (int,float) or not math.isfinite(duration) or duration<=0:errors.append('Invalid duration')
        else:
            cursor=0
            for row in sorted(cov.get('reviewed_ranges',[]),key=lambda r:r['start_s']):
                a,b=row['start_s'],row['end_s']
                if not all(type(n) in (int,float) and math.isfinite(n) for n in (a,b)) or a<0 or b<=a or b>duration+1e-4 or a>cursor+1e-4:
                    errors.append('Invalid/incomplete reviewed ranges');break
                cursor=max(cursor,b)
            if abs(cursor-duration)>1e-4 or cov.get('missing_ranges')!=[]:errors.append('Missing reviewed coverage')
        actual_duration=probe(source)['duration_s']
        if duration is None or abs(actual_duration-duration)>0.1:errors.append('Coverage duration differs from source')
        provenance=visual.get('analysis_provenance',{})
        if provenance.get('video_id')!=video_id or provenance.get('source_sha256')!=digest(source):errors.append('Source identity/hash mismatch')
        if provenance.get('model')!=expected_model or provenance.get('reasoning_effort')!=expected_effort or not provenance.get('session_id'):errors.append('Missing actual model/session provenance')
        bg=visual.get('background_segments',[]);cursor=0
        for row in bg:
            a,b=row['start_s'],row['end_s']
            if not all(type(n) in (int,float) and math.isfinite(n) for n in (a,b)) or b<=a or abs(a-cursor)>1e-4:errors.append('Invalid background coverage')
            cursor=b
        if not bg or cursor!=duration:errors.append('Backgrounds do not cover source')
        cuts=visual.get('cuts',[]);ids={c['id'] for c in cuts}
        for field in ('layers','animations','film_overlays'):
            rows=visual.get(field,[])
            if not isinstance(rows,list) or len(rows)!=len(ids) or {r.get('cut_id') for r in rows}!=ids:errors.append('Missing/duplicate per-cut '+field)
        layer_ids=set();animation_ids=set()
        for row in visual.get('layers',[]):
            if row.get('status') not in ('observed','inferred','unknown'):errors.append('Missing layer observation status')
            stack=row.get('stack')
            if not isinstance(stack,list):errors.append('Invalid layer stack');continue
            if not stack and (row.get('status')!='unknown' or not row.get('uncertainty')):errors.append('Empty layer stack without explicit uncertainty')
            for layer in stack:
                if not layer.get('layer_id') or not layer.get('role'):errors.append('Missing layer ID/role')
                else:layer_ids.add(layer['layer_id'])
        for field in ('animations','film_overlays'):
            for row in visual.get(field,[]):
                presence=row.get('presence');events=row.get('events')
                if presence not in ('present','absent','unknown') or not isinstance(events,list):errors.append('Invalid '+field+' presence/events');continue
                if presence=='absent' and events:errors.append('Absent effect has events')
                if presence=='present' and not events:errors.append('Present effect lacks events')
                for event in events:
                    if not isinstance(event,dict) or not event.get('id'):errors.append('Missing effect ID');continue
                    if field=='animations':animation_ids.add(event['id'])
        for cut in cuts:
            if not set(cut.get('animation_ids',[]))<=animation_ids:errors.append('Unknown animation reference')
            if not cut.get('precision') or not cut.get('evidence'):errors.append('Missing per-cut precision/evidence')
        entries=[c['parent_background_id'] for c in cuts if c.get('event_type')=='background_entry']
        if sorted(entries)!=sorted(b['id'] for b in bg):errors.append('Background entry relation mismatch')
        for cut in cuts:
            if cut.get('event_type') not in ('background_entry','foreground_entry','animation_start','grouped'):errors.append('Invalid event type')
            if not all(k in cut for k in ('new_element_ids','active_element_ids','animation_ids','precision','evidence')):errors.append('Missing event fields')
        evidence_count=0
        def walk(node):
            nonlocal evidence_count
            if isinstance(node,dict):
                if isinstance(node.get('file'),str):
                    p=(folder/node['file']).resolve()
                    if not p.is_file():errors.append('Missing evidence '+node['file'])
                    else:
                        evidence_count+=1;linked.add(str(p))
                for v in node.values():walk(v)
            elif isinstance(node,list):
                for v in node:walk(v)
        walk(visual)
        if not evidence_count:errors.append('No evidence files linked')
        jsonschema.validate(script,json.loads((Path(__file__).resolve().parent.parent/'references/script.schema.json').read_text()))
        scursor=0
        for row in script.get('sections',[]):
            if row['start_s']!=scursor or row['end_s']<=row['start_s']:errors.append('Script section coverage invalid')
            scursor=row['end_s']
        if scursor!=duration:errors.append('Script does not cover the video')
        if script.get('video_id')!=video_id or script.get('duration_s')!=duration:errors.append('Script identity/duration mismatch')
        if speech.get('status')=='unknown' and speech.get('reason'):
            pass  # Explicitly unverified rate is permitted by the analysis contract.
        elif not speech.get('source_input_sha256') or 'char_count' not in speech:
            errors.append('Missing measured speech rate or explicit unknown reason')
        else:
            transcript=folder/'transcript.json'
            linked.add(str(transcript))
            if not transcript.is_file() or digest(transcript)!=speech['source_input_sha256']:
                errors.append('Speech rate transcript hash mismatch')
    except (OSError,ValueError,TypeError,KeyError,AttributeError,subprocess.SubprocessError,jsonschema.ValidationError) as e:errors.append(str(e))
    outputs=[folder/n for n in names]
    return {'passed':not errors,'errors':errors,'output_sha256':hashes(outputs) if all(p.is_file() for p in outputs) else {},
            'dependencies_sha256':hashes([p for p in linked if Path(p).is_file()]),
            'source_sha256':digest(source),'video_id':video_id,
            'model':expected_model,'reasoning_effort':expected_effort,'visual_accuracy_verified':False}


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('folder');p.add_argument('--source',required=True)
    p.add_argument('--video-id',required=True);p.add_argument('--out',required=True);a=p.parse_args()
    try:result=check(a.folder,a.source,a.video_id)
    except (OSError,ValueError) as e:result={'passed':False,'errors':[str(e)]}
    Path(a.out).parent.mkdir(parents=True,exist_ok=True);Path(a.out).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'passed':result['passed'],'errors':result['errors']},ensure_ascii=False));return 0 if result['passed'] else 1

if __name__=='__main__':sys.exit(main())
