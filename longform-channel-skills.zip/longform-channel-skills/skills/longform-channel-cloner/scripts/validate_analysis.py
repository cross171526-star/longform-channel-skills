#!/usr/bin/env python3
"""Check that a video's analysis is complete and schema-valid before it is used for recreation or aggregation.

  run.sh validate_analysis <project> --video ID [--range 0:30] [--strict]
  run.sh validate_analysis <project> --all

Errors (exit 1): missing files, cuts without annotation, annotation schema violations, source without evidence,
script.json schema violations, transition frame counts far from the measured boundary.
With --strict, low-confidence/unavailable sources and unconfirmed keyframes become errors.
Other warnings still require human review before a cut is confirmed.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from jsonschema import Draft202012Validator

from common import parse_range, read_json

REF = Path(__file__).resolve().parent.parent / "references"


def check_video(project: Path, vid: str, rng: str | None, strict: bool) -> tuple[list, list, dict]:
    errs, warns = [], []
    ad = project / "analysis" / vid
    need = ["cuts.json", "captions.json", "transcript.json", "audio.json", "source_signals.json", "script.json"]
    for f in need:
        if not (ad / f).exists():
            errs.append(f"missing {ad / f}")
    if not (ad / "cuts.json").exists():
        return errs, warns, {}
    doc = read_json(ad / "cuts.json")
    lo, hi = parse_range(rng, doc["video"]["duration_s"]) if rng else (0, 1e9)
    cuts = [c for c in doc["cuts"] if lo <= c["start_s"] < hi]
    av = Draft202012Validator(read_json(REF / "annotation.schema.json"))
    fps = doc["video"]["fps"]
    done = 0
    for c in cuts:
        ann = c.get("annotation")
        if not ann:
            errs.append(f"{c['id']} ({c['start_s']:.2f}s) not annotated")
            continue
        done += 1
        for e in av.iter_errors(ann):
            errs.append(f"{c['id']} annotation: {'/'.join(map(str, e.path))} {e.message[:160]}")
        src = ann.get("source", {})
        if src.get("confidence", 1) < 0.5:
            (errs if strict else warns).append(f"{c['id']} source '{src.get('type')}' confidence {src.get('confidence')}")
        if src.get("acquire", {}).get("method") == "unavailable":
            (errs if strict else warns).append(f"{c['id']} source marked unavailable")
        kf = ann.get("keyframes", {})
        if c["duration_frames"] >= 3 and not c.get("motion") and not kf.get("override"):
            (errs if strict else warns).append(f"{c['id']} has no measured motion (run motion_track)")
        if not kf.get("confirmed"):
            (errs if strict else warns).append(f"{c['id']} keyframes not confirmed against frames")
        bi, ti = c.get("boundary_in"), ann.get("transition_in", {})
        if bi and ti:
            measured = 0 if bi.get("auto_type") == "cut" else bi.get("frames", 0)
            if ti.get("type") != "cut" and abs(ti.get("frames", 0) - measured) > max(3, 0.3 * measured) and not bi.get("manual"):
                warns.append(f"{c['id']} transition {ti.get('type')} {ti.get('frames')}f vs measured {measured}f")
            if ti.get("type") == "cut" and measured > 4:
                warns.append(f"{c['id']} annotated cut but measured gradual {measured}f ({bi.get('auto_type')})")
    stats = {"cuts_in_range": len(cuts), "annotated": done}
    if (ad / "script.json").exists():
        sv = Draft202012Validator(read_json(REF / "script.schema.json"))
        for e in sv.iter_errors(read_json(ad / "script.json")):
            errs.append(f"script.json: {'/'.join(map(str, e.path))} {e.message[:160]}")
    if (ad / "captions.json").exists():
        cap = read_json(ad / "captions.json")
        evs = [e for e in cap["events"] if lo <= e["start_s"] < hi]
        linked = {tid for c in cuts for o in (c.get("annotation") or {}).get("overlays", []) for tid in o.get("text_event_ids", [])}
        for e in evs:
            if not e.get("style"):
                warns.append(f"caption {e['id']} has no style")
        unlinked = [e["id"] for e in evs if e["id"] not in linked and e.get("zone") != cap["zones"][0]["id"]] if cap.get("zones") else []
        if unlinked:
            warns.append(f"{len(unlinked)} non-subtitle text events not referenced by any cut overlay: {unlinked[:8]}")
        stats["text_events"] = len(evs)
        if not any(e.get("font_candidates") for e in cap["events"]):
            warns.append("font_match not run")
    if (ad / "audio.json").exists():
        au = read_json(ad / "audio.json")
        ref_sfx = {s for c in cuts for s in (c.get("annotation") or {}).get("sfx_ids", [])}
        ref_sfx |= {s for c in cuts for s in ((c.get("annotation") or {}).get("transition_in") or {}).get("sfx_ids", [])}
        on_cut = [e["id"] for e in au.get("sfx_events", []) if e.get("on_cut") and e.get("likely_sfx") and lo <= e["t"] < hi]
        missing = [s for s in on_cut if s not in ref_sfx]
        if missing:
            warns.append(f"{len(missing)} on-cut SFX not referenced in annotations: {missing[:8]}")
        stats["sfx_events"] = len([e for e in au.get("sfx_events", []) if lo <= e["t"] < hi])
    return errs, warns, stats


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("project")
    ap.add_argument("--video")
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--range")
    ap.add_argument("--strict", action="store_true")
    a = ap.parse_args()
    project = Path(a.project)
    if a.all:
        sel = read_json(project / "channel.json")["selection"]
        vids = list(dict.fromkeys(sel["top_views"] + sel["recent"]))
    else:
        vids = [a.video]
    bad = False
    for vid in vids:
        errs, warns, stats = check_video(project, vid, a.range, a.strict)
        print(f"== {vid} {stats}")
        for e in errs:
            print("  ERROR", e)
        for w in warns[:40]:
            print("  warn ", w)
        if len(warns) > 40:
            print(f"  ... {len(warns) - 40} more warnings")
        bad |= bool(errs)
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
