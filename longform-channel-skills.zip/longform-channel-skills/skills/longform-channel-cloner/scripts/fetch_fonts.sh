#!/usr/bin/env bash
# Download open-licensed (OFL) Korean + Latin display fonts used for font matching and rendering.
# Usage: scripts/fetch_fonts.sh [DEST]   (default $LFC_HOME/fonts)
set -euo pipefail
LFC_HOME="${LFC_HOME:-$HOME/.longform-cloner}"
DEST="${1:-$LFC_HOME/fonts}"
mkdir -p "$DEST"
GF="https://raw.githubusercontent.com/google/fonts/main/ofl"
files=(
  "blackhansans/BlackHanSans-Regular.ttf" "dohyeon/DoHyeon-Regular.ttf" "jua/Jua-Regular.ttf"
  "notosanskr/NotoSansKR%5Bwght%5D.ttf" "nanumgothic/NanumGothic-Regular.ttf" "nanumgothic/NanumGothic-Bold.ttf"
  "nanumgothic/NanumGothic-ExtraBold.ttf" "gothica1/GothicA1-Black.ttf" "gothica1/GothicA1-Bold.ttf"
  "gasoekone/GasoekOne-Regular.ttf" "nanummyeongjo/NanumMyeongjo-ExtraBold.ttf" "sunflower/Sunflower-Bold.ttf"
  "ibmplexsanskr/IBMPlexSansKR-Bold.ttf" "gowundodum/GowunDodum-Regular.ttf" "dongle/Dongle-Bold.ttf"
  "nanumpenscript/NanumPenScript-Regular.ttf" "hahmlet/Hahmlet%5Bwght%5D.ttf" "songmyung/SongMyung-Regular.ttf"
  "yeonsung/YeonSung-Regular.ttf" "hannari/Hannari-Regular.ttf" "kiranghaerang/KirangHaerang-Regular.ttf"
  "bebasneue/BebasNeue-Regular.ttf" "anton/Anton-Regular.ttf" "montserrat/Montserrat%5Bwght%5D.ttf"
  "oswald/Oswald%5Bwght%5D.ttf" "roboto/Roboto%5Bwdth,wght%5D.ttf" "inter/Inter%5Bopsz,wght%5D.ttf"
)
for f in "${files[@]}"; do
  name="$(basename "$f" | sed 's/%5B/[/g; s/%5D/]/g')"
  [ -s "$DEST/$name" ] && continue
  curl -fsSL -o "$DEST/$name" "$GF/$f" || echo "WARN: failed $f" >&2
done
if [ ! -s "$DEST/Pretendard-Bold.otf" ]; then
  tmp="$(mktemp -d)"
  curl -fsSL -o "$tmp/p.zip" "https://github.com/orioncactus/pretendard/releases/download/v1.3.9/Pretendard-1.3.9.zip"
  unzip -q -o "$tmp/p.zip" -d "$tmp/p"
  find "$tmp/p" -path '*public/static/*' -name 'Pretendard-*.otf' -exec cp {} "$DEST/" \;
  rm -rf "$tmp"
fi
ls "$DEST" | wc -l | xargs echo "fonts in $DEST:"
