import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

spec = importlib.util.spec_from_file_location("local_renderer", Path(__file__).with_name("render_tts_first.py"))
renderer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(renderer)

class CaptionStackTests(unittest.TestCase):
    def fixture(self, root):
        source = root / "source"
        (source / "src").mkdir(parents=True)
        (source / "src/Main.tsx").write_text('<Sequence name={cut.id}>bg</Sequence>\n<Sequence name={item.id}>caption</Sequence>\n')
        (source / "package.json").write_text('{"name":"fixture"}')
        return source

    def test_only_local_caption_sequence_changes_and_reuse_is_stable(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory); source = self.fixture(root); before = renderer.inventory(source); target = root / "render"
            renderer.prepare_template(source, target)
            self.assertEqual(before, renderer.inventory(source))
            text = (target / "src/Main.tsx").read_text()
            self.assertIn("name={item.id} style={{zIndex: 100}}>", text)
            self.assertIn("name={cut.id}>bg", text)
            local = renderer.inventory(target)
            renderer.prepare_template(source, target)
            self.assertEqual(local, renderer.inventory(target))
            self.assertEqual(json.loads((target / ".caption-stack.json").read_text())["local_sha256"], local)

    def test_manual_changes_are_preserved_and_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory); source = self.fixture(root); target = root / "render"
            renderer.prepare_template(source, target)
            p = target / "src/Main.tsx"; p.write_text(p.read_text() + "manual")
            with self.assertRaises(ValueError):
                renderer.prepare_template(source, target)
            self.assertTrue(p.read_text().endswith("manual"))

    def test_unknown_caption_structure_does_not_create_target(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory); source = self.fixture(root); target = root / "render"
            (source / "src/Main.tsx").write_text("new incompatible structure")
            with self.assertRaises(ValueError):
                renderer.prepare_template(source, target)
            self.assertFalse(target.exists())
            self.assertEqual((source / "src/Main.tsx").read_text(), "new incompatible structure")

if __name__ == "__main__":
    unittest.main()
