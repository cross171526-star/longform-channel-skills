"""로컬 renderer에만 자막 stacking을 보정하고 기존 TTS 우선 도구를 실행한다."""
import argparse
import hashlib
import json
import os
import shutil
import sys
import uuid
from pathlib import Path

sys.dont_write_bytecode = True

def inventory(root):
    result = {}
    for directory, dirs, files in os.walk(root):
        dirs[:] = [n for n in dirs if n not in {"node_modules", ".git", "__pycache__"}]
        for name in files:
            p = Path(directory) / name
            if name == ".caption-stack.json":
                continue
            result[str(p.relative_to(root))] = hashlib.sha256(p.read_bytes()).hexdigest()
    return result

def caption_patch(text):
    needle = "name={item.id}>"
    changed = "name={item.id} style={{zIndex: 100}}>"
    if text.count(changed) == 1 and needle not in text:
        return text
    if text.count(needle) != 1:
        raise ValueError("기본 자막 Sequence 형식이 달라 자동 수정할 수 없습니다. 원본을 유지하고 로컬 Main.tsx를 확인하세요.")
    return text.replace(needle, changed, 1)

def prepare_template(source, target):
    source, target = Path(source).resolve(), Path(target).resolve()
    if source == target or source in target.parents:
        raise ValueError("출력 renderer는 공용 원본 폴더 밖에 있어야 합니다.")
    before = inventory(source)
    main = source / "src/Main.tsx"
    if not main.is_file():
        raise ValueError("runtime skill의 실제 Remotion Main.tsx가 없습니다.")
    patched = caption_patch(main.read_text())
    marker = target / ".caption-stack.json"
    if target.exists():
        if not marker.is_file():
            raise ValueError("기존 renderer 폴더를 덮어쓰지 않습니다. 새 작업 renderer 경로를 사용하세요.")
        previous = json.loads(marker.read_text())
        if previous.get("source_sha256") != before or previous.get("local_sha256") != inventory(target):
            raise ValueError("원본 또는 로컬 renderer가 변경됐습니다. 기존 변경을 보존하고 새 renderer 경로를 지정하세요.")
        return target
    target.parent.mkdir(parents=True, exist_ok=True)
    staging = target.with_name(target.name + ".preparing-" + uuid.uuid4().hex[:8])
    shutil.copytree(source, staging, ignore=shutil.ignore_patterns("node_modules", ".git", "__pycache__"))
    (staging / "src/Main.tsx").write_text(patched)
    data = {"source": str(source), "source_sha256": before, "local_sha256": inventory(staging),
            "patch": "기본 자막 Sequence style.zIndex=100; 다른 편집 코드 유지"}
    (staging / ".caption-stack.json").write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")
    if target.exists():
        raise ValueError("출력 폴더가 동시에 생성됐습니다. 새로 준비한 폴더를 보존하고 충돌을 확인하세요.")
    staging.rename(target)
    return target

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runtime-skill", type=Path, required=True)
    parser.add_argument("--edl", type=Path, required=True)
    parser.add_argument("--project", type=Path, required=True)
    parser.add_argument("--renderer-source", type=Path)
    parser.add_argument("--template-only", action="store_true", help="로컬 복사/해시/자막 순서만 준비한다")
    args, rest = parser.parse_known_args()
    runtime = args.runtime_skill.resolve()
    local = prepare_template(runtime / "assets/remotion-template",
                             args.renderer_source or args.edl.resolve().parent / "renderer-source")
    if args.template_only:
        print(json.dumps({"renderer_source": str(local), "shared_source_modified": False}, ensure_ascii=False))
        return
    if not args.edl.is_file() or not args.project.is_dir():
        parser.error("실제 EDL 파일과 project 폴더가 필요합니다.")
    sys.path.insert(0, str(runtime / "scripts"))
    import build_timeline
    import check_render_timing
    build_timeline.TEMPLATE = local
    check_render_timing.TEMPLATE = local
    sys.argv = ["build_timeline", "--edl", str(args.edl.resolve()),
                "--project", str(args.project.resolve()), *rest]
    build_timeline.main()

if __name__ == "__main__":
    main()
