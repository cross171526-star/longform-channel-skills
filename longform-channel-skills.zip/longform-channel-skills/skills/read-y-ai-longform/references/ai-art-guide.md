# AI 원화 제작

이미지 생성/편집은 imagegen 스킬과 도구를 사용한다. 코드로 인물을 대신 그리거나 이미지 필터로 그림체를 대체하지 않는다. Remotion/SVG는 말풍선·종이·선·TV 틀 같은 단순 도형과 편집에 사용한다.

## 원화 설계

대본의 연결 비트마다 필요한 인물·자세·손·시선·소품·장소를 먼저 표로 쓴다. 표정만 바꿔 같은 몸을 반복하기보다 동작이 달라지면 새 자세를 만든다. 인물의 얼굴·시대 의복·색·실루엣은 같은 인물로 이어져야 한다.

- 인물/소품: 2D 잉크 윤곽, 읽기 쉬운 형태, 제한된 음영, 일관된 색과 시대/의복. 전경 자산은 투명 배경으로 만든다.
- 장소: 같은 그림체, 대사와 인물이 들어갈 여백, 인물 없는 깨끗한 구도. 편집에서 배경만 흐릴 수 있게 별도 생성한다.
- 관계 장면: 두 사람의 시선/손/거리와 물건의 이동을 정한다. 군중/환자/상대가 필요한 장면은 단독 인물로 축소하지 않는다.
- 손/도구/표정: 중요 행동을 읽는 데 필요하면 클로즈업 자산을 준비한다. 전화 장면의 새 내용은 화면 텍스트만 바꾸는 것이 아니라 자세/손/반응도 바뀐다.

투명 2×2 자세 시트도 사용할 수 있다. 칸별 균일 크기·완전한 피사체·경계 밖 잘림 없음·칸 라벨/글자 없음을 요청한다. 실제 이미지 크기/alpha를 확인한 뒤 각각 Remotion 클립으로 분리한다. 원화 편집이 필요하면 이미지 생성 도구로 수정한다.

## 프롬프트의 구성

아래 빈 항목은 새 소재에 맞춰 채운다. 타이거의 빨간 폴로·현대 호텔·차량 사고를 모든 영상에 복사하지 않는다.

> Create a consistent 2D editorial illustration character for [인물/시대]. Clean dark ink outlines, readable shapes, restrained shading, [의복/색]. [행동, 손과 소품, 시선, 상대]. Camera [앞/뒤/측면, 거리]. Transparent background, full required silhouette inside frame, no words or labels. Match the supplied visual reference in line weight and treatment.

장소 프롬프트:

> 16:9 2D ink-outlined location illustration of [기록으로 확인한 장소 유형/시대], [시간대/빛]. Empty clear foreground for [인물 배치], background landmarks kept readable, no people, no text. Same visual treatment as the character assets.

생성 후 그림을 직접 보고 피사체/동작/손/소품·투명 배경·잘림을 확인한다. 장소가 실제 현장의 복원이 아니라 일반 설명용이면 내부 소스 목록에 그렇게 적는다.

## 원화 이후

생성 그림은 자산이다. 말풍선/글자/이름표를 원화에 구워 넣지 말고 편집에서 의미 시각에 등장시킨다. 앞·뒤/앉음/구조 등 원화를 교체하고 반응·소품의 등장과 전경/후경 이동을 따로 구현한다.

기본 방식은 AI 정지 원화+편집 애니메이션이다. 사용자 지시나 분석 근거 없이 생성 동영상으로 바꾸지 않는다. 검증한 실제 영상/사진의 근거 역할은 필요한 위치에 유지한다.
