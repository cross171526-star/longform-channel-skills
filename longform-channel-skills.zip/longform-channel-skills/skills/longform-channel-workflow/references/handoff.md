# 독립 제작 MD와 채널 인계

클로너는 최초 채널 도입, 채널 프로젝트는 이후 반복 제작을 담당한다. 이 문서는 확정된 분석을 이동하는 방법이며 새 승인 단계를 추가하지 않는다.

## 인계 폴더

```text
handoff/
  제작규칙.md
  handoff.json
  references/
    채널제목분석.md
    화면분석.md
    대본분석.md
    승인본기준.md
    쇼츠기준.md          # 사용자가 지정·확정했을 때
  assets/               # 재배포 가능한 필름·코드·템플릿 등 필요한 자산
```

`제작규칙.md`는 템플릿의 미완성 표시를 실제 확인값으로 바꿔 작성한다. 인물·주제·기간만 바꾸면 다음 영상을 제작할 수 있는 수준으로 서사·화면·수치를 남긴다. 분석 파일은 새 채널에 필요한 범위만 담고 채팅 전체나 비밀키·쿠키·공유 DB를 넣지 않는다. 파일 링크는 인계 폴더 안 상대경로로 쓴다. 영상·음원 원본을 배포하지 않으면 원출처·확보 방법·실제 연결 위치를 명시한다.

`handoff.json` 형식:

```json
{
  "channel_name": "새채널형",
  "rules_file": "제작규칙.md",
  "channel_url": "실제 채널 URL",
  "reference_url": "실제 분석한 영상 URL",
  "approval": {"user_message": "실제 사용자 확정 발언", "source": "실제 채팅 또는 기록 식별자"},
  "evidence_files": ["references/화면분석.md", "references/대본분석.md"],
  "duration_minutes": [10, 20],
  "shorts_reference": null
}
```

분량은 해당 채널에서 확정된 값으로 바꾼다. null인 쇼츠 레퍼런스는 미지정 상태이며 스포츠몽땅 레퍼런스를 자동으로 복사하지 않는다. 사용자 발언과 출처를 만들지 않는다. 명령의 성공은 파일 인계 완료이며 사용자 승인의 진위를 자동으로 검증했다는 뜻이 아니다.

인계 실행:

```bash
python3 scripts/manage.py channel --name 새채널형 --handoff /절대경로/handoff --dest "$HOME/lfc_projects/새채널형" --cloner-project /절대경로/롱폼클로너
```

`scripts/manage.py`는 이 스킬 폴더 기준이며 공유 저장소 최상위에서는 `python3 lfc.py channel ...`도 같다. 기존 폴더·클로너 내부 목적지·상위 클로너 지침을 상속하는 위치는 거부한다. 참조 파일과 해시를 기록하고 새 프로젝트 시작 문장을 만든다. 앱에 새 폴더를 별도 프로젝트로 추가한 뒤 그곳에서 시작한다.

## 스포츠몽땅 준비된 프로필

```bash
python3 scripts/manage.py channel --name 스포츠몽땅형 --profile sportsmongttang --dest "$HOME/lfc_projects/스포츠몽땅형"
```

동봉된 스포츠몽땅 제작규칙·라우다 승인본 기준·쇼츠 스킬을 프로젝트 안에 복사한다. 과거 영상 파일과 API 키는 포함되지 않는다. 이름만 다른 채널에 이 프로필을 자동 적용하지 않는다. 이는 스포츠몽땅의 명시적으로 선택한 재현 프로필이다.
