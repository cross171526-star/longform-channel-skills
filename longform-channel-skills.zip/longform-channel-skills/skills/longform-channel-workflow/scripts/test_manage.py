import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

SCRIPT = Path(__file__).with_name('manage.py')


class WorkflowTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def run_cli(self, *args, ok=True):
        result = subprocess.run([sys.executable, str(SCRIPT), *map(str, args)], capture_output=True, text=True)
        self.assertEqual(result.returncode == 0, ok, result.stdout + result.stderr)
        return result

    def test_install_idempotent_and_conflict_preflight(self):
        dest = self.root / 'skills'
        self.run_cli('install', '--dest', dest)
        self.run_cli('install', '--dest', dest)
        changed = dest / 'longform-channel-cloner/SKILL.md'
        changed.write_text('user edit')
        import shutil
        shutil.rmtree(dest / 'sportsmongttang-shorts')
        self.run_cli('install', '--dest', dest, ok=False)
        self.assertEqual(changed.read_text(), 'user edit')
        self.assertFalse((dest / 'sportsmongttang-shorts').exists())

    def test_cloner_isolation_existing_preserved(self):
        dest = self.root / 'cloner'
        self.run_cli('cloner', '--dest', dest)
        self.run_cli('cloner', '--dest', dest, ok=False)
        self.run_cli('channel', '--name', 'sports', '--profile', 'sportsmongttang', '--dest', dest / 'child', ok=False)
        self.assertFalse((dest / 'child').exists())
        self.assertEqual(json.loads((dest / 'workflow.json').read_text())['kind'], 'cloner')

    def test_sports_video_and_collision(self):
        dest = self.root / 'sports'
        self.run_cli('channel', '--name', '스포츠몽땅형', '--profile', 'sportsmongttang', '--dest', dest)
        self.assertTrue((dest / 'references/approved-lauda-v2.md').is_file())
        self.assertTrue((dest / 'toolkit/remotion-template/package.json').is_file())
        self.assertTrue((dest / 'toolkit/speech_rate.py').is_file())
        self.assertTrue((dest / '.agents/skills/longform-companion-shorts/scripts/render_v7.py').is_file())
        self.assertTrue((dest / '.agents/skills/video-output-cleanup/scripts/check_delivery.py').is_file())
        self.assertFalse((dest / 'skills/longform-channel-cloner').exists())
        self.run_cli('video', '--project', dest, '--keyword', '라우다', '--title', '돌아온 챔피언')
        dirs = list((dest / '결과물').glob('*'))
        self.assertEqual(len(dirs), 1)
        self.assertEqual(len([p for p in dirs[0].iterdir() if p.is_dir()]), 4)
        self.assertFalse((dirs[0] / '제작정보.json').exists())
        self.assertEqual(len(list((dest / 'work').glob('*/제작정보.json'))), 1)
        self.run_cli('video', '--project', dest, '--keyword', '라우다', '--title', '다른 제목', ok=False)
        self.assertEqual(len(list((dest / 'work').iterdir())), 1)
        self.run_cli('video', '--project', dest, '--keyword', '../oops', '--title', 'bad', ok=False)
        output = self.run_cli('doctor', '--project', dest)
        self.assertTrue(json.loads(output.stdout)['rules_file_exists'])

    def handoff(self):
        handoff = self.root / 'handoff'
        handoff.mkdir()
        (handoff / '제작규칙.md').write_text('# 새채널\n실제 분석과 승인값은 사용자가 준비한다. 테스트용 문서.')
        (handoff / '분석.md').write_text('테스트용 분석 기록')
        (handoff / 'handoff.json').write_text(json.dumps({'channel_name': '새채널', 'rules_file': '제작규칙.md',
            'channel_url': 'https://example.com/channel', 'reference_url': 'https://example.com/video',
            'approval': {'user_message': '테스트용 승인', 'source': 'test fixture'}, 'evidence_files': ['분석.md']}))
        return handoff

    def test_custom_has_no_sports_rules(self):
        handoff = self.handoff()
        dest = self.root / 'custom'
        self.run_cli('channel', '--name', '새채널', '--handoff', handoff, '--dest', dest)
        self.assertTrue((dest / 'skills/channel-production/SKILL.md').is_file())
        self.assertFalse((dest / 'skills/sportsmongttang-longform').exists())
        self.assertEqual((dest / '제작규칙.md').read_bytes(), (handoff / '제작규칙.md').read_bytes())

    def test_unfilled_missing_traversal_and_symlink_rejected(self):
        handoff = self.handoff()
        rule = handoff / '제작규칙.md'
        dest = self.root / 'custom'
        rule.write_text('{{CHANNEL_NAME}}')
        self.run_cli('channel', '--name', 'new', '--handoff', handoff, '--dest', dest, ok=False)
        self.assertFalse(dest.exists())
        rule.write_text('완성 규칙')
        (handoff / '분석.md').unlink()
        self.run_cli('channel', '--name', 'new', '--handoff', handoff, '--dest', dest, ok=False)
        metadata = json.loads((handoff / 'handoff.json').read_text())
        metadata['evidence_files'] = ['../outside.md']
        (self.root / 'outside.md').write_text('outside')
        (handoff / 'handoff.json').write_text(json.dumps(metadata))
        self.run_cli('channel', '--name', 'new', '--handoff', handoff, '--dest', dest, ok=False)
        (handoff / 'link').symlink_to(self.root / 'outside.md')
        self.run_cli('channel', '--name', 'new', '--handoff', handoff, '--dest', dest, ok=False)
        self.assertFalse(dest.exists())


if __name__ == '__main__':
    unittest.main()
