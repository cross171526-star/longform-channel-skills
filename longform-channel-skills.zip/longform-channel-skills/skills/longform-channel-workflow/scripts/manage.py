#!/usr/bin/env python3
"""롱폼 프로젝트 설치·분리·제작 폴더 도구. 표준 라이브러리만 사용."""
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import uuid
from zoneinfo import ZoneInfo

SKILLS = Path(__file__).resolve().parents[2]
FLOW = SKILLS / 'longform-channel-workflow'
CLONER = SKILLS / 'longform-channel-cloner'
BASE = ['longform-channel-cloner', 'longform-channel-analysis', 'longform-channel-planning',
        'longform-channel-production', 'longform-channel-review']
ALL = sorted(p.name for p in SKILLS.iterdir() if (p / 'SKILL.md').is_file())
IGNORES = shutil.ignore_patterns('__pycache__', '*.pyc', '.DS_Store', 'node_modules')


def write(path, content):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding='utf-8')


def dump(path, data):
    write(path, json.dumps(data, ensure_ascii=False, indent=2) + '\n')


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def name(value):
    if not value.strip() or value in {'.', '..'} or any(c in value for c in '/\\\0\n\r'):
        raise ValueError('이름에는 경로 구분자·줄바꿈을 쓸 수 없습니다.')
    return value


def copy(src, dst):
    shutil.copytree(src, dst, ignore=IGNORES)


def hashes(root):
    return {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in root.rglob('*') if p.is_file() and not any(
                x in {'__pycache__', 'node_modules', '.DS_Store'} for x in p.parts) and p.suffix != '.pyc'}


def state(root, scope):
    if (root / 'AGENTS.md').exists():
        policy = (FLOW / 'references/current-policy.md').read_text(encoding='utf-8')
        with (root / 'AGENTS.md').open('a', encoding='utf-8') as handle:
            handle.write('\n' + policy)
        for item in ['longform-companion-shorts', 'video-output-cleanup', 'longform-project-handoff']:
            if (SKILLS / item).is_dir():
                copy(SKILLS / item, root / '.agents/skills' / item)
    write(root / '작업상태.md', f'''# 작업상태

- 목적: {scope}
- 생성: {dt.datetime.now(ZoneInfo('Asia/Seoul')).isoformat()}
- 요청 모델: gpt-6.1-sol / high
- 실제 모델·추론 설정·세션: 실행 채팅에서 확인해 기록할 것. 이 명령은 앱 설정을 변경하지 않음.
- 완료: 폴더와 실행 지침 생성
- 미완료: 실제 분석·제작·검증·사용자 승인
- 사용자 지시와 출처: 실행 채팅에서 기록
- 다음 단계: 시작하기.txt 및 AGENTS.md 읽기
- 적용 파일 해시: 적용파일해시.json
''')
    dump(root / '적용파일해시.json', hashes(root))


ASSETS = '''# 실행 환경과 자산

Python 3.12 이상, Node 22 이상, ffmpeg/ffprobe와 Python 의존성이 필요하다.
패키지 루트의 README 설치 절차를 따른다. ~/.longform-cloner/venv/bin/python으로 음성 스크립트를 실행한다.
API 키는 환경변수나 ~/.longform-cloner/secrets.env에만 저장한다. 값은 작업 기록에 쓰지 않는다.
TTS 스크립트의 --help와 채널 제작규칙을 읽고 공급자·목소리·배속을 명시한다.
fixed-bgm.json의 local_path는 각 컴퓨터에서 확보한 음원 경로로 연결해야 한다.
음원·원본 영상·쿠키·API 키·폰트 바이너리는 이 패키지에 포함하지 않는다.
폰트는 fetch_fonts.sh와 채널별 규칙을 확인해 확보하고 실제 사용 파일을 기록한다.
Remotion 템플릿에서 npm ci 후 현재 프로젝트의 편집값과 자산을 연결한다.
템플릿은 구현 시작점이다. 폴더 생성만으로 영상 제작이나 기존 승인본 픽셀 재현이 완료되지는 않는다.
'''


def fresh(dest, builder):
    dest = dest.expanduser().resolve()
    if dest.exists():
        raise ValueError(f'기존 폴더를 보존합니다: {dest}')
    dest.parent.mkdir(parents=True, exist_ok=True)
    temp = Path(tempfile.mkdtemp(prefix='.lfc-new-', dir=dest.parent))
    try:
        builder(temp)
        if dest.exists():
            raise ValueError('생성 도중 목적지 폴더가 생겼습니다. 덮어쓰지 않습니다.')
        temp.rename(dest)
    finally:
        if temp.exists():
            shutil.rmtree(temp)
    print(dest)


def install(args):
    dest = args.dest.expanduser().resolve()
    for item in ALL:
        if not (SKILLS / item / 'SKILL.md').is_file():
            raise ValueError(f'패키지 누락: {item}')
        target = dest / item
        if target.exists() and hashes(target) != hashes(SKILLS / item):
            raise ValueError(f'기존 스킬과 충돌합니다. 기존 폴더를 별도 백업·비교 후 처리하세요: {target}')
    dest.mkdir(parents=True, exist_ok=True)
    for item in ALL:
        if not (dest / item).exists():
            copy(SKILLS / item, dest / item)
    print(f'설치 확인: {dest} ({len(ALL)}개, 기존 동일 파일 보존)')


def cloner(args):
    def build(root):
        for item in ALL:
            copy(SKILLS / item, root / 'skills' / item)
        dump(root / 'workflow.json', {'kind': 'cloner', 'name': '롱폼클로너'})
        write(root / 'AGENTS.md', '''# 롱폼클로너

skills/longform-channel-workflow/SKILL.md와 skills/longform-channel-cloner/SKILL.md를 읽고 실행한다.
요청 모델은 gpt-6.1-sol / high이며 실제 설정·세션을 기록한다.
채널 링크 → 제목 분석 → 5분 이내 테스트 주제 승인 → 최신 적격 원본 1편 정밀 분석 → 대본·TTS·묵음 제거 → 자료·편집 → 170~210초 테스트 전달 → 피드백 순서다.
요청 시작부터 승인 대기 포함 3600초 기준이며 초과해도 시간을 숨기거나 자동 중단하지 않는다.
사용자가 확정한 전용 스킬과 자료를 준비한다. 사용자가 새 제작 프로젝트에 넣고 그곳에서 “인계해라”라고 하면 현재 프로젝트에 연결한다. 인계 요청으로 새 프로젝트를 만들지 않는다.
작업은 work/의 고유 폴더에서 수행하고 작업상태.md에 지시 출처·해시·완료·미완료·검증·다음 단계를 기록한다.
''')
        write(root / '시작하기.txt', '이 폴더를 Codex 프로젝트로 추가하고 이름을 롱폼클로너로 지정하세요.\n새 채팅: "$longform-channel-workflow 이 채널을 분석하고 3분 테스트부터 만들어줘: [채널 URL]"\n테스트 확정 뒤: "확정한 제작 방식을 전용 스킬과 참조 자료로 정리해줘. 새 제작 프로젝트에 넣은 뒤 그곳에서 인계해라라고 요청한다."\n')
        write(root / '자산설정.md', ASSETS)
        state(root, '채널 최초 분석·테스트·제작 MD 인계')
    fresh(args.dest, build)


def safe_file(root, relative):
    p = (root / relative).resolve()
    if not p.is_relative_to(root.resolve()) or not p.is_file():
        raise ValueError(f'인계 파일이 없거나 폴더 밖을 가리킵니다: {relative}')
    return p


def channel(args):
    name(args.name)
    dest = args.dest.expanduser().resolve()
    if args.cloner_project and dest.is_relative_to(args.cloner_project.expanduser().resolve()):
        raise ValueError('채널 제작 프로젝트는 클로너 프로젝트 밖에 만드세요.')
    for parent in [dest] + list(dest.parents):
        config = parent / 'workflow.json'
        if config.is_file() and read(config).get('kind') == 'cloner':
            raise ValueError('클로너 프로젝트 하위에는 독립 제작 프로젝트를 만들 수 없습니다.')
        agents = parent / 'AGENTS.md'
        if agents.is_file() and 'longform-channel-cloner' in agents.read_text(encoding='utf-8'):
            raise ValueError(f'상위 클로너 지침이 상속되는 위치입니다: {parent}')
    handoff = args.handoff.expanduser().resolve() if args.handoff else None
    manifest = None
    if handoff:
        if any(p.is_symlink() for p in handoff.rglob('*')):
            raise ValueError('인계 폴더는 심볼릭 링크 없이 준비하세요.')
        manifest = read(handoff / 'handoff.json')
        for key in ['channel_name', 'rules_file', 'channel_url', 'reference_url', 'approval', 'evidence_files']:
            if not manifest.get(key):
                raise ValueError(f'인계 메타데이터 누락: {key}')
        for key in ['user_message', 'source']:
            if not manifest['approval'].get(key):
                raise ValueError(f'실제 사용자 승인 근거 누락: approval.{key}')
        rules = safe_file(handoff, manifest['rules_file']).read_text(encoding='utf-8')
        if '{{' in rules or not rules.strip():
            raise ValueError('제작규칙의 미작성 자리표시자를 실제 분석·확정값으로 채우세요.')
        for file in manifest['evidence_files']:
            safe_file(handoff, file)
        reserved = {'AGENTS.md', 'workflow.json', 'skills', 'toolkit', '작업상태.md', '시작하기.txt'}
        if any((handoff / item).exists() for item in reserved):
            raise ValueError('인계 폴더에 프로젝트 예약 파일·폴더가 있습니다.')
    def build(root):
        if handoff:
            shutil.copytree(handoff, root, dirs_exist_ok=True)
            rules_file = manifest['rules_file']
            production = 'skills/channel-production/SKILL.md'
            write(root / production, f'''---
name: channel-production
description: {json.dumps(args.name + ' 전용 주제·대본·본편·피드백·쇼츠를 제작한다.', ensure_ascii=False)}
---

# {args.name} 제작

프로젝트 루트의 `{rules_file}`와 `handoff.json` 및 연결된 분석·승인 근거를 읽는다.
로컬 `skills/longform-channel-workflow/references/production-cycle.md`의 반복 제작을 따른다.
클로너 및 하위 단계의 최초 테스트 절차는 적용하지 않는다. 실제 채널 제작규칙이 스타일을 정한다.
''')
        else:
            rules_file = '제작규칙.md'
            production = 'skills/sportsmongttang-longform/SKILL.md'
            for item in ['sportsmongttang-longform', 'sportsmongttang-shorts']:
                copy(SKILLS / item, root / 'skills' / item)
            refs = SKILLS / 'sportsmongttang-longform' / 'references'
            shutil.copy2(refs / '스포츠몽땅형_영상제작규칙.md', root / rules_file)
            copy(refs, root / 'references')
        copy(FLOW, root / 'skills' / FLOW.name)
        toolkit = root / 'toolkit'
        toolkit.mkdir()
        for source in (CLONER / 'scripts').iterdir():
            if source.is_file() and source.suffix in {'.py', '.sh', '.txt'}:
                shutil.copy2(source, toolkit / source.name)
        copy(CLONER / 'assets' / 'remotion-template', toolkit / 'remotion-template')
        dump(root / 'workflow.json', {'kind': 'channel', 'name': args.name, 'rules_file': rules_file,
             'production_skill': production, 'profile': args.profile or 'custom', 'handoff': manifest})
        write(root / 'AGENTS.md', f'''# {args.name} 제작

최초에 `{rules_file}`와 `{production}`를 읽는다. 운영은 `skills/longform-channel-workflow/SKILL.md`의 독립 채널 분기를 따른다.
이 프로젝트에는 longform-channel-cloner 및 분석·기획·제작·검수 하위 단계 스킬의 최초 테스트 절차를 적용하지 않는다.
주제 3개·선택 → 썸네일과 제목 각 3개 → 설명글·사실 조사·대본 → TTS·묵음 제거 → 자료·편집·렌더 → 기본 확인·전달 → 피드백 → 같은 주제 쇼츠 3편 순서다.
요청한 작업 범위와 이미 받은 승인을 유지한다. 채널 스타일은 제작규칙과 사용자 직접 지시가 우선한다.
모델은 gpt-6.1-sol / high 지정이며 실제 설정·세션을 기록한다. 앱 설정은 자동 변경되지 않는다.
작업은 work/의 고유 폴더에서 수행한다. 공통 설치 스킬이나 다른 채널을 수정하지 않는다.
확정 기준 변경 전후에는 versions/에 문서·해시·이유·검증·복원 방법을 보관한다.
''')
        write(root / '시작하기.txt', f'이 폴더를 Codex의 별도 프로젝트로 추가하세요.\n새 채팅: "제작규칙.md와 AGENTS.md 읽고 주제줘."\n주제 선택 후: "[선택 주제]로 썸네일·제목 3개와 전체 본편 제작을 진행해줘."\n본편 후: "같은 핵심 주제로 쇼츠 3개 만들어줘."\n쇼츠 레퍼런스 미설정 채널은 별도 쇼츠 기준을 먼저 연결하세요.\n')
        write(root / '자산설정.md', ASSETS)
        state(root, f'{args.name} 독립 반복 제작')
    fresh(dest, build)


def video(args):
    project = args.project.expanduser().resolve()
    if read(project / 'workflow.json').get('kind') != 'channel':
        raise ValueError('독립 채널 프로젝트에서 실행하세요.')
    name(args.keyword)
    name(args.title)
    day = dt.datetime.now(ZoneInfo('Asia/Seoul')).strftime('%Y%m%d')
    key = f'{day}_{args.keyword}'
    dest = project / '결과물' / key
    def build(root):
        for folder in ['01_썸네일', '02_설명글', '03_영상완성본', '04_쇼츠']:
            (root / folder).mkdir()
    fresh(dest, build)
    work = project / 'work' / f'{key}-{uuid.uuid4().hex[:8]}'
    work.mkdir(parents=True)
    dump(work / '제작정보.json', {'title': args.title, 'date': day, 'keyword': args.keyword,
                                'thread_title': f'{day[4:6]}/{day[6:8]}_{args.title}'})
    state(work, args.title)
    print(f'작업 폴더: {work}\n영상은 아직 생성되지 않았습니다.')


def doctor(args):
    runtime = Path(os.environ.get('LFC_HOME', str(Path.home() / '.longform-cloner')))
    checks = {'python_3_12': sys.version_info >= (3, 12), 'python_executable': sys.executable}
    for tool in ['ffmpeg', 'ffprobe', 'node']:
        binary = shutil.which(tool) or (str(runtime / 'bin' / tool) if (runtime / 'bin' / tool).is_file() else None)
        checks[tool] = binary
        if tool == 'node' and binary:
            out = subprocess.run([binary, '--version'], capture_output=True, text=True, timeout=10)
            checks['node_22'] = out.returncode == 0 and int(out.stdout.strip().lstrip('v').split('.')[0]) >= 22
    checks['venv'] = (runtime / 'venv' / 'bin' / 'python').is_file()
    checks['secrets_file_exists_not_validated'] = (runtime / 'secrets.env').is_file()
    checks['api_env_present'] = {key: bool(os.environ.get(key)) for key in ['TYPECAST_API_KEY', 'ELEVENLABS_API_KEY', 'OPENAI_API_KEY']}
    if args.project:
        project = args.project.expanduser().resolve()
        config = read(project / 'workflow.json')
        checks['project_kind'] = config['kind']
        checks['rules_file_exists'] = (project / config.get('rules_file', 'AGENTS.md')).is_file()
    checks['note'] = '파일·실행기 존재 점검입니다. API 인증·다운로드·음원·폰트·영상 렌더의 성공은 검증하지 않습니다.'
    print(json.dumps(checks, ensure_ascii=False, indent=2))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    p = commands.add_parser('install', help='동봉 스킬 설치; 충돌 시 중단')
    p.add_argument('--dest', type=Path, default=Path(os.environ.get('CODEX_HOME', str(Path.home() / '.codex'))) / 'skills')
    p.set_defaults(func=install)
    p = commands.add_parser('cloner', help='롱폼클로너 프로젝트 생성')
    p.add_argument('--dest', type=Path, required=True)
    p.set_defaults(func=cloner)
    p = commands.add_parser('channel', help='클로너 밖의 독립 제작 프로젝트 생성')
    p.add_argument('--name', required=True)
    p.add_argument('--dest', type=Path, required=True)
    group = p.add_mutually_exclusive_group(required=True)
    group.add_argument('--profile', choices=['sportsmongttang'])
    group.add_argument('--handoff', type=Path)
    p.add_argument('--cloner-project', type=Path)
    p.set_defaults(func=channel)
    p = commands.add_parser('video', help='새 본편의 작업·결과물 폴더 생성')
    p.add_argument('--project', type=Path, required=True)
    p.add_argument('--keyword', required=True)
    p.add_argument('--title', required=True)
    p.set_defaults(func=video)
    p = commands.add_parser('doctor', help='읽기 전용 환경 확인')
    p.add_argument('--project', type=Path)
    p.set_defaults(func=doctor)
    args = parser.parse_args()
    try:
        args.func(args)
    except (ValueError, OSError, KeyError, TypeError) as exc:
        parser.exit(2, f'오류: {exc}\n')


if __name__ == '__main__':
    main()
