#!/usr/bin/env bash
# 스킬 5종을 설치하며 기존 동명 경로는 덮어쓰지 않습니다.
set -euo pipefail
SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEST_DIR="${CODEX_HOME:-$HOME/.codex}/skills"
SKILLS=(longform-channel-cloner longform-channel-analysis longform-channel-planning longform-channel-production longform-channel-review)
for name in "${SKILLS[@]}"; do
  [ -f "$SOURCE_DIR/$name/SKILL.md" ] || { echo "필수 파일 누락: $name/SKILL.md" >&2; exit 1; }
  if [ -e "$DEST_DIR/$name" ] || [ -L "$DEST_DIR/$name" ]; then
    echo "기존 스킬이 있습니다. 백업·비교 후 설치하세요: $DEST_DIR/$name" >&2
    exit 1
  fi
done
mkdir -p "$DEST_DIR"
for name in "${SKILLS[@]}"; do
  cp -R "$SOURCE_DIR/$name" "$DEST_DIR/$name"
done
echo "스킬 5종 설치 완료: $DEST_DIR"
echo "README.md의 실행 환경 설정을 이어서 진행하세요."
