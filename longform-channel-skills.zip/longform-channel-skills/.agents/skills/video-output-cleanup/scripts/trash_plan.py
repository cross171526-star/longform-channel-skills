"""Execute explicit, reviewed cleanup plans; default is read-only dry run."""
from pathlib import Path
import argparse,hashlib,json,os,shutil,subprocess,sys,uuid,datetime

def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for block in iter(lambda:f.read(4*1024*1024),b''):h.update(block)
 return h.hexdigest()
def inspect(plan):
 roots=[Path(x).resolve() for x in plan['roots']];keep={str(Path(x['path']).resolve()):x for x in plan['keep']};seen=set()
 for key,x in keep.items():
  p=Path(key);assert p.is_file() and sha(p)==x['sha256'],f'Keep changed/missing: {p}'
 for x in plan['remove']:
  raw=Path(x['path']);p=raw.resolve();key=str(p)
  assert raw.is_absolute() and raw==p and not raw.is_symlink(),f'Noncanonical or symlink: {raw}'
  assert p.is_file() and any(p.is_relative_to(r) for r in roots),f'Outside scope/missing: {p}'
  assert key not in keep and key not in seen,f'Keep/delete conflict or duplicate: {p}'
  if x.get('replacement'):
   assert str(Path(x['replacement']).resolve()) in keep,f'Missing protected replacement: {p}'
  else:
   assert x.get('disposable') is True,f'No replacement or explicit disposable review: {p}'
  assert x.get('dependency_review')=='clear' and x.get('reason'),f'Unreviewed: {p}'
  st=p.stat();assert st.st_size==x['size'] and st.st_mtime_ns==x['mtime_ns'] and sha(p)==x['sha256'],f'Changed: {p}'
  seen.add(key)
 return keep

def execute(plan,journal,apply=False,trash=None,check_open=True):
 keep=inspect(plan)
 if not apply:return {'dry_run':True,'files':len(plan['remove']),'bytes':sum(x['size'] for x in plan['remove'])}
 journal=Path(journal).resolve();assert str(journal) not in {x['path'] for x in plan['remove']};assert not journal.exists(),'Journal already exists'
 if check_open:
  r=subprocess.run(['/usr/sbin/lsof','-Fn'],capture_output=True,text=True);assert r.returncode in [0,1],r.stderr
  opened={line[1:] for line in r.stdout.splitlines() if line.startswith('n')};assert not opened.intersection(x['path'] for x in plan['remove']),'Some candidates are open'
 destination=(Path(trash) if trash else Path.home()/'.Trash')/('video-cleanup-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S')+'-'+uuid.uuid4().hex[:8]);destination.mkdir(parents=True)
 state={'destination':str(destination),'items':[],'complete':False};journal.parent.mkdir(parents=True,exist_ok=True)
 def save():
  tmp=journal.with_suffix('.tmp');tmp.write_text(json.dumps(state,ensure_ascii=False,indent=2));os.replace(tmp,journal)
 save()
 for i,x in enumerate(plan['remove']):
  p=Path(x['path']);st=p.stat();assert st.st_size==x['size'] and st.st_mtime_ns==x['mtime_ns'],f'Changed before move: {p}'
  d=destination/f'{i:04}-{p.name}';record={**x,'trash_path':str(d),'status':'pending'};state['items'].append(record);save()
  shutil.move(str(p),str(d));record['status']='moved';save()
 for k,x in keep.items():assert Path(k).is_file() and sha(k)==x['sha256'],f'Keep changed: {k}'
 state['complete']=True;state['bytes']=sum(x['size'] for x in plan['remove']);save();return {'complete':True,'files':len(state['items']),'bytes':state['bytes'],'journal':str(journal),'trash':str(destination)}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('plan');p.add_argument('--journal',required=True);p.add_argument('--apply',action='store_true');a=p.parse_args();print(json.dumps(execute(json.loads(Path(a.plan).read_text()),a.journal,a.apply),ensure_ascii=False,indent=2))
