"""Read-only check for one completed work's delivery directory."""
from pathlib import Path
import argparse,json,re

def check(root):
 root=Path(root);errors=[];counts={}
 allowed={'01_썸네일':{'.png','.jpg','.jpeg','.webp'},'02_설명글':{'.txt'},'03_영상완성본':{'.mp4'},'04_쇼츠':{'.mp4'}}
 if not root.is_dir():return {'ok':False,'errors':['Missing work directory'],'counts':{}}
 for folder in root.iterdir():
  if not folder.is_dir() or folder.name not in allowed:
   errors.append(f'납품 분류 밖 파일/폴더: {folder.name}');continue
  files=list(folder.iterdir());counts[folder.name]=len(files)
  for p in files:
   if not p.is_file() or p.suffix.lower() not in allowed[folder.name]:errors.append(f'잘못 배치한 자료: {p.relative_to(root)}')
   if folder.name=='04_쇼츠' and p.is_file() and (re.search(r'(?:[_ -](?:GRB(?:형)?(?:_?v\d+)*|쇼츠-v\d+|v\d+)(?:[_ -]v\d+)*)$',p.stem,re.I) or re.match(r'^(?:쇼츠)?\d{2}_',p.stem)):
    errors.append(f'쇼츠 파일명은 제목만 사용: {p.name}')
  if folder.name=='03_영상완성본' and len(files)!=1:errors.append('본편은 최신 유효본 1개만 유지')
  if not files:errors.append(f'불필요한 빈 폴더: {folder.name}')
 return {'ok':not errors,'errors':errors,'counts':counts}
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('work_directory');a=p.parse_args();r=check(a.work_directory);print(json.dumps(r,ensure_ascii=False,indent=2));raise SystemExit(0 if r['ok'] else 1)
